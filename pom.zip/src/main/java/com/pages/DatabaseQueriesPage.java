package com.pages;

import com.base.ActionClass;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.openqa.selenium.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.*;
import java.util.*;

public class DatabaseQueriesPage {


    WebDriver driver;
    ActionClass actions;
    //ApplicationPortalPage app = new ApplicationPortalPage(driver);
    List<String> Herds = new LinkedList<String>();
    HashMap<String, String> agentmap = new HashMap<>();

    public DatabaseQueriesPage(WebDriver driver) {
        this.driver = driver;
        actions = new ActionClass(driver);
    }

    // Clicking on the Pagination Button
//    public void DevCDpsDataScript() {
//        String value = "jdbc:oracle:thin:@//dbconn.agriculture.gov.ie:1532/DEVC.agriculture.gov.ie";
//        String username = "DPS_DATA";
//        String password = "DPS_DATA";
//
//        try {
//            Connection connection = DriverManager.getConnection(value, username, password);
//            System.out.println("valuestring");
//
//            String HerdNumber = app.GetCurrentHerdNumber();
//
//            String sql = ("set serveroutput on\n" +
//                    "\n" +
//                    "conn DPS_DATA/DPS_DATA@DEVC\n" +
//                    "\n" +
//                    "select pkco_audit.Set_Audit('DPS','DPS') from dual;\n" +
//                    "\n" +
//                    " \n" +
//                    "\n" +
//                    "declare\n" +
//                    "\n" +
//                    "v_app_id number;\n" +
//                    "\n" +
//                    "begin\n" +
//                    "\n" +
//                    "dbms_output.put_line('Holding Id='||get_hold('"+HerdNumber+"'));\n" +
//                    "\n" +
//                    "select app_id into v_app_id from tddp_application where app_applicant_holding_id = get_hold('"+HerdNumber+"') and app_syr_code = 2022;\n" +
//                    "\n" +
//                    "pkdp_application.DeleteApplication(v_app_id);\n" +
//                    "\n" +
//                    "commit;\n" +
//                    "\n" +
//                    "end;");
////            String sql0 = ("set serveroutput on");
////            String sql1 = ("select pkco_audit.Set_Audit('DPS','DPS') from dual;");
////            String sql2 = ("select pkco_audit.Set_Audit('DPS','DPS') from dual;");
////            String sql3 = ("declare");
////            String sql4 = ("v_app_id number;");
////            String sql5 = ("begin");
////            String sql6 = ("dbms_output.put_line('Holding Id='||get_hold('"+HerdNumber+"'));");
////            String sql7 = ("select app_id into v_app_id from tddp_application where app_applicant_holding_id = get_hold('"+HerdNumber+"') and app_syr_code = 2022;");
////            String sql8 = ("pkdp_application.DeleteApplication(v_app_id);");
////            String sql9 = ("commit;");
////            String sql = ("end;");
//
//            // String sql = ("Select pln_app_id, gfi_herd_no, pln_plan_id, pln_ver_num, pln_plan_year From tdga_farm_info_generic, tdga_plan, tsga_plan_type where gfi_id =pln_gfi_id And gfi_sch_code = 4 And pln_plan_type = plt_plan_type_code");
//            Statement statement = connection.createStatement();
//            ResultSet rs = statement.executeQuery(sql);
//            while (rs.next()) {
//                String pln_app_id = rs.getString(1);
//                System.out.println("Query is working");
//            }
//
//        } catch (SQLException throwables) {
//            throwables.printStackTrace();
//        }
//    }

    static public String getQueryForHerd(int NumberOfRowsToFetch) {
        HashMap<String, String> herdmap = new HashMap<>();
        String herdsWithNoSubmission = "select DISTINCT A1.BAP_HERD BAP_HERD from ENTS_DATA.TDEN_BISS_APP A1\n" +
        "where  A1.BAP_HERD <> ALL (SELECT A2.IAP_FROM_HERD IAP_FROM_HERD\n" +
                "from ENTS_DATA.TDEN_INET_APPLICATION A2\n" +
                "WHERE A2.IAP_GROUP_CODE = 4)\n" +
                "fetch first "+NumberOfRowsToFetch+" rows only";
        herdmap.put("herdsWithNoSubmission",herdsWithNoSubmission);
        return herdmap.get("herdsWithNoSubmission");
    }

    public String getQueryForAgent(String i) {
        System.out.println(i);
            String agentOfHerdsWithNoSubmission = "select hbcus.bcus_bus_id HerdNo, hbcus.bcus_id HerdBcusId, hbcus.bcus_cust_id HerdCustId,\n" +
                    "(select ui.uri_username FROM tdcr_user_info ui\n" +
                    "where uri_ccs_bus_id =  abcus.bcus_bus_id AND ROWNUM = 1) LoginId,abcus.bcus_id AgentBcusId,abcus.bcus_cust_id AgentCustId,abcus.bcus_bus_id AgentId\n" +
                    "from tdco_customer_asscs ca,tdco_business_customers abcus,tdco_business_customers hbcus\n" +
                    "where SYSDATE BETWEEN ca.ca_start_date AND ca.ca_end_date\n" +
                    "and ca.ca_cac_code = 194 -- BPS Agent to Customer\n" +
                    "and ca.ca_bcus_id_from = abcus.bcus_id\n" +
                    "and ca.ca_bcus_id_to = hbcus.bcus_id\n" +
                    "and hbcus.BCUS_ROLE_CODE = 100\n" +
                    "and hbcus.bcus_bus_end_date > sysdate\n" +
                    "and hbcus.bcus_bus_id in (" + "'" + i + "'" + ")";

            agentmap.put("agentOfHerdsWithNoSubmission", agentOfHerdsWithNoSubmission);

//            String herdsWithNoSubmission = "select hbcus.bcus_bus_id HerdNo, hbcus.bcus_id HerdBcusId, hbcus.bcus_cust_id HerdCustId,\n" +
//                    "(select ui.uri_username FROM tdcr_user_info ui\n" +
//                    "where uri_ccs_bus_id =  abcus.bcus_bus_id AND ROWNUM = 1) LoginId,abcus.bcus_id AgentBcusId,abcus.bcus_cust_id AgentCustId,abcus.bcus_bus_id AgentId\n" +
//                    "from tdco_customer_asscs ca,tdco_business_customers abcus,tdco_business_customers hbcus\n" +
//                    "where SYSDATE BETWEEN ca.ca_start_date AND ca.ca_end_date\n" +
//                    "and ca.ca_cac_code = 194 -- BPS Agent to Customer\n" +
//                    "and ca.ca_bcus_id_from = abcus.bcus_id\n" +
//                    "and ca.ca_bcus_id_to = hbcus.bcus_id\n" +
//                    "and hbcus.BCUS_ROLE_CODE = 100\n" +
//                    "and hbcus.bcus_bus_end_date > sysdate\n" +
//                    "and hbcus.bcus_bus_id in (" + "'" + Herds.get(NumberOfRowsToFetch) + "'" + ")";
//            herdmap.put("herdsWithNoSubmission", herdsWithNoSubmission);
        return agentmap.get("agentOfHerdsWithNoSubmission");
    }


    // Initializing Objects needed to work on the sheet
    static HSSFWorkbook hwb = new HSSFWorkbook();
    static HSSFSheet sheet = hwb.createSheet("new sheet");
    static HSSFRow rowhead = sheet.createRow((short) 0);
    static HSSFRow row = sheet.createRow((short) 1);

    // Write Herds to Excel File
    public void WritHerdToFile(List<String> HerdNumber, String FilePath, String HeaderValue) throws IOException, InterruptedException {
        File herdfile = new File(FilePath);
        if(herdfile.exists()) {
            herdfile.delete();
            rowhead.createCell((short) 0).setCellValue(HeaderValue);
            int rowCount = 1;
            for (String s : HerdNumber) {
                Row row = sheet.createRow(rowCount++);
                Cell cell = row.createCell(0);
                cell.setCellValue(s);
            }
            FileOutputStream fileOut = new FileOutputStream(herdfile);
            hwb.write(fileOut);
            fileOut.close();
            System.out.println("Your existing excel file has been deleted and new file generated!");
        }
        else {
            rowhead.createCell((short) 0).setCellValue(HeaderValue);
            int rowCount = 1;
            for (String s : HerdNumber) {
                //sheet.getLastRowNum();
                Row row = sheet.createRow(rowCount++);
                Cell cell = row.createCell(0);
                cell.setCellValue(s);
            }
            FileOutputStream fileOut = new FileOutputStream(herdfile);
            hwb.write(fileOut);
            fileOut.close();
            System.out.println("Your excel file has been generated!");
        }
    }

    public void commonCentestENTSDataScriptRunner(String sql, String FilePath, String HerdHeader, String HeaderValue) {
        // Connection Paramenters for Database
        String url = "jdbc:oracle:thin:@//dbconn.agriculture.gov.ie:1532/CENTEST.agriculture.gov.ie";
        String username = "ENTS_DATA";
        String password = "ENTS_DATA";
        try {
            // Setting up connection to the Database
            Connection connection = DriverManager.getConnection(url, username, password);
            // Execute the SQL Statement
            ResultSet resultSet =  connection.prepareStatement(sql).executeQuery();
            // Add values to a List

            while (resultSet.next()) {
                Herds.add(resultSet.getString(HerdHeader));
                System.out.println(resultSet.getString(HerdHeader));
            }
            System.out.println(Herds);
            // Write the Herds obtained in an Excel File
            WritHerdToFile(Herds, FilePath, HeaderValue);
            //System.out.println(Herds);
        } catch (SQLException | IOException | InterruptedException throwables) {
            throwables.printStackTrace();
        }
    }

    public String commonCentestBPSDataScriptRunner(String sql, String AgentHeader, int counterOfAgents) throws SQLException, IOException, InterruptedException {
        // Connection Paramenters for Database
        String url = "jdbc:oracle:thin:@//dbconn.agriculture.gov.ie:1532/CENTEST.agriculture.gov.ie";
        String username = "BPS_CONNECT";
        String password = "BPS_CONNECT";
         // Setting up connection to the Database
            Connection connection = DriverManager.getConnection(url, username, password);
            // Execute the SQL Statement
            ResultSet resultSet =  connection.prepareStatement(sql).executeQuery();
            // Add values to a List
            List<String> Agents = new LinkedList<String>();
            while (resultSet.next()) {

                Agents.add(resultSet.getString(AgentHeader));
                System.out.println(resultSet);
                System.out.println(resultSet.getString(AgentHeader));
            }
            System.out.println(Agents);
       // WritHerdToFile(Agents, FilePath, HeaderValue);
            return Agents.get(counterOfAgents);
    }

    public void runQueryForHerds(int NumberOfRowsToFetch, String FilePath) {
        String herdWithNoSubmissionsql = String.valueOf(getQueryForHerd(NumberOfRowsToFetch));
        String HerdHeader = "BAP_HERD";
        commonCentestENTSDataScriptRunner(herdWithNoSubmissionsql, FilePath, HerdHeader, "Herd Number");
    }

    public String runQueryForAgents(String agent, int counterOfAgents) throws SQLException, IOException, InterruptedException {
        String agentWithNoSubmissionsql = String.valueOf(getQueryForAgent(agent));
        String AgentHeader = "LOGINID";
        return commonCentestBPSDataScriptRunner(agentWithNoSubmissionsql, AgentHeader, counterOfAgents);
    }

//    public String runQueryForAgents(int agent) throws SQLException {
//
//        String agentWithNoSubmissionsql ="select hbcus.bcus_bus_id HerdNo, hbcus.bcus_id HerdBcusId, hbcus.bcus_cust_id HerdCustId,\n" +
//                "(select ui.uri_username FROM tdcr_user_info ui\n" +
//                "where uri_ccs_bus_id =  abcus.bcus_bus_id AND ROWNUM = 1) LoginId,abcus.bcus_id AgentBcusId,abcus.bcus_cust_id AgentCustId,abcus.bcus_bus_id AgentId\n" +
//                "from tdco_customer_asscs ca,tdco_business_customers abcus,tdco_business_customers hbcus\n" +
//                "where SYSDATE BETWEEN ca.ca_start_date AND ca.ca_end_date\n" +
//                "and ca.ca_cac_code = 194 -- BPS Agent to Customer\n" +
//                "and ca.ca_bcus_id_from = abcus.bcus_id\n" +
//                "and ca.ca_bcus_id_to = hbcus.bcus_id\n" +
//                "and hbcus.BCUS_ROLE_CODE = 100\n" +
//                "and hbcus.bcus_bus_end_date > sysdate\n" +
//                "and hbcus.bcus_bus_id in ("+"'"+Herds.get(agent)+"'"+")";
//        String AgentHeader = "LOGINID";
//        System.out.println(Herds.get(agent));
//        return commonCentestBPSDataScriptRunner(agentWithNoSubmissionsql, AgentHeader);
//    }

    // Get a Herd from the specified Excel File
    public String getHerdNumberFromSpecifiedFile(int HerdNumberRow, String Filepath) throws IOException {
        System.out.println(Filepath);
        File herdFile = new File(Filepath);
        FileInputStream fis = new FileInputStream(herdFile);
        Workbook wrkbk = new HSSFWorkbook(fis);
        Sheet sheet = wrkbk.getSheetAt(0);
        Iterator<Row> iterator = sheet.iterator();
        List<String> HerdNumbers = new ArrayList<>();
        while (iterator.hasNext()) {
            Row nextRow = iterator.next();
            Iterator<Cell> cellIterator = nextRow.cellIterator();
            while (cellIterator.hasNext()) {
                Cell cell = cellIterator.next();
                String HerdNumber = cell.getStringCellValue();
                HerdNumbers.add(HerdNumber);
            }
        }
        int HerdNumber = HerdNumbers.size();
        int n = HerdNumber-HerdNumberRow;
        String Herd = HerdNumbers.get(HerdNumber-n);
        System.out.println(Herd);
        wrkbk.close();
        fis.close();
        return Herd;
    }

    // Get a Agent from the specified Excel File
    public String getAgentNumberFromSpecifiedFile(int agentNumberRow, String Filepath) throws IOException {
        File agentFile = new File(Filepath);
        FileInputStream fis = new FileInputStream(agentFile);
        Workbook wrkbk = new HSSFWorkbook(fis);
        Sheet sheet = wrkbk.getSheetAt(0);
        Iterator<Row> iterator = sheet.iterator();
        List<String> agentNumbers = new ArrayList<>();
        while (iterator.hasNext()) {
            Row nextRow = iterator.next();
            Iterator<Cell> cellIterator = nextRow.cellIterator();
            while (cellIterator.hasNext()) {
                Cell cell = cellIterator.next();
                String agentNumber = cell.getStringCellValue();
                agentNumbers.add(agentNumber);
            }
        }
        int agentNumber = agentNumbers.size();
        int n = agentNumber-agentNumberRow;
        String agent = agentNumbers.get(agentNumber-n);
        System.out.println(agent);
        wrkbk.close();
        fis.close();
        return agent;
    }


}


