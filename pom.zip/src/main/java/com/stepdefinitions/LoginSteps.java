package com.stepdefinitions;
import com.base.*;
import com.pages.ApplicationPortalPage;
import com.pages.BPSdashboardPage;
import com.pages.LoginPage;
import com.pages.MyClientsPage;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class LoginSteps {

    private static final Logger log = LoggerFactory.getLogger(LoginSteps.class);
    LoginPage loginPage;
    BPSdashboardPage bpsdashboardPage;
    MyClientsPage myClientsPage;
    ApplicationPortalPage applicationPortalPage;
    WebDriver driver;
    Properties prop;
    ConfigReader configReader;
    ActionClass actions;

    public LoginSteps(DriverManager driverManager){
        try {
            driver = driverManager.getDriver();
            loginPage = new LoginPage(driver);
            bpsdashboardPage = new BPSdashboardPage(driver);
            myClientsPage = new MyClientsPage(driver);
            applicationPortalPage = new ApplicationPortalPage(driver);
            actions = new ActionClass(driver);
            configReader = new ConfigReader();
            prop = configReader.init_prop();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    // region BPS Code
    @When("enters Sub Division Username")
    public void enters_subdiv_username() {
        loginPage.loginWithUserName(prop.getProperty("subdivusername"));
    }

    @When("enters Catch Crop Username")
    public void enters_catch_crop_username() {
        loginPage.loginWithUserName(prop.getProperty("catchcropusername"));
    }

    @When("enters Protein Crop Username")
    public void enters_protein_crop_username() {
        loginPage.loginWithUserName(prop.getProperty("proteincropusername"));
    }

    @When("enters LPIS Username")
    public void enters_LPIS_username() {
        loginPage.loginWithUserName(prop.getProperty("lpisusername"));
    }

    @When("enters Island Plot Username")
    public void enters_IslandPlot_username() {
        loginPage.loginWithUserName(prop.getProperty("islandplotusername"));
    }

    @When("enters GLAS Username")
    public void enters_GLAS_username() {
        loginPage.loginWithUserName(prop.getProperty("glasusername"));
    }

    @When("enters Organic Tab Update Username")
    public void enters_organic_tab_update_username() {
        loginPage.loginWithUserName(prop.getProperty("organictabusername"));
    }

    @When("enters MultiYear Username")
    public void enters_MultiYear_username() {
        loginPage.loginWithUserName(prop.getProperty("multiyearusername"));
    }

    @Given("user on staff login page")
    public void staff_on_login_page() {
        loginPage.launchStaffAppURL();
    }

    @And("click on the Basic Payments Scheme application")
    public void clickOnTheBasicPaymentsSchemeApplication() {

        loginPage.ClickOnBISSApplication();
    }

    // Old Enter Pin Code
    //    @And("Agent Enters First pin Number")
    //    public void enterFirstPinNumber(){
    //        loginPage.enterPin1(prop.getProperty("pin"));
    //    }
    //
    //    @Then("Agent Enters Second Pin Number")
    //    public void enterSecondPinNumber()  {
    //        loginPage.enterPin2(prop.getProperty("pin"));
    //    }
    //
    //    @And("Agent Enters Third Pin Number")
    //    public void enterThirdPinNumber() {
    //        loginPage.enterPin3(prop.getProperty("pin"));
    //    }
    // endregion

    // region BISS code

    @Given("user on login page")
    public void supervisor_is_on_login_page() {
        loginPage.launchAppURL();
    }

    @Given("user on individual login page")
    public void individual_is_on_login_page() {
        loginPage.launchIndividualAppURL();
    }

    @Given("user on partner login page")
    public void partner_is_on_login_page() {
        loginPage.launchPartnerAppURL();
    }

    @And("Get Usernames and Login")
    public void GetUserNames() throws IOException {
        myClientsPage.getAllRows();
        List<String> AgentNumbers = myClientsPage.getAllRows();
        int AgentsCount = AgentNumbers.size();
        for (int i=0; i<=AgentsCount; i++) {
            loginPage.loginWithUserName(AgentNumbers.get(i));
        }
    }

    @When("enters username")
    public void enters_username()  {
        loginPage.loginWithUserName(prop.getProperty("agentusername"));
    }

    @When("enters {string} as username")
    public void enters_given_username(String Username)  {
        loginPage.loginWithUserName(Username);
    }

    @When("enters {string} as new username")
    public void enters_given_new_username(String Username)  {
        loginPage.loginWithNewUserName(Username);
    }

    @When("Agent Enters Agent 1 Username for Transfers")
    public void enters_agent1_username()  {
        loginPage.loginWithUserName(prop.getProperty("agent1username"));
    }

    @When("Agent Enters New Agent 1 Username for Transfers")
    public void enters_new_agent1_username()  {
        loginPage.loginWithNewUserName(prop.getProperty("agent1username"));
    }

    @When("Agent Enters Agent 2 Username for Transfers")
    public void enters_agent2_username()  {
        loginPage.loginWithUserName(prop.getProperty("agent2username"));
    }

    @When("Agent Enters New Agent 2 Username for Transfers")
    public void enters_new_agent2_username()  {
        loginPage.loginWithNewUserName(prop.getProperty("agent2username"));
    }

    @When("Agent Enters Agent 3 Username for Transfers")
    public void enters_agent3_username()  {
        loginPage.loginWithUserName(prop.getProperty("agent3username"));
    }

    @When("Agent Enters New Agent 3 Username for Transfers")
    public void enters_new_agent3_username()  {
        loginPage.loginWithNewUserName(prop.getProperty("agent3username"));
    }

    @When("Agent Enters Agent 4 Username for Transfers")
    public void enters_agent4_username()  {
        loginPage.loginWithUserName(prop.getProperty("agent4username"));
    }

    @When("Agent Enters New Agent 4 Username for Transfers")
    public void enters_new_agent4_username()  {
        loginPage.loginWithNewUserName(prop.getProperty("agent4username"));
    }

    @When("Agent Enters Agent 5 Username for Transfers")
    public void enters_agent5_username()  {
        loginPage.loginWithUserName(prop.getProperty("agent5username"));
    }

    @When("Agent Enters New Agent 5 Username for Transfers")
    public void enters_new_agent5_username()  {
        loginPage.loginWithNewUserName(prop.getProperty("agent5username"));
    }

    @When("Agent Enters Agent 6 Username for Transfers")
    public void enters_agent6_username()  {
        loginPage.loginWithUserName(prop.getProperty("agent6username"));
    }

    @When("Agent Enters New Agent 6 Username for Transfers")
    public void enters_new_agent6_username()  {
        loginPage.loginWithNewUserName(prop.getProperty("agent6username"));
    }

    @When("Agent Enters Transferee Agent 1 Username for Transfers")
    public void enters_transferee_agent1_username()  {
        loginPage.loginWithUserName(prop.getProperty("transfereeagent1username"));
    }

    @When("Agent Enters New Transferee Agent 1 Username for Transfers")
    public void enters_new_transferee_agent1_username()  {
        loginPage.loginWithNewUserName(prop.getProperty("transfereeagent1username"));
    }

    @When("Agent Enters Transferee Agent 2 Username for Transfers")
    public void enters_transferee_agent2_username()  {
        loginPage.loginWithUserName(prop.getProperty("agent7username"));
    }

    @When("Agent Enters New Transferee Agent 2 Username for Transfers")
    public void enters_new_transferee_agent2_username()  {
        loginPage.loginWithNewUserName(prop.getProperty("agent7username"));
    }

    @When("Agent Enters ETF Agent 1 Username for Transfers")
    public void enters_etf_agent1_username()  {
        loginPage.loginWithUserName(prop.getProperty("etfagentusername"));
    }

    @When("Agent Enters NRCISYF Agent 1 Username")
    public void enters_nrcisyf_agent1_username()  {
        loginPage.loginWithUserName(prop.getProperty("nrcisyfagent"));
    }

    @When("Agent Enters new NRCISYF Agent 1 Username")
    public void enters_new_nrcisyf_agent1_username() {
        loginPage.loginWithNewUserName(prop.getProperty("nrcisyfagent"));
    }

    @When("Agent Enters new NRCISYF Agent 2 Username")
    public void enters_new_nrcisyf_agent2_username() {
        loginPage.loginWithNewUserName(prop.getProperty("nrcisyfagent2"));
    }

    @When("Agent Enters Individual Username for Transfers")
    public void enters_individual_username() {
        loginPage.loginWithUserName(prop.getProperty("individualusername"));
    }

    @When("Agent Enter {string} as Trasferee Username")
    public void enter_transferee_username(String Arg0){
        loginPage.loginWithUserName(Arg0);
    }

    @When("Agent Enter {string} as Individual's Username")
    public void enter_individual_username(String Arg0) throws InterruptedException {
        Thread.sleep(2000);
        loginPage.loginWithNewUserName(Arg0);
    }

    @When("enters MIG Username")
    public void enters_mig_username() {
        loginPage.loginWithUserName(prop.getProperty("migagentusername"));
    }

    @When("Enters Incorrect Username")
    public void enters_incorrect_username()  {
        loginPage.loginWithUserName(prop.getProperty("incorrectusername"));
    }

    @Then("Wait For Chat Window")
    public void waitForChatWindow() {
        loginPage.waitForChatWindow();
    }

    @And("Agent Enters the Pin Number")
    public void agentEnterPinNumber() {
        loginPage.enterPinCode(prop.getProperty("pin"));
    }

    @And("Agent Enters {string} as the OTP")
    public void agentEnterOTP(String otp) {
            loginPage.enterOTP(otp);
    }

    @Then("Individual Enters sms OTP")
    public void individualEnterOTP() {
        loginPage.IndividualEnterOTP();
    }

    @Then("Partner Enters MS authenticator OTP")
    public void partnerEnterOTP() {
        loginPage.PartnerEnterOTP();
    }

    @When("enter password")
    public void enter_password()  {
        loginPage.loginWithpassword(prop.getProperty("agentpassword"));
    }

    @When("enter staff password")
    public void enter_staff_password()  {
        loginPage.loginWithStaffpassword(prop.getProperty("agentpassword"));
    }

    @And("Enters Incorrect Password")
    public void enter_incorrect_password()  {
        loginPage.loginWithpassword(prop.getProperty("incorrectpassword"));
    }

    @When("clicks on Login button")
    public void clicks_on_login_button() throws InterruptedException {
        loginPage.loginWithsubmit();
        Thread.sleep(3000);
    }


    @When("clicks on Continue button")
    public void clicks_on_continue_button() throws InterruptedException {
        loginPage.ClickOnContinueButton();
        Thread.sleep(2000);
    }

    @Then("External User Enters sms OTP")
    public void externalUserEntersSmsOTP() {
        loginPage.externalUserEnterOTP();
    }

    @When("clicks on new agent login button")
    public void clicks_on_new_login() throws InterruptedException {
        Thread.sleep(3000);
        loginPage.AgentClickOnNewLoginButton();
        Thread.sleep(5000);
    }

    @When("clicks on partner Login button")
    public void clicks_on_partner_login_button() throws InterruptedException {
        loginPage.partnerloginWithsubmit();
        Thread.sleep(3000);
    }

    @And("Click on the Basic Income Support for Sustainability application")
    public void clickOnTheBasicIncomeSupportForSustainabilityApplication() throws InterruptedException {
        Thread.sleep(3000);
        loginPage.ClickOnBISSApplication();
        Thread.sleep(3000);
    }

    @Given("Agent is on BISS Agent Home Screen")
    public void AgentOnBISSHomeScreen() {
        actions.zoomScreenTo("50%");
        String title = driver.getTitle();
        System.out.println("Title of BISS Home Page is : " + title);
    }

    @And("Click on the My Account Button")
    public void AgentClickOnMyAccountButton() throws InterruptedException {
        bpsdashboardPage.AgentClickOnMyAccountButton();
        Thread.sleep(3000);
    }

    @And("Click on Exit BISS Link")
    public void clickOnTheExitBISSLink() throws InterruptedException {
        bpsdashboardPage.AgentClickOnExitButton();
    }


    @And("Click on Contact US Button")
    public void AgentClickOnTheContactUsButton() throws InterruptedException {
        bpsdashboardPage.AgentClickOnContactUsButton();
    }

    @And("Click on Logout Button")
    public void clickOnLogoutButton() throws InterruptedException {
        loginPage.StaffLogout();
        Thread.sleep(5000);
    }

    // endregion

    @Then("Click on the Agent BISS {string} Tab")
    public void ClickOnTheBISSAgentSideNavButtons(String Arg0) throws InterruptedException {
        Thread.sleep(4000);
        bpsdashboardPage.AgentClickOnDashboardSidenavElements(Arg0);
        Thread.sleep(3000);
    }

    @Given("Agent is on BPS Agent Home Screen")
    public void StaffParcelSearchPage() {
        String title = driver.getTitle();
        System.out.println("title of Home Page is : " + title);
    }

    @And("Agent Navigates  to My Clients Screen")
    public void NavigateToMyClientsScreen() {
        bpsdashboardPage.AgentClickOnMyClientsTab();
    }

    @And("Agent Navigates to My Clients With No Herd Number Screen")
    public void NavigateToMyClientsWithNoHerdNumberScreen(){
        bpsdashboardPage.AgentClickOnMyClientsWithNoHerdNumberTab();
    }

    @And("Agent Navigates to Checks By Monitoring Screen")
    public void NavigateToChecksByMonitoringScreen() {
        bpsdashboardPage.AgentClickOnChecksByMonitoringTab();
    }

    @And("Agent Navigates to BPS Applications Screen")
    public void NavigateToBPSApplicationsScreen() {
        bpsdashboardPage.AgentClickOnBPSApplicationsTab();
    }


    @And("Agent Navigates to Agent Dashboard Screen")
    public void NavigateToAgentDashboardScreen() throws InterruptedException {
        bpsdashboardPage.AgentClickOnAgentDashboardTab();
        Thread.sleep(3000);
    }

    @And("Agent Navigates to Outstanding BPS Errors Screen")
    public void NavigateToOutstandingBPSErrorsScreen() throws InterruptedException {
        bpsdashboardPage.AgentClickOnOutstandingBPSErrorsTab();
        Thread.sleep(3000);
    }

    // region Multiple Login
    @Given("Agent Numbers are taken from Excel File and used as UserName")
    public void the_excel_file_name_and_location_is_given_as(IDataReader dataTable) throws InterruptedException, IOException {
        // Write code here that turns the phrase above into concrete actions
        // For automatic transformation, change DataTable to one of
        // E, List<E>, List<List<E>>, List<Map<K,V>>, Map<K,V> or
        // Map<K, List<V>>. E,K,V must be a String, Integer, Float,
        // Double, Byte, Short, Long, BigInteger or BigDecimal.
        // For other transformations you can register a DataTableType.
        System.out.println(dataTable.getAllRows());
//        loginPage.GetAgentNumbersArray(dataTable);
        List<String> agents = dataTable.getAllRows();
        for (int i=0 ; i<agents.size() ;i++) {
            String currentherd = agents.get(i);
            String Split1 = currentherd.replaceAll("\\[", "");
            String Split2 = Split1.replaceAll("]", "");
            String Split3[] = Split2.split("\\.");
            String AgentNumber = Split3[0];
            myClientsPage.StoreAgentNumberInExcel(AgentNumber);
            loginPage.launchAppURL();
            loginPage.loginWithUserName(AgentNumber);
            loginPage.enterPinCode("1");
            loginPage.loginWithpassword("@c3ntst678!!");
            loginPage.loginWithsubmit();
            Thread.sleep(2000);
            myClientsPage.GetLastAgentNumber();
            Thread.sleep(2000);
            loginPage.ClickOnBISSApplication();
            String title = driver.getTitle();
            System.out.println("Title of BISS Home Page is : " + title);
            bpsdashboardPage.AgentClickOnDashboardSidenavElements("My Clients");
            Thread.sleep(4000);
            myClientsPage.AgentSelectQuickFilters("NotStarted");
            Thread.sleep(2000);
            myClientsPage.AgentSelectFirstHerdInList(1);
            myClientsPage.StoreHerdNumberInExcel();
            applicationPortalPage.AgentClickOnButtonsInFarmerDashboard("Start application");
            Thread.sleep(4000);
            applicationPortalPage.AgentCheckActivityStatusLabelText("Grassland", "Topping");
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Next");
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnSchemeCard("Organics");
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Next");
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnDialogBoxButton("I understand");
            Thread.sleep(2000);
            applicationPortalPage.AddInvalidParcel();
            Thread.sleep(3000);
            applicationPortalPage.AddArchivedParcel();
            Thread.sleep(4000);
            AddParcelAndPlotForAgent();
            Thread.sleep(4000);
//            applicationPortalPage.AgentCheckMandatoryInfoWarning();
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Next");
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Next");
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnCheckBoxForNoEcoScheme();
            Thread.sleep(3000);
            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Next");
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnNextButtonInReviewAndSubmitScreen();
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Submit");
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnTermsAndConditionsCheckBox();
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Submit");
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnDialogBoxButton("Yes, I confirm");
            Thread.sleep(10000);
        }

    }


    @Then("Login with the Username {string}")
    public void AgentLoginWithGivenUsername(String AgentNumber){
        loginPage.loginWithUserName(AgentNumber);
    }


    @Then("Login with the Partner Username {string}")
    public void AgentLoginWithPartnerUsername(String AgentNumber){
        loginPage.loginWithPartnerUserName(AgentNumber);
    }

    @And("Enter the number as {string} after login")
    public void PartnerEnterNumber(String Number) {
        loginPage.enterMobileNumber(Number);
    }

    @Then("Partner Enter {string} as the one time code")
    public void PartnerEnterOneTimeCode(String Code) {
        loginPage.enterOneTimeCode(Code);
    }

    // Multiple Login for Active Agent
    @Given("Agent Numbers are taken from Excel File and used as UserName targeting Active Herds")
    public void ActiveHerdsBatchLoad(IDataReader dataTable) throws InterruptedException, IOException {
        // Write code here that turns the phrase above into concrete actions
        // For automatic transformation, change DataTable to one of
        // E, List<E>, List<List<E>>, List<Map<K,V>>, Map<K,V> or
        // Map<K, List<V>>. E,K,V must be a String, Integer, Float,
        // Double, Byte, Short, Long, BigInteger or BigDecimal.
        // For other transformations you can register a DataTableType.
        System.out.println(dataTable.getAllRows());
//        System.out.println(dataTable.getAllRowsSecondColumn());
//        loginPage.GetAgentNumbersArray(dataTable);
        List<String> agents = dataTable.getAllRows();
//        Map<String, String> herd = dataTable.getASingleRow();
//        List<String> herds = dataTable.getAllRowsSecondColumn();
        for (int i=0 ; i<agents.size() ;i++) {
            String currentagent = agents.get(i);
            String Split1 = currentagent.replaceAll("\\[", "");
            String Split2 = Split1.replaceAll("]", "");
//            String Split3[] = Split2.split("\\.");
            String Split3[] = Split2.split(",");
            //String AgentNumber = Split3[0];
            System.out.println("Agent Number : " + Split3[0]);
            String AgentNumber = Split3[0];
            System.out.println("Herd Number : "+ Split3[1]);
            String HerdNumber = Split3[1];
            myClientsPage.StoreAgentNumberInExcel(AgentNumber);
            // Printing Agent Number Used
            System.out.println(AgentNumber);
            loginPage.launchAppURL();
            loginPage.loginWithUserName(AgentNumber);
            loginPage.enterPinCode("1");
            loginPage.loginWithpassword("@c3ntst678!!");
            loginPage.loginWithsubmit();
            Thread.sleep(2000);
            myClientsPage.GetLastAgentNumber();
            Thread.sleep(2000);
            loginPage.ClickOnBISSApplication();
            String title = driver.getTitle();
            System.out.println("Title of BISS Home Page is : " + title);
            bpsdashboardPage.AgentClickOnDashboardSidenavElements("My Clients");
            Thread.sleep(4000);
            myClientsPage.AgentSelectQuickFilters("Submitted");
            Thread.sleep(2000);
            // Getting Herds from Second Column
//            String currentherd = herds.get(i);
//            String SplitHerd1 = currentherd.replaceAll("\\[", "");
//            String SplitHerd2 = SplitHerd1.replaceAll("]", "");
//            String SplitHerd3[] = SplitHerd2.split("\\.");
//            String HerdNumber = SplitHerd3[0];
            // Printing Herd Number Used
//            System.out.println(HerdNumber);
            myClientsPage.AgentSearchForHerd(HerdNumber);
            Thread.sleep(5000);
            myClientsPage.AgentSelectFirstHerdInList(1);
            // Continue from here
            myClientsPage.StoreHerdNumberInExcel();
            Thread.sleep(2000);
            applicationPortalPage.AgentDeleteDraftIfStarted("Delete draft");
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnButtonsInFarmerDashboard("Start amendment");
            Thread.sleep(4000);
            // Next Button in Active Farmer Page
            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Next");
            Thread.sleep(2000);
            // Next Button in Scheme Selection Page
            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Next");
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnDialogBoxButton("I understand");
            Thread.sleep(3000);
//            applicationPortalPage.AgentSelectFirstParcelInList();
//            Thread.sleep(2000);
            applicationPortalPage.AgentChangeClaimedArea();
            Thread.sleep(3000);
            applicationPortalPage.AgentClickOnSideDrawerButtons("Save changes");
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnSideDrawerButtons("Cancel");
            Thread.sleep(3000);
            // Check for the warning message in Land Details Page
//            applicationPortalPage.AgentCheckForOverClaimWarning();
//            Thread.sleep(2000);
            // Next Button in Land Details Page
            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Next");
            Thread.sleep(2000);
            // Next Button in GAEC8 Page
            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Next");
            Thread.sleep(2000);
            // Agent Check if AP selected if not opt out
            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Next");
            applicationPortalPage.EcoWarningMessageCheck();
            applicationPortalPage.AgentCheckIfOptOutOfSchemePresentAndProceed();
            Thread.sleep(3000);
            // Next Button in Eco-Scheme Page
            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Next");
            Thread.sleep(2000);
            // Next Button in ACRES page
            applicationPortalPage.CheckAcresPageAndClickNext();
            Thread.sleep(4000);
            // Agent navigate through Accordion
            applicationPortalPage.AgentClickOnNextButtonInReviewAndSubmitScreen();
            Thread.sleep(4000);
            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Submit");
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnTermsAndConditionsCheckBox();
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Submit");
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnDialogBoxButton("Yes, I confirm");
            Thread.sleep(15000);
//            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Application Summary");
//            Thread.sleep(3000);
            bpsdashboardPage.AgentClickOnDashboardSidenavElements("Correspondence");
            Thread.sleep(5000);
            String AmendmentDate = applicationPortalPage.GetDateOfAmendmentApplication();
            String SystemDate = CurrentDate();
//            Assert.assertEquals(AmendmentDate,SystemDate,"Amendment Application has been created");
            if (Objects.equals(AmendmentDate, SystemDate)) {
                System.out.println("Dates match");
            }
            else {
                System.out.println("Dates don't match");
            }
        }
    }

    // Multiple Login for Active Agent for Amendments
    @Given("Agent Numbers are taken from Excel File and used as UserName targeting Active Herds for Amendments")
    public void ActiveHerdsBatchLoadFoAmendments(IDataReader dataTable) throws InterruptedException, IOException {
        System.out.println(dataTable.getAllRows());
//        loginPage.GetAgentNumbersArray(dataTable);
        List<String> agents = dataTable.getAllRows();
        for (int i=0 ; i<agents.size() ;i++) {
            String currentherd = agents.get(i);
            String Split1 = currentherd.replaceAll("\\[", "");
            String Split2 = Split1.replaceAll("]", "");
            String Split3[] = Split2.split("\\.");
            String AgentNumber = Split3[0];
            myClientsPage.StoreAgentNumberInExcel(AgentNumber);
            loginPage.launchAppURL();
            loginPage.loginWithUserName(AgentNumber);
            loginPage.enterPinCode("1");
            loginPage.loginWithpassword("@c3ntst678!!");
            loginPage.loginWithsubmit();
            Thread.sleep(2000);
            myClientsPage.GetLastAgentNumber();
            Thread.sleep(2000);
            loginPage.ClickOnBISSApplication();
            String title = driver.getTitle();
            System.out.println("Title of BISS Home Page is : " + title);
            bpsdashboardPage.AgentClickOnDashboardSidenavElements("My Clients");
            Thread.sleep(4000);
            myClientsPage.AgentSelectQuickFilters("Submitted");
            Thread.sleep(2000);
            myClientsPage.AgentSelectFirstHerdInList(1);
            // Continue from here
            myClientsPage.StoreHerdNumberInExcel();
            Thread.sleep(2000);
            applicationPortalPage.AgentDeleteDraftIfStarted("Delete draft");
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnButtonsInFarmerDashboard("Start amendment");
            Thread.sleep(4000);
            // Next Button in Active Farmer Page
            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Next");
            Thread.sleep(2000);
            // Next Button in Scheme Selection Page
            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Next");
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnDialogBoxButton("I understand");
            Thread.sleep(3000);
//            applicationPortalPage.AgentSelectFirstParcelInList();
//            Thread.sleep(2000);
            applicationPortalPage.AgentChangeClaimedArea();
            Thread.sleep(3000);
            applicationPortalPage.AgentClickOnSideDrawerButtons("Save changes");
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnSideDrawerButtons("Cancel");
            Thread.sleep(3000);
            // Check for the warning message in Land Details Page
            applicationPortalPage.AgentCheckForOverClaimWarning();
            Thread.sleep(2000);
            // Next Button in Land Details Page
            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Next");
            Thread.sleep(2000);
            // Next Button in GAEC8 Page
            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Next");
            Thread.sleep(2000);
            // Agent Check if AP selected if not opt out
            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Next");
            applicationPortalPage.EcoWarningMessageCheck();
            applicationPortalPage.AgentCheckIfOptOutOfSchemePresentAndProceed();
            Thread.sleep(3000);
            // Next Button in Eco-Scheme Page
            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Next");
            Thread.sleep(2000);
            // Next Button in ACRES page
            applicationPortalPage.CheckAcresPageAndClickNext();
            Thread.sleep(4000);
            // Agent navigate through Accordion
            applicationPortalPage.AgentClickOnNextButtonInReviewAndSubmitScreen();
            Thread.sleep(4000);
            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Submit");
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnTermsAndConditionsCheckBox();
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Submit");
            Thread.sleep(2000);
            applicationPortalPage.AgentClickOnDialogBoxButton("Yes, I confirm");
            Thread.sleep(15000);
//            applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Application Summary");
//            Thread.sleep(3000);
            bpsdashboardPage.AgentClickOnDashboardSidenavElements("Correspondence");
            Thread.sleep(5000);
            String AmendmentDate = applicationPortalPage.GetDateOfAmendmentApplication();
            String SystemDate = CurrentDate();
//            Assert.assertEquals(AmendmentDate,SystemDate,"Amendment Application has been created");
            if (Objects.equals(AmendmentDate, SystemDate)) {
                System.out.println("Dates match");
            }
            else {
                System.out.println("Dates don't match");
            }
        }
    }


    @Given("Agent check if EcoScheme Textbox selected")
    public void CheckEcoScheme() throws InterruptedException {
        loginPage.launchAppURL();
        loginPage.loginWithUserName("agr21182");
        loginPage.enterPinCode("1");
        loginPage.loginWithpassword("@c3ntst678!!");
        loginPage.loginWithsubmit();
        loginPage.ClickOnBISSApplication();
        String title = driver.getTitle();
        System.out.println("Title of BISS Home Page is : " + title);
        bpsdashboardPage.AgentClickOnDashboardSidenavElements("My Clients");
        Thread.sleep(4000);
        myClientsPage.AgentSelectQuickFilters("Submitted");
        Thread.sleep(2000);
        myClientsPage.AgentSelectFirstHerdInList(1);
        applicationPortalPage.AgentClickOnButtonsInFarmerDashboard("Continue amendment");
        Thread.sleep(4000);
        applicationPortalPage.EcoWarningMessageCheck();
//        Boolean ToggleStatus = applicationPortalPage.CheckIfToggleEnabled();
//        System.out.println(ToggleStatus);
        applicationPortalPage.AgentCheckIfOptOutOfSchemePresentAndProceed();
        Thread.sleep(5000);
        applicationPortalPage.AgentClickOnNextOrBackOrSubmitButton("Next");

    }


    public String CurrentDate() {
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy ");
        Date date = new Date();
        String currentdate = dateFormat.format(date);
        System.out.println("Current System Date : " + currentdate);
        return currentdate;
    }

    @And("Delete Application Created")
    public void TryDeletingApplication() {
        applicationPortalPage.DeleteApplicationProcedure1();
    }

//    public List<String> PickParcelsAndPlotsForAgent(int CaseNumber) throws IOException {
//        List<String> ParcelsAndPlots = null;
//        switch (CaseNumber) {
//            case 0: {
//                // ha = 2
//                ParcelsAndPlots.add("J1591700019");
//                ParcelsAndPlots.add("");
//                return ParcelsAndPlots;
//            }
//            case 1: {
//                int n=2;
//                return ParcelsAndPlots;
//            }
//            default:
//                return null;
//        }
//    }



    public void AddParcelAndPlotForAgent() throws IOException {
        if(myClientsPage.GetLastAgentNumber() == "agr21182") {
            applicationPortalPage.AddParcelToBatch("J1591700019");
            applicationPortalPage.AddPlotToBatch("Cavan","Aghabane - B15501","T12345671");
        }
        else if(myClientsPage.GetLastAgentNumber() == "agr13650") {
            applicationPortalPage.AddParcelToBatch("K2100300067");
            applicationPortalPage.AddPlotToBatch("Donegal","Aghadachor - E22301","T12345672");
        }
        else if(myClientsPage.GetLastAgentNumber() == "aga12363") {
            applicationPortalPage.AddParcelToBatch("L1370100001");
            applicationPortalPage.AddPlotToBatch("Cavan","Aghadrumgulli - B11701","T12345673");
        }
        else if(myClientsPage.GetLastAgentNumber() == "agr9639") {
            applicationPortalPage.AddParcelToBatch("J1980300008");
            applicationPortalPage.AddPlotToBatch("Donegal","Aghafoy - E18801","T12345674");
        }
        else if(myClientsPage.GetLastAgentNumber() == "agr11150") {
            applicationPortalPage.AddParcelToBatch("R1061800017");
            applicationPortalPage.AddPlotToBatch("Kerry","Aghatubrid - H22901","T12345675");
        }
//        else if (myClientsPage.GetLastAgentNumber() == "aga6689") {
//            applicationPortalPage.AddPlotToBatch("Cavan","Aghabane - B15501","T12345676");
//        }
    }

    @DataTableType
    public IDataReader excelToDataTable(Map<String, String> entry) { // [Excel= <fileName>, Location=<FileLocation> ..]
        ExcelConfiguration config = new ExcelConfiguration.ExcelConfigurationBuilder()
                .setFileName(entry.get("Excel"))
                .setFileLocation(entry.get("Location"))
                .setSheetName(entry.get("Sheet"))
                .setIndex(Integer.parseInt(entry.getOrDefault("Index", "0")))
                .build();
        return new ExcelDataReader(config);

    }
    // endregion


    // region AMS code

    // endregion
}
