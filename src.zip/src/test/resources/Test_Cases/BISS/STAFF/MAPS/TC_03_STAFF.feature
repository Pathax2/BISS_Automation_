# ====================================================================================================================================
# TC_03_STAFF.feature
# ====================================================================================================================================
@maps @regression @staff
Feature: TC_03_STAFF - Generated Map Details and Pagination

  # Migrated from legacy "Regression Suite for Checking Map Generated for HerdNumber"
  # (AT-TC-01, 02).
  #
  # BUSINESS FLOW
  #   After requesting a map, the generated maps table records the request. Staff confirm the
  #   herd identity on screen, then confirm the request was recorded with its full metadata
  #   and reached a terminal status. The table paginates once enough requests exist.
  #
  # WHAT THIS VALIDATES
  #   1. Herd name and address are displayed for the searched herd.
  #   2. A generated map row carries status, id, herd number and date.
  #   3. The request reaches its final status rather than staying in progress.
  #   4. The generated maps table pages forward and back.


  Background:
    Given the staff user is logged in to the BISS internal portal as "agr2332"
    And the staff user is on the Map Printing screen

  @e2e @generated-map
  Scenario: Staff verifies generated map metadata and pages through the results table

    # SECTION 1 - AT-TC-01 (BISSAGL-14962)
    # Validates: the herd is identified on screen and the resulting request row carries every
    # metadata field. Legacy printed name/address rather than asserting them - the herd is DB
    # resolved so its expected name is not known to the feature; presence is what is checked.
    When the staff user searches Map Printing for the next submitted herd for scheme year "2023"
    Then the staff user should see the herd identity details
      | name    |
      | address |
    When the staff user requests a map with the following settings
      | parcels | single              |
      | mapType | Full Color Ortho A4 |
      | legend  | yes                 |
    Then the generated map should be recorded with the following details
      | status     |
      | id         |
      | herdNumber |
      | date       |

    # SECTION 2 - AT-TC-02 (BISSAGL-14960)
    # Validates: as Section 1, plus the request settles at its final status and the results
    # table pages forward and back once a second request exists.
    When the staff user searches Map Printing for the next submitted herd for scheme year "2023"
    Then the staff user should see the herd identity details
      | name    |
      | address |
    When the staff user requests a map with the following settings
      | parcels | single              |
      | mapType | Full Color Ortho A4 |
      | legend  | yes                 |
    Then the generated map should be recorded with the following details
      | status     |
      | id         |
      | herdNumber |
      | date       |
    Then the map generation request should be accepted
    And the generated map should reach its final status
    When the staff user pages through the generated maps table
      | Next page     |
      | Previous page |
    Then the generated maps table should remain displayed
