Feature: TC_S37 - Regression Pack for Eco Scheme iNet - TRNs with Grassland and AP2

  # ──────────────────────────────────────────────────────────────────────────
  # Purpose:
  #   Validates the agent flow for Eco Scheme AP2 eligibility for TRNs with
  #   parcels and greater than 50% Grassland. Covers:
  #     - TC01: Start or continue application for herd A1360089
  #     - TC02: Start or continue application for herd A1131667
  #
  # Common Background:
  #   Agent login as aga6306 with OTP → open BISS application → My Clients tab.
  #   This is an iNet agent-side flow.
  #
  # DB Data:
  #   No DB pool step required. Fixed herds A1360089 and A1131667 are the
  #   specific TRN test herds with known Grassland AP2 eligibility.
  #
  # Notes:
  #   1. aga6306 is the agent user authorised for both herds.
  #   2. TC01 and TC02 navigate to the dashboard and start or continue the
  #      application — further Eco AP2 validation steps are pending completion.
  #   3. Both herds are known to have greater than 50% Grassland which triggers
  #      the AP2 eligibility logic in the Eco scheme selection step.
  #
  # Author  : Aniket Pathare | aniket.pathare@government.ie
  # Created : 2026-05-14
  # ──────────────────────────────────────────────────────────────────────────

  Background:
    Given the agent user is on the login page
    When the agent logs into the application with valid credentials and OTP as "aga6306"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    And the agent navigates to the "Home" and "My Clients" Left Menu Link

  @tmsLink=BISSAGL-14776 @tmsLink=BISSAGL-14777 @regression
  Scenario: TC_S37 - Eco Scheme iNet TRNs Grassland AP2 end-to-end regression

    # ── TC01: Start or continue application for herd A1360089 ────────────────
    When the agent searches for herd "A1360089" and opens the farmer dashboard
    And the agent starts or continues the application from the farmer dashboard
    Then the application stepper should be displayed and ready for Eco AP2 validation

    # ── TC02: Start or continue application for herd A1131667 ────────────────
    When the agent navigates back to My Clients, searches for herd "A1131667" and opens the farmer dashboard
    And the agent starts or continues the application from the farmer dashboard
    Then the application stepper should be displayed and ready for Eco AP2 validation