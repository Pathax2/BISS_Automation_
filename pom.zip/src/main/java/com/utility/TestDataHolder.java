package com.utility;

import com.google.common.base.Strings;
import lombok.Getter;
import lombok.extern.log4j.Log4j2;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;


@Log4j2
public class TestDataHolder {

    private static Set<String> envs = new CopyOnWriteArraySet<>();

    public static final String ENVIRONMENT = "ENVIRONMENT";
    public static final String ZEPHYR_TEST_ID = "ZEPHYR_TEST_ID";

    @Getter
    private static Map<String, String> testDataMap;

    public static String getRecord(String key) {
        if (testDataMap == null) {
            initDataMap();
        }
        log.debug("getting the value for the key " + key);
        String record = testDataMap.get(key);
        if (key.equals(ENVIRONMENT) && Strings.isNullOrEmpty(record)) {
            TestDataHolder.addRecord(TestDataHolder.ENVIRONMENT, "ENVIRONMENT_DEFAULT");
            record = testDataMap.get(key);
        } else if (record == null) {
            log.debug("no record found for " + key + " . Returning empty string instead...");
            record = "";
        }

        log.debug("record: " + key + " = " + record);
        return record;
    }

    private static void initDataMap() {
        testDataMap = new HashMap<>();
    }

    public static void addRecord(String key, String value) {
        addRecord(key, value, true, true);
    }

    public static void addRecord(String key, String value, boolean overwrite, boolean printValueInLog) {
        if (testDataMap == null) {
            initDataMap();
        }
        if (overwrite) {
            testDataMap.remove(key);
        }
        final boolean isKeyRecordedBefore = testDataMap.containsKey(key);
        if (isKeyRecordedBefore) {
            if (!Strings.isNullOrEmpty(testDataMap.get(key))) {
                key = key + "_i";
            }
        }
        if (printValueInLog) {
            log.debug("recording the test data key: " + key + " with the value: " + value);
        }
        testDataMap.put(key, value);
        if (key.equals(TestDataHolder.ENVIRONMENT)) {
            addTestEnvironment(value.toUpperCase());
        }
    }


    public static boolean addTestEnvironment(String env) {
        return envs.add(env);
    }

}