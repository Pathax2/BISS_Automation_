#Removed after discussion on 01/10/2025

#Feature: Regression Suite for Crop not Defined
#
#  @tmslink=BISSAGL-14963
#  @regression
#  Scenario: AT-TC-01 - BISS_24.1.Sprint_5 TC1 for BISSAGL-7546 Crop 552 not defined for 2023 application on herd O1060339
#    Given user on login page
#    When clicks on new agent login button
#    #Added code to take agent from config file
#    When Agent Enters new Agent Username
#    #When Enters "aga6029" as new username
#    And clicks on Login button
#    And enter password
#    And clicks on Login button
#    Then External User Enters sms OTP
#    And clicks on Login button
#    #When enters "aga6029" as username
#    #And Agent Enters the Pin Number
#    #And enters agent password
#    #And Clicks On Agent Logon Button
#    And Click on the Basic Income Support for Sustainability application
#    Given Agent is on BISS Agent Home Screen
#    Then Click on the Agent BISS "My Clients" Tab
#    #Q1330285 Thomas Martin
#    And Agent Select " Not Started " Quick Filter
#    And Agent picks herd in list
#    Then Agent Search for Herd Number
#    #Then Agent Search for Herd Number "Q1330285"
#    #And Agent Click on the Row with the Client "Q1330285"
#    Then Agent Click on the View Dashboard Button
#    Given  Agent is on BISS Farmer Dashboard Screen
#    And Delete Draft if exists
#    And Agent Click On " Start Application " Farmer Dashboard Button
#    #And Agent Check the Active Farmer Status and opts under "Grassland" farming practice "Making Hay/Silage/Haylage" activity
#    And Agent Click on the "Making Hay/Silage/Haylage" CheckBox
#    Then Agent Click on Application Stepper "Next" Button
#    Then Agent Click on the "Organics" scheme card
#    Then Agent Click on the "Eco" scheme card
#    Then Agent Click on Application Stepper "Next" Button
#    Then Agent Click on the "I understand" dialog box button
##    And Agent Select "Action Required" Quick Filter
##    Then Agent Fill in Mandatory Agricultural Activity Information
##    And Agent Select "View all" Quick Filter
##    Then Agent Click on Application Stepper "Next" Button
##    Then Agent Click on Application Stepper "Next" Button
#    Then Agent Fill in Mandatory Information
#    Then Agent Click on Application Stepper "Next" Button
#    Then Agent Click on Application Stepper "Next" Button
#    And Agent Click on Next Button in Review and Submit Page
#    Then Agent Click on Application Stepper "Submit" Button
#    Then Agent Click on Terms & Conditions CheckBox
#    Then Agent Click on Application Stepper "Submit" Button
#    And Agent Click on the "Yes, I confirm" dialog box button
#   # And Click on the My Account Button
##    And Click on Exit BISS Link
##    And Click on Logout Button
#    Given user on staff login page
#    When Login with the Username "agr4442"
#    And enter password
#    Then Staff Select Data Protection CheckBox
#    And clicks on Login button
#    And Click on the Basic Income Support for Sustainability application
#    Then Staff Enter same herd in the "herdNumber" field
#    #Then Staff Enter Value as "Q1330285" in the "herdNumber" field
#    Then Staff Select "schemeYear" dropdown value as "2026"
#    Then Staff Click on the "Search" button
#    And Staff Click On the "application-search-table" table "Amend" link number 1
#    Then Agent Click on the "Organics" scheme card
#    Then Agent Click on Application Stepper "Next" Button
#    #And Agent Select "Action Required" Quick Filter
#    #And Agent Fill in Mandatory Organic Status Information
#    Then Staff Click on the "Submit Changes" button
#
#
#
#
