package com.stepdefinitions;


import com.base.ConfigReader;
import com.base.DriverManager;
import com.pages.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import java.io.IOException;
import java.util.Properties;

public class BPSApplicationSteps {

    LoginPage loginPage;
    BPSApplicationsPage bpsapplicationsPage;
    ApplicationPortalPage applicationportalPage;
    MyClientsPage myClientsPage;
    WebDriver driver;
    Properties prop;
    ConfigReader configReader;
    DriverManager driverManager;

    public BPSApplicationSteps(DriverManager driverManager){
        try {
//            driver = driverManager.getDriver();
            this.driverManager=driverManager;
            driver=driverManager.getDriverInstance();
            loginPage = new LoginPage(driver);
            //bpsdashboardPage = new BPSdashboardPage(driver);
            applicationportalPage = new ApplicationPortalPage(driver);
            bpsapplicationsPage = new BPSApplicationsPage(driver);
            myClientsPage = new MyClientsPage(driver);
            configReader = new ConfigReader();
            prop = configReader.init_prop();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    // region BPS Code

    @And("Agent is on BPS Applications Page")
    public void BPSApplicationsPage() {
        String title = driver.getTitle();
        System.out.println("title of BPS Applications" + title);
    }


    @Then("Agent Navigates to Submitted Applications Tab")
    public void AgentClickOnSubmittedApplicationsTab() throws InterruptedException {
        bpsapplicationsPage.AgentClickOnSubmittedApplicationsTab();
        Thread.sleep(2000);
    }

    @And("Agent Navigates to Outstanding Applications Tab")
    public void AgentClickOnOutstandingApplicationsTab() throws InterruptedException {
        bpsapplicationsPage.AgentClickOnOutstandingApplicationsTab();
        Thread.sleep(3000);
    }

    @And("Agent Navigates to Draft Applications Tab")
    public void AgentClickOnDraftApplicationsTab() throws InterruptedException {
        bpsapplicationsPage.AgentClickOnDraftApplicationsTab();
        Thread.sleep(2000);
    }

    @And("Agent Navigates to Paid Clients Tab")
    public void AgentClickOnPaidClientsTab() throws InterruptedException {
        bpsapplicationsPage.AgentClickOnPaidClientsTab();
        Thread.sleep(2000);
    }

    @Then("Check if Print Preview Button is Visible")
    public void AgentCheckPrintPreviewVisibility() throws InterruptedException {
        bpsapplicationsPage.VisibilityOfPrintPreviewButton();
    }

    @Then("Agent Clicks on Print Preview Button")
    public void AgentClicksOnPrintPreviewButton() throws InterruptedException {
        bpsapplicationsPage.AgentClickOnPrintPreviewButton();
    }

    @And("Check if Download Button is Visible")
    public void AgentCheckDownloadButtonVisibility() throws InterruptedException {
        Assert.assertTrue(bpsapplicationsPage.VisibilityOfDownloadButton());
    }

    @Then("Agent Clicks on Download Button")
    public void AgentClicksOnDownloadButton() throws InterruptedException {
        bpsapplicationsPage.AgentClickOnDownloadButton();
        Thread.sleep(5000);
    }

    @Then("Agent Clicks on Client Radio Button")
    public void AgentClicksOnClientRadioButton() throws InterruptedException {
        bpsapplicationsPage.AgentClickOnBPSApplicationsClientRadioButton();
    }

    @Then("Agent Clicks on View Button")
    public void AgentClicksOnViewButton() throws InterruptedException {
        bpsapplicationsPage.AgentClickOnBPSApplicationsViewButton();
    }

    @And("Check if No Clients are Displayed")
    public void AgentCheckClientListVisibility() throws InterruptedException {
        bpsapplicationsPage.CheckIfNoCLientsDisplayed();
    }

    @Then("Agent View Dashboard for Expanded Farmer")
    public void AgentClickOnExpandedFarmer() throws InterruptedException, IOException {
        myClientsPage.AgentClickOnViewDashboard();
        Thread.sleep(5000);
    }

    // endregion

    // region BISS Code



    // endregion
}
