//package com.stepdefinitions;
//
//import java.io.File;
//import java.io.IOException;
//import java.util.Arrays;
//import java.util.List;
//import java.util.Map;
//import java.util.Properties;
//
//import com.base.*;
//import com.pages.ApplicationPortalPage;
//import com.pages.ExcelPage;
//import com.pages.LoginPage;
//import com.pages.MyClientsPage;
//import io.cucumber.datatable.DataTable;
//import io.cucumber.java.DataTableType;
//import io.cucumber.java.en.And;
//import io.cucumber.java.en.Given;
//import org.openqa.selenium.WebDriver;
//
//public class ExcelDataReaderSteps {
//
//    Properties prop;
//    WebDriver driver;
//    ConfigReader configReader;
//    ApplicationPortalPage applicationPortalPage;
//    MyClientsPage myClientsPage;
//    LoginPage loginPage;
//    DriverManager driverManager;
//
//    public ExcelDataReaderSteps(DriverManager driverManager){
//        try {
////            driver = driverManager.getDriver();
//            this.driverManager=driverManager;
//            driver=driverManager.getDriverInstance();
////            applicationPortalPage = new ApplicationPortalPage(driver);
////            myClientsPage = new MyClientsPage(driver);
//            loginPage = new LoginPage(driver);
//            configReader = new ConfigReader();
//            prop = configReader.init_prop();
//        }
//        catch (Exception e){
//            e.printStackTrace();
//        }
//    }
//
////    @Given("The Agent checks if the file is present at location {string}")
////    public void CheckFile(String location) {
////        File file = new File(location);
////        System.out.println(file.exists());
////    }
//
////    @Given("The Owner ID numbers are acquired from the sheet and the calculations are checked")
////    @Given("Agent Numbers are taken from Excel File and used as UserName")
//    public void the_excel_file_name_and_location_is_given_as(IDataReader dataTable) throws InterruptedException, IOException {
//        // Write code here that turns the phrase above into concrete actions
//        // For automatic transformation, change DataTable to one of
//        // E, List<E>, List<List<E>>, List<Map<K,V>>, Map<K,V> or
//        // Map<K, List<V>>. E,K,V must be a String, Integer, Float,
//        // Double, Byte, Short, Long, BigInteger or BigDecimal.
//        //
//        // For other transformations you can register a DataTableType.
////        System.out.println(dataTable.getAllRows());
////       myClientsPage.GetAgentNumberAsArray(dataTable);
//
////       List<String> ListData = dataTable.getAllRows();
////        System.out.println(ListData);
//        System.out.println(dataTable.getAllRows());
//        loginPage.GetAgentNumbersArray(dataTable);
//
//    }
//
//    // 1. create a another method
//    // 2. Parameter to the method will be a map object
//    // 3. IdataReader will be return type
//    // 4. @DataTableType
//
//    @DataTableType
//    public IDataReader excelToDataTable(Map<String, String> entry) { // [Excel= <fileName>, Location=<FileLocation> ..]
//        ExcelConfiguration config = new ExcelConfiguration.ExcelConfigurationBuilder()
//                .setFileName(entry.get("Excel"))
//                .setFileLocation(entry.get("Location"))
//                .setSheetName(entry.get("Sheet"))
//                .setIndex(Integer.parseInt(entry.getOrDefault("Index", "0")))
//                .build();
//        return new ExcelDataReader(config);
//
//    }
//
////    @And("Get Usernames")
////    public void GetUserNames() throws IOException {
////        myClientsPage.getAllRows();
////        List<String> AgentNumbers = myClientsPage.getAllRows();
////
////    }
//
//}
//
//
