# ====================================================================================================================================
# TC_04_STAFF.feature
# ====================================================================================================================================
@maps @regression @staff
Feature: TC_04_STAFF - Partnership Herd Maps and Download

  # Migrated from legacy "Regression Pack for Generating Map" (BISSAGL-3161 AT-TC-01, 02).
  #
  # BUSINESS FLOW
  #   Herds held in a partnership span multiple herd owners, so a map request must resolve
  #   every parcel across the partnership - whether the search starts from the herd or from
  #   one of its parcels. Once generated, the map is downloadable from the results table.
  #
  # WHAT THIS VALIDATES
  #   1. A partnership herd generates an A3 map across all its parcels, with full metadata.
  #   2. The same holds when the search starts from a parcel belonging to the partnership.
  #   3. The completed map exposes a working download link.
  #
  # TEST DATA NOTE
  #   K1361753 (herd) and K1360100094 (parcel) are hardcoded partnership fixtures. No legacy
  #   query returns partnership herds, so these cannot be DB-resolved without a new query -
  #   substituting a generic submitted herd would silently stop testing the partnership path.
  #   ACTION: add a "partnership herds" DBRouter case to remove these literals.

  Background:
    Given the staff user is logged in to the BISS internal portal as "agr4442"
    And the staff user is on the Map Printing screen

  @e2e @partnership @download
  Scenario: Staff generates and downloads maps spanning a partnership holding

    # SECTION 1 - AT-TC-01 (BISSAGL-14866)
    # Validates: an A3 map generates across all parcels of the partnership herd, records
    # full metadata, settles at its final status, and can be downloaded.
    When the staff user searches Map Printing for partnership herd "K1361753" for scheme year "2023"
    And the staff user requests a map with the following settings
      | parcels | all                 |
      | mapType | Full Color Ortho A3 |
      | legend  | yes                 |
    Then the generated map should be recorded with the following details
      | status     |
      | id         |
      | herdNumber |
      | date       |
    Then the map generation request should be accepted
    And the generated map should reach its final status
    And the staff user should be able to download the generated map

    # SECTION 2 - AT-TC-02 (BISSAGL-14865)
    # Validates: the multi-herd path - starting from a partnership parcel resolves the same
    # holding and produces an equally complete, downloadable map.

    When the staff user searches Map Printing with no parcel number

    When the staff user searches Map Printing for partnership parcel "K1360100094" for scheme year "2023"
    And the staff user requests a map with the following settings
      | parcels | all                 |
      | mapType | Full Color Ortho A3 |
      | legend  | yes                 |
    Then the generated map should be recorded with the following details
      | status     |
      | id         |
      | herdNumber |
      | date       |
    Then the map generation request should be accepted
    And the generated map should reach its final status
    And the staff user should be able to download the generated map
