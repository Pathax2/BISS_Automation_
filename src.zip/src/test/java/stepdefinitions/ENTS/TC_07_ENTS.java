// ===================================================================================================================================
// File          : TC_07_ENTS.java
// Package       : stepdefinitions.ENTS
// Description   : Step definitions for TC_07_ENTS - Transfer Application E2E (Agent to ETF Partner).
//
//                 Only the steps unique to an ETF partner transferee live here. The ETF partner logs in like any other
//                 user, opens My Clients -> Transfers, searches the transferee herd and accepts with the transfer key.
//                 On the partner dashboard the acceptance starts with the ETF button ("Access an application using
//                 Transfer Key"); when that button is not shown the standard View Transfer Application route is taken.
//
//                 Steps in this file (2):
//                   1. the agent logs out and re-logs in as the ETF partner {string}
//                   2. the ETF partner completes the transferee acceptance flow (DataTable)
//
//                 Every other step of TC_07_ENTS.feature / TC_10_ENTS.feature is already defined:
//                   login / portal navigation             -> stepdefinitions.TC_03
//                   tab switching                         -> stepdefinitions.TC_06
//                   login as a named user                 -> stepdefinitions.ENTS.TC_08_ENTS
//                   create / upload / send / key / submit -> stepdefinitions.ENTS.TC_01_ENTS
//                   transferor re-login between sections  -> stepdefinitions.ENTS.TC_03_ENTS
//
//                 Playwright edition (30-09-2026):
//                   - Same step texts, same ObjectRepository keys, same flow.
//                   - The copied Keycloak login (username, PIN loop, TOTP, T&C, Account Expired) and the local
//                     performLogout / performLogin / isVisible copies are replaced by EntsSession.logout / loginAs.
//                     An expired account fails the step with the login in the message; the Selenium copy called
//                     Hooks.markAgentExpired for the BISS runtime agent (a different user).
//                   - Step 2 opens the transferee herd with EntsSession.openTransferOutHerd, which waits for the row of
//                     THAT herd and skips rows marked expired. Selenium slept 2 s and clicked the first View link.
//                   - The acceptance screens are EntsSession.acceptWithTransferKey (shared with TC_05 and TC_08).
//                   - The key comes from TC_01_ENTS.iCapturedTransferKey and is checked before it is typed.
//                   - Runtime data: the ETF partner named in the feature file manages the transferee herd, so the pair is
//                     a cross-agent pick (transfereeAgent row = the partner login, EntsTestData.nextCrossAgentPair) and
//                     the login step uses {transferee.agent}. Plain logins and herds still work, to pin a case.
//
// Author        : Aniket Pathare | aniket.pathare@government.ie
// Date Created  : 31-03-2026 | Updated: 30-09-2026 (Playwright + runtime ENTS data)
// ===================================================================================================================================

package stepdefinitions.ENTS;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;
import org.junit.jupiter.api.Assertions;
import utilities.EntsTestData;

import java.util.Map;
import java.util.logging.Logger;

public class TC_07_ENTS
{
    private static final Logger log = Logger.getLogger(TC_07_ENTS.class.getName());


    // ===================================================================================================================================
    //  ETF PARTNER LOGIN - log out of the agent session, log in as the partner
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent logs out and re-logs in as the ETF partner {string}
    // Description   : Logs out of the current session and logs in as the ETF partner (username, password TD:Password,
    //                 PIN or OTP, TOTP, T&C - EntsSession.loginAs). The feature file then opens Home -> My Clients ->
    //                 Transfers itself, as in the Selenium version.
    // Parameters    : pPartnerUsername (String) - partner login, e.g. "agr15594", or {transferee.agent}
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 30-09-2026 (Playwright, shared login)
    // ***************************************************************************************************************************************************************************************
    @When("the agent logs out and re-logs in as the ETF partner {string}")
    public void theAgentLogsOutAndReLogsInAsTheETFPartner(String pPartnerUsername)
    {
        String iUsername = EntsTestData.resolve(pPartnerUsername);
        log.info("[STEP] When the agent logs out and re-logs in as the ETF partner: " + iUsername);

        EntsSession.logout();
        EntsSession.loginAs(iUsername, "[LOGIN-ETF-PARTNER]");

        log.info("Re-logged in as ETF partner: " + iUsername);
    }


    // ===================================================================================================================================
    //  ETF PARTNER TRANSFEREE ACCEPTANCE
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the ETF partner completes the transferee acceptance flow (DataTable)
    // Description   : 1. Searches the transferee herd in the partner's Transfer Out list and opens its first not-expired row
    //                 2. ETF button (partner dashboard) or View Transfer Application, the captured transfer key, View
    //                 3. Notes, Submit Application to DAFM, T&C, confirm
    //
    //                 DataTable keys:
    //                   transfereeHerd (String) - herd number, or {transferee.herd}
    //                   notes          (String) - transferee notes, e.g. "Approved Test"
    //
    //                 Depends on the key captured by TC_01_ENTS "the transfer key should be captured".
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 30-09-2026 (Playwright + runtime ENTS data)
    // ***************************************************************************************************************************************************************************************
    @And("the ETF partner completes the transferee acceptance flow")
    public void theETFPartnerCompletesTheTransfereeAcceptanceFlow(DataTable pDataTable)
    {
        log.info("[STEP] And the ETF partner completes the transferee acceptance flow");

        Map<String, String> iData = EntsTestData.resolveTable(pDataTable.asMap(String.class, String.class));

        String iTransfereeHerd = iData.get("transfereeHerd").trim();
        String iNotes          = iData.get("notes").trim();
        String iTransferKey    = TC_01_ENTS.iCapturedTransferKey;

        Assertions.assertFalse(iTransferKey == null || iTransferKey.isEmpty(),
                "Transfer key must have been captured in the Transferor flow before the ETF partner can accept.");

        EntsSession.openTransferOutHerd(iTransfereeHerd);
        log.info("Transferee herd opened: " + iTransfereeHerd);

        EntsSession.acceptWithTransferKey(iTransferKey, iNotes);

        log.info("ETF partner transferee acceptance completed for herd: " + iTransfereeHerd
                + " | login=" + EntsTestData.loggedInUser());
    }
}
