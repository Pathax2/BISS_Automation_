Feature: TC_S27 - Regression Pack for Openshift View Application Cases

  # ──────────────────────────────────────────────────────────────────────────
  # Purpose:
  #   End-to-end regression for Openshift covering application view interactions:
  #     - TC01: Force Majeure cancel for scheme years 2025, 2024 and 2023
  #     - TC02: Force Majeure save then unsave for scheme years 2024 and 2023
  #     - TC03: Open View Details dialog and close it
  #     - TC04: Hover over "Determined area with compensation" info icon in Land Details
  #     - TC05-TC08: Skeleton screens for Active Farmer, Land Details, GAEC8, Digitisation Task
  #
  # Common Background:
  #   Openshift staff login as agr4442 → open BISS application.
  #   TC06-TC08 switch to agr11612 for the skeleton screen scenarios.
  #
  # DB Data:
  #   15 herds with Submission, 5 Reference Numbers, 5 LPIS Parcels resolved from DB.
  #   Row references used throughout — no hardcoded herd numbers.
  #
  # Notes:
  #   1. TC01 and TC02 use herd from row 6 across all three scheme years.
  #   2. Force Majeure save/unsave uses a note text field ("addNoteText") before confirming.
  #   3. TC03 opens the second View Details dialog in the mdc-data-table.
  #   4. TC04 uses herd from row 7 to trigger the Land Details info icon.
  #   5. TC05-TC08 are skeleton scenarios — steps to be expanded when screens are ready.
  #
  # Author  : Aniket Pathare | aniket.pathare@government.ie
  # Created : 2026-05-14
  # ──────────────────────────────────────────────────────────────────────────

  Background:
    Given the staff user is on the Openshift staff login page
    When the staff user logs in with username "agr4442"
    And the staff user selects the data protection checkbox and clicks login
    And the staff user opens the "Basic Income Support for Sustainability" application
    Then Get 15 Herds with Submission from DB
    And Get 5 Reference Numbers from DB
    And Get 5 LPIS Parcels from DB

  @tmsLink=BISSAGL-12927 @tmsLink=BISSAGL-12928 @tmsLink=BISSAGL-12929 @tmsLink=BISSAGL-12930
  @tmsLink=BISSAGL-13008 @tmsLink=BISSAGL-13009 @tmsLink=BISSAGL-13010 @tmsLink=BISSAGL-13011 @regression
  Scenario: TC_S27 - Openshift View Application end-to-end regression

    # ── TC01: Force Majeure cancel for scheme years 2025, 2024 and 2023 ──────
    When the staff user opens herd from row 6 for scheme year "2025" and clicks the Force Majeure checkbox
    And the staff user cancels the Force Majeure dialog
    When the staff user opens herd from row 6 for scheme year "2024" and clicks the Force Majeure checkbox
    And the staff user cancels the Force Majeure dialog
    When the staff user opens herd from row 6 for scheme year "2023" and clicks the Force Majeure checkbox
    And the staff user cancels the Force Majeure dialog
    Then no Force Majeure changes should have been saved

    # ── TC02: Force Majeure save then unsave for scheme years 2024 and 2023 ──
    When the staff user opens herd from row 6 for scheme year "2024" and saves Force Majeure with note "Test Save"
    And the staff user toggles Force Majeure again and saves with note "Test UnSave"
    When the staff user opens herd from row 6 for scheme year "2023" and saves Force Majeure with note "Test Save"
    And the staff user toggles Force Majeure again and saves with note "Test UnSave"
    Then the Force Majeure state should be restored to its original value

    # ── TC03: Open View Details dialog from application table and close ───────
    When the staff user opens herd from row 6 for scheme year "2024" and opens the second View Details dialog from the application table
    Then closing the dialog should return to the application summary without errors

    # ── TC04: Hover over Determined area with compensation info icon ──────────
    When the staff user opens herd from row 7 for scheme year "2024" and hovers over the Determined area with compensation info icon in Land Details
    Then the info tooltip should be triggered without errors

    # ── TC05-TC08: Skeleton screens (to be expanded when screens are enabled) ─
    When "agr11612" logs in and opens the BISS application
    Then the Active Farmer, Land Details, GAEC8 and Digitisation Task screens should each be navigable without errors