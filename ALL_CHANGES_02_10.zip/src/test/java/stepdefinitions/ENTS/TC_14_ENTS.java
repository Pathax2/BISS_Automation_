// ===================================================================================================================================
// File          : TC_14_ENTS.java
// Package       : stepdefinitions.ENTS
// Description   : ETF Authorisation steps (TC_14_ENTS - an individual adds an ETF authorisation, the ETF partner checks it).
//
//                 Steps in this file (3):
//                   1. the individual adds ETF authorisation with the following details (DataTable)
//                   2. the ETF partner searches for herd {string} and opens it
//                   3. the ETF authorisation should be visible
//
//                 Playwright edition (22-09-2026):
//                   - Same step texts, same ObjectRepository keys, same flow (including the "already authorised" branch).
//                   - Step 1 checks its Object Repository keys before the first click (none were in the Playwright
//                     repository on 22-09-2026).
//                   - Step 2 uses EntsSession.openTransferOutHerd, which waits for the row of THAT herd and skips rows
//                     marked expired, instead of Thread.sleep + the first View link.
//                   - Step 3 is unchanged on purpose: the Selenium version only checks that "Create Transfer Application"
//                     is shown on the herd page, not the authorisation row itself. Tell us if it should check the row.
//
//                 Kept from Selenium, worth a look:
//                   - The "already authorised" branch is tied to ETF00009 by its key names (iETF00009TableRow ...), while
//                     the ETF comes from the feature file (etfCode). Another ETF code would always take the "add" branch.
//                   - That branch clicks Delete, then Remove, then Edit on the same row. If the row is gone after Remove,
//                     Edit cannot be clicked. Please confirm the intended order on screen.
//
// Author        : Aniket Pathare | aniket.pathare@government.ie
// Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
// ===================================================================================================================================

package stepdefinitions.ENTS;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;
import utilities.EntsTestData;
import utilities.ObjReader;

import java.util.Map;
import java.util.logging.Logger;

import static commonFunctions.CommonFunctions.iAction;
import static stepdefinitions.ENTS.EntsSession.isVisible;

public class TC_14_ENTS
{
    private static final Logger log = Logger.getLogger(TC_14_ENTS.class.getName());


    // ***************************************************************************************************************************************************************************************
    // Step          : the individual adds ETF authorisation with the following details (DataTable)
    // Description   : Allow Entitlement -> when the ETF00009 row is already there: Delete, Remove, Edit, the two limits,
    //                 Update; otherwise: Add ETF Authorisation, pick the ETF, the two limits, confirm.
    //
    //                 DataTable keys:
    //                   etfCode          (String) - ETF as shown in the dropdown, e.g. "SMYTH, SHEILA - [ETF00009]"
    //                   txorEntsAllowed  (String) - entitlements allowed as transferor, e.g. "2"
    //                   txeeEntsAllowed  (String) - entitlements allowed as transferee, e.g. "3"
    //
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @And("the individual adds ETF authorisation with the following details")
    public void theIndividualAddsETFAuthorisation(DataTable pDataTable)
    {
        log.info("[STEP] And the individual adds ETF authorisation with the following details");

        EntsSupport.requireKeys("the individual adds ETF authorisation with the following details",
                "iAllowEntitlementBtn", "iETF00009TableRow", "iETF00009DeleteBtn", "iRemoveETABtn", "iETF00009EditBtn",
                "UpdateETABtn", "iAddETFAuthorisationBtn", "iETFAvailableDropdown", "iTxorEntsAllowedField",
                "iTxeeEntsAllowedField", "iAddETFAuthorisationConfirmBtn");

        Map<String, String> iData = EntsTestData.resolveTable(pDataTable.asMap(String.class, String.class));

        String iEtfCode = iData.get("etfCode").trim();
        String iTxor    = iData.get("txorEntsAllowed").trim();
        String iTxee    = iData.get("txeeEntsAllowed").trim();

        iAction("CLICK", "XPATH", ObjReader.getLocator("iAllowEntitlementBtn"), null);

        if (isVisible(ObjReader.getLocator("iETF00009TableRow"), 2))
        {
            log.info("[ETF-AUTH] ETF00009 is already authorised - removing and editing the existing row (Selenium order).");
            iAction("CLICK",   "XPATH", ObjReader.getLocator("iETF00009DeleteBtn"), null);
            iAction("CLICK",   "XPATH", ObjReader.getLocator("iRemoveETABtn"), null);
            iAction("CLICK",   "XPATH", ObjReader.getLocator("iETF00009EditBtn"), null);
            iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iTxorEntsAllowedField"), iTxor);
            iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iTxeeEntsAllowedField"), iTxee);
            iAction("CLICK",   "XPATH", ObjReader.getLocator("UpdateETABtn"), null);
            log.info("[ETF-AUTH] Existing ETF authorisation updated: txor=" + iTxor + " txee=" + iTxee);
        }
        else
        {
            iAction("CLICK",   "XPATH", ObjReader.getLocator("iAddETFAuthorisationBtn"), null);
            iAction("LIST",    "XPATH", ObjReader.getLocator("iETFAvailableDropdown"), iEtfCode);
            iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iTxorEntsAllowedField"), iTxor);
            iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iTxeeEntsAllowedField"), iTxee);
            iAction("CLICK",   "XPATH", ObjReader.getLocator("iAddETFAuthorisationConfirmBtn"), null);
            log.info("[ETF-AUTH] ETF authorisation added: " + iEtfCode + " | txor=" + iTxor + " txee=" + iTxee);
        }
    }


    // ***************************************************************************************************************************************************************************************
    // Step          : the ETF partner searches for herd {string} and opens it
    // Description   : Searches the herd in the ETF partner's list and opens its first not-expired row.
    // Parameters    : pHerd (String) - herd number, e.g. "Y104069X" (a runtime token also works)
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @And("the ETF partner searches for herd {string} and opens it")
    public void theETFPartnerSearchesForHerdAndOpensIt(String pHerd)
    {
        String iHerd = EntsTestData.resolve(pHerd);
        log.info("[STEP] And the ETF partner searches for herd " + iHerd + " and opens it");

        EntsSession.openTransferOutHerd(iHerd);
    }


    // ***************************************************************************************************************************************************************************************
    // Step          : the ETF authorisation should be visible
    // Description   : Same check as Selenium: the herd page shows "Create Transfer Application" for the ETF partner.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @Then("the ETF authorisation should be visible")
    public void theETFAuthorisationShouldBeVisible()
    {
        log.info("[STEP] Then the ETF authorisation should be visible");
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iCreateTransferBtn"), null);
    }
}
