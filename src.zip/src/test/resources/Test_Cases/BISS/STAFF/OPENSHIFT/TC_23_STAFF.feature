Feature: TC_S23 - Regression Pack for AMS Internal Screen Filter and Search Options

  # ──────────────────────────────────────────────────────────────────────────
  # Purpose:
  #   Validates the filter and search options available on the AMS internal screen.
  #   Currently a navigation-level regression — the multi-select AMS filter steps
  #   will be expanded once dedicated step definitions are available.
  #
  # Common Background:
  #   Staff login as agr4442 → open BISS application.
  #
  # DB Data:
  #   No DB pool step required. Fixed herd IFP10100 (2024) has known AMS filter data.
  #
  # Notes:
  #   1. agr4442 is the authorised staff user for AMS filter interaction.
  #   2. The AMS filter UI uses multi-select dropdowns that require dedicated
  #      step definitions — these will be added when the steps are finalised.
  #
  # Author  : Aniket Pathare | aniket.pathare@government.ie
  # Created : 2026-05-14
  # ──────────────────────────────────────────────────────────────────────────

  Background:
    Given the staff user is on the staff login page
    When the staff user logs in with username "agr4442"
    And the staff user selects the data protection checkbox and clicks login
    And the staff user opens the "Basic Income Support for Sustainability" application

  @tmsLink=BISSAGL-14725 @regression
  Scenario: TC_S23 - AMS Internal Filter and Search end-to-end regression

    # ── TC01: Navigate to AMS tab for IFP10100 and verify filter options load ─
    When the staff user searches for herd "IFP10100" for scheme year "2024" and views the application
    And the staff user navigates to "Inspections" and switches to the AMS tab
    Then the AMS filter and search panel should be visible and accessible on screen