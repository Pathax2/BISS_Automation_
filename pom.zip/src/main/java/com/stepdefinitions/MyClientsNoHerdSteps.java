package com.stepdefinitions;


import com.base.ConfigReader;
import com.base.DriverManager;
import com.pages.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;

import com.pages.LoginPage;

import java.util.Properties;

public class MyClientsNoHerdSteps {

    LoginPage loginPage;
    //BPSdashboardPage bpsdashboardPage;
    MyClientsNoHerdPage myclientsnoherdPage;
    WebDriver driver;
    Properties prop;
    ConfigReader configReader;
    DriverManager driverManager;

    public MyClientsNoHerdSteps(DriverManager driverManager){
        try {
//            driver = driverManager.getDriver();
            this.driverManager=driverManager;
            driver=driverManager.getDriverInstance();
            loginPage = new LoginPage(driver);
            //bpsdashboardPage = new BPSdashboardPage(driver);
            myclientsnoherdPage = new MyClientsNoHerdPage(driver);
            configReader = new ConfigReader();
            prop = configReader.init_prop();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    @And("Agent is on My Clients No Herd Page")
    public void MyClientsNoHerdPage() {
        String title = driver.getTitle();
        System.out.println("title of My Clients No Herd Page" + title);
    }

    @And("Agent Selects a Client with No Herd by Clicking on Checkbox")
    public void AgentClickOnClientNoHerdRadioButton() {
        myclientsnoherdPage.AgentClickOnClientRadioButton();
    }

    @Then("Click on the Client with No Herd View Button")
    public void AgentClickOnClientNoHerdViewButton() throws InterruptedException {
        myclientsnoherdPage.AgentClickOnViewButton();
        Thread.sleep(2000);
    }

    @And("Agent Clicks on the Create Client Awaiting Herd Number")
    public void AgentClickOnCreateClientAwaitingHerdRadioButton() {
        myclientsnoherdPage.AgentClickOnCreateClientAwaitingHerdNumberButton();
    }

    @And("Agent is on the Create Client Awaiting Herd Number Page")
    public void CreateClientAwaitingHerdNumberHerdPage() {
        String title = driver.getTitle();
        System.out.println("title of Create Client Awaiting Herd Number Page" + title);
    }

    @And("Agent enters the Client Name {string}")
    public void AgentEnterClientFullName(String arg0) {
        myclientsnoherdPage.AgentEnterClientAwaitingHerdNumberDetailsFullName(arg0);
    }

    @And("Agent enters the Address 1 {string}")
    public void AgentEnterClientAddress1(String arg0) {
        myclientsnoherdPage.AgentEnterClientAwaitingHerdNumberDetailsAddress1(arg0);
    }

    @And("Agent enters the Address 2 {string}")
    public void AgentEnterClientAddress2(String arg0) {
        myclientsnoherdPage.AgentEnterClientAwaitingHerdNumberDetailsAddress2(arg0);
    }

    @And("Agent enters the Address 3 {string}")
    public void AgentEnterClientAddress3(String arg0) {
        myclientsnoherdPage.AgentEnterClientAwaitingHerdNumberDetailsAddress3(arg0);
    }

    @And("Agent enters the Phone Number {string}")
    public void AgentEnterClientPhoneNumber(String arg0) {
        myclientsnoherdPage.AgentEnterClientAwaitingHerdNumberDetailsContactNumber(arg0);
    }

    @And("Agent Click on the BPS Checkbox")
    public void AgentClickOnBPSCheckBox() {
        myclientsnoherdPage.AgentClickOnClientAwaitingHerdNumberDetailsBPSCheckBox();
    }

    @And("Agent Click on the Transfers Checkbox")
    public void AgentClickOnTransfersCheckBox() {
        myclientsnoherdPage.AgentClickOnClientAwaitingHerdNumberDetailsTransfersCheckBox();
    }

    @And("Agent Click on the NRYFS Checkbox")
    public void AgentClickOnNRYFSCheckBox() {
        myclientsnoherdPage.AgentClickOnClientAwaitingHerdNumberDetailsNRYFSCheckBox();
    }

    @Then("Click on the Create Client Button")
    public void AgentClickOnCreateClientButton() {
        myclientsnoherdPage.AgentClickOnCreateClientButton();
    }

    @And("Click on No Button in the Modal")
    public void AgentClickOnConfimationModalNoButton() {
        myclientsnoherdPage.AgentClickOnClientAwaitingHerdConfirmationModalNoButton();
    }

    @And("Click on Yes Button in the Modal")
    public void AgentClickOnConfimationModalYesButton() {
        myclientsnoherdPage.AgentClickOnClientAwaitingHerdConfirmationModalYesButton();
    }

}
