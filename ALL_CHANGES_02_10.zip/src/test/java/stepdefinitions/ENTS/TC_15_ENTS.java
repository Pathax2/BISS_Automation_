// ===================================================================================================================================
// File          : TC_15_ENTS.java
// Package       : stepdefinitions.ENTS
// Description   : Staff ENTSCore login + verification steps, and the OwnerID / side-nav steps they need
//                 (TC_15_ENTS, TC_16_ENTS, TC_17_ENTS).
//
//                 Steps in this file (9):
//                   1. the agent navigates to the {string} side nav tab
//                   2. the agent captures the OwnerID of the herd
//                   3. the agent searches for herd {string} and opens it
//                   4. the agent verifies the entitlement position is displayed
//                   5. the staff user logs into ENTSCore as {string}
//                   6. the staff searches for the herd by OwnerID
//                   7. the staff navigates to year {string} and {string} tab
//                   8. the NRCISYF submission should be visible in ENTSCore
//                   9. the transfer submission should be visible in ENTSCore
//
//                 Playwright edition (22-09-2026, checked against the Selenium file again on 02-10-2026):
//                   - Same step texts, same ObjectRepository keys, same flow.
//                   - Step 3 uses EntsSession.openTransferOutHerd (waits for the row of THAT herd, skips expired rows)
//                     instead of Thread.sleep + the first View link.
//                   - Step 5: the Selenium logout (Exit, Logout, popup) is the shared EntsSession.logout; the cookies are
//                     cleared as in Selenium. The staff login page address was Hooks.istaffUrl in Selenium; the
//                     Playwright Hooks has no such field, so staffUrl() below reads it (see its comment).
//                   - The private performLogin / performLogout copies are gone (performLogin was never called).
//                   - Steps 2 and 4-9 check their Object Repository keys before the first click (none were in the
//                     Playwright repository on 22-09-2026 - see the key list in STEP_07).
//
// Author        : Aniket Pathare | aniket.pathare@government.ie
// Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
// ===================================================================================================================================

package stepdefinitions.ENTS;

import commonFunctions.UiHelpers;
import io.cucumber.java.en.*;
import stepdefinitions.Hooks;
import utilities.ConfigManager;
import utilities.EntsTestData;
import utilities.ExcelUtilities;
import utilities.ObjReader;

import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static commonFunctions.CommonFunctions.iAction;

public class TC_15_ENTS
{
    private static final Logger log = Logger.getLogger(TC_15_ENTS.class.getName());

    // OwnerID captured from the Entitlements / Usage page, used by the staff search. Also published as the system
    // property lastCapturedOwnerID (same as Selenium).
    private static String iCapturedOwnerID = "";

    // Config sheet columns tried for the staff login address when -Dstaff.url / BISS_STAFF_URL is not set
    private static final String[] STAFF_URL_COLUMNS = { "StaffURL", "Staff URL", "Staff_URL", "StaffUrl" };


    // ===================================================================================================================================
    //  AGENT SIDE - navigation and OwnerID
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent navigates to the {string} side nav tab
    // Description   : Clicks the farmer side-navigation link with that text (same union XPath as Selenium).
    // Parameters    : pTabName (String) - e.g. "Entitlements / Usage", "Transfers", "NR-CISYF"
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @And("the agent navigates to the {string} side nav tab")
    public void theAgentNavigatesToTheSideNavTab(String pTabName)
    {
        log.info("[STEP] And the agent navigates to the " + pTabName + " side nav tab");
        iAction("CLICK", "XPATH",
                "//a[contains(normalize-space(),'" + pTabName + "')] | //mat-list-item[contains(.,'" + pTabName + "')]", null);
    }


    // ***************************************************************************************************************************************************************************************
    // Step          : the agent captures the OwnerID of the herd
    // Description   : Reads the "Owner Id: 123456" text and keeps the number for the staff search.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @And("the agent captures the OwnerID of the herd")
    public void theAgentCapturesTheOwnerID()
    {
        log.info("[STEP] And the agent captures the OwnerID of the herd");
        EntsSupport.requireKeys("the agent captures the OwnerID of the herd", "iOwnerIDField");

        String iOwnerIdText = iAction("GETTEXT", "XPATH", ObjReader.getLocator("iOwnerIDField"), null);
        log.info("Raw OwnerID text returned: " + iOwnerIdText);

        Matcher iMatcher = Pattern.compile("Owner\\s*Id:\\s*(\\d+)").matcher(iOwnerIdText == null ? "" : iOwnerIdText);
        if (!iMatcher.find())
        {
            throw new RuntimeException("Unable to extract Owner ID from text: " + iOwnerIdText);
        }

        iCapturedOwnerID = iMatcher.group(1);
        System.setProperty("lastCapturedOwnerID", iCapturedOwnerID);
        log.info("OwnerID captured: " + iCapturedOwnerID);
    }


    // ***************************************************************************************************************************************************************************************
    // Step          : the agent searches for herd {string} and opens it
    // Description   : Searches the herd in the Transfers list and opens its first not-expired row.
    // Parameters    : pHerd (String) - herd number (a runtime token also works)
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @When("the agent searches for herd {string} and opens it")
    public void theAgentSearchesForHerdAndOpensIt(String pHerd)
    {
        String iHerd = EntsTestData.resolve(pHerd);
        log.info("[STEP] When the agent searches for herd " + iHerd + " and opens it");
        EntsSession.openTransferOutHerd(iHerd);
    }


    // ***************************************************************************************************************************************************************************************
    // Step          : the agent verifies the entitlement position is displayed
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @Then("the agent verifies the entitlement position is displayed")
    public void theAgentVerifiesEntitlementPosition()
    {
        log.info("[STEP] Then the agent verifies the entitlement position is displayed");
        EntsSupport.requireKeys("the agent verifies the entitlement position is displayed", "iEntitlementPositionTable");
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iEntitlementPositionTable"), null);
    }


    // ===================================================================================================================================
    //  STAFF SIDE - ENTSCore
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the staff user logs into ENTSCore as {string}
    // Description   : Logs out of the agent session, clears the cookies, opens the staff login page, types username +
    //                 TD:Password, ticks the data protection box, logs in and opens ENTS.
    // Parameters    : pStaffUsername (String) - staff login, e.g. "AGR2214"
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @When("the staff user logs into ENTSCore as {string}")
    public void theStaffUserLogsIntoENTSCore(String pStaffUsername)
    {
        log.info("[STEP] When the staff user logs into ENTSCore as: " + pStaffUsername);
        EntsSupport.requireKeys("the staff user logs into ENTSCore", "iStaffDataProtectionCheckbox", "iENTSLink");

        String iStaffUrl = staffUrl();

        EntsSession.logout();
        UiHelpers.clearCookies();
        UiHelpers.navigateTo(iStaffUrl);

        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iUsernametxtbox"), pStaffUsername);
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iPasswordtxtbox"), "TD:Password");
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iStaffDataProtectionCheckbox"), null);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iLoginbtn"), null);

        iAction("CLICK", "XPATH", ObjReader.getLocator("iENTSLink"), null);
        EntsTestData.setLoggedInUser(pStaffUsername);
        log.info("Staff logged into ENTSCore: " + pStaffUsername);
    }


    // ***************************************************************************************************************************************************************************************
    // Step          : the staff searches for the herd by OwnerID
    // Description   : Types the captured OwnerID and clicks Search (the OwnerID link click stays commented out, as in
    //                 Selenium).
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @And("the staff searches for the herd by OwnerID")
    public void theStaffSearchesForHerdByOwnerID()
    {
        log.info("[STEP] And the staff searches for the herd by OwnerID: " + iCapturedOwnerID);
        EntsSupport.requireKeys("the staff searches for the herd by OwnerID", "iStaffHerdSearchField", "iStaffSearchBtn");

        if (iCapturedOwnerID.isBlank())
        {
            throw new IllegalStateException("[STAFF] No OwnerID captured - 'the agent captures the OwnerID of the herd' must run first.");
        }

        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iStaffHerdSearchField"), iCapturedOwnerID);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iStaffSearchBtn"), null);
        // iAction("CLICK", "XPATH", ObjReader.getLocator("iStaffOwnerIDLink"), null);
    }


    // ***************************************************************************************************************************************************************************************
    // Step          : the staff navigates to year {string} and {string} tab
    // Parameters    : pYear (String) - e.g. "2026" | pTab (String) - e.g. "NR / CISYF", "Transfers"
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @And("the staff navigates to year {string} and {string} tab")
    public void theStaffNavigatesToYearAndTab(String pYear, String pTab)
    {
        log.info("[STEP] And the staff navigates to year " + pYear + " and " + pTab + " tab");
        iAction("CLICK", "XPATH", "//a[contains(text(),'" + pYear + "')]", null);
        iAction("CLICK", "XPATH", "//a[contains(normalize-space(),'" + pTab + "')] | //span[contains(text(),'" + pTab + "')]", null);
    }


    // ***************************************************************************************************************************************************************************************
    // Step          : the NRCISYF submission should be visible in ENTSCore
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @Then("the NRCISYF submission should be visible in ENTSCore")
    public void theNRCISYFSubmissionShouldBeVisibleInENTSCore()
    {
        log.info("[STEP] Then the NRCISYF submission should be visible in ENTSCore");
        EntsSupport.requireKeys("the NRCISYF submission should be visible in ENTSCore", "iStaffNRCISYFSection");
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iStaffNRCISYFSection"), null);
    }


    // ***************************************************************************************************************************************************************************************
    // Step          : the transfer submission should be visible in ENTSCore
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @Then("the transfer submission should be visible in ENTSCore")
    public void theTransferSubmissionShouldBeVisibleInENTSCore()
    {
        log.info("[STEP] Then the transfer submission should be visible in ENTSCore");
        EntsSupport.requireKeys("the transfer submission should be visible in ENTSCore", "iStaffTransfersSection");
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iStaffTransfersSection"), null);
    }


    // ===================================================================================================================================
    //  HELPERS
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Function Name : staffUrl
    // Description   : Address of the staff login page (Hooks.istaffUrl in Selenium). Looked up in this order:
    //                   1. staff.url through ConfigManager (-Dstaff.url=..., BISS_STAFF_URL, application-<env>.properties)
    //                   2. the Config sheet of TestData.xlsx, row of the current environment, first column found of
    //                      StaffURL / Staff URL / Staff_URL / StaffUrl
    //                 Fails with a clear message when neither is set.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 22-09-2026
    // ***************************************************************************************************************************************************************************************
    private static String staffUrl()
    {
        String iUrl = ConfigManager.getOrDefault("staff.url", "").trim();
        if (!iUrl.isEmpty())
        {
            log.info("[STAFF] Staff login URL from staff.url: " + iUrl);
            return iUrl;
        }

        String iEnvironment = Hooks.iEnvironment == null ? "" : Hooks.iEnvironment.trim();
        try
        {
            ExcelUtilities iExcel = new ExcelUtilities(
                    ConfigManager.getOrDefault("test.data.file.path", "src/test/resources/Test_Data/TestData.xlsx"));
            int iRow = iExcel.findRow("Config", "Env", iEnvironment);
            if (iRow != -1)
            {
                for (String iColumn : STAFF_URL_COLUMNS)
                {
                    try
                    {
                        String iValue = iExcel.getCellValue("Config", iRow, iColumn);
                        if (iValue != null && !iValue.trim().isEmpty())
                        {
                            log.info("[STAFF] Staff login URL from Config sheet column '" + iColumn + "': " + iValue.trim());
                            return iValue.trim();
                        }
                    }
                    catch (Exception iNoColumn)
                    {
                        // column not in the sheet - try the next name
                    }
                }
            }
        }
        catch (Exception iExcelError)
        {
            log.warning("[STAFF] Could not read the Config sheet: " + iExcelError.getMessage());
        }

        throw new IllegalStateException("[STAFF] Staff login URL not set. Add staff.url to application-" + iEnvironment
                + ".properties (or pass -Dstaff.url=...), or a StaffURL column to the Config sheet.");
    }
}
