package com.base;

import java.util.Objects;

public class ExcelConfiguration {

    // Private fields that were passed as datatable format in the feature file
    private final String fileName;

    public String getFileName() {
        return fileName;
    }

    public String getFileLocation() {
        return fileLocation;
    }

    public String getSheetName() {
        return sheetName;
    }

    public int getIndex() {
        return index;
    }

    private final String fileLocation;
    private final String sheetName;
    // this denotes that by default user will want to read all rows from the excel file
    private int index = -1;

    // Private Constructor so that End User needs a nested static class to get the instance of the configuration
    private ExcelConfiguration(String fileName, String fileLocation, String sheetName, int index) {
        this.fileName = fileName;
        this.fileLocation = fileLocation;
        this.sheetName = sheetName;
        this.index = index;
    }

    // Following methods are Setter methods that are going to set the values for all the variables
    // return type is ExcelConfigurationBuilder so we can invoke other setter methods on the same object
    public static class ExcelConfigurationBuilder {
        private String fileName;
        private String fileLocation;
        private String sheetName;
        private int index = -1;

        public ExcelConfigurationBuilder setFileName(String fileName) {
            this.fileName = fileName;
            return this;
        }

        public ExcelConfigurationBuilder setFileLocation(String fileLocation) {
            this.fileLocation = fileLocation;
            return this;
        }

        public ExcelConfigurationBuilder setSheetName(String sheetName) {
            this.sheetName = sheetName;
            return this;
        }

        public ExcelConfigurationBuilder setIndex(int index) {
            this.index = index;
            return this;
        }

        // Responsibility of following Build method is to create instance of ExcelConfiguration class
        // When the following method is called it will create an object of this class
        public ExcelConfiguration build() {
            // Will throw exception if not initialised or if value not given
            // In short it is a validation
            Objects.requireNonNull(fileName);
            Objects.requireNonNull(fileLocation);
            Objects.requireNonNull(sheetName);
            return new ExcelConfiguration(fileName, fileLocation, sheetName, index);
        }


    }

}