Feature: TC_S29 - Regression Pack for Openshift Home Screen Application Search

  # ──────────────────────────────────────────────────────────────────────────
  # Purpose:
  #   End-to-end regression for all search modes on the Openshift Home Screen:
  #     - TC01: Valid herd number returns results
  #     - TC02: Invalid herd number shows validation error
  #     - TC03: Empty search shows both herd and reference validation errors
  #     - TC04: Reference Number search returns and opens application
  #     - TC05: Farmer name and county search
  #     - TC06: Numeric surname shows validation error
  #     - TC07: Valid parcel search — verify View Claimants, Commonage, History and Map buttons
  #     - TC08: Invalid parcel — clear — whitespace input
  #     - TC09: Reference No. tab search with valid reference number
  #     - TC10: Reference No. tab with invalid reference shows error
  #     - TC11: Online Response tab search without filters
  #     - TC12: Online Response tab filtered by herd number
  #
  # Common Background:
  #   Openshift staff login as agr4442 → open BISS application.
  #
  # DB Data:
  #   15 herds with Submission, 15 Reference Numbers, 15 LPIS Parcels from DB.
  #   Row references used throughout — no hardcoded values in scenario steps.
  #
  # Notes:
  #   1. TC07 verifies all four parcel action buttons in one flow.
  #      The GIS map opens and must be returned from using the Return to Land Details button.
  #   2. Error messages in TC02, TC03, TC10 use a non-span wrapper variant —
  #      handled by the step definition.
  #
  # Author  : Aniket Pathare | aniket.pathare@government.ie
  # Created : 2026-05-14
  # ──────────────────────────────────────────────────────────────────────────

  Background:
    Given the staff user is on the Openshift staff login page
    When the staff user logs in with username "agr4442"
    And the staff user selects the data protection checkbox and clicks login
    And the staff user opens the "Basic Income Support for Sustainability" application
    Then Get 15 Herds with Submission from DB
    And Get 15 Reference Numbers from DB
    And Get 15 LPIS Parcels from DB

  @tmsLink=BISSAGL-18521 @tmsLink=BISSAGL-18524 @tmsLink=BISSAGL-18541 @tmsLink=BISSAGL-18544
  @tmsLink=BISSAGL-18546 @tmsLink=BISSAGL-18548 @tmsLink=BISSAGL-18653 @tmsLink=BISSAGL-18655
  @tmsLink=BISSAGL-18657 @tmsLink=BISSAGL-18659 @tmsLink=BISSAGL-18661 @tmsLink=BISSAGL-18665
  @tmsLink=BISSAGL-18668 @regression
  Scenario: TC_S29 - Openshift Home Screen Application Search end-to-end regression

    # ── TC01: Valid herd number search ────────────────────────────────────────
    When the staff user searches for herd with submission from row 7 for scheme year "2024"
    Then application search results should be displayed

    # ── TC02: Invalid herd number shows validation error ──────────────────────
    When the staff user searches for herd "ASUDASHADI" for scheme year "2024"
    Then the validation error "The herd number you entered is invalid" should be displayed

    # ── TC03: Empty search shows both required field errors ───────────────────
    When the staff user submits the search form without entering any search criteria
    Then the validation errors "The herd number you entered is invalid" and "The reference number you entered is invalid" should both be displayed

    # ── TC04: Reference Number search and open application ───────────────────
    When the staff user searches for reference number from row 4 for scheme year "2024" and views the application
    Then the application summary should be displayed

    # ── TC05: Farmer name and county search ──────────────────────────────────
    When the staff user switches to Farmer search mode and searches with surname "mc" and county "Donegal"
    Then farmer search results should be displayed

    # ── TC06: Numeric surname shows validation error ──────────────────────────
    When the staff user switches to Farmer search mode and searches with surname "123" and county "Donegal"
    Then a farmer name validation error should be displayed

    # ── TC07: Valid parcel — verify all four action buttons ───────────────────
    When the staff user switches to the Parcels tab and searches for LPIS parcel from row 8 for scheme year "2024"
    Then the View Claimants, View Commonage, Parcel History and View Map action buttons should all function correctly
    And the staff user returns from the GIS map to Land Details using the Return to Land Details button

    # ── TC08: Invalid parcel — clear field — whitespace input ─────────────────
    When the staff user switches to the Parcels tab and searches for invalid parcel "adssdasd" for scheme year "2024"
    And the staff user clears the search field and searches again with whitespace only
    Then no parcel results should be returned for invalid inputs

    # ── TC09: Reference No. tab — valid reference number search ──────────────
    When the staff user switches to the "Reference No." tab and searches for reference from row 2 for scheme year "2023"
    Then reference number search results should be displayed

    # ── TC10: Reference No. tab — invalid reference number shows error ────────
    When the staff user switches to the "Reference No." tab and searches for "adssdasd"
    Then the validation error "Invalid reference no." should be displayed

    # ── TC11: Online Response — search without filters ────────────────────────
    When the staff user switches to the "Online Response" tab and submits a search without filters
    Then online response results should be returned

    # ── TC12: Online Response — filtered by herd number from row 8 ───────────
    When the staff user switches to the "Online Response" tab and enters herd from row 8 as a filter
    Then filtered online response results should be returned