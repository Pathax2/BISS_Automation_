
Feature: TC_S28 - Regression Pack for Openshift Notes and History Screen

  # ──────────────────────────────────────────────────────────────────────────
  # Purpose:
  #   End-to-end regression for the Openshift Notes/History screen.
  #   Covers TC01-TC08 all using herd row 7 for scheme year 2024:
  #     - TC01: Navigate to Notes/History and click Add Note
  #     - TC02-TC08: Navigate to Notes/History — each covers a distinct behaviour
  #                  to be expanded per TC when full steps are available
  #
  # Common Background:
  #   Openshift staff login as agr4442 → open BISS application.
  #
  # DB Data:
  #   15 herds with Submission, 5 Reference Numbers, 5 LPIS Parcels resolved from DB.
  #   Row 7 used for all eight TC blocks.
  #
  # Notes:
  #   1. All TCs in this feature target the same herd and scheme year —
  #      this matches the legacy design where each TC tests a distinct
  #      Notes/History page behaviour (add note, filter, sort, etc.).
  #   2. Full step assertions for TC02-TC08 will be added when the
  #      Notes/History-specific step definitions are finalised.
  #
  # Author  : Aniket Pathare | aniket.pathare@government.ie
  # Created : 2026-05-14
  # ──────────────────────────────────────────────────────────────────────────

  Background:
    Given the staff user is on the Openshift staff login page
    When the staff user logs in with username "agr4442"
    And the staff user selects the data protection checkbox and clicks login
    And the staff user opens the "Basic Income Support for Sustainability" application
    Then Get 15 Herds with Submission from DB
    And Get 5 Reference Numbers from DB
    And Get 5 LPIS Parcels from DB

  @tmsLink=BISSAGL-18477 @tmsLink=BISSAGL-18479 @tmsLink=BISSAGL-18481 @tmsLink=BISSAGL-18483
  @tmsLink=BISSAGL-18486 @tmsLink=BISSAGL-18492 @tmsLink=BISSAGL-18495 @tmsLink=BISSAGL-18498 @regression
  Scenario: TC_S28 - Openshift Notes and History end-to-end regression

    # ── TC01: Navigate to Notes/History and click Add Note ────────────────────
    When the staff user opens herd from row 7 for scheme year "2024" and navigates to Notes/History
    Then the Add Note button should be visible and clickable

    # ── TC02-TC08: Notes/History screen regression paths ─────────────────────
    When the staff user opens herd from row 7 for scheme year "2024" and navigates to Notes/History
    Then the Notes/History screen should load without errors (regression path 2)

    When the staff user opens herd from row 7 for scheme year "2024" and navigates to Notes/History
    Then the Notes/History screen should load without errors (regression path 3)

    When the staff user opens herd from row 7 for scheme year "2024" and navigates to Notes/History
    Then the Notes/History screen should load without errors (regression path 4)

    When the staff user opens herd from row 7 for scheme year "2024" and navigates to Notes/History
    Then the Notes/History screen should load without errors (regression path 5)

    When the staff user opens herd from row 7 for scheme year "2024" and navigates to Notes/History
    Then the Notes/History screen should load without errors (regression path 6)

    When the staff user opens herd from row 7 for scheme year "2024" and navigates to Notes/History
    Then the Notes/History screen should load without errors (regression path 7)

    When the staff user opens herd from row 7 for scheme year "2024" and navigates to Notes/History
    Then the Notes/History screen should load without errors (regression path 8)