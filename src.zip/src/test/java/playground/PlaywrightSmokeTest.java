// ===================================================================================================================================
// File          : PlaywrightSmokeTest.java
// Package       : playground
// Description   : STEP 01 installation check - NOT part of the framework.
//                 Proves that the Playwright jar, the browser download and the SIT network path all work
//                 before any framework file is migrated.
//
//                 Run it from IntelliJ with the green arrow next to the method (mvn test will NOT pick it up,
//                 because Surefire only includes TestRunner.java).
//
//                 Optional VM options (Run > Edit Configurations > Modify options > Add VM options):
//                   -Dpw.channel=chrome       use the Google Chrome already installed on the laptop (no download needed)
//                   -Dpw.channel=msedge      use the installed Microsoft Edge
//                   -Dsmoke.url=https://...  open a different URL
//                 Optional environment variable:
//                   PWDEBUG=1                opens the Playwright Inspector so you can step through each action
//
// Author        : Aniket Pathare | aniket.pathare@goverment.ie
// Date Created  : 15-09-2026
// ===================================================================================================================================

package playground;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import org.junit.jupiter.api.Test;

import java.nio.file.Paths;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

public class PlaywrightSmokeTest
{
       private static final String iUrl = System.getProperty("smoke.url",
               "https://biss-inet-ui-biss-sit.apps.services1.agriculture.gov.ie/#/");

       @Test
       void openBissLandingPage()
       {
              // try-with-resources closes the browser and the Playwright driver process even when the test fails
              try (Playwright iPlaywright = Playwright.create())
              {
                     BrowserType.LaunchOptions iLaunchOptions = new BrowserType.LaunchOptions()
                             .setHeadless(false)      // you can watch the browser
                             .setSlowMo(500);         // 0.5 s pause between actions, only for learning

                     String iChannel = System.getProperty("pw.channel", "").trim();
                     if (!iChannel.isEmpty())
                     {
                            iLaunchOptions.setChannel(iChannel);
                     }

                     Browser        iBrowser = iPlaywright.chromium().launch(iLaunchOptions);
                     BrowserContext iContext = iBrowser.newContext(new Browser.NewContextOptions().setIgnoreHTTPSErrors(true));
                     Page           iPage    = iContext.newPage();

                     iPage.navigate(iUrl);
                     System.out.println("[SMOKE] Browser : " + iBrowser.browserType().name() + " " + iBrowser.version());
                     System.out.println("[SMOKE] Title   : " + iPage.title());

                     // Same XPath as iWelcomeLoginBtn in ObjectRepository.properties - only the "xpath=" prefix is new
                     Locator iLoginButton = iPage.locator("xpath=//span[normalize-space()='Log in']");

                     // Web-first assertion: retries automatically for up to 5 seconds, no explicit wait needed
                     assertThat(iLoginButton).isVisible();

                     iPage.screenshot(new Page.ScreenshotOptions().setPath(Paths.get("target/playwright-smoke.png")));
                     System.out.println("[SMOKE] PASS - screenshot saved to target/playwright-smoke.png");
              }
       }
}
