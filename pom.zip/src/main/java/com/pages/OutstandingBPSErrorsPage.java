package com.pages;

import com.base.ActionClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class OutstandingBPSErrorsPage {


    WebDriver driver;
    ActionClass actions;

    By HomeNavBarLink = By.xpath("//a[contains(text(),'Home')]");
    By ContactUsNavBarLink = By.xpath("//a[contains(text(),'Contact Us')]");
    By HelpNavBarLink = By.xpath("//a[contains(text(),'Help')]");
    By ClientRadioButton = By.id("optionsRadios2");
    By OutStandingBPSErrorsViewClientButton = By.xpath("//body/div[3]/span[1]/div[1]/div[1]/div[1]/div[1]/div[2]/form[1]/input[2]");
    By SelectAppSchemeSearchYear = By.id("previousAppSearchSchemeYear");


    // Locators for future use
    public OutstandingBPSErrorsPage(WebDriver driver) {
        this.driver = driver;
        actions = new ActionClass(driver);
    }

    // Click on the Home Link in NavBar
    public void AgentClickOnHomeNavBarLink() {
        actions.waitForVisibilityOfElement(HomeNavBarLink,15);
        actions.clickUsingJS(HomeNavBarLink);
    }

    // Click on the Contact Us Link in NavBar
    public void AgentClickOnContactUsNavBarLink() {
        actions.waitForVisibilityOfElement(ContactUsNavBarLink,15);
        actions.clickUsingJS(ContactUsNavBarLink);
    }

    // Click on the Help Link in NavBar
    public void AgentClickOnHelpNavBarLink() {
        actions.waitForVisibilityOfElement(HelpNavBarLink,15);
        actions.clickUsingJS(HelpNavBarLink);
    }

    // Click on the Client Radio Button
    public void AgentClickOnOutStandingBPSErrorsClientRadioButton() {
        actions.waitForVisibilityOfElement(ClientRadioButton, 10);
        actions.click(ClientRadioButton);
    }

    public void SelectApplicaionSchemeSearchYear(String Arg0){
        WebElement SchemeYear = driver.findElement(SelectAppSchemeSearchYear);
        Select dropdown = new Select(SchemeYear);
        dropdown.selectByVisibleText(Arg0);
    }

    // Clicking on the View  button
    public void AgentClickOnOutstandingBPSErrorsViewButton() {
        if(driver.findElements(OutStandingBPSErrorsViewClientButton).isEmpty()==false) {
            actions.waitForVisibilityOfElement(OutStandingBPSErrorsViewClientButton, 10);
            actions.click(OutStandingBPSErrorsViewClientButton);
        }
        else {
            System.out.println("No clients displayed here so no View Button");
        }
    }
}
