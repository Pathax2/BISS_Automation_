Feature: TC_S25 - Regression Pack for Openshift General Cases

  # ──────────────────────────────────────────────────────────────────────────
  # Purpose:
  #   End-to-end regression for the Openshift environment covering:
  #     - TC01: Tab navigation (Coordination → Home)
  #     - TC02: Search by Reference Number
  #     - TC03: Search by Herd Number
  #     - TC04: Parcel search via Parcels tab
  #     - TC05: Generate Inspection Discovery map by Parcel Number
  #     - TC06: Generate Full Color Ortho A4 by Herd Number, verify, paginate
  #     - TC07: Online Response search by Herd Number
  #     - TC08: Internal amendment — submit without scheme changes
  #     - TC09: Navigate all Navbar links within a herd record
  #     - TC10: Navigate to Active Farmer and initiate admin check
  #
  # Common Background:
  #   Openshift staff login page is used for all scenarios.
  #   Different users per TC block: agr4442 (general), agr11612 (map printing),
  #   agr2332 (map download).
  #
  # DB Data:
  #   - 5 herds with Submission
  #   - 5 Reference Numbers
  #   - 5 LPIS Parcels
  #   All resolved from Oracle DB at runtime. Row references used throughout.
  #
  # Notes:
  #   1. TC05 uses agr11612 for map printing — a login switch is performed mid-scenario.
  #   2. TC06 uses agr2332 for map download — another login switch.
  #   3. TC07-TC10 return to agr4442.
  #
  # Author  : Aniket Pathare | aniket.pathare@government.ie
  # Created : 2026-05-14
  # ──────────────────────────────────────────────────────────────────────────

  Background:
    Given the staff user is on the Openshift staff login page
    Then Get 5 Herds with Submission from DB
    And Get 5 Reference Numbers from DB
    And Get 5 LPIS Parcels from DB

  @regression
  Scenario: TC_S25 - Openshift General Cases end-to-end regression

    # ── TC01: Navigate between Coordination and Home tabs ─────────────────────
    When "agr4442" logs in and opens the BISS application
    And the staff user navigates to "Coordination" in the side navigation bar
    Then navigating back to "Home" should succeed without errors

    # ── TC02: Search by Reference Number ─────────────────────────────────────
    When the staff user searches for reference number from row 1 for scheme year "2023"
    Then application search results should be returned

    # ── TC03: Search by Herd Number ──────────────────────────────────────────
    When the staff user searches for herd with submission from row 1 for scheme year "2024"
    Then application search results should be returned

    # ── TC04: Search by Parcel Number via Parcels tab ────────────────────────
    When the staff user switches to the "Parcels" tab and searches for LPIS parcel from row 1 for scheme year "2024"
    Then parcel search results should be returned

    # ── TC05: Generate Inspection Discovery map by Parcel Number ─────────────
    When "agr11612" logs in, opens Map Printing and switches to Parcel mode
    And the staff user searches for LPIS parcel from row 2 for scheme year "2023"
    And the staff user selects a single parcel, chooses map type "Inspection Discovery" and enables the legend
    Then the map generation request should be submitted successfully

    # ── TC06: Generate Full Color Ortho A4 by Herd Number, verify and paginate
    When "agr2332" logs in and opens the Map Printing tab
    And the staff user searches for herd with submission from row 2 for scheme year "2023"
    And the staff user logs the herd name and address, selects a single parcel, chooses "Full Color Ortho A4" with legend and generates the map
    Then the generated map should display status, id, herd number and date, reach final status
    And the Next page and Previous page pagination controls should work correctly

    # ── TC07: Online Response search by Herd Number ──────────────────────────
    When "agr4442" logs in, switches to the Online Response tab and searches for herd from row 3 for scheme year "2023"
    Then online response search results should be returned

    # ── TC08: Internal amendment — submit without scheme changes ─────────────
    When the staff user opens herd with submission from row 4 for scheme year "2024" and submits the amendment without making any scheme changes
    Then the amendment should be submitted successfully

    # ── TC09: Navigate through all Navbar links within a herd record ──────────
    When the staff user opens herd with submission from row 5 for scheme year "2024" and views the application
    Then the following Navbar sections should each load correctly
      | Payments | Correspondence | Errors/Stops | Inspections | Notes/History | BISS Application | SIM |

    # ── TC10: Navigate to Active Farmer and initiate admin check ─────────────
    When the staff user opens herd with submission from row 6 for scheme year "2023" and navigates to the Active Farmer section
    And the staff user clicks Start admin check
    Then the admin check should be initiated successfully