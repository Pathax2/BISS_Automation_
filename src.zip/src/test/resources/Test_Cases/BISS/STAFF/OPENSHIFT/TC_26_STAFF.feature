Feature: TC_S26 - Regression Pack for Openshift Map Printing

  # ──────────────────────────────────────────────────────────────────────────
  # Purpose:
  #   End-to-end map printing regression for the Openshift environment covering:
  #     - TC01: Generate Full Color Ortho A4 by Herd Number — verify metadata and download
  #     - TC02: Generate Inspection Discovery by Parcel Number — verify status and download
  #     - TC03: Invalid herd number produces no results
  #     - TC04: Invalid parcel number shows "Parcel number is invalid" error
  #     - TC05: Both required field errors appear in the correct search modes
  #
  # Common Background:
  #   Openshift staff login as agr11612 → open BISS → navigate to Map Printing tab.
  #
  # DB Data:
  #   - 5 herds with Submission (TC01 uses row 2)
  #   - 5 Reference Numbers
  #   - 5 LPIS Parcels (TC02 uses row 3)
  #   All resolved from Oracle DB at runtime.
  #
  # Notes:
  #   1. agr11612 is the authorised internal map printing user for Openshift.
  #   2. TC01 and TC02 download the map using the first "Ready to download" link
  #      in the map history table (mdc-data-table).
  #   3. TC03 and TC04 verify that invalid inputs are handled gracefully with
  #      appropriate messages rather than unhandled exceptions.
  #
  # Author  : Aniket Pathare | aniket.pathare@government.ie
  # Created : 2026-05-14
  # ──────────────────────────────────────────────────────────────────────────

  Background:
    Given the staff user is on the Openshift staff login page
    When the staff user logs in with username "agr11612"
    And the staff user selects the data protection checkbox and clicks login
    And the staff user opens the "Basic Income Support for Sustainability" application
    And the staff user navigates to the "Map Printing" tab
    Then Get 5 Herds with Submission from DB
    And Get 5 Reference Numbers from DB
    And Get 5 LPIS Parcels from DB

  @tmsLink=BISSAGL-18579 @tmsLink=BISSAGL-18583 @tmsLink=BISSAGL-18586 @tmsLink=BISSAGL-18589 @tmsLink=BISSAGL-18591 @regression
  Scenario: TC_S26 - Openshift Map Printing end-to-end regression

    # ── TC01: Generate Full Color Ortho A4 by Herd Number — verify and download
    When the staff user enters herd with submission from row 2 and searches for scheme year "2023"
    And the staff user logs the herd name and address, selects a single parcel, chooses "Full Color Ortho A4" with legend
    And the staff user generates the map
    Then the generated map should display status, id, herd number and date and reach final status
    And the staff user downloads the first available ready map

    # ── TC02: Inspection Discovery map by Parcel Number — verify and download ─
    When the staff user switches to Parcel mode and enters LPIS parcel from row 3 for scheme year "2023"
    And the staff user selects a single parcel and chooses map type "Inspection Discovery" with legend
    And the staff user generates the map
    Then the map should reach its final ready status
    And the staff user downloads the first available ready map

    # ── TC03: Invalid herd number produces no results ─────────────────────────
    When the staff user returns to Herd search mode and enters "ABDAAPT" for scheme year "2023"
    Then no map results should be returned for the invalid herd number

    # ── TC04: Invalid parcel number displays error message ────────────────────
    When the staff user switches to Parcel mode and enters invalid parcel "ABDAAPT" for scheme year "2023"
    Then the error message "Parcel number is invalid" should be displayed

    # ── TC05: Required field errors in both Herd and Parcel search modes ──────
    When the staff user returns to Herd search mode and submits without entering any value
    Then the error message "Herd number required." should be displayed
    When the staff user switches to Parcel mode and submits without entering any value
    Then the error message "Parcel number required." should be displayed