package com.stepdefinitions;

import com.base.ConfigReader;
import com.base.DriverManager;
import com.pages.OutstandingBPSErrorsPage;
import com.pages.LoginPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;

import java.util.Properties;

public class OutstandingBPSErrorsSteps {


        LoginPage loginPage;
        OutstandingBPSErrorsPage outstandingbpserrorsPage;
        WebDriver driver;
        Properties prop;
        ConfigReader configReader;
        DriverManager driverManager;

        public OutstandingBPSErrorsSteps(DriverManager driverManager){
            try {
//            driver = driverManager.getDriver();
                this.driverManager=driverManager;
                driver=driverManager.getDriverInstance();
                loginPage = new LoginPage(driver);
                outstandingbpserrorsPage = new OutstandingBPSErrorsPage(driver);
                configReader = new ConfigReader();
                prop = configReader.init_prop();
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }

    @And("Agent is on Outstanding BPS Errors Page")
    public void OutstandingBPSErrorsPage() {
        String title = driver.getTitle();
        System.out.println("title of Outstanding BPS Errors Page" + title);
    }

    @Then("Click on Home Button")
    public void AgentClicksOnHomeNavBarLink() throws InterruptedException {
        outstandingbpserrorsPage.AgentClickOnHomeNavBarLink();
        Thread.sleep(2000);
    }

    @Then("Click on Contact Us Button")
    public void AgentClicksOnContactUsNavBarLink() throws InterruptedException {
        outstandingbpserrorsPage.AgentClickOnContactUsNavBarLink();
        Thread.sleep(2000);
    }

    @Then("Click on Help Button")
    public void AgentClicksOnHelpNavBarLink() throws InterruptedException {
        outstandingbpserrorsPage.AgentClickOnHelpNavBarLink();
        Thread.sleep(2000);
    }

    @And("Agent Clicks on OutStanding BPS Errors View Button")
    public void AgentClicksOnViewButton() throws InterruptedException {
        outstandingbpserrorsPage.AgentClickOnOutstandingBPSErrorsViewButton();
        Thread.sleep(2000);
    }


    @And("Agent selects Application And Payments Summary Scheme Year {string} from the dropdown")
    public void AgentSelectAppSchemeSearchYear(String Arg0) {
            outstandingbpserrorsPage.SelectApplicaionSchemeSearchYear(Arg0);
    }
}
