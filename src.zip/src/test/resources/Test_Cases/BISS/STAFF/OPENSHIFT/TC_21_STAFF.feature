Feature: TC_S21 - Regression Pack for Add Payments Tab to iNet Applications Menu

  # ──────────────────────────────────────────────────────────────────────────
  # Purpose:
  #   Validates the Payments tab and schemeYear dropdown added to the
  #   Applications / Payments section of the Agent portal for iNet 2024.
  #   Covers:
  #     - Payments tab is present in the Applications / Payments section
  #     - schemeYear dropdown is present
  #     - Land Details tab is present
  #     - Clicking Payments tab shows "There are no records to display"
  #
  # Common Background:
  #   Agent login as aga6128 with OTP → open BISS application → My Clients tab.
  #   This is an agent-side (iNet) flow.
  #
  # DB Data:
  #   No DB pool step required. Fixed herd N1142057 has known Payments tab data.
  #
  # Notes:
  #   1. aga6128 is the agent user authorised for herd N1142057.
  #   2. The "There are no records to display" message confirms the Payments tab
  #      loads without error even when no payment data exists.
  #
  # Author  : Aniket Pathare | aniket.pathare@government.ie
  # Created : 2026-05-14
  # ──────────────────────────────────────────────────────────────────────────

  Background:
    Given the agent user is on the login page
    When the agent logs into the application with valid credentials and OTP as "aga6128"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    And the agent navigates to the "Home" and "My Clients" Left Menu Link

  @tmsLink=BISSAGL-14785 @regression
  Scenario: TC_S21 - Add Payments Tab iNet regression

    # ── TC01: Verify Payments tab, schemeYear dropdown and empty state ────────
    When the agent searches for herd "N1142057" and opens the farmer dashboard
    And the agent navigates to the "Applications / Payments" tab
    Then the schemeYear dropdown should be present
    And the Land Details tab should be present
    And the Payments tab should be present
    When the agent selects the Payments tab
    Then the message "There are no records to display" should be shown