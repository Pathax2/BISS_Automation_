# ====================================================================================================================================
# File          : TC_14_STAFF.feature
# Purpose       : Query Letter Free Text E2E Regression Pack
#                 Modernised from the legacy staff scenarios - single chained E2E Scenario with
#                 # SECTION markers mapping back to the original AT-TC ids.
# Data          : URL launched by Hooks (Config sheet, by environment). Password resolved from the
#                 TestData.xlsx Password column via the TD: mechanism. Herd/parcel/reference values
#                 supplied in-feature via DataTable (no row references).
# Step Defs     : StaffSteps.java (stepdefinitions.STAFF)
# Locators      : ObjectRepository.properties - Staff sections
# Author        : Aniket Pathare | aniket.pathare@government.ie
# Created       : 14-07-2026
# ====================================================================================================================================

Feature: TC_14_STAFF - Query Letter Free Text E2E Regression Pack

  Background:
    Given user on staff login page

  @regression @staff @correspondence @query-letter @e2e
  Scenario: AT-STAFF-QUERY-LETTER-E2E-01 - Staff adds free text to the Commonage Evidence query letter and previews

    # SECTION 1 : Commonage Evidence query letter with free text - AT-TC-01 (BISSAGL-14857)
    When Staff logs in with the Username "agr4442"
    And Staff opens the "Basic Income Support for Sustainability" application
    And Staff searches on the Home screen with the following details
      | field      | herdNumber |
      | herdValue  | G1060529   |
      | schemeYear | 2024       |
    And Staff clicks the "View" link number 1 in the "application-search-table" table
    Then Staff clicks on "Correspondence" Link in Navbar
    And Staff switches to the "Query Letter" tab in the Correspondence header
    And Staff changes the "docType" query letter dropdown value to "BISS Commonage Evidence Letter"
    And Staff types text "Test Comment" in the "comment" query letters textarea
    Then Staff clicks the "Preview" button
