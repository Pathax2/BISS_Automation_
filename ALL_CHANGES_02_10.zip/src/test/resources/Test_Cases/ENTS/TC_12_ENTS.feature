Feature: TC_12_ENTS - Transfer Application E2E (ETF Partner to Individual)

  # Migrated from: TC_12_ENTS.feature (legacy 8 scenarios)
  # Transferor: ETF Partner (agr15512) | Transferee: Individual (various)
  # Uses MANUAL entitlements same as TC_11
  # Reused: TC_11_ENTS (ETF manual create), TC_05_ENTS (individual transferee)
  #
  #
  # Runtime data (Playwright, 02-10-2026):
  #   The transferor stays the ETF partner's own herd C2057024 (pinned, never written to the used-herds file).
  #   The transferee is an individual with their own login from the Individual Login query / vault pool ENTS_INDIVIDUAL
  #   ("transfereeType | Individual" row - EntsTestData.nextIndividualTransfereeForFixedTransferor), filling
  #     {transferee.herd}  {transferee.name}  {transferee.address}  {transferee.login}
  #   Selenium values are kept in the section comments. Put a herd, name or login back in a cell to pin it.
  #   Section 3 (Lease) has a leaseYear row (the Selenium file relied on the dropdown appearing).
  #
  # Author: Aniket Pathare | Created: 31-03-2026

  Background:
    Given the ETF partner logs in as transferor "agr15512"
    And the agent opens the "Basic Income Support for Sustainability" application

  @regression @transfers @etf-to-individual @e2e
  Scenario: AT-ENTS-TRANSFERS-E2E-12 - ETF Partner completes all transfer types to Individual

    # SECTION 1 : CLE (206)
    When the ETF partner creates a transfer with manual entitlements
      | transferorHerd   | C2057024                 |
      | transfereeHerd   | {transferee.herd}        |
      | transfereeName   | {transferee.name}        |
      | transfereeAddress| {transferee.address}     |
      | transfereeType   | Individual               |
      | transferType     | Change of Legal Entity|
      | entitlements     | 0.01                     |
      | entitlementType  | BISS                     |
      | netUV            | 1                        |
      | notes            | Test Notes               |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    When the agent logs out and re-logs in as the individual transferee "{transferee.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers                 |
    And the individual completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfer should be submitted successfully

    # SECTION 2 : Change of Registration (205)
    Given the ETF partner logs in as transferor "agr15512"
    And the agent opens the "Basic Income Support for Sustainability" application
    When the ETF partner creates a transfer with manual entitlements
      | transferorHerd   | C2057024                 |
      | transfereeHerd   | {transferee.herd}        |
      | transfereeName   | {transferee.name}        |
      | transfereeAddress| {transferee.address}     |
      | transfereeType   | Individual               |
      | transferType     | Change of Registration Details|
      | entitlements     | 0.01                     |
      | entitlementType  | BISS                     |
      | netUV            | 1                        |
      | notes            | Test Notes               |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    When the agent logs out and re-logs in as the individual transferee "{transferee.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers                 |
    And the individual completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfer should be submitted successfully

    # SECTION 3 : Lease (211)
    Given the ETF partner logs in as transferor "agr15512"
    And the agent opens the "Basic Income Support for Sustainability" application
    When the ETF partner creates a transfer with manual entitlements
      | transferorHerd   | C2057024                 |
      | transfereeHerd   | {transferee.herd}        |
      | transfereeName   | {transferee.name}        |
      | transfereeAddress| {transferee.address}     |
      | transfereeType   | Individual               |
      | transferType     | Lease of Entitlements|
      | entitlements     | 0.01                     |
      | leaseYear        | Yes                      |
      | entitlementType  | BISS                     |
      | netUV            | 1                        |
      | notes            | Test Notes               |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured


    When the agent logs out and re-logs in as the individual transferee "{transferee.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers                 |
    And the individual completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfer should be submitted successfully

    # SECTION 4 : Gift (202)
    Given the ETF partner logs in as transferor "agr15512"
    And the agent opens the "Basic Income Support for Sustainability" application
    When the ETF partner creates a transfer with manual entitlements
      | transferorHerd   | C2057024                 |
      | transfereeHerd   | {transferee.herd}        |
      | transfereeName   | {transferee.name}        |
      | transfereeAddress| {transferee.address}     |
      | transfereeType   | Individual               |
      | transferType     | Gift of Entitlements     |
      | entitlements     | 0.01                     |
      | entitlementType  | BISS                     |
      | netUV            | 1                        |
      | notes            | Test Notes               |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    When the agent logs out and re-logs in as the individual transferee "{transferee.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers                 |
    And the individual completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfer should be submitted successfully


    # SECTION 5 : Merger (203)
    Given the ETF partner logs in as transferor "agr15512"
    And the agent opens the "Basic Income Support for Sustainability" application
    When the ETF partner creates a transfer with manual entitlements
      | transferorHerd   | C2057024                 |
      | transfereeHerd   | {transferee.herd}        |
      | transfereeName   | {transferee.name}        |
      | transfereeAddress| {transferee.address}     |
      | transfereeType   | Individual               |
      | transferType     | Merger of 2 or more holdings (forming an unregistered Farm Partnership)|
      | entitlements     | 0.01                     |
      | entitlementType  | BISS                     |
      | netUV            | 1                        |
      | notes            | Test Notes               |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    When the agent logs out and re-logs in as the individual transferee "{transferee.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers                 |
    And the individual completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfer should be submitted successfully

    # SECTION 6 : Division (204)
    Given the ETF partner logs in as transferor "agr15512"
    And the agent opens the "Basic Income Support for Sustainability" application
    When the ETF partner creates a transfer with manual entitlements
      | transferorHerd   | C2057024                 |
      | transfereeHerd   | {transferee.herd}        |
      | transfereeName   | {transferee.name}        |
      | transfereeAddress| {transferee.address}     |
      | transfereeType   | Individual               |
      | transferType     | Division of Entitlements (Scission)|
      | entitlements     | 0.01                     |
      | entitlementType  | BISS                     |
      | netUV            | 1                        |
      | notes            | Test Notes               |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    When the agent logs out and re-logs in as the individual transferee "{transferee.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers                 |
    And the individual completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfer should be submitted successfully


    # SECTION 7 : Inheritance (201)
    Given the ETF partner logs in as transferor "agr15512"
    And the agent opens the "Basic Income Support for Sustainability" application
    When the ETF partner creates a transfer with manual entitlements
      | transferorHerd   | C2057024                 |
      | transfereeHerd   | {transferee.herd}        |
      | transfereeName   | {transferee.name}        |
      | transfereeAddress| {transferee.address}     |
      | transfereeType   | Individual               |
      | transferType     | Inheritance of Entitlements|
      | entitlements     | 0.01                     |
      | entitlementType  | BISS                     |
      | netUV            | 1                        |
      | notes            | Test Notes               |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    When the agent logs out and re-logs in as the individual transferee "{transferee.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers                 |
    And the individual completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfer should be submitted successfully


    # SECTION 8 : Sale (212)
    Given the ETF partner logs in as transferor "agr15512"
    And the agent opens the "Basic Income Support for Sustainability" application
    When the ETF partner creates a transfer with manual entitlements
      | transferorHerd   | C2057024                 |
      | transfereeHerd   | {transferee.herd}        |
      | transfereeName   | {transferee.name}        |
      | transfereeAddress| {transferee.address}     |
      | transfereeType   | Individual               |
      | transferType     | Sale of Entitlements     |
      | entitlements     | 0.01                     |
      | entitlementType  | BISS                     |
      | netUV            | 1                        |
      | notes            | Test Notes               |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    When the agent logs out and re-logs in as the individual transferee "{transferee.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers                 |
    And the individual completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfer should be submitted successfully
