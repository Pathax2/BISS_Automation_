package com.utility;

import com.atlassian.jira.rest.client.api.JiraRestClient;
import com.atlassian.jira.rest.client.api.domain.BasicProject;
import com.atlassian.jira.rest.client.api.domain.Issue;
import com.atlassian.jira.rest.client.internal.async.AsynchronousJiraRestClientFactory;
import com.base.ConfigReader;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.utility.PropertyReader;
import io.atlassian.util.concurrent.Promise;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.apache.commons.lang3.StringUtils;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.json.JSONObject;
import org.junit.Assume;


import java.net.URI;
import java.util.*;

import static io.restassured.RestAssured.basic;

public class JiraZephyrClient implements AutoCloseable {

    private String userName;
    private String password;
    private JiraRestClient jiraRestClient;


    public JiraZephyrClient() {
        this(URI.create(PropertyReader.getFieldValue("JIRA_URL")), PropertyReader.getFieldValue("ZAPI_PATH"), PropertyReader.getFieldValue("Jirausername"),
                PropertyReader.getFieldValue("JiraPassword"));
    }

    /**
     * @param jiraUri
     *            in DAFM's case this is: https://jira.agriculture.gov.ie/jira
     * @param zapiPath
     *            the installation path of the ZAPI Plugin for Jira. DAFM's Case this is: /rest/zapi/latest
     * @param userName
     *            is the normal Jira user name
     * @param password
     *            is the normal Jira password
     */
    public JiraZephyrClient(URI jiraUri, String zapiPath, String userName,
                            String password) {
        System.out.println("set jira url to: " + jiraUri.toString());
        System.out.println("set jira username to: " + userName);// and password to: " + "" + password);
        this.userName = userName;
        this.password = password;
        jiraRestClient = new AsynchronousJiraRestClientFactory()
                .createWithBasicHttpAuthentication(jiraUri, userName, password);
        RestAssured.baseURI = jiraUri.toString() + zapiPath;
        RestAssured.authentication = basic(userName, password);
    }

    /**
     * @see #createNewExecution(String, String, String, String, String, String)
     */
    public String createNewExecution(String cycleId, String issueId, String projectId) {
        String cycleAndVersionDefaultValue = "-1";
        String folderId = "";
        String assigneeDefaultValue = "bamboo.ecs";
        return createNewExecution(cycleId, issueId, projectId, cycleAndVersionDefaultValue,
                assigneeDefaultValue, folderId);
    }

    /**
     * Creates a new execution. The status of the execution after this call will be 'Not Executed'.<br>
     * All parameters have to be supplied as non null Strings except folderId
     *
     * @param cycleId
     *            Zephyr cycle id as per {@link #getExecutionCycleByProjectIdAndCycleNames(String, String)} or "-1" for
     *            the 'AD HOC' cycle
     * @param issueId
     *            is the JIRA issue id as String returned from {@link Issue#getId()} where the {@link Issue} can be
     *            found by calling {@link #findIssue(String)}
     * @param projectId
     *            is the JIRA project id as String returned from {@link BasicProject#getId()} where the
     *            {@link BasicProject} can be found by calling {@link Issue#getProject()}
     * @param versionId
     *            is the JIRA Version Id as String or -1 for 'Unschedualed' the later is the most used value in DAFM
     * @param assignee
     *            name
     * @param folderId
     *            or '-1' if non
     * @return the id of the newly created execution ready for use in future calls
     */
    public String createNewExecution(@NonNull String cycleId, @NonNull String issueId,
                                     @NonNull String projectId, @NonNull String versionId, @NonNull String assignee,
                                     String folderId) {
        JSONObject jsonPayload = new JSONObject();
        jsonPayload.put("cycleId", cycleId);
        jsonPayload.put("issueId", issueId);
        jsonPayload.put("projectId", projectId);
        jsonPayload.put("versionId", versionId);
        jsonPayload.put("assigneeType", "assignee");
        jsonPayload.put("assignee", assignee);
        jsonPayload.put("folderId", folderId);
        final String executionTargetUrlString = "/execution";
        Response response = RestAssured.with().auth().preemptive().basic(userName, password)
                .contentType(ContentType.JSON).body(jsonPayload.toString()).post(executionTargetUrlString);
        System.out.println("JSON payload: " + jsonPayload.toString());

        new JSONObject(response.asString());
        System.out.println("JSON response: " + response.toString());
        String executionId = new JSONObject(response.asString()).keys().next();
        System.out.println("execution created with the ID: " + executionId);
        return executionId;
    }


    public String getExecutionCycleByProjectIdAndCycleNames(String projectId, String partialCycleName) {
        String cycleTarget = "/cycle";
        String cycleKey = null;

        Response response = RestAssured.with().auth().preemptive().basic(userName, password)
                .contentType(ContentType.JSON).param("projectId", projectId).get(cycleTarget);

        System.out.println("-JSON response:" + response.toString());
        System.out.println("-JIRA JSON Object: " + response.asString());

        JSONObject searchCyclesJsonResponseObject = new JSONObject(response.asString());

        // used to retrieve parent level JSONArray keys from /cycles response to allow
        // iteration through all cycle folders
        JsonElement jsonElement = JsonParser.parseString(response.asString());
        List<String> listOfParentLevelkeys = getCycleReleaseParentLevelKeys(jsonElement, "");
        System.out.println("JSON Parent Level Cycle Keys = " + listOfParentLevelkeys);

        for (String keysString : listOfParentLevelkeys) {
            JSONObject allCyclesJSON = searchCyclesJsonResponseObject.getJSONArray(keysString).getJSONObject(0);
            Iterator<String> keysIterator = allCyclesJSON.keys();
            System.out.println("searching keys for JSON Object containing  partialCycleName: " + partialCycleName);

            while (keysIterator.hasNext()) {
                String key = keysIterator.next();
                JSONObject currentJSONObject = allCyclesJSON.optJSONObject(key);

                if (currentJSONObject != null
                        && StringUtils.containsIgnoreCase(currentJSONObject.getString("name"), partialCycleName)) {
                    System.out.println("cycle key: " + key);
                    cycleKey = key;
                }
            }
        }
        return cycleKey;
    }

    public static List<String> getCycleReleaseParentLevelKeys(final JsonElement jsonElement, final String prefix) {
        List<String> keys = new ArrayList<>();
        if (jsonElement.isJsonObject()) {
            com.google.gson.JsonObject jObj = jsonElement.getAsJsonObject();
            for (Map.Entry<String, JsonElement> entry : jObj.entrySet()) {
                JsonElement value = entry.getValue();
                String newPrefix = prefix + entry.getKey();

                if (value.isJsonArray()) {
                    keys.add(newPrefix);
                    keys.addAll(getCycleReleaseParentLevelKeys(value, newPrefix + "_"));
                }
            }
        } else {
            com.google.gson.JsonArray array = jsonElement.getAsJsonArray();
            for (JsonElement element : array) {
                keys.addAll(getCycleReleaseParentLevelKeys(element, prefix));
            }
        }
        return keys;
    }

    //    /**
//     * @param executionId
//     *            of the execution which should be updated . The current use case involves creating the execution
//     *            beforehand
//     * @param newExecutionStatusCode
//     *            either {@link ConstantsProvider#EXECUTION_STATUS_PASS},
//     *            {@link ConstantsProvider#EXECUTION_STATUS_FAIL} or {@link ConstantsProvider#EXECUTION_STATUS_WIP}
//     * @param executionComment
//     *            comment that should appear in the comments section
//     * @return {@link Response} after updating the execution
//     */
    public Response updateExecutionStatus(String executionId, String newExecutionStatusCode,
                                          String executionComment) {
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            System.out.println(e.getMessage());
            // skipping the test in case of system failure
            Assume.assumeTrue(false);
        }
        String updateExecutionTarget = "/execution/" + executionId + "/execute";
        return RestAssured.with().auth().preemptive().basic(userName, password)
                .contentType(ContentType.JSON).body(
                        new JSONObject().put("status", newExecutionStatusCode).put("comment", executionComment)
                                .toString())
                .put(updateExecutionTarget);
    }

    /**
     * This call blocks till the response is retrieved from the JIRA server
     *
     * @param issueLabel
     *            which is the label seen on the JIRA UI (eg. JIRA-650)
     * @return {@link Issue}
     */
    public Issue findIssue(@NonNull String issueLabel) {
        System.out.println("search for issue with label: " + issueLabel);
        Promise<Issue> promise = jiraRestClient.getIssueClient().getIssue(issueLabel);
        System.out.println("waiting for search results from Jira...");
        while (!promise.isDone()) {

        }
        return promise.claim();
    }

    @Override
    public void close() throws Exception {
        if (jiraRestClient != null) {
            jiraRestClient.close();
        }
    }



}
