# ====================================================================================================================================
# File          : TC_09_STAFF.feature
# Purpose       : Supplementary Payments Roles E2E Regression Pack
#                 Modernised from the legacy staff scenarios - single chained E2E Scenario with
#                 # SECTION markers mapping back to the original AT-TC ids.
# Data          : URL launched by Hooks (Config sheet, by environment). Password resolved from the
#                 TestData.xlsx Password column via the TD: mechanism. Herd/parcel/reference values
#                 supplied in-feature via DataTable (no row references).
# Step Defs     : StaffSteps.java (stepdefinitions.STAFF)
# Locators      : ObjectRepository.properties - Staff sections
# Author        : Aniket Pathare | aniket.pathare@government.ie
# Created       : 14-07-2026
# ====================================================================================================================================

Feature: TC_09_STAFF - Supplementary Payments Roles E2E Regression Pack

  Background:
    Given user on staff login page

  @regression @staff @payments @roles @sso @e2e
  Scenario: AT-STAFF-PAY-ROLES-E2E-01 - Staff assigns BISS roles via SSO Admin and verifies supplementary payment access

    # SECTION 1 : Assign Co-ordination + Processing + Inspections + Risk roles - AT-TC-01 (BISSAGL-14868)
    When Staff logs in with the Username "agr0043"
    And Staff opens the "SSO Administration" application
    And Staff enters value "agr0191" in the helpdesk "search-form-username" field
    And Staff clicks the "Search" button
    And Staff clicks the agent row in SSO Admin search
    And Staff switches to the "authorisations" tab for the user
    And Staff selects "BISS" as the Application value
    And Staff switches to the "Roles" authorisation tab
    And Staff selects all roles on the "right" side box
    And Staff clicks the "arrow_back" SSO button
    And Staff assigns the following SSO roles
      | filter        | role                        |
      | CO-ORDINATION | BISS Co-ordination 1        |
      | CO-ORDINATION | BISS Co-ordination 2        |
      | PROCESSING    | BISS Processing 3           |
      | INSPECTIONS   | BISS Inspections 3          |
      | RISK          | BISS Risk Management 3 User |
    And Staff clicks the "Save Authorisations" button
    And Staff clicks the SignOut button

    # SECTION 2 : Verify supplementary payment controls as processing user
    When Staff logs in with the Username "agr0191"
    And Staff opens the "Basic Income Support for Sustainability" application
    And Staff searches on the Home screen with the following details
      | field      | herdNumber |
      | herdValue  | A1110015   |
      | schemeYear | 2024       |
    And Staff clicks the "View" link number 1 in the "application-search-table" table
    Then Staff clicks on "Payments" Link in Navbar
    And Staff clicks the "Request Supplementary Payment" button
    Then Staff verifies the dropdown "paymentReason" is present
    And Staff verifies the element "irregularitiesDate" is present
    And Staff verifies the element "adminControlDate" is present
    And Staff verifies the element "conditionalityControlDate" is present