//package com.stepdefinitions;
//
//
//import com.base.ConfigReader;
//import com.base.DriverManager;
//import com.pages.ApplicationPortalPage;
//import com.pages.DatabaseQueriesPage;
//import io.cucumber.java.en.And;
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//import org.openqa.selenium.WebDriver;
//
//import java.util.Properties;
//
//public class DataBaseQuerySteps {
//
//    DatabaseQueriesPage databaseQueriesPage;
//    ApplicationPortalPage applicationPortalPage;
//    WebDriver driver;
//    Properties prop;
//    ConfigReader configReader;
//
//    public DataBaseQuerySteps(DriverManager driverManager){
//        try {
//            driver = driverManager.getDriver();
//            databaseQueriesPage = new DatabaseQueriesPage(driver);
//            applicationPortalPage = new ApplicationPortalPage(driver);
//            configReader = new ConfigReader();
//            prop = configReader.init_prop();
//        }
//        catch (Exception e){
//            e.printStackTrace();
//        }
//    }
//
//    @Given("Application has been created by Agent")
//    public void ApplicationSubmittedByAgent() {
//        System.out.println("Application Submitted");
//    }
//
//    @Then("Execute the script for the DEVC_DPS_DATA Database")
//    public void DevcDpsDataScriptCall() {
//            applicationPortalPage.DevCDpsDataScript();
//    }
//
//}
