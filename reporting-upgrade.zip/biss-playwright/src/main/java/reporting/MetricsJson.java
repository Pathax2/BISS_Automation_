// ===================================================================================================================================
// File          : MetricsJson.java
// Package       : reporting
// Description   : Writes everything ExecutionMetrics recorded, plus the test case results, as one JSON document
//                 (BISS_Execution_Metrics_<ts>.json beside the HTML report). Meant for other tools and for the
//                 run history of Phase 3 (trends). Plain StringBuilder - no JSON library needed.
//                 Contains herd numbers and logins (team use only, like the Word reports); no farmer names.
//
// Author        : Aniket Pathare | aniket.pathare@government.ie
// Date Created  : 13-10-2026
// ===================================================================================================================================

package reporting;

import reporting.ExecutionMetrics.DbCall;
import reporting.ExecutionMetrics.Failure;
import reporting.ExecutionMetrics.Flow;
import reporting.ExecutionMetrics.HerdRow;
import reporting.ExecutionMetrics.StepEvent;
import reporting.ExecutionMetrics.TestCaseInfo;
import reporting.ReportManager.TestCaseResult;

import java.util.Map;

final class MetricsJson
{
    private MetricsJson() { }

    static String build()
    {
        StringBuilder j = new StringBuilder(64_000);
        j.append("{\n");
        j.append("  \"schema\": 1,\n");
        j.append("  \"runStarted\": ").append(q(ReportManager.getSuiteStartTime())).append(",\n");
        j.append("  \"runFinished\": ").append(q(ReportManager.getSuiteEndTime())).append(",\n");
        j.append("  \"environment\": ").append(q(ReportManager.getEnvironment())).append(",\n");
        j.append("  \"browser\": ").append(q(ReportManager.getBrowser())).append(",\n");
        j.append("  \"build\": ").append(q(ReportManager.getBuildNumber())).append(",\n");

        j.append("  \"counters\": {");
        boolean first = true;
        for (Map.Entry<String, Integer> e : ExecutionMetrics.counters().entrySet())
        {
            j.append(first ? "" : ",").append("\n    ").append(q(e.getKey())).append(": ").append(e.getValue());
            first = false;
        }
        j.append(first ? "},\n" : "\n  },\n");

        j.append("  \"testCases\": [");
        first = true;
        for (TestCaseResult r : ReportManager.getResults())
        {
            TestCaseInfo i = ExecutionMetrics.testCase(r.iTestCaseID);
            j.append(first ? "" : ",").append("\n    {\"id\": ").append(q(r.iTestCaseID)).append(", \"module\": ").append(q(ExecutionMetrics.moduleOf(r.iTestCaseID))).append(", \"status\": ").append(q(r.iStatus))
             .append(", \"durationMs\": ").append(r.iDurationMs).append(", \"setupMs\": ").append(i.setupMs).append(", \"scenarioMs\": ").append(i.scenarioMs)
             .append(", \"teardownMs\": ").append(i.teardownMs).append(", \"scenarios\": ").append(i.scenarios).append(", \"steps\": ").append(r.iSteps.size())
             .append(", \"wordDoc\": ").append(q(i.wordDoc)).append(", \"screenshot\": ").append(q(i.screenshot)).append("}");
            first = false;
        }
        j.append(first ? "],\n" : "\n  ],\n");

        j.append("  \"herds\": [");
        first = true;
        for (HerdRow r : ExecutionMetrics.herds())
        {
            j.append(first ? "" : ",").append("\n    {\"time\": ").append(q(r.time)).append(", \"testCase\": ").append(q(r.testCase))
             .append(", \"section\": ").append(q(r.purpose)).append(", \"role\": ").append(q(r.role)).append(", \"herd\": ").append(q(r.herd))
             .append(", \"login\": ").append(q(r.login)).append(", \"pool\": ").append(q(r.pool)).append(", \"try\": ").append(r.tryNo)
             .append(", \"outcome\": ").append(q(r.outcome)).append(", \"note\": ").append(q(r.note)).append("}");
            first = false;
        }
        j.append(first ? "],\n" : "\n  ],\n");

        j.append("  \"transfers\": [");
        first = true;
        for (Flow f : ExecutionMetrics.flows())
        {
            j.append(first ? "" : ",").append("\n    {\"testCase\": ").append(q(f.testCase)).append(", \"from\": ").append(q(f.from))
             .append(", \"to\": ").append(q(f.to)).append(", \"section\": ").append(q(f.purpose)).append("}");
            first = false;
        }
        j.append(first ? "],\n" : "\n  ],\n");

        j.append("  \"failures\": [");
        first = true;
        for (Failure f : ExecutionMetrics.failures())
        {
            j.append(first ? "" : ",").append("\n    {\"testCase\": ").append(q(f.testCase)).append(", \"scenario\": ").append(q(f.scenario))
             .append(", \"step\": ").append(q(f.step)).append(", \"cause\": ").append(q(f.cause)).append(", \"message\": ").append(q(f.message))
             .append(", \"screenshot\": ").append(q(f.screenshot)).append("}");
            first = false;
        }
        j.append(first ? "],\n" : "\n  ],\n");

        j.append("  \"dbQueries\": [");
        first = true;
        for (DbCall d : ExecutionMetrics.dbCalls())
        {
            j.append(first ? "" : ",").append("\n    {\"db\": ").append(q(d.db)).append(", \"label\": ").append(q(d.label))
             .append(", \"ms\": ").append(d.ms).append(", \"rows\": ").append(d.rows).append("}");
            first = false;
        }
        j.append(first ? "],\n" : "\n  ],\n");

        j.append("  \"actions\": [");
        first = true;
        for (StepEvent e : ExecutionMetrics.steps())
        {
            j.append(first ? "" : ",").append("\n    {\"testCase\": ").append(q(e.testCase)).append(", \"action\": ").append(q(e.action))
             .append(", \"orKey\": ").append(q(e.orKey)).append(", \"locator\": ").append(q(e.locator)).append(", \"ms\": ").append(e.ms)
             .append(", \"status\": ").append(q(e.status)).append(", \"jsFallback\": ").append(e.jsFallback).append(", \"rootCause\": ").append(q(e.rootCause)).append("}");
            first = false;
        }
        j.append(first ? "]\n" : "\n  ]\n");
        return j.append("}\n").toString();
    }

    // JSON string
    static String q(String pText)
    {
        if (pText == null) return "\"\"";
        StringBuilder s = new StringBuilder("\"");
        for (char c : pText.toCharArray())
        {
            switch (c)
            {
                case '"':  s.append("\\\""); break;
                case '\\': s.append("\\\\"); break;
                case '\n': s.append("\\n");  break;
                case '\r': s.append("\\r");  break;
                case '\t': s.append("\\t");  break;
                default:
                    if (c < 0x20) s.append(String.format("\\u%04x", (int) c));
                    else s.append(c);
            }
        }
        return s.append('"').toString();
    }
}
