# ====================================================================================================================================
# TC_10_STAFF.feature
# ====================================================================================================================================
@maps @regression @staff
Feature: TC_10_STAFF - Map Download from the Generated Maps Table

  # Migrated from legacy "Regression Pack for Generating and Downloading Map"
  # (BISSAGL-7682 AT-TC-01, 02).
  #
  # BUSINESS FLOW
  #   A generated map moves through its statuses to completion, at which point the results
  #   table offers it for download. This pack covers the download itself, from both a herd
  #   search and a parcel search.
  #
  # WHAT THIS VALIDATES
  #   1. A herd map records full metadata and reaches its final status.
  #   2. A parcel map does the same and exposes a working download link.
  #
  # LEGACY INCONSISTENCY
  #   AT-TC-01 has its download step COMMENTED OUT while AT-TC-02 does not - so the herd
  #   path never actually asserts the download this pack exists to test. Preserved exactly:
  #   Section 1 stops at final status. ACTION: confirm whether the omission was deliberate.
  #
  # TEST DATA NOTE
  #   K1361753 is the same partnership fixture used by TC_04; B1410500035 is a parcel
  #   fixture. Both hardcoded in legacy and kept as literals.

  Background:
    Given the staff user is logged in to the BISS internal portal as "agr2332"
    And the staff user is on the Map Printing screen

  @e2e @download
  Scenario: Staff generates maps by herd and parcel and downloads the completed output

    # SECTION 1 - AT-TC-01 (BISSAGL-14884)
    # Validates: metadata and final status only - legacy disables the download assertion.
    When the staff user searches Map Printing for partnership herd "K1361753" for scheme year "2023"
    And the staff user requests a map with the following settings
      | parcels | single              |
      | mapType | Full Color Ortho A4 |
      | legend  | yes                 |
    Then the generated map should be recorded with the following details
      | status     |
      | id         |
      | herdNumber |
      | date       |
    Then the map generation request should be accepted
    And the generated map should reach its final status

    # SECTION 2 - AT-TC-02 (BISSAGL-14883)
    # Validates: the full path including download, from a parcel search across all parcels.
    When the staff user searches Map Printing with no parcel number
    And the staff user searches Map Printing for parcel "B1410500035" for scheme year "2023"
    And the staff user requests a map with the following settings
      | parcels | all                 |
      | mapType | Full Color Ortho A4 |
      | legend  | yes                 |
    Then the generated map should be recorded with the following details
      | status     |
      | id         |
      | herdNumber |
      | date       |
    Then the map generation request should be accepted
    And the generated map should reach its final status
    And the staff user should be able to download the generated map