Feature: TC_S36 - Regression Pack for Deleting and Re-Adding Parcels on Multi Herd RFPs

  # ──────────────────────────────────────────────────────────────────────────
  # Purpose:
  #   Validates the agent flow for deleting and re-adding parcels/plots on
  #   multi-herd RFPs (Request for Payment) in the iNet agent portal.
  #   Covers:
  #     - TC01: Open dashboard for herd A1230614 and start or continue the application
  #
  # Common Background:
  #   Agent login as aga6306 with OTP → open BISS application → My Clients tab.
  #   This is an iNet agent-side flow.
  #
  # DB Data:
  #   No DB pool step required. Herd A1230614 is a fixed multi-herd RFP test herd.
  #
  # Notes:
  #   1. aga6306 is the agent user authorised for herd A1230614.
  #   2. Steps after the application stepper loads are pending completion
  #      once the parcel delete/re-add and validation workflow steps are finalised.
  #   3. A1230614 is a known multi-herd RFP herd with shared parcels
  #      between multiple herd holders.
  #
  # Author  : Aniket Pathare | aniket.pathare@government.ie
  # Created : 2026-05-14
  # ──────────────────────────────────────────────────────────────────────────

  Background:
    Given the agent user is on the login page
    When the agent logs into the application with valid credentials and OTP as "aga6306"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    And the agent navigates to the "Home" and "My Clients" Left Menu Link

  @tmsLink=BISSAGL-14687 @regression
  Scenario: TC_S36 - Deleting and Re-Adding Parcels on Multi Herd RFPs end-to-end regression

    # ── TC01: Open A1230614 dashboard and start or continue the application ───
    When the agent searches for herd "A1230614" and opens the farmer dashboard
    And the agent starts or continues the application from the farmer dashboard
    Then the application stepper should be displayed and ready for parcel management