Feature: TC_10_ENTS - Transfer Application E2E Regression Pack (Individual to ETF Partner)

  # --------------------------------------------------------------------------------------------------------------------
  # Purpose:
  #   Single end-to-end regression journey covering Transfer of Entitlements flows where the Transferor is an
  #   Individual (own login) and the Transferee is a herd managed by ETF partner agr15678, who accepts from the ETF
  #   button after searching the herd in Transfer Out.
  #
  #   Transfer types covered:
  #     Section 1 : Lease                  (211)  - Selenium: SOUTHVIEW1 to D1460081 (Timothy Mangan)     + lease year
  #     Section 2 : Merger                 (203)  - Selenium: TERENCE1   to D1190050 (Thomas Treanor)     (heading said Gift; type kept)
  #     Section 3 : Sale                   (212)  - Selenium: DANIELPAUL to D1190246 (Oliver Griffin)
  #     Section 4 : Inheritance            (201)  - Selenium: SOUTHVIEW1 to J1350309 (Cadden Suppliers)
  #     Section 5 : Merger                 (203)  - Selenium: TERENCE1   to J1360045 (Nestor Exports Ltd)
  #     Section 6 : Division               (204)  - Selenium: DANIELPAUL to D1051289 (Browne Exports Ltd)
  #     Section 7 : Change of Registration (205)  - Selenium: TERENCE1   to D1190050 (Thomas Treanor)
  #     Section 8 : Change of Legal Entity (206)  - Selenium: DANIELPAUL to J1360045 (Nestor Exports Ltd)
  #
  # Migrated from: TC_10_ENTS.feature (legacy 8 separate scenarios)
  #
  # Runtime data (Playwright, 30-09-2026):
  #   The login step runs before the create step, so the pair is built in two halves (EntsTestData):
  #     "the individual logs in as transferor {transferor.login}" picks an unused herd from the Individual Login query
  #       (holder has their own online login) and logs its owner in
  #     the create step then picks the transferee: an unused herd from the Agent Login pool of agr15678
  #       ("transfereeAgent | agr15678", completePairWithAgentTransferee)
  #     {transferor.login}  {transferee.herd}  {transferee.name}  {transferee.agent}
  #   Change from the Selenium file: the ETF partner side now opens Home -> My Clients -> Transfers after the login
  #   (the same two steps TC_07_ENTS uses), because the acceptance step searches the herd in Transfer Out.
  #   Every pick is written to runtime-data/ents_used_herds.csv and never reused. Put a herd number, name or login back
  #   in any cell to pin it for debugging (the Selenium values are in the comments of each section).
  #
  # Step reuse:
  #   Background login / navigation / side navigation -> stepdefinitions.TC_03
  #   Individual login + create                       -> stepdefinitions.ENTS.TC_08_ENTS
  #   Send / key / submit                             -> stepdefinitions.ENTS.TC_01_ENTS
  #   Tab switching                                   -> stepdefinitions.TC_06
  #   ETF partner login + acceptance                  -> stepdefinitions.ENTS.TC_07_ENTS
  #
  # Author : Aniket Pathare | aniket.pathare@government.ie
  # Created: 31-03-2026 | Updated: 30-09-2026 (Playwright + runtime ENTS data)
  # --------------------------------------------------------------------------------------------------------------------

  Background:
    Given the agent user is on the login page
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |

  @regression @transfers @individual-to-etf @e2e
  Scenario: AT-ENTS-TRANSFERS-E2E-10 - Individual completes all transfer types to ETF

    # ===========================================
    # SECTION 1 : Lease of Entitlements (211)
    # Selenium: SOUTHVIEW1 to D1460081 (Timothy Mangan)
    # NOTE: Lease includes lease year selection
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual creates a transfer application with the following details
      | transfereeHerd  | {transferee.herd}     |
      | transfereeName  | {transferee.name}     |
      | transfereeAgent | agr15678              |
      | transferType    | Lease of Entitlements |
      | entitlements    | 0.01                  |
      | leaseYear       | Yes                   |
      | notes           | Test Notes            |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (ETF Partner) ---
    When the agent logs out and re-logs in as the ETF partner "{transferee.agent}"
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the ETF partner completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 2 : Merger of Entitlements (203)
    # Selenium: TERENCE1 to D1190050 (Thomas Treanor) - Selenium heading said Gift, the type was Merger
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual creates a transfer application with the following details
      | transfereeHerd  | {transferee.herd}                                                       |
      | transfereeName  | {transferee.name}                                                       |
      | transfereeAgent | agr15678                                                                |
      | transferType    | Merger of 2 or more holdings (forming an unregistered Farm Partnership) |
      | entitlements    | 0.01                                                                    |
      | notes           | Test Notes                                                              |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (ETF Partner) ---
    When the agent logs out and re-logs in as the ETF partner "{transferee.agent}"
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the ETF partner completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 3 : Sale of Entitlements (212)
    # Selenium: DANIELPAUL to D1190246 (Oliver Griffin)
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual creates a transfer application with the following details
      | transfereeHerd  | {transferee.herd}    |
      | transfereeName  | {transferee.name}    |
      | transfereeAgent | agr15678             |
      | transferType    | Sale of Entitlements |
      | entitlements    | 0.01                 |
      | notes           | Test Notes           |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (ETF Partner) ---
    When the agent logs out and re-logs in as the ETF partner "{transferee.agent}"
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the ETF partner completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 4 : Inheritance (201)
    # Selenium: SOUTHVIEW1 to J1350309 (Cadden Suppliers)
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual creates a transfer application with the following details
      | transfereeHerd  | {transferee.herd}           |
      | transfereeName  | {transferee.name}           |
      | transfereeAgent | agr15678                    |
      | transferType    | Inheritance of Entitlements |
      | entitlements    | 0.01                        |
      | notes           | Test Notes                  |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (ETF Partner) ---
    When the agent logs out and re-logs in as the ETF partner "{transferee.agent}"
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the ETF partner completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 5 : Merger of Entitlements (203)
    # Selenium: TERENCE1 to J1360045 (Nestor Exports Ltd)
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual creates a transfer application with the following details
      | transfereeHerd  | {transferee.herd}                                                       |
      | transfereeName  | {transferee.name}                                                       |
      | transfereeAgent | agr15678                                                                |
      | transferType    | Merger of 2 or more holdings (forming an unregistered Farm Partnership) |
      | entitlements    | 0.01                                                                    |
      | notes           | Test Notes                                                              |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (ETF Partner) ---
    When the agent logs out and re-logs in as the ETF partner "{transferee.agent}"
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the ETF partner completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 6 : Division of Entitlements (204)
    # Selenium: DANIELPAUL to D1051289 (Browne Exports Ltd)
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual creates a transfer application with the following details
      | transfereeHerd  | {transferee.herd}                   |
      | transfereeName  | {transferee.name}                   |
      | transfereeAgent | agr15678                            |
      | transferType    | Division of Entitlements (Scission) |
      | entitlements    | 0.01                                |
      | notes           | Test Notes                          |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (ETF Partner) ---
    When the agent logs out and re-logs in as the ETF partner "{transferee.agent}"
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the ETF partner completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 7 : Change of Registration (205)
    # Selenium: TERENCE1 to D1190050 (Thomas Treanor)
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual creates a transfer application with the following details
      | transfereeHerd  | {transferee.herd}              |
      | transfereeName  | {transferee.name}              |
      | transfereeAgent | agr15678                       |
      | transferType    | Change of Registration Details |
      | entitlements    | 0.01                           |
      | notes           | Test Notes                     |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (ETF Partner) ---
    When the agent logs out and re-logs in as the ETF partner "{transferee.agent}"
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the ETF partner completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 8 : Change of Legal Entity (206)
    # Selenium: DANIELPAUL to J1360045 (Nestor Exports Ltd)
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual creates a transfer application with the following details
      | transfereeHerd  | {transferee.herd}      |
      | transfereeName  | {transferee.name}      |
      | transfereeAgent | agr15678               |
      | transferType    | Change of Legal Entity |
      | entitlements    | 0.01                   |
      | notes           | Test Notes             |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (ETF Partner) ---
    When the agent logs out and re-logs in as the ETF partner "{transferee.agent}"
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the ETF partner completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully