package com.stepdefinitions;

import com.base.ConfigReader;
import com.base.DriverManager;
import com.pages.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.codehaus.plexus.util.cli.Arg;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Action;
import org.testng.Assert;

import java.io.IOException;
import java.util.Properties;

public class CreateBPSApplicationSteps {


        LoginPage loginPage;
        ApplicationPortalPage applicationportalPage;
        BPSdashboardPage bpSdashboardPage;
        WebDriver driver;
        Properties prop;
        ConfigReader configReader;
        DriverManager driverManager;

        public CreateBPSApplicationSteps(DriverManager driverManager){
            try {
//            driver = driverManager.getDriver();
                this.driverManager=driverManager;
                driver=driverManager.getDriverInstance();
                loginPage = new LoginPage(driver);
                applicationportalPage = new ApplicationPortalPage(driver);
                bpSdashboardPage = new BPSdashboardPage(driver);
                configReader = new ConfigReader();
                prop = configReader.init_prop();
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }

    // region BPS Steps

    @When("Agent navigates to the fourth page using pagination")
    public void NavigateToPageWithNoApplicationClient() throws InterruptedException {
        applicationportalPage.AgentClickOnPaginationButton();
        Thread.sleep(2000);
    }

    @And("Agent Selects Client with GLAS Application")
    public void AgentSelectClientWithGLASApplication() {
        applicationportalPage.AgentclickOnGLASApplicationClientRadiobutton();
    }

    @Then("Agent Check if GLAS Tab Displayed")
    public void AgentCheckVisibilityOfGLASTab() throws InterruptedException {
        Assert.assertTrue(applicationportalPage.VisibilityOfGLASTab());
        Thread.sleep(3000);
    }

    @Then("Agent clicks on the Client View Button")
    public void AgentClickOnClientViewButton() throws InterruptedException {
        applicationportalPage.AgentClickOnViewClientButton();
        Thread.sleep(2000);
    }

    @Then("Agent Click on Outstanding Application Tab View Button")
    public void AgentClickOnOutstandingApplicationPageViewButton() throws InterruptedException {
        applicationportalPage.ClickOnOutstandingBPSApplicationsViewButton();
        Thread.sleep(2000);
    }

    @And("Agent is on BPS Agent Application portal")
    public void ApplicationPortalPage() {
        String title = driver.getTitle();
        System.out.println("title of Application Portal Page" + title);
    }

    @And("Agent clicks on the Start 2022 BPS Application")
    public void AgentClicksOnStartBPSApplicationButton() throws InterruptedException {
        applicationportalPage.AgentClickOnStartApplicationButton();
        Thread.sleep(2000);
    }

    @And("Agent clicks on the Start 2022 BPS Amendment")
    public void AgentClicksOnStartBPSAmendmentButton() throws InterruptedException {
        applicationportalPage.AgentClickOnStartAmendmentButton();
        Thread.sleep(2000);
    }

    @And("Agent clicks on the email in the Applicant Details panel")
    public void AgentClicksOnApplicantDetailsEmail() throws InterruptedException {
        applicationportalPage.AgentClickOnApplicantDetailsEmail();
        Thread.sleep(2000);
    }

    @And("Agent clicks on Organic Farming Checkbox")
    public void AgentClicksOnOrganicFarmingCheckbox() throws InterruptedException {
        applicationportalPage.AgentClickOnOrganicFarmingCheckbox();
        Thread.sleep(2000);
    }

    @And("Agent clicks on ANC Checkbox")
    public void AgentClicksOnANCCheckbox() throws InterruptedException {
        applicationportalPage.AgentClickOnANCCheckbox();
        Thread.sleep(2000);
    }

    @And("Agent Check ANC CheckBox Text for Year 2022")
    public void AgentCheckANC2022() {
        Assert.assertTrue(applicationportalPage.AgentCheckANCCheckBoxText());
    }

    @And("Check if the Active Farmer Section Visible")
    public void AgentCheckIfActiveFarmerSectionVisible() throws InterruptedException {
        Assert.assertTrue(applicationportalPage.VisibilityOfActiverFarmerSection());
        Thread.sleep(2000);
    }

    @And("Click on the Real Estate option in Active Farmers Section")
    public void AgentClicksOnRealEstateOption() throws InterruptedException {
        applicationportalPage.AgentClickOnRealEstateCheckbox();
        Thread.sleep(2000);
    }

    @And("Click on the Waterworks option in Active Farmers Section")
    public void AgentClicksOnWaterworksOption() throws InterruptedException {
        applicationportalPage.AgentClickOnWaterworksCheckbox();
        Thread.sleep(2000);
    }

    @Then("Click on the I have Land Changes Button")
    public void AgentClickOnIHaveLandChangesButton() throws InterruptedException {
        applicationportalPage.AgentClickOnIhaveLandChanges();
        Thread.sleep(2000);
    }

    @Then("Agent Deletes Draft Application")
    public void AgentDeleteDraftApplciation() throws InterruptedException {
        applicationportalPage.DeleteDraftApplication();
        Thread.sleep(2000);
    }

    @And("Agent clicks on the Resume 2022 BPS Application")
    public void AgentClicksOnResumeBPSApplicationButton() throws InterruptedException {
        applicationportalPage.AgentClickOnResumeApplicationButton();
        Thread.sleep(2000);
    }

    @And("Agent Clicks on Applicant Details Page Next Button")
    public void AgentClicksOnApplicantDetailsNextButton() throws InterruptedException {
        applicationportalPage.AgentClickOnApplicantDetailsNextButton();
        Thread.sleep(3000);
    }

    @Then("Agent Clicks on the Land Details Page Add Parcel Button")
    public void AgentClicksOnLandDetailsAddParcelButton() throws InterruptedException {
        applicationportalPage.AgentClickOnApplicantAddParcelButton();
        Thread.sleep(2000);
    }

    @And("Agent Enters the Land Details Parcel Number {string}")
    public void AgentEnterLandDetailsParcelNumber(String arg0) {
        applicationportalPage.AgentEnterLandDetailsParcelNumber(arg0);
    }

    @And("Agent Selects County as {string} for Opening Map")
    public void AgentSelectCountyToOpenMap(String arg0) {
        applicationportalPage.AgentSelectCountyForMap(arg0);
    }

    @And("Agent Selects Townland as {string} for Opening Map")
    public void AgentSelectTownlandToOpenMap(String arg0) {
        applicationportalPage.AgentSelectTownlandForMap(arg0);
    }

    @Then("Agent Click On Open Map Button")
    public void AgentClickOnOpenMapButton() {
        applicationportalPage.AgentClickOnParcelSearchOpenMapButton();
    }


    @Then("Agent Select Published Parcel from Feature Box")
    public void AgentSelectPublishedParcelOnMap() {
        applicationportalPage.AgentClickOnPublishedParcel();
    }


    @And("Agent Clicks on the Land Details Page Parcel Search Claim Button")
    public void AgentClicksOnLandDetailsParcelSearchClaimButton() throws InterruptedException {
        applicationportalPage.AgentClickOnParcelSearchClaimButton();
        Thread.sleep(3000);
    }

    @And("Check if the Parcel Not Found Message is Displayed")
    public void AgentCheckIfParcelNotFoundMessageVisible() throws InterruptedException {
        //applicationportalPage.VisibilityOfParcelNotFoundMessage();
        //Assert.assertTrue("Parcel not found.", applicationportalPage.VisibilityOfParcelNotFoundMessage());
        Assert.assertEquals("Parcel not found.", applicationportalPage.VisibilityOfParcelNotFoundMessage());
        Thread.sleep(2000);
    }

    @And("Check if the Parcel Archived Message is Displayed")
    public void AgentCheckIfParcelArchivedMessageVisible() throws InterruptedException {
        Assert.assertEquals("This parcel has been archived, below is the current iteration of this parcel", applicationportalPage.VisibilityOfParcelArchivedMessage());
        Thread.sleep(2000);
    }

    @And("Check if the Parcel Claimed Message is Displayed")
    public void AgentCheckIfParcelClaimedMessageVisible() throws InterruptedException {
        Assert.assertEquals("You have already claimed this parcel. To modify a claim on a parcel, please return to the land details list and amend the parcel's details.", applicationportalPage.VisibilityOfParcelClaimedMessage());
        Thread.sleep(2000);
    }


    @And("Check if the Parcel Search Dialog Next Button is Disabled")
    public void AgentCheckIfParcelSearchDialogNextButtonDisabled() throws InterruptedException {
        Assert.assertFalse(applicationportalPage.VisibilityOfParcelSearchDialogNextButton());
        Thread.sleep(2000);
    }

    @And("Check if the Add Plot Dialog Next Button is Disabled")
    public void AgentCheckIfAddPlotDialogNextButtonDisabled() throws InterruptedException {
        Assert.assertFalse(applicationportalPage.AgentCheckIfAddPlotDialogNextButtonStatus());
        Thread.sleep(2000);
    }

    @And("Agent Enters the Claimed Area in ha {string}")
    public void AgentEnterClaimedArea(String arg0) {
        applicationportalPage.AgentEnterClaimedAreaInParcelSearchDialog(arg0);
    }


    @And("Agent selects Ownership Status as {string} from the dropdown")
    public void AgentSelectOwnershipStatusFromDropdown(String arg0) {
        applicationportalPage.AgentSelectOwnershipStatus(arg0);
    }

    @And("Agent selects Parcel Use as {string} from the dropdown")
    public void AgentSelectParcelUseFromDropdown(String arg0) {
        applicationportalPage.AgentSelectParcelUse(arg0);
    }

    @And("Agent Enter Commonage Fraction Numerator Value")
    public void AgentEntercommonageFractionNumeratorValue() {
        applicationportalPage.AgentEnterParcelCommonageFractionNumeratorValue();
    }

    @And("Agent Enter Commonage Fraction Denominator Value")
    public void AgentEntercommonageFractionDenominatorValue() {
        applicationportalPage.AgentEnterParcelCommonageFractionDenominatorValue();
    }

    @And("Agent click on the Parcel Search Dialog Next Button")
    public void AgentClicksOnParcelSearchDialogNextButton() throws InterruptedException {
        applicationportalPage.AgentClickOnParcelSearchDialogNextButton();
        Thread.sleep(2000);
    }

//    @And("Agent Selects Organic Status as {string} for created map parcel")
//    public void ChangeOrganicStatusOfMapParcel(String arg0) throws InterruptedException {
//        applicationportalPage.AgentSelectMapParcel2OrganicStatus(arg0);
//        Thread.sleep(2000);
//    }

    @Then("Agent Selects Organic Status as {string} for created parcel")
    public void AgentSelectParcelOrganicStatusFromDropdown(String arg0) throws InterruptedException {
        applicationportalPage.AgentSelectParcelOrganicStatus(arg0);
        Thread.sleep(2000);
    }

    @And("Agent Selects Organic Status as {string} for created map parcel")
    public void AgentSelectMapParcelOrganicStatusFromDropdown(String arg0) throws InterruptedException {
        applicationportalPage.AgentSelectMapParcelOrganicStatus(arg0);
        Thread.sleep(2000);
    }


    @And("Agent Navigate to First Page in Land Details Tab")
    public void AgentNavigateToFirstTabInLandDetailsTab() throws InterruptedException {
        applicationportalPage.AgentNavigateToFirstTabInLandDetails();
        Thread.sleep(1000);
    }

    @Then("Agent Selects Organic Status as {string} for all existing parcels")
    public void ChangeOrganicStatusOfAllExistingParcels(String arg0) throws InterruptedException {
        applicationportalPage.ChangeOrganicStatusOfAlreadyPresentParcels(arg0);
        Thread.sleep(2000);
    }

//    @And("Agent Selects Organic Status as {string} for created map plot")
//    public void ChangeOrganicStatusOfMapPlot(String arg0) throws InterruptedException {
//            applicationportalPage.AgentSelectMapPlot2OrganicStatus(arg0);
//            Thread.sleep(2000);
//    }

    @Then("Agent Check the Warning Message displayed when Notes Empty")
    public void AgentCheckMapInfoSectionWarningMessage() {
        Assert.assertEquals(applicationportalPage.AgentCheckInfoSectionWarningMessage(), "Note cannot be empty.");
    }


    // Add Plot Box

    @And("Agent clicks on the ANC check box to enable Island Plots")
    public void AgentClicksOnANCcheckbox() throws InterruptedException {
        applicationportalPage.AgentClickOnANCCheckBox();
        Thread.sleep(2000);
    }

    @Then("Agent Clicks on the Land Details Page Add Plot Button")
    public void AgentClicksOnLandDetailsAddPlotButton() throws InterruptedException {
        applicationportalPage.AgentClickOnApplicantAddPlotButton();
        Thread.sleep(2000);
    }

    @And("Agent Check Visibility of Island Plot CheckBox")
    public void AgentCheckIfIslandPlotCheckBoxVisible() throws InterruptedException {
        Assert.assertTrue(applicationportalPage.VisibilityOfIslandPlotCheckBox());
        Thread.sleep(2000);
    }

    @And("Agent Selects County as {string} for adding Plot")
    public void AgentSelectAddPlotCountyFromDropdown(String arg0) {
        applicationportalPage.AgentSelectAddPlotCounty(arg0);
    }

    @And("Agent Selects Townland as {string} for adding Plot")
    public void AgentSelectAddPlotTownlandFromDropdown(String arg0) {
        applicationportalPage.AgentSelectAddPlotTownland(arg0);
    }

    @And("Agent Enters the Add Plot Plot Reference in ha {string}")
    public void AgentEnterAddPlotPlotReference(String arg0) {
        applicationportalPage.AgentEnterAddPlotPlotReferenceNumber(arg0);
    }

    @And("Agent Selects Ownership Status as {string} for adding Plot")
    public void AgentSelectAddPlotOwnershipStatusFromDropdown(String arg0) {
        applicationportalPage.AgentSelectAddPlotOwnershipStatus(arg0);
    }

    @And("Agent Enters the Add Plot Claimed Area in ha {string}")
    public void AgentEnterAddPlotClaimedArea(String arg0) {
        applicationportalPage.AgentEnterAddPlotClaimedArea(arg0);
    }

    @And("Agent Selects Plot Use as {string} for adding Plot")
    public void AgentSelectAddPlotPlotUseFromDropdown(String arg0) {
        applicationportalPage.AgentSelectAddPlotPlotUse(arg0);
    }

    @Then("Agent click on the Add Plot Dialog Submit Paper Map By Post Radio Button")
    public void AgentClicksOnAddPlotDialogSubmitMapByPostRadioButton() throws InterruptedException {
        applicationportalPage.AgentClickOnAddPlotSubmitMapRadioButton();
        Thread.sleep(2000);
    }

    @Then("Agent click on the Add Plot Dialog Edit Map Online Radio Button")
    public void AgentClicksOnAddPlotDialogEditMapOnlineRadioButton() throws InterruptedException {
        applicationportalPage.AgentClickOnAddPlotEditMapOnlineRadioButton();
        Thread.sleep(2000);
    }

    @Then("Agent click on the Add Plot Upload Map Radio Button")
    public void AgentClicksOnAddPlotDialogUploadMapRadioButton() throws InterruptedException {
        applicationportalPage.AgentClickOnAddPlotUploadMapRadioButton();
        Thread.sleep(2000);
    }

    @And("Agent click on the Add Plot Dialog Next Button")
    public void AgentClicksOnAddPlotDialogNextButton() throws InterruptedException {
        applicationportalPage.AgentClickOnAddPlotNextButton();
        Thread.sleep(2000);
    }

    @And("Agent click on the Add Plot Dialog Next Button to Draw Map")
    public void AgentClicksOnAddPlotDialogNextButtonToDrawMap() throws InterruptedException {
        applicationportalPage.AgentClickOnAddPlotNextButtonToDrawMap();
        Thread.sleep(2000);
    }

    @And("Agent Close the Useful Information Dialog")
    public void AgentClickOnUsefulInfomrationDialogBoxCloseButton() throws InterruptedException{
        applicationportalPage.AgentClickOnUsefulInformationDialogCloseButton();
        Thread.sleep(2000);
    }

    @Then("Agent Click On the Edit Map Page Draw Button")
    public void AgentClickOnEditMapPageDrawButton() throws InterruptedException {
        applicationportalPage.AgentClickOnEditMapPageDrawButton();
        Thread.sleep(10000);
    }

    @And("Agent Draw plot on the Map")
    public void AgentDrawPlotOnMap() throws InterruptedException {
        applicationportalPage.AgentDrawMapBoundariesOnEditMapScreen();
        Thread.sleep(6000);
    }


    @And("Agent Draw plot on the Parcel Split Map")
    public void AgentDrawPlotOnParcelSplitMap() throws InterruptedException {
        applicationportalPage.AgentDrawMapBoundariesOnSplitMapScreen();
        Thread.sleep(6000);
    }

    @And("Agent Click On the Edit Map Page Confirm Button")
    public void AgentClickOnEditMapPageConfirmButton() throws InterruptedException {
        applicationportalPage.AgentClickOnEditMapPageConfirmButton();
        Thread.sleep(6000);
    }

    @And("Agent Enter Attribute Notes as {string} in the Info Section of Edit Maps Page")
    public void AgentEnterAttributeNotesInEditMapPage(String Arg0) {
        applicationportalPage.AgentEnterAttributeNotes(Arg0);
    }

    @And("Agent Click on the Edit Map Page Info Section Confirm Button")
    public void AgentClickOnInfoSectionConfirmButton() throws InterruptedException {
        applicationportalPage.AgentClickOnEditMapPageInfoSectionConfirmButton();
        Thread.sleep(6000);
    }

    @Then("Agent Click on the Return to Land Details Page Button")
    public void AgentclickOnReturnToLandDetailsButton(){
        applicationportalPage.AgentClickOnReturnToLandDetails();
    }

    @And("Agent Selects Organic Status as {string} for first created plot")
    public void AgentSelectPlot1OrganicStatusFromDropdown(String arg0) throws InterruptedException {
        applicationportalPage.AgentSelectPlot1OrganicStatus(arg0);
        Thread.sleep(2000);
    }

    @And("Agent Selects Organic Status as {string} for second created plot")
    public void AgentSelectPlot2OrganicStatusFromDropdown(String arg0) throws InterruptedException {
        applicationportalPage.AgentSelectPlot2OrganicStatus(arg0);
        Thread.sleep(2000);
    }

    @And("Agent Selects Organic Status as {string} for created map plot")
    public void AgentSelectMapPlotOrganicStatusFromDropdown(String arg0) throws InterruptedException {
        applicationportalPage.AgentSelectMapPlotOrganicStatus(arg0);
        Thread.sleep(2000);
    }

    @And("Agent Clicks on Land Details Page Next Button")
    public void AgentClicksOnLandDetailsNextButton() throws InterruptedException {
        applicationportalPage.AgentClickOnLandDetailsNextButton();
        Thread.sleep(2000);
    }

    @Then("Agent Selects Ownership Status as {string} for second created plot")
    public void AgentSelectPlotOwnershipStatusFromDropdown(String arg0) throws InterruptedException {
        applicationportalPage.AgentSelectPlot2OwnershipStatus(arg0);
        Thread.sleep(2000);
    }

    @And("Check if the Plot Cannot Be Rented In Message is Displayed")
    public void AgentCheckIfPlotCannotBeRentedInMessageVisible() throws InterruptedException {
        Assert.assertEquals("Warning: Rented or Commonage lands cannot be claimed for the Organic Farming Scheme", applicationportalPage.VisibilityOfPlotCannotBeRentedInErrorMessage());
        Thread.sleep(2000);
    }

    @And("Agent Check Visibility of Change of MEA CheckBox")
    public void AgentCheckIfChangOfMEACheckBoxVisible() throws InterruptedException {
        Assert.assertTrue(applicationportalPage.VisibilityOfChangeOfMEACheckbox());
        Thread.sleep(2000);
    }

    @And("Click on the Change of MEA Checkbox")
    public void AgentClicksOnChangOfMEACheckbox() throws InterruptedException {
        applicationportalPage.AgentClickOnChangeOfMEACheckBox();
        Thread.sleep(2000);
    }

    @And("Agent Enters the MEA Note as {string}")
    public void AgentEnterMEANote(String arg0) throws InterruptedException {
        applicationportalPage.AgentEnterNoteInMEATextBox(arg0);
    }

    @And("Verify if Please describe reason Change of MEA Error Message is displayed")
    public void AgentCheckIfChangeOfMEAErrorMessageVisible() throws InterruptedException {
        //Assert.assertEquals("Please describe reason for requesting change of MEA", applicationportalPage.VisibilityOfChangeOfMEAMessage());
        Thread.sleep(2000);
    }

    @Then("Agent deletes all existing parcels")
    public void AgentDeleteAllExistingParcels() throws InterruptedException {
        applicationportalPage.DeleteAlreadyPresentParcels();
        Thread.sleep(3000);
    }

//    @Then("Agent deletes first existing parcel")
//    public void AgentDeleteFirstParcel() throws InterruptedException {
//        applicationportalPage.AgentClickOnFirstExistingParcelDeleteButton();
//        Thread.sleep(1000);
//    }
//
//    @And("Agent deletes second existing parcel")
//    public void AgentDeleteSecondParcel() throws InterruptedException {
//        applicationportalPage.AgentClickOnSecondExistingParcelDeleteButton();
//        Thread.sleep(1000);
//    }
//
//    @And("Agent deletes third existing parcel")
//    public void AgentDeleteThirdParcel() throws InterruptedException {
//        applicationportalPage.AgentClickOnThirdExistingParcelDeleteButton();
//        Thread.sleep(1000);
//    }
//
//    @And("Agent deletes fourth existing parcel")
//    public void AgentDeleteFourthParcel() throws InterruptedException {
//        applicationportalPage.AgentClickOnFourthExistingParcelDeleteButton();
//        Thread.sleep(1000);
//    }
//
//    @And("Agent deletes fifth existing parcel")
//    public void AgentDeleteFifthParcel() throws InterruptedException {
//        applicationportalPage.AgentClickOnFifthExistingParcelDeleteButton();
//        Thread.sleep(1000);
//    }
//
//    @And("Agent deletes sixth existing parcel")
//    public void AgentDeleteSixthParcel() throws InterruptedException {
//        applicationportalPage.AgentClickOnSixthExistingParcelDeleteButton();
//        Thread.sleep(1000);
//    }


    @Then("Agent tries to delete created parcel")
    public void AgentDeleteParcel() throws InterruptedException {
        applicationportalPage.AgentClickOnParcelDeleteButton();
        Thread.sleep(2000);
    }

    @Then("Agent tries to subdivide created parcel {string}")
    public void AgentSubdivideParcel(String Arg0) throws InterruptedException {
        applicationportalPage.AgentClickOnParcelSubdivideButton(Arg0);
    }

    @And("Agent clicks on Undo icon to reverse the deletion of Parcel")
    public void AgentUndoParcelDelete() throws InterruptedException {
        applicationportalPage.AgentClickOnParcelUndoDeleteButton();
        Thread.sleep(2000);
    }

    @Then("Check if ANC column is displayed")
    public void AgentCheckANCVisibility() throws InterruptedException {
        applicationportalPage.VisibilityOfANCColumnLabel();
        Thread.sleep(2000);
    }


    @Then("Check if GLAS column is displayed")
    public void AgentCheckGLASVisibility() throws InterruptedException {
        Assert.assertTrue(applicationportalPage.VisibilityOfGLASColumnLabel());
        Thread.sleep(2000);
    }

    @And("Click on Save Button in the Land Details Page")
    public void AgentSaveApplication() throws InterruptedException {
        applicationportalPage.AgentClickOnLandDetailsSaveButton();
        Thread.sleep(2000);
    }

    @And("{string} found on Organic Page")
    public void NoParcelsOnOrganicPage(String arg0) throws InterruptedException {
        Assert.assertEquals(arg0, applicationportalPage.VisibilityOfNoParcelsOrPlotsMessage());
        Thread.sleep(2000);
    }

    @And("{string} not found on Organic Page")
    public void ParcelsFoundOnOrganicPage(String arg0) throws InterruptedException {
        //Assert.assertNotEquals(arg0, applicationportalPage.VisibilityOfNoParcelsOrPlotsMessage());
        System.out.println(arg0 + "message not found");
        Thread.sleep(2000);
    }

    @And("Agent Clicks on Organic Details Page Back Button")
    public void AgentClickOnBackButton() throws InterruptedException {
        applicationportalPage.AgentClickOnBackButton();
        Thread.sleep(2000);
    }

    @And("Check if Lease expiry date populated as {string}")
    public void AgentCheckIfChangeOfMEAErrorMessageVisible(String arg0) throws InterruptedException {
        System.out.println("Date = " + applicationportalPage.VisibilityOfLeaseExpiryDate());
        //Assert.assertEquals(arg0, applicationportalPage.VisibilityOfLeaseExpiryDate());
        Thread.sleep(2000);
    }

    @Then("Agent Check if Crop Diversification Provisional Status Displayed and Read Only")
    public void AgentcheckVisibilityOfCDProvisionalStatus() {
        Assert.assertTrue(applicationportalPage.CheckVisibilityOfCDProvisionalStatus());
    }

    @And("Agent Check if EFA Provisional Status Displayed and Read Only")
    public void AgentcheckVisibilityOfEFAProvisionalStatus() {
        Assert.assertTrue(applicationportalPage.CheckVisibilityOfEFAProvisionalStatus());
    }

    @Then("Agent Check if GLAS Area Actions Tab Displayed First")
    public void AgentCheckGLASActionsAreaTabDisplayedFirst() {
        applicationportalPage.VisibilityOfGLASAreaActionsTab();
    }

    @And("Agent Clear Claimed Area for first Parcel in GLAS Area Actions Tab")
    public void AgentClearclaimedAreaForFirstGLASAreaActionsParcel() {
        applicationportalPage.ClaimedAreaClearedForGLAsAreaActions();
    }

    @And("Agent Check if Claimed Area Empty Error Message Displayed for GLAS Area Actions")
    public void AgentCheckIfClaimedAreaEmptyErrorMessageDisplayedForGLASAreaActions() {
        Assert.assertTrue(applicationportalPage.ClaimedAreaEmptyForGLASAreaActions());
    }

    @And("Agent Navigate to GLAS Linear Actions Tab")
    public void AgentNavigateToGLASLinearActionsTab() throws InterruptedException {
        applicationportalPage.ClickOnGLASLinearActionsTab();
        Thread.sleep(1000);
    }

    @And("Agent Navigate to GLAS Numerical Actions Tab")
    public void AgentNavigateToGLASNumericalActionsTab() throws InterruptedException {
        applicationportalPage.ClickOnGLASNumericalActionsTab();
        Thread.sleep(1000);
    }

    @And("Agent Navigate to GLAS Whole Farm Actions Tab")
    public void AgentNavigateToGLASWholeFarmActionsTab() throws InterruptedException {
        applicationportalPage.ClickOnGLASWholeFarmActionsTab();
        Thread.sleep(1000);
    }

    @And("Agent Navigate to GLAS Commonage Actions Tab")
    public void AgentNavigateToGLASCommonageActionsTab() throws InterruptedException {
        applicationportalPage.ClickOnGLASCommonageActionsTab();
        Thread.sleep(1000);
    }

    @And("Agent Check if GLAS Claimed Area field is Numeric")
    public void AgentCheckIfClaimedAreaFieldIsNumeric() throws InterruptedException {
        //Assert.assertTrue(applicationportalPage.AgentCheckClaimedAreaForGLASAreaActionsIsNumeric());
        Assert.assertEquals(applicationportalPage.AgentCheckClaimedAreaForGLASAreaActionsIsNumeric(),"1.98");
        Thread.sleep(4000);
    }


    @Then("Navigate to Client HomePage")
    public void AgentNavigateToClientPage() throws InterruptedException {
        bpSdashboardPage.AgentNavigateToClientHomePage();
        driver.switchTo().alert().accept();
        Thread.sleep(2000);
    }

    @And("Agent Navigate to Second Page in Land Details Tab")
    public void AgentNavigateToSecondPageOfLandDetailsTab() throws InterruptedException {
        applicationportalPage.AgentNavigateToSecondTabInLandDetails();
        Thread.sleep(3000);
    }

    @Then("Enter Reference Claimed Area as {string} for Parcel")
    public void AgentEnterOrganicPageClaimedAreaForParcel(String arg0) throws InterruptedException {
        applicationportalPage.AgentEnterOrganicReferenceclaimedArea("Keys.DELETE");
        applicationportalPage.AgentEnterOrganicReferenceclaimedArea(arg0);
        Thread.sleep(2000);
    }

    @Then("Delete Reference Claimed Area using {string} for Plot")
    public void AgentDeleteOrganicPageClaimedAreaForPlot(String arg0) throws InterruptedException {
        applicationportalPage.AgentEnterOrganicReferenceclaimedAreaForPlot("Keys.DELETE");
        Thread.sleep(2000);
    }

    @And("Check if Reference Claimed Area Empty Error Message Displayed")
    public void AgentCheckAgentClaimedAreaEmptyMessage() throws InterruptedException {
        Assert.assertEquals("Please enter Reference Claimed Area",applicationportalPage.ReferenceAreaEmptyErrorMessage());
        Thread.sleep(2000);
    }

    @And("Check if Reference Claimed Area Greater Error Message Displayed")
    public void AgentCheckAgentClaimedAreaGreaterMessage() throws InterruptedException {
        Assert.assertEquals("Reference Claimed Area is greater than the Reference area",applicationportalPage.ReferenceAreaGreaterErrorMessage());
        Thread.sleep(2000);
    }

    @And("Check if Parcel1 Displayed in Greening Page")
    public void AgentCheckIfParcel1Displayed() throws InterruptedException {
        Assert.assertEquals("L1350400015",applicationportalPage.TextOfParcel1Number());
    }

    @And("Check if Plot1 Displayed in Greening Page")
    public void AgentCheckIfPlot1Displayed() throws InterruptedException {
        Assert.assertEquals("T1261300010",applicationportalPage.TextOfPlot1Number());
    }

    @And("Check if Plot2 Displayed in Greening Page")
    public void AgentCheckIfPlot2Displayed() throws InterruptedException {
        Assert.assertEquals("T1261300011",applicationportalPage.TextOfPlot2Number());
    }

    @And("Agent Clicks on Organic Details Page Next Button")
    public void AgentClickOnOrganicPageNextButton() throws InterruptedException {
        applicationportalPage.AgentClickOnOrganicPageNextButton();
        Thread.sleep(2000);
    }

    @And("Check if Greening Exemption Enabled in Greening Page")
    public void AgentCheckIfGreeningExemptionEnabled() {
        Assert.assertTrue(applicationportalPage.GreeningExemptionEnabled());
    }

    @And("Agent Navigates from Greening Page to GLAS Page")
    public void AgentNavigateToGLASPage() throws InterruptedException {
        applicationportalPage.NavigateToGLASPage();
        Thread.sleep(2000);
    }

    @And("Agent Navigates from GLAS Page to Application Summary Page")
    public void AgentNavigateToApplicationSummaryPage() throws InterruptedException {
        applicationportalPage.NavigateToApplicationSummaryPage();
        Thread.sleep(2000);
    }

    @And("Agent Navigates to Greening Page Crop Diversification Tab")
    public void AgentNavigateToGreeeningPageCropDiversification() throws InterruptedException {
        //applicationportalPage.ClickOnGreeningPageNextButton();
        applicationportalPage.NavigateToGreeningCropDiversificationPage();
        Thread.sleep(2000);
    }

    @And("Agent Navigates to Greening Page Summary Tab")
    public void AgentNavigateToGreeeningPageSummary() throws InterruptedException {
        //applicationportalPage.ClickOnGreeningPageNextButton();
        applicationportalPage.NavigateToGreeningSummaryPage();
        Thread.sleep(2000);
    }


    @And("Agent Navigates to Greening EFA Tab")
    public void AgentNavigateToGreeeningPageEFA() throws InterruptedException {
        //applicationportalPage.ClickOnGreeningPageNextButton();
        applicationportalPage.NavigateToGreeningEFAPage();
        Thread.sleep(2000);
    }

    @Then("Agent Clicks on the 50 Percent Exemption CheckBox")
    public void AgentSelectGreeningFiftyPercentExemption() throws InterruptedException {
        applicationportalPage.SelectFiftyPercentExemptionCheckBox();
        Thread.sleep(1000);
    }

    @And("Agent CLick on Greening Page Crop Diversification Save Button")
    public void AgentClickOnGreeningCropDiversificationSaveButton() throws InterruptedException {
        applicationportalPage.ClickOnGreeningPageCropDiversificationSaveButton();
        Thread.sleep(1000);
    }

    @Then("Agent Clicks on the 50 Percent Exemption Link")
    public void AgentClickOnGreeningFiftyPercentExemptionLink() throws InterruptedException {
        applicationportalPage.ClickOnTheFiftyPercentExemptionLink();
        Thread.sleep(2000);
    }

    @Then("Agent Check if Upload Map displayed for Plot 2")
    public void AgentCheckIfPlot2MessageDisplayed() throws InterruptedException {
        Assert.assertEquals("After submitting this form, please upload required maps and documentation to support your claims on plots:",applicationportalPage.Plot2MapMessageText());
        Assert.assertEquals("T1261300011.",applicationportalPage.PlotNumberforUploadMap());
    }

    @Then("Agent Check if Submit Map By Post displayed for Plot 1")
    public void AgentCheckIfPlot1MessageDisplayed() throws InterruptedException {
        Assert.assertEquals("Please ensure you submit by post required maps and documentation to support your claims on plots:",applicationportalPage.Plot1MapMessageText());
        Assert.assertEquals("T1261300010.",applicationportalPage.PlotNumberforSubmitMap());
    }

    @And("Agent Enters the Application Note as {string}")
    public void AgentEnterApplicationNote(String arg0) throws InterruptedException {
        applicationportalPage.AgentEnterNotesForApplication(arg0);
        Thread.sleep(5000);
    }

    @Then("Agent Open Pre-Submit Checklist")
    public void AgentClickOnPreSubmitCheckListLink() {
        applicationportalPage.AgentClickOnPreSubmitcheckList();
    }

    @And("Agent Close Pre-Submit Checklist")
    public void AgentClickOnCloseCheckList() {
        applicationportalPage.AgentClickOnCloseButton();
    }

    @Then("Agent Click on Application Summary Ineligible ANC Parcels")
    public void AgentOpenOnIneligibleANCParcels() {
        applicationportalPage.AgentClickOnIneligibleParcels();
    }

    @And("Agent Select Ineligible Parcel from List")
    public void AgentSelectIneligibleParcel() throws InterruptedException {
        applicationportalPage.AgentSelectIneligibleParcel();
        Thread.sleep(2000);
    }

    @And("Agent Save the Ineligible Parcels")
    public void AgentSaveIneligibleParcels() throws InterruptedException {
        applicationportalPage.AgentSaveIneligibleParcels();
        Thread.sleep(2000);
    }

    @And("Agent Clicks on Application Summary Page Back Button")
    public void AgentClickOnApplicationSummaryPageBackButton() throws InterruptedException {
        applicationportalPage.AgentClickOnBackButton();
        Thread.sleep(2000);
    }

    @Then("Navigate to Terms And Conditions Page")
    public void AgentNavigateToTermsAndConditionsPage() throws InterruptedException {
        applicationportalPage.NavigateToTermsAndConditionsPage();
        Thread.sleep(2000);
    }

    @Then("Agent Check if  Terms And Conditions not Accepted")
    public void AgentCheckIfTermsAndConditionsNotAccepted() throws InterruptedException {
        Assert.assertFalse(applicationportalPage.TermsAndConditionsCheckboxNotSelected());
    }

    @And("Agent Check if Submit Button is Inactive")
    public void AgentCheckIfSubmitButtonInactive() throws InterruptedException {
        Assert.assertFalse(applicationportalPage.CheckIfSubmitButtonInActive());
    }

    @And("Agent Accept Terms and Conditions")
    public void AgentAcceptTermsAndConditions() throws InterruptedException {
        applicationportalPage.TermsAndConditionsAccpeted();
    }

    @And("Agent Check if  Terms And Conditions Accepted")
    public void AgentCheckIfTermsAndConditionsAccepted() throws InterruptedException {
        Assert.assertTrue(applicationportalPage.TermsAndConditionsCheckboxNotSelected());
    }

    @And("Agent Check if Submit Button is Active")
    public void AgentCheckIfSubmitButtonActive() throws InterruptedException {
        Assert.assertTrue(applicationportalPage.CheckIfSubmitButtonInActive());
        Thread.sleep(5000);
    }

    @Then("Click on Return to Portal Button")
    public void AgentClickOnReturnToPortalButton() {
        applicationportalPage.ClickOnVisitPortalPage();
    }

    @Then("Click on Submit Application Button")
    public void AgentClickOnSubmitButton() throws InterruptedException {
        applicationportalPage.SubmitApplication();
        driver.switchTo().alert().accept();
        Thread.sleep(4000);
    }

    @And("Get the Herd number of Application being Submitted")
    public void GetHerdNumberOfApplicationBeingSubmitted() throws InterruptedException {
        System.out.println("The herd number used is :" + applicationportalPage.GetCurrentHerdNumber());
        Thread.sleep(2000);
    }

    @Then("Navigate to Upload Documents Screen")
    public void AgentNavigateToUploadDocumentScreen() {
        applicationportalPage.ClickOnUploadDocumentationButton();
    }

    @And("Upload Document using Choose File Option")
    public void AgentSelectFileForUpload() throws InterruptedException {
        applicationportalPage.UploadDocument();
        Thread.sleep(2000);
    }

    @And("Select Type of Document as {string} from Document Type Dropdown")
    public void AgentSelectDocType(String Arg0) {
        applicationportalPage.SelectDocumentType(Arg0);
    }

    @And("Click On Upload Button and Confirm")
    public void AgentUploadDoc() {
        applicationportalPage.ClickUploadButton();
        applicationportalPage.ClickOnUploadFileConfirmation();
    }

    @And("Click on View Application Confirmation Button")
    public void AgentClickOnViewApplicationConfirmation() throws InterruptedException {
        applicationportalPage.ClickOnVisitConfirmation();
        Thread.sleep(2000);
    }

    @Then("Agent Click on Application Confirmation Button to go back to Confirmation Page")
    public void AgentClickOnBackToApplicationConfirmationButton(){
        applicationportalPage.ClickOnBackToApplicationConfirmation();
    }

    @And("Click on Confirmation Page Print Cover Letter Button")
    public void AgentClickOnConfirmationPagePrintCoverLetterButton() {
        applicationportalPage.ClickOnPrintCoverLetterButton();
    }

    @Then("Click on the Print Preview Dialog Close Button")
    public void AgentClickOnPrintPreviewDialogCloseButton() {
        applicationportalPage.ClickOnClosePrintCoverLetterButton();
    }

    @And("Click on Confirmation Page View Application Summary Button")
    public void AgentClickOnConfirmationPageViewApplicationSummaryButton() {
        applicationportalPage.ClickOnViewApplicationSummaryButton();
    }

    @Then("Click on the Application Summary Close Button")
    public void AgentClickOnApplicationSummaryDialogCloseButton() {
        applicationportalPage.ClickOnCloseApplicationSummaryButton();
    }

    @And("Click on the Confirmation Screen Homepage Button")
    public void AgentClickOnConfirmationScreenHomepageButton() {
        applicationportalPage.ClickOnHomepageButton();
    }

    // endregion

    // region BISS Steps

    @And("Agent Click On {string} Farmer Dashboard Button")
    public void AgentClickOnContinueApplicationButton(String Arg0) throws InterruptedException {
            applicationportalPage.AgentClickOnButtonsInFarmerDashboard(Arg0);
            Thread.sleep(6000);
    }

    @Then("Agent Click on {string} Stepper")
    public void AgentClickOnApplicationStepper(String Arg0) throws InterruptedException {
            applicationportalPage.AgentClickOnApplicationStepper(Arg0);
            Thread.sleep(2000);
    }

    @When("Agent Check the Active Farmer Status and opts under {string} farming practice {string} activity")
    public void AgentCheckActiveFarmerStatus(String FarmingActivity, String GrasslandOrTillageActivity) throws InterruptedException {
            applicationportalPage.AgentCheckActivityStatusLabelText(FarmingActivity, GrasslandOrTillageActivity);
            Thread.sleep(4000);
    }

    @And("Agent Click on the {string} CheckBox")
    public void AgentClickOnActiveFarmerCheckBox(String Arg0) throws InterruptedException {
        applicationportalPage.AgentClickOnCheckbox(Arg0);
        Thread.sleep(5000);
    }

    @Then("Agent Click on the {string} scheme card")
    public void AgentClickOnSchemeCard(String Arg0) {
        applicationportalPage.AgentClickOnSchemeCard(Arg0);
    }

    @And("Agent Click on Application Stepper {string} Button")
    public void AgentClickOnApplicationStepperNextOrBackOrSubmitButton(String Arg0) throws InterruptedException {
        applicationportalPage.AgentClickOnNextOrBackOrSubmitButton(Arg0);
        Thread.sleep(15000);
    }

    @And("Agent Verify Application Stepper {string} Button")
    public void AgentVerifyOnApplicationStepperNextOrBackOrSubmitButton(String Arg0) throws InterruptedException {
        Assert.assertTrue(applicationportalPage.AgentVerifyNextOrBackOrSubmitButton(Arg0));
        Thread.sleep(6000);
    }

    @Then("Agent Click on the {string} dialog box button")
    public void AgentClickOnDialogBoxButtons(String Arg0) throws InterruptedException {
        applicationportalPage.AgentClickOnDialogBoxButton(Arg0);
    }


    @And("Agent Navigate to {string} tab on the SideNavBar")
    public void AgentClickOnSideNavBarTab(String Arg0) throws InterruptedException {
        applicationportalPage.AgentNavigateToPagesUsingSideNavBar(Arg0);
        Thread.sleep(5000);
    }


    @And("Agent Click on the {string} Actions Column Button for parcel {string}")
    public void AgentClickOnActionsColumnButtonInParcelList(String Action, String ParcelNo) throws InterruptedException {
//        applicationportalPage.AgentClickOnActionsButtonInParcelList(ParcelNo, Action);
    }

    @And("Agent Click on {string} button in the GIS Map Application NavLink")
    public void AgentClickOnGISAppNavlinks(String Arg0) throws InterruptedException {
        applicationportalPage.AgentClickOnNavLinksInMap(Arg0);
        Thread.sleep(3000);
    }

    @Given("Agent is on ENTS Farmer Dashboard Screen")
    public void AgentOnFarmerDashboardScreen() {
        String title = driver.getTitle();
        System.out.println("Title of Farmer Dashboard Page is : " + title);
    }

    @Given("Agent is on AMS Screen")
    public void AgentOnAMSScreen() {
        String title = driver.getTitle();
        System.out.println("Title of Farmer Dashboard Page is : " + title);
    }

    @And("Agent Click on the {string} Button in land details page")
    public void AgentClickOnAddParcelOrPlotButtonInLandDetailsPage(String Arg0) {
            applicationportalPage.AgentClickOnAddPlotOrAddParcelButton(Arg0);
    }




    @And("Agent Click on Next Button in Review and Submit Page")
    public void AgentClickOnNextButtonInReviewAndSubmitPage() throws InterruptedException {
        applicationportalPage.AgentClickOnNextButtonInReviewAndSubmitScreen();
    }

    @Then("Agent Click on Terms & Conditions CheckBox")
    public void AgentClickOnTermsAndConditionsCheckBox() throws InterruptedException {
            applicationportalPage.AgentClickOnTermsAndConditionsCheckBox();
            Thread.sleep(6000);
    }

    @Then("Agent Enter Value {string} in the {string} Add Parcel Or Plot Dialog TextBox")
    public void AgentEnterValueInAddParcelOrPlotDialogTextBox(String Arg0, String Arg1) {
            applicationportalPage.AgentEnterValueInAddPlotOrParcelDialog(Arg0,Arg1);
    }

    @And("Agent Click on the {string} option to submit changes to Map")
    public void AgentSelectMapChangesOption(String Arg0) {
            applicationportalPage.AgentClickOnRadioButtonsInDialogBox(Arg0);
    }

    @Then("Agent Select Value {string} in the {string} Add Parcel Or Plot Dialog Dropdown")
    public void AgentSelectValueInAddParcelOrPlotDialogDropDown(String Arg0, String Arg1) throws InterruptedException {
        applicationportalPage.AgentSelectDropdownValuesInParcelAndPlotModal(Arg0,Arg1);
    }

    @And("Check for Invalid Parcel Warning Message")
    public void AgentCheckInvalidParcelWarningMessage() {
            Assert.assertEquals(applicationportalPage.AgentCheckWarningMessageInDialog(),"Please enter a valid parcel number");
    }

    @And("Check for Claimed Parcel Warning Message")
    public void AgentCheckClaimedParcelWarningMessage() {
        Assert.assertEquals(applicationportalPage.AgentCheckBissPanelWarningMessages(),"You have already claimed this parcel. To modify a claim on a parcel, please return to the land details list and amend the parcels details.");
    }

    @And("Agent Click On {string} Tool Option inb GIS Application")
    public void AgentClickOnSelectFeatureTool(String Arg0) {
        applicationportalPage.AgentClickOnSelectFeatureToolInGIS(Arg0);
    }

    @And("Agent Click on Parcel from the Map")
    public void AgentClickOnParcel007FromMap() {
        applicationportalPage.AgentSelectParcelOnMapScreen();
    }

    @And("Agent Click on the Map Page Claim Button in GIS")
    public void AgentClickOnMapPageClaimButtoninGIS() {
        applicationportalPage.AgentClickOnMapPageClaimParcelButton();
    }

    @And("Agent Click on Plot Reference {string} to open Side Drawer")
    public void AgentClickOnPlotReferenceInList(String PlotRef) {
            applicationportalPage.AgentClickOnPlotReferenceToOpenSideDrawer(PlotRef);
    }

    // Change the dropdown value in the Side Drawer
    @And("Agent select the value as {string} in the Side Drawer {string} dropdown")
    public void AgentChangeDropdownValueInSideDrawer(String Dropdown, String Value) {
        applicationportalPage.AgentSelectValueFromSideDrawerDropdown(Dropdown, Value);
    }

    // Edit Parcel Drawer
    @And("Agent Click on CheckBox to request Eh Change")
    public void AgentClickOnReqEhChangeCheckBox() throws InterruptedException {
        Thread.sleep(4000);
            applicationportalPage.AgentClickOnReqEhChangeCheckBox();
    }

    @Then("Agent do Request for EhChange in Side Drawer with reason as {string}")
    public void AgentDoRequestForEhChangeInSideDrawer(String Reason) throws InterruptedException {
            applicationportalPage.AgentEnterReasonForEhChange(Reason);
    }

    // Check if the row number being found properly
    @Then("Agent picks the {string} parcel and performs {string} action")
    public void RowNumberCheckAndPerformAction(String ParcelNo, String ActionsColumnButton) throws InterruptedException {
            applicationportalPage.RowNumberContainingParcelAndAction(ParcelNo, ActionsColumnButton);
            Thread.sleep(4000);
    }

    // Undo Deletion of the Parcel
    @Then("Agent performs Undo action for Deletion of the Parcel")
    public void AgentUndoDeletionOfParcel() throws InterruptedException {
            applicationportalPage.UndoDeletionOfParcel();
            Thread.sleep(3000);
    }

    // Check Map for a Parcel in GAEC8 Page
    @And("Agent check Map for the parcel {string} in GAEC8 Page")
    public void AgentOpenMapForParcelINGAEC8Page(String ParcelNo) {
            applicationportalPage.AgentClickOnViewMapForParcel(ParcelNo);
    }

    // Change the GAEC8 Contribution Type
    @And("Agent change GAEC8 contribution type to {string} for the parcel {string}")
    public void AgentChangeGAEC8ContributionType(String Contribution, String ParcelNo) {
            applicationportalPage.AgentSelectGAEC8ContributionForAParcel(ParcelNo, Contribution);
    }

    // Get the SFN Contribution Value
    @And("Agent check SFN Value and Eligibilty")
    public void AgentCheckSFNValueAndEligibility() {
            applicationportalPage.CaptureSFNContributionValue();
    }


    /// ECO Page
    // Agent Select option for Eco Scheme
    @And("Agent Select the {string} Scheme Option in Eco Page")
    public void AgentSelectECOSchemeOption(String EcoSchemeOption) throws InterruptedException {
            applicationportalPage.AgentControlTogglesInEcoPage(EcoSchemeOption);
            Thread.sleep(2000);
    }

    // Agent CheckBox for Any Scheme
    @Then("Agent Click on CheckBox for {string} Scheme in Eco Page")
    public void AgentClickOnAPSchemeEcoCheckBox(String EcoScheme) throws InterruptedException {
            applicationportalPage.AgentClickOnCheckBoxForEcoScheme(EcoScheme);
            Thread.sleep(2000);
    }

    // Agent Click on Stocking Density Save and Select for AP2
    @Then("Agent Click on Save & Select for {string} Scheme in Eco Page")
    public void AgentClickOnAP2SchemeEcoSaveAndSelect(String EcoScheme) throws InterruptedException {
        applicationportalPage.AgentClickOnSaveAndSelectButton(EcoScheme);
        Thread.sleep(3000);
    }

    @And("Agent Click on AP4 Scheme {string} Radio Button")
    public void AgentClickOnAP4SchemeRadioButton(String Option) throws InterruptedException {
        applicationportalPage.AgentClickOnRadioButtonInAP4Scheme(Option);
        Thread.sleep(1000);
    }

    @And("Agent Selects the {string} Approved Spreader Type from the {string} dropdown")
    public void AgentSelectApprovedSpreaderTypeFromDropDown(String ApprovedSpreader, String Dropdown) {
            applicationportalPage.AgentSelectDropdownValuesForApprovedSpreader(Dropdown, ApprovedSpreader);
    }

//    AgentClickOnRadioButtonInAP5
    @And("Agent Click on {string} as Choice of Fertiliser Application Equipment")
    public void AgentChooseFertilisationApplicationMode(String Type) throws InterruptedException {
            applicationportalPage.AgentClickOnRadioButtonInAP5(Type);
    }

    @And("Agent enters data {string} in the {string} textbox")
    public void AgentEnterSerialNumberInTextBox(String Text, String AP5TextBox) {
            applicationportalPage.AgentFillInTheAP5TextBoxes(Text,AP5TextBox);
    }

    @And("Agent Click on Application without Eco Checkbox")
    public void AgentClickOnNoEcoSchemeCheckbox() throws InterruptedException {
        applicationportalPage.AgentClickOnCheckBoxForNoEcoScheme();
        Thread.sleep(3000);
    }

    //region AMS
    @Then("Agent Click On View Button for first Farmer")
    public  void AgentClickOnFirstViewButton() throws InterruptedException {
        applicationportalPage.AgentClickOnViewButtonForFarmer();
        Thread.sleep(2000);
    }

    @And("Agent Click On the first AMS Parcel with Response Pending Status")
    public void AgentClickOnFirstResponsePendingParcel() throws InterruptedException {
            applicationportalPage.AgentClickOnFirstParcelWithAMSStatusPending();
            Thread.sleep(2000);
    }

    @And("Agent Click on the {string} button in the AMS Side Drawer")
    public void AgentClickOnAgreeOrDisagreeButtonInSideDrawer(String Arg0) {
            applicationportalPage.AgreeOrDisagreeInSideDrawer(Arg0);
    }
    @And("Agent Click on the {string} disagree reason option in the AMS Side Drawer")
    public void AgentClickOnDisagreeReasonButtonInSideDrawer(String Arg0) {
        applicationportalPage.DisagreeReasonInSideDrawer(Arg0);
    }

    @Then("Agent Change Claimed Area of Parcel with reason {string}")
    public void AgentChecgeClaimedAreaOfParcel(String Reason) throws InterruptedException {
            applicationportalPage.AgentClickOnReqEhChangeCheckBox();
            applicationportalPage.AgentEnterReasonForEhChange(Reason);
            applicationportalPage.AgentChangeClaimedAreaInAMS();
    }
    // endregion
    // endregion

    // region ENTS Steps
    @Then("Agent Click On View Link for Searched Herd")
    public void AgentClickOnViewLink() throws InterruptedException {
            Thread.sleep(3000);
            applicationportalPage.AgentClickOnViewLinkForSearchedHerd();
            Thread.sleep(2000);
    }

    @Then("Agent Click on the {string} button")
    public void AgentClickOnButton(String Button) throws InterruptedException {
            applicationportalPage.AgentClickOnButton(Button);
            Thread.sleep(4000);
    }

    @Then("Agent Click on the {string} personal details dialog issue")
    public void AgentclickOnPersonalDialogButton(String PersonalDialogbutton) throws InterruptedException {
            Thread.sleep(5000);
            applicationportalPage.AgentClcikOnButtoninPersonalDetailsDialog(PersonalDialogbutton);
    }

    @Then("AgentClick On ETF Button")
    public void AgentClickOnETFButton() throws InterruptedException {
        Thread.sleep(4000);
        applicationportalPage.AgentClickOnETFButton();
    }

    @Then("Agent Click on the Dialog Box {string} button")
    public void AgentClickOnDialogBoxButton(String Button) throws InterruptedException {
        applicationportalPage.AgentClickOnButtonInDialog(Button);
        Thread.sleep(4000);
    }

    @Then("Agent Click on the Dialog Box Lease Year {string} button")
    public void AgentClickOnDialogBoxSelectLeaseYearButton(String Button) throws InterruptedException {
        applicationportalPage.AgentClickOnSelectLeaseYearButtonInDialog(Button);
        Thread.sleep(4000);
    }

    @And("Agent Click on Transfer Type {string} Button")
    public void AgentClickOnTransferTypeButton(String Arg0) throws InterruptedException {
        applicationportalPage.AgentClickOnNextOrBackOrSubmitButton(Arg0);
        Thread.sleep(5000);
    }

    @Then("Agent Fill {string} field value as {string}")
    public void AgentEnterValueInField(String Field, String Value) {
        applicationportalPage.AgentEnterTextInDialog(Field, Value);
    }

    @When("Agent Select the Lease Year")
    public void AgentSelectLeaseYear() {
            applicationportalPage.AgentSelectLeaseYear();
    }

    @And("Agent select the Start End Date for herd {string}")
    public void AgentSelectStartEndDate(String Herd) {
            applicationportalPage.AgentSelectStartEndDate(Herd);
    }

    @Then("Agent select {string} as Transfer Type")
    public void AgentSelectTransferType(String TransferType) throws InterruptedException {
            applicationportalPage.AgentSelectTransferType(TransferType);
            Thread.sleep(3000);
    }

    @Then("Agent Search for Herd Number Field and Enter Herd as {string}")
    public void AgentSearchForHerdNumber(String Arg0) throws InterruptedException {
        Thread.sleep(4000);
        applicationportalPage.AgentSearchForHerdField(Arg0);
        Thread.sleep(3000);
    }

    @And("Agent Click on First Add Entitlement Button for Transferor")
    public void AgentClickOnAddEntitlementButton() throws InterruptedException {
            Thread.sleep(3000);
            applicationportalPage.AgentClickOnAddEntitlements();
    }

    @Then("Agent Check Add Entitlement Button not present")
    public void AgentCheckEntitlementButtonNotPresent() {
            if(applicationportalPage.AgentCheckEntitlementsNotPresent() == true) {
                System.out.println("Entitlements not Available");
            }
            else {
                System.out.println("Entitilements Available");
            }
    }

    @Then("Agent Click on Add Manual Entitlements Button")
    public void AgentClickOnAddManualEntitlement() {
            applicationportalPage.AgentClickOnAddManualEntitlements();
    }

    @Then("Agent Click On {string} Link in Transfer Summary Page")
    public void AgentClickOnLinkinENTS(String Link) {
            applicationportalPage.AgentClickOnLink(Link);
    }

    @And("Agent Enter Transfer Notes as {string}")
    public void AgentEnterTransferNotes(String Notes) throws InterruptedException {
            applicationportalPage.AgentAddNotesToEntitlements(Notes);
            Thread.sleep(3000);
    }

    @Then("Agent Select from {string} dropdown the doctype {string} to Upload for Transfers")
    public void AgentSelectDocTypeToUpload(String DropdownName, String DocType) {
        applicationportalPage.AgentSelectDocumentTypeInDropdown(DropdownName,DocType);
    }

    @Then("Agent Select Entitlement Type as {string} from the Entitlement Type dropdown")
    public void AgentSelectEntitlementType(String Type) {
        applicationportalPage.AgentSelectEntitlementType(Type);
    }

    @Then("Agent Select Lease End Year as {string} from the Entitlement Type dropdown")
    public void AgentSelectLeaseEndYear(String Year) {
        applicationportalPage.AgentSelectLeaseEndYear(Year);
    }

    @And("Upload Document for Transfers")
    public void AgentUploadDocumentForTransfers() throws InterruptedException {
        applicationportalPage.UploadDocumentForTransfer();
        Thread.sleep(5000);
    }

    @And("Agent Click On Terms and Conditions CheckBox")
    public void AgentClickOnTermsAndConditionsCheckBoxForTransfers() throws InterruptedException {
            applicationportalPage.AgentClickOnTermsAndConditionsCheckBoxForTransfers();
            Thread.sleep(2000);
    }

    @Then("Agent Capture Transfer Key in Summary Screen")
    public void AgentCaptureTransferKey() throws InterruptedException {
            Thread.sleep(2000);
            applicationportalPage.AgentCaptureTransferKey();
    }

    @Then("Click on View button in Transferee Dashboard with Herd Number {string}")
    public void AgentClickOnTrasfereeViewButton(String HerdNum) throws InterruptedException {
            Thread.sleep(3000);
            applicationportalPage.AgentClickOnViewButtonInTransfereeScreen();
    }


    @Then("Click on View Button in Individual Transferee Screen with Herd Number {string}")
    public void AgentClickOnIndividualTransfereeViewButtons(String HerdNum) throws InterruptedException {
        Thread.sleep(3000);
        applicationportalPage.AgentClickOnViewButtonForIndividualTransfereeFromETF(HerdNum);
        Thread.sleep(2000);
    }

    @Then("Click on View Button in Individual Transferee Dashboard with Herd Number {string}")
    public void AgentClickOnIndiviualTransfereeViewButton(String TransfereeHerd) throws InterruptedException {
            Thread.sleep(3000);
            applicationportalPage.AgentClickOnViewButtonForTransfereeFromETF(TransfereeHerd);
    }


    @Then("Agent Fill {string} field value with Transfer Key")
    public void AgentEnterTransferKeyValueInField(String Field) {
        applicationportalPage.AgentEnterTransferKeyInDialog(Field);
    }

//    @Then("Collect All Herds of that agent which are not submitted")
//    public void collectAllHerdsOfThatAgentWhichAreNotSubmitted() throws InterruptedException {
//        applicationportalPage.collectAllHerdsOfThatAgentWhichAreNotSubmitted();
//    }

    @Given("Agent Search for Herd Number Field and Enter Herd from row {int}")
    public void agentSearchForHerdNumberFieldAndEnterHerd(int rowNum) throws IOException {
        applicationportalPage.agentSearchForHerdNumberFieldAndEnterHerd(rowNum);
    }

    @Given("Agent Search for Herd Number Field and Enter Herd")
    public void agentSearchForHerdNumberFieldAndEnterHerd() {
        applicationportalPage.agentSearchForHerdNumberFieldAndEnterHerd();
    }
    // endregion
}
