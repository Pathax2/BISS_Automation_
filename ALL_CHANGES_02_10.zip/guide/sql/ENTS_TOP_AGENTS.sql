-- ENTS Top agents - agent logins ranked by how many usable herds they manage
-- Same herd filters as the "ENTS Agent Login herds" query: more than 10 entitlements, herd number starts with a
-- letter, holder alive, two-word name. Current agent links only (end date 31-DEC-9999).
-- Run on CENTEST_ENTS_DATA. Expected: aga6581 near the top with about 75, aga6325 near the bottom with about 5.

WITH idx AS (
    SELECT LEVEL k FROM dual CONNECT BY LEVEL <= 10
),
links AS (
    SELECT DISTINCT ohs_herd herd_number,
           LOWER(REGEXP_SUBSTR(UPPER(herd_agt), '31-DEC-9999 ([^, ]+)', 1, idx.k, NULL, 1)) agent_login
    FROM tden_owner_history,
         vwen_ent_sets,
         vwco_ents_herd_abls_rpt,
         idx
    WHERE ohs_scheme_year = ent_scheme_year
    AND   ohs_own_id      = ent_own_id
    AND   ohs_hist_no     = ent_hist_no
    AND   ent_scheme_year = 2026
    AND   ent_num_ents    > 10
    AND   ohs_herd        = herd_id
    AND   UPPER(herd_agt) LIKE '%31-DEC-9999%'
    AND   REGEXP_LIKE(ohs_herd, '^[A-Z]')
    AND   idx.k <= REGEXP_COUNT(UPPER(herd_agt), '31-DEC-9999 [^, ]+')
)
SELECT * FROM (
    SELECT l.agent_login, COUNT(*) herd_count
    FROM links l
    WHERE l.agent_login LIKE 'ag%'
    AND   EXISTS (SELECT 1 FROM vwco_ems_client_details d
                  WHERE d.herd_number = l.herd_number
                  AND   d.death_indicator = 'N'
                  AND   REGEXP_LIKE(TRIM(d.payee_name), '^[[:alpha:]-]+ [[:alpha:]-]+$'))
    GROUP BY l.agent_login
    ORDER BY COUNT(*) DESC
)
WHERE ROWNUM <= 10;
