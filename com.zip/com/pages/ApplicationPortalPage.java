package com.pages;

//import com.DB.storedprocedures.*;
import com.base.ActionClass;
//import com.base.IDataReader;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import static org.openqa.selenium.support.locators.RelativeLocator.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.File;
import java.math.BigDecimal;
import java.sql.*;
import java.util.List;
import java.util.Objects;

public class ApplicationPortalPage {


    WebDriver driver;
    ActionClass actions;
    Actions action;

    public ApplicationPortalPage(WebDriver driver) {
        this.driver = driver;
        actions = new ActionClass(driver);
        action = new Actions(driver);
    }


    // region BISS code

    // region DBQueries
    public void CentestBissDataScript() throws SQLException {
        String url = "jdbc:oracle:thin:@//dbconn.agriculture.gov.ie:1532/DEVC.agriculture.gov.ie";
        String username = "BISS_DATA";
        String password = "BISS_DATA";

//        try {
            Connection connection = DriverManager.getConnection(url, username, password);
            //System.out.println("valuestring");

//            if(connection.isClosed()) {
//                System.out.println("Connection Unsuccessful");
//            }
//            else {
//                System.out.println("Connection Successful");
//            }

            Statement stmt =  connection.createStatement();
            ResultSet resultSet = stmt.executeQuery("select * from vwbs_application_herd fetch first 5 rows only");
            while (resultSet.next()) {
                System.out.println(resultSet.getInt("APH_ID"));
            }



            String sql = ("select * from vwbs_application_herd\n" +
                    "\n" +
                    "where mde_abbrev = 'I'\n" +
                    "\n" +
                    "and app_year = 2023\n" +
                    "\n" +
                    "and not exists (select 1 from tdbs_application_land where apl_year = 2023 and apl_app_id = aph_app_id)");


            // String sql = ("Select pln_app_id, gfi_herd_no, pln_plan_id, pln_ver_num, pln_plan_year From tdga_farm_info_generic, tdga_plan, tsga_plan_type where gfi_id =pln_gfi_id And gfi_sch_code = 4 And pln_plan_type = plt_plan_type_code");
//            Statement statement = connection.createStatement();
//            ResultSet rs = statement.executeQuery(sql);
//            while (rs.next()) {
//                String pln_app_id = rs.getString(1);
//                System.out.println(pln_app_id);
//                System.out.println("Query is working");
//            }

//        } catch (SQLException throwables) {
//            throwables.printStackTrace();
//        }
    }
    //endregion


    // region Common Elements

    // Agent navigate to pages through Side NavBar
    // Locators Arg Home , My Clients , Farmer Dashboard , Farm Details , Entitlement Position , Transfers , NR-CISYF , Correspondence
    public void AgentNavigateToPagesUsingSideNavBar(String Arg0) {
        if(Objects.equals(Arg0, "Transfers")) {
            By NavBarButtons = By.xpath("//mat-selection-list/descendant::span[contains(text(),'Transfer')]");
            actions.waitForVisibilityOfElement(NavBarButtons,30);
            actions.clickUsingJS(NavBarButtons);
        }
        else {
            By NavBarButtons = By.xpath("//mat-selection-list/descendant::span[contains(text(),'"+Arg0+"')]");
            actions.waitForVisibilityOfElement(NavBarButtons,30);
            actions.clickUsingJS(NavBarButtons);
        }
    }

    // Agent Click on the Next/Back Button
    // Locators Arg Next, Back, Submit
    public void AgentClickOnNextOrBackOrSubmitButton(String Arg0) throws InterruptedException {
        By BackAndNextButton = By.xpath("//button/descendant::span[contains(text(),'"+Arg0+"')]");
//        actions.waitForVisibilityOfElement(BackAndNextButton,30);
        Thread.sleep(4000);
        actions.clickUsingJS(BackAndNextButton);
    }

    public Boolean AgentVerifyNextOrBackOrSubmitButton(String Arg0) {
        By BackAndNextButton = By.xpath("//button/descendant::span[contains(text(),'"+Arg0+"')]");
        Boolean Visible = actions.waitForVisibilityOfElement(BackAndNextButton,30);
        return Visible;
    }

    // Agent Click on the Application Stepper
    // Locator Arg Check heading of each step and give as Argument
    public void AgentClickOnApplicationStepper(String Arg0) {
        By StepLink = By.xpath("//mat-step-header/descendant::div[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(StepLink,30);
        actions.clickUsingJS(StepLink);
    }

    // Agent Click on Buttons in Dialog Box
    // Locators Arg "No, cancel", "Yes, continue", "I understand", "Claim" , "Open Map" , "Cancel" , "Add" , "Cancel" , "Don't save" , "Save changes", "Next", "Yes, I confirm", "No, cancel"
    public void AgentClickOnDialogBoxButton(String Arg0) {
        if(Objects.equals(Arg0, "Open Map")) {
            By DialogBoxButton = By.xpath("//mat-dialog-container/descendant::button/span[contains(text(),'"+Arg0+"')]");
//            actions.waitForVisibilityOfElement(DialogBoxButton,30);
            actions.clickUsingJS(DialogBoxButton);
            actions.clickUsingJS(DialogBoxButton);
        }
        else {
            By DialogBoxButton = By.xpath("//mat-dialog-container/descendant::button/span[contains(text(),'"+Arg0+"')]");
//            actions.waitForVisibilityOfElement(DialogBoxButton,30);
            actions.clickUsingJS(DialogBoxButton);
            actions.waitforSeconds(5);
        }
    }

    // Agent Click on Close Dialog Button
    public void AgentCloseDialog() {
        By CloseButton = By.xpath("//mat-dialog-container/descendant::mat-icon[contains(text(),'close')]");
        actions.waitForVisibilityOfElement(CloseButton,30);
        actions.clickUsingJS(CloseButton);
    }

    // Agent Select Dropdown Values in Parcel and Plot Modals
    // Locators Arg0
    public void AgentSelectDropdownValues(String Arg0, String Arg1) {
        By SearchParcelDropdowns = By.xpath("//mat-select[@formcontrolname='"+Arg1+"']");
        actions.waitForVisibilityOfElement(SearchParcelDropdowns,30);
        actions.clickUsingJS(SearchParcelDropdowns);
        By CountyOrTownland = By.xpath("//span[contains(text(),'"+Arg0+"')]/ancestor::mat-option");
        actions.waitForVisibilityOfElement(CountyOrTownland, 30);
        actions.clickUsingJS(CountyOrTownland);
        actions.waitforSeconds(6);
    }

    // Store Herd Number of Application being created

    // endregion

    // region BISS Application Portal Dashboard

    // Click on the Farmer Dashboard Application Related Buttons
    // Locators Arg Delete draft, Continue application, Start application, Start amendment , Continue amendment , View entitlements
    public void AgentClickOnButtonsInFarmerDashboard(String Arg0) {
        By DashboardButtons = By.xpath("//button/descendant::span[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(DashboardButtons,30);
        actions.clickUsingJS(DashboardButtons);
    }



    //Added to start a new application or continue a draft application
    public void AgentClickOnStartOrContinue() {
        //By ApplyButton = By.xpath("//lib-biss-button/descendant::button/span");
        By ApplyButton = By.xpath("//button/descendant::span[contains(text(),' Start Application ')]");
        List<WebElement> ApplyButtonVisibilityCheck = driver.findElements(ApplyButton);
        if (ApplyButtonVisibilityCheck.isEmpty()) {
            By EditButton = By.xpath("//button/descendant::span[contains(text(),' Continue application ')]");
            actions.clickUsingJS(EditButton);
        }
        else {
        //    By StartApplication = By.xpath("//button/descendant::span[contains(text(),' Start Application ')]");
            actions.clickUsingJS(ApplyButton);
        }
    }

    //Added to delete a draft application if exists
    public void deleteDraftIfExists() {
        //By ApplyButton = By.xpath("//lib-biss-button/descendant::button/span");
        By ApplyButton = By.xpath("//button/descendant::span[contains(text(),' Start Application ')]");
        List<WebElement> ApplyButtonVisibilityCheck = driver.findElements(ApplyButton);
        By ApplyAmendmentButton = By.xpath("//button/descendant::span[contains(text(),' Start amendment ')]");
        List<WebElement> ApplyAmendmentButtonVisibilityCheck = driver.findElements(ApplyAmendmentButton);
        if (ApplyButtonVisibilityCheck.isEmpty() && ApplyAmendmentButtonVisibilityCheck.isEmpty()) {
            By deleteButton = By.xpath("//button/descendant::span[contains(text(),' Delete draft ')]");
            actions.clickUsingJS(deleteButton);
            By yesDeleteButton = By.xpath("//button/descendant::span[contains(text(),'Yes, delete')]");
            actions.clickUsingJS(yesDeleteButton);
        }
    }

    //Added to start a new application or continue a draft amendment
    public void AgentClickOnStartOrContinueAmendment() {
        //By ApplyButton = By.xpath("//lib-biss-button/descendant::button/span");
        By ApplyButton = By.xpath("//button/descendant::span[contains(text(),' Start amendment ')]");
        List<WebElement> ApplyButtonVisibilityCheck = driver.findElements(ApplyButton);
        if (ApplyButtonVisibilityCheck.isEmpty()) {
            By EditButton = By.xpath("//button/descendant::span[contains(text(),' Continue amendment ')]");
            actions.clickUsingJS(EditButton);
        }
        else {
            //    By StartApplication = By.xpath("//button/descendant::span[contains(text(),' Start Application ')]");
            actions.clickUsingJS(ApplyButton);
        }
    }

    public void agentGivesReasonForLateAmendment(){
        By reason = By.xpath(" //textarea[contains(@placeholder,'Reason For Late Amendments')]");
        actions.sendKeys(reason,"Automation Test - CENTEST Env");
    }

    // Agent Click on the links in the Farmer Dashboard
    // Locators Arg View , Read More
    public void AgentClickOnLinksInFarmerDashboard(String Arg0) {
        By FarmerDashboardLinks = By.xpath("//a[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(FarmerDashboardLinks,30);
        actions.clickUsingJS(FarmerDashboardLinks);
    }

    // Check if Application is in Draft state and delete draft
    public void AgentDeleteDraftIfStarted(String Arg0) throws InterruptedException {
        List<WebElement> DeleteDraft = driver.findElements(By.xpath("//button/descendant::span[contains(text(),'"+Arg0+"')]"));
        if(DeleteDraft.isEmpty()) {
//            AgentClickOnButtonsInFarmerDashboard("");
            System.out.println("Amendment not Started");
        }
        else {
            AgentClickOnButtonsInFarmerDashboard(Arg0);
            Thread.sleep(3000);
            AgentClickOnDialogBoxButton("Yes, delete");
//            driver.findElement(By.xpath("//mat-dialog-container/descendant::button/span[contains(text(),'Yes, delete')]")).click();
        }
    }



    // endregion

    // region Active Farmer Status Step

    // Agent Check Active Farmer Status if Active or Not Active
    // Arg0 : Grassland / Tillage
    // Arg1 : Grassland (Making Hay/Silage/Haylage, Topping, Other Grazing livestock e.g.Equines, Plan to purchase livestock in 2023 (payment may be delayed), Landscape Feature Maintenance, Other)
    public void AgentCheckActivityStatusLabelText(String FarmingPractice, String GrasslandOrTillageActivity) throws InterruptedException {
        String ActiveStatusText = driver.findElement(By.xpath("(//mat-card-content[contains(@class,'mat-card-content')]/descendant::div[3])[1]")).getText();
        String ActiveFarmer = driver.findElement(By.xpath("//div[@class='active-farmer-status-description']/div[1]")).getText();
        System.out.println(ActiveStatusText);

        if (Objects.equals(ActiveFarmer, "Not Active!")) {
            if (Objects.equals(FarmingPractice, "Grassland")) {
                //AgentClickOnCheckbox(GrasslandActivity);
                By RadioButton = By.xpath("//mat-radio-button/descendant::span[contains(text(),'" + FarmingPractice + "')]");
                actions.clickUsingJS(RadioButton);
                if (Objects.equals(GrasslandOrTillageActivity, "Others")) {
                    By OtherNotes = By.xpath("//textarea[@formcontrolname='note']");
                    actions.sendKeys(OtherNotes, "");
                } else {
                    By CheckBoxOptions = By.xpath("//mat-checkbox/descendant::span[contains(text(),'"+GrasslandOrTillageActivity+"')]");
                    actions.clickUsingJS(CheckBoxOptions);
                }
            }
            else if (Objects.equals(FarmingPractice, "Tillage")) {
                By RadioButton = By.xpath("//mat-radio-button/descendant::span[contains(text(),'" + FarmingPractice + "')]");
                actions.clickUsingJS(RadioButton);
                if (Objects.equals(GrasslandOrTillageActivity, "Others")) {
                    By OtherNotes = By.xpath("//textarea[@formcontrolname='note']");
                    actions.sendKeys(OtherNotes, "");
                } else {
                    By CheckBoxOptions = By.xpath("//mat-checkbox/descendant::span[contains(text(),'"+GrasslandOrTillageActivity+"')]");
                    actions.clickUsingJS(CheckBoxOptions);
                }
            }
        }
        else if (Objects.equals(ActiveFarmer,"Active Farmer")) {
            AgentClickOnNextOrBackOrSubmitButton("Next");
        }
    }

    // Agent Click on a Checkbox in Active Farmer Section
    // Locators Arg "Check the options for the Checkboxes"
    public void AgentClickOnCheckbox(String Arg0) {
//        By CheckBoxOptions = By.xpath("//mat-checkbox/descendant::label[contains(text(),'"+Arg0+"')]");
//        if(Arg0.equals("Other")){
//            By CheckBoxOther = By.xpath("//mat-checkbox/descendant::label[text()=' Other ']");
//            actions.clickUsingJS(CheckBoxOther);
//        }
//        else{
//            actions.clickUsingJS(CheckBoxOptions);
//        }
        By CheckBoxOptions = By.xpath("//mat-checkbox/descendant::label[contains(text(),'"+Arg0+"')]");
        By activeFarmer = By.xpath("//mat-icon[@data-mat-icon-name ='active-farmer']");
        List<WebElement> options = driver.findElements(CheckBoxOptions);
        if(options.isEmpty()){
            driver.findElement(activeFarmer).isDisplayed();
        }
        else {
            actions.clickUsingJS(CheckBoxOptions);
        }
    }

    // Agent Check for Warning Message if Checkbox not selected
    public void AgentCheckActiveFarmerStatusWarning() {
        By WarningMessage=By.xpath("//mat-error[contains(text(),'You must select an option')]");
        actions.waitForVisibilityOfElement(WarningMessage,30);
        actions.clickUsingJS(WarningMessage);
    }

    // Agent Enter Text in the Other Section Notes
    public void AgentEnterTextInOtherNotes(String Notes) {
        By OtherNotesBox = By.xpath("//textarea[@formcontrolname='note']");
        actions.sendKeys(OtherNotesBox,Notes);
    }
    // endregion

    // region Active Farmer

    // Staff Select Active Farmer Admin Check Summary Radio Buttons
    public void AdminCheckSummaryRadioButtons(String Choice) {
        By AdminCheckResultRadio = By.xpath("//mat-radio-button[@value='"+Choice+"']");
        actions.clickUsingJS(AdminCheckResultRadio);
    }

    // endregion

    // region Scheme Selection Step

    // Agent Click on Cards in the Scheme Selection Page
    // Locators Arg BISS , CRISS , ANC , Eco , Organics , SIM , Protein Aid Scheme
    public void AgentClickOnSchemeCard(String Arg0) {
        By SchemeCards = By.xpath("//mat-card/descendant::span[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(SchemeCards,30);
        actions.clickUsingJS(SchemeCards);
    }

    // endregion

    //region Land Details Step
    // Locators
    By CommonagePlotCheckBox = By.xpath("//span[contains(text(),'Commonage Plot')]");
    By MandatoryInfoWarning = By.xpath("//div[contains(text(),'Your application is missing mandatory information.')]");

    // Agent Click on Quick Filter in Land Details Page
    public void AgentClickOnQuickFilter(String Filter) {
        By FilterName = By.xpath("//button/span[contains(text(),'"+Filter+"')]");
        actions.clickUsingJS(FilterName);
    }

    // Agent Check Mandatory Information Warning
    public void AgentCheckMandatoryInfoWarning() throws InterruptedException {
        Boolean visibility = driver.findElement(MandatoryInfoWarning).isDisplayed();
        if (visibility.equals(true)) {
            AgentClickOnNextOrBackOrSubmitButton("Back");
            AgentClickOnSchemeCard("Organics");
            AgentClickOnNextOrBackOrSubmitButton("Next");
            AgentClickOnDialogBoxButton("I understand");
        }
        else {
            System.out.println("No Mandatory Warnings");
        }
    }

    // Agent Check for Archived Parcel
    public void AgentCheckForArchivedParcelMessage() {
        By Warning = By.xpath("//div[contains(text(),'Your parcel has been archived, the new parcel iteration is below')]");
        WebElement WarningMessage = driver.findElement(Warning);
        if (WarningMessage.isDisplayed()){
            System.out.println("Parcel is Archived");
        }
    }

    // Agent Click On Parcel in List
    public void AgentClickOnParcelInList(String Arg0) {
        By ParcelInList = By.xpath("//td[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(ParcelInList,30);
        actions.clickUsingJS(ParcelInList);
        driver.findElement(CommonagePlotCheckBox);
    }

    // Agent Click on Add Plot/Parcel Button
    // Locators Arg Add parcel, Add plot
    public void AgentClickOnAddPlotOrAddParcelButton(String Arg0) {
        By AddPlotOrParcelButton = By.xpath("//button/descendant::span[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(AddPlotOrParcelButton, 30);
        actions.clickUsingJS(AddPlotOrParcelButton);
        actions.waitforSeconds(4);
    }

    // region Warning Messages

    // Check angular error Warning Messages in the dialog
    public String AgentCheckWarningMessageInDialog() {
        String DialogWarning = driver.findElement(By.xpath("//mat-error/descendant::span")).getText();
        return DialogWarning;
    }

    // Check biss error panel Warning Messages
    public String AgentCheckBissPanelWarningMessages() {
        String DialogWarning = driver.findElement(By.xpath("//biss-error-panel/descendant::div[contains(text(),'You have already claimed this parcel. To modify a claim on a parcel, please return to the land details list and amend the parcels details.')]")).getText();
        return DialogWarning;
    }


    // endregion

    // Agent populate input fields in Parcel or Plot modal
    // Locator Arg parcelInput , claimedArea , plotReference
    public void AgentEnterValueInAddPlotOrParcelDialog(String Arg0, String Arg1) {
        By ParcelSearchInput = By.xpath("//mat-dialog-container/descendant::input[@id='"+Arg1+"']");
        actions.waitForVisibilityOfElement(ParcelSearchInput,30);
        actions.sendKeys(ParcelSearchInput,Arg0);
    }

    // Locator Arg parcelInput , claimedArea , plotReference
    public void AgentClearValueInAddPlotOrParcelDialog(String Arg1) {
        By ParcelSearchInput = By.xpath("//mat-dialog-container/descendant::input[@id='"+Arg1+"']");
        actions.waitForVisibilityOfElement(ParcelSearchInput,30);
        driver.findElement(ParcelSearchInput).clear();
    }

    // Agent Select Dropdown Values in Parcel and Plot Modals
    // Locators Arg county, townland , ownershipStatus , parcelUse , organicStatus , agriculturalActivity , plotUse
    public void AgentSelectDropdownValuesInParcelAndPlotModal(String Arg0, String Arg1) {
        By SearchParcelDropdowns = By.xpath("//mat-select[@formcontrolname='"+Arg1+"']");
        actions.waitForVisibilityOfElement(SearchParcelDropdowns,30);
        actions.clickUsingJS(SearchParcelDropdowns);
        By CountyOrTownland = By.xpath("//span[contains(text(),'"+Arg0+"')]/ancestor::mat-option");
        actions.waitForVisibilityOfElement(CountyOrTownland, 30);
        actions.clickUsingJS(CountyOrTownland);
        actions.waitforSeconds(6);
    }

    // Agent Click on Radio Buttons inside the Dialog Box
    // Locators Arg Edit Map Online , Upload Map , Submit Paper Map By Post
    public void AgentClickOnRadioButtonsInDialogBox(String Arg0) {
        By MapChangesRadioButton = By.xpath("//mat-radio-button/descendant::span[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(MapChangesRadioButton,30);
        actions.clickUsingJS(MapChangesRadioButton);
    }

    // Select Parcel On Map
    public void AgentSelectParcelOnMapScreen() {
        actions.waitforSeconds(5);
        Actions act = new Actions(driver);
        WebElement el = driver.findElement(By.xpath("//span[@id ='outer-west-resizer']"));
        act.moveToElement(el, 450, 234).click().build().perform();
        actions.waitforSeconds(2);
        act.moveToElement(el, 450, 234).click().build().perform();
        actions.waitforSeconds(2);
        act.moveToElement(el, 450, 234).click().build().perform();
        actions.waitforSeconds(2);
//        act.moveToElement(el, 450, 234).click().build().perform();
        System.out.println("Map Clicked");
        actions.waitforSeconds(5);
    }

    // Click on Select Feature Tool in GIS Application
    public void AgentClickOnSelectFeatureToolInGIS(String Arg0) {
        actions.waitforSeconds(4);
        By SelectFeature = By.xpath("//a/descendant::span[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(SelectFeature,50);
        actions.clickUsingJS(SelectFeature);
        actions.waitforSeconds(10);
    }

    // Claim Parcel On Map
    public void AgentClickOnMapPageClaimParcelButton() {
        By MapPageClaimParcelButton = By.xpath("//button[contains(text(),'Claim')]");
        actions.waitForVisibilityOfElement(MapPageClaimParcelButton,15);
        actions.clickUsingJS(MapPageClaimParcelButton);
    }

    // Clicking on the Commonage Plot Checkbox
    public void AgentClickOnCommonageCheckBox() {
        actions.waitForVisibilityOfElement(CommonagePlotCheckBox,30);
        actions.clickUsingJS(CommonagePlotCheckBox);
    }

    // Agent populate Commonage fraction Numerator and Denominator
    // Locator Arg commonageNumerator , commonageDenominator
    public void AgentPopulateCommonageFraction(String Arg0, String Arg1) {
        By CommonageFractionFields = By.xpath("//mat-dialog-container/descendant::input[@formcontrolname='"+Arg0+"']");
        actions.waitForVisibilityOfElement(CommonageFractionFields,30);
        actions.sendKeys(CommonageFractionFields,Arg1);
    }

    // Clicking on Add Plot Map Amendment Radio Buttons
    public void AgentClickOnRadioButton(String Arg0) {
        By PlotRadioButtons = By.xpath("//mat-radio-button/descendant::span[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(PlotRadioButtons,30);
        actions.clickUsingJS(PlotRadioButtons);
    }

    // Clicking on the Quick Filter Tabs
    // Locators Arg View All , Action Required
    public void AgentClickOnQuickFilterTabs(String Arg0) {
        By QuickFilterButtons = By.xpath("//mat-button-toggle-group/descendant::button/span[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(QuickFilterButtons,30);
        actions.clickUsingJS(QuickFilterButtons);
    }

    // Agent Click on SideNav Links in Map Application (To be used mainly after View Map Button in Parcel List)
    // Locators Arg0 'Select Feature', 'Deselect All', 'Measure', 'Toggle Legend', 'Close', Return to Land Details
    public void AgentClickOnNavLinksInMap(String Arg0) throws InterruptedException {
        By MapsNavLink = By.xpath("//a/descendant::span[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(MapsNavLink,30);
        actions.clickUsingJS(MapsNavLink);
        Thread.sleep(5000);
    }

    // region Side Drawer

    // Locators
    By EligibleHectareChange = By.xpath("//mat-dialog-container/descendant::div/mat-checkbox[@formcontrolname='requestChangeEh']/descendant::input");
    By ReasonForEhChangeTextBox = By.xpath("//mat-dialog-container/descendant::textarea[@formcontrolname='reasonEhChange']");

    // Agent Open Side Drawer for First Parcel in List
    public void AgentSelectFirstParcelInList() {
        By FirstParcel = By.xpath("(//td[contains(@class,'cdk-column-parcelRef')])[1]");
        actions.clickUsingJS(FirstParcel);
    }

    // Agent add 5.2 to Claimed Area Value and close side Drawer
    public void AgentChangeClaimedArea() throws InterruptedException {
        By ClaimedArea = By.xpath("(//td[contains(@class,'cdk-column-claimedArea')])[1]");
        BigDecimal ClaimedAreaText = new BigDecimal(driver.findElement(ClaimedArea).getText());
        AgentSelectFirstParcelInList();
        Thread.sleep(2000);
        By ClaimedAreaIDField = By.id("claimedArea");

        By ClaimedAreaField = By.xpath("//mat-dialog-container/descendant::input[@formcontrolname='claimedArea']");
        BigDecimal Constant = BigDecimal.valueOf(5.2);
//        float ClaimedAreaValue = Float.parseFloat(ClaimedAreaText);
        Thread.sleep(2000);
        driver.findElement(ClaimedAreaField).clear();
        Thread.sleep(2000);
        BigDecimal UpdatedValue = Constant.add(ClaimedAreaText);
        Thread.sleep(2000);
        actions.sendKeys(ClaimedAreaField, String.valueOf(UpdatedValue));
    }

    // Agent Change Claimed Area in AMS
    public void AgentChangeClaimedAreaInAMS() throws InterruptedException {
        By ClaimedAreaField = By.xpath("//mat-dialog-container/descendant::input[@formcontrolname='claimedArea']");
        BigDecimal Constant = BigDecimal.valueOf(0.5);
//        float ClaimedAreaValue = Float.parseFloat(ClaimedAreaText);
        Thread.sleep(2000);
        driver.findElement(ClaimedAreaField).clear();
        Thread.sleep(2000);
        BigDecimal UpdatedValue = Constant.add(BigDecimal.valueOf(14));
        Thread.sleep(2000);
        actions.sendKeys(ClaimedAreaField, String.valueOf(UpdatedValue));
        Thread.sleep(5000);
    }

    // Agent Open Side Drawer for Parcel/Plot by clicking on Parcel Number in list
    public void AgentClickOnPlotReferenceToOpenSideDrawer(String Arg0) {
        By PlotReference = By.xpath("//td/span[contains(text(),'"+Arg0+"')]");
        actions.clickUsingJS(PlotReference);
    }

    // Agent Open Staff Side Drawer for Parcel/Plot by clicking on Parcel Number in list
    public void AgentClickOnPlotReferenceToOpenStaffSideDrawer(String Arg0) {
        By PlotReference = By.xpath("//td[contains(text(),'"+Arg0+"')]");
        actions.clickUsingJS(PlotReference);
    }

    // Agent Open Staff Side Drawer for First Parcel/Plot by clicking on Parcel Number in list
    public void AgentClickOnFirstPlotReferenceToOpenStaffSideDrawer() {
        By PlotReference = By.xpath("(//td[contains(@class,'mat-column-townLand')])[1]");
        actions.clickUsingJS(PlotReference);
    }


    // Agent move to previous or next parcel or click close button in the Side Drawer
    // Locator Arg Close, Previous land, Next land
    public void AgentChangeParcelOrCloseSideDrawer(String Arg0) {
        By BackAndFrontButton = By.xpath("//mat-dialog-container/descendant::mat-icon[@aria-label="+Arg0+"]");
        actions.waitForVisibilityOfElement(BackAndFrontButton,30);
        actions.clickUsingJS(BackAndFrontButton);
    }

    // Agent Click on the Eligible Hectare Change Request CheckBox
    public void AgentClickOnReqEhChangeCheckBox() throws InterruptedException {
//        actions.waitForVisibilityOfElement(EligibleHectareChange,50);
        actions.clickUsingJS(EligibleHectareChange);
    }

    // Agent Click on Eligible Hectare Change Request CheckBox and enter reason in TextBox
    public void AgentEnterReasonForEhChange(String Arg0) throws InterruptedException {
        // Enter Text
        actions.waitForVisibilityOfElement(ReasonForEhChangeTextBox,30);
        actions.sendKeys(ReasonForEhChangeTextBox,Arg0);
    }

    // Agent perform actions on parcel inside side drawer
    // Locators Arg Edit Map , Subdivide parcel, Delete parcel
    public void AgentClickOnActionsInEditParcelDrawer(String Arg0) {
        By ActionButtons = By.xpath("//button/descendant::mat-icon[@aria-label='"+Arg0+"']");
        actions.waitForVisibilityOfElement(ActionButtons,30);
        actions.clickUsingJS(ActionButtons);
    }

    // Agent Edit Value in Side Drawer Field
    public void AgentEditValueInSideDrawerFields(String Value, String Field) {
        By SideDrawerField = By.xpath("//mat-dialog-container/descendant::input[@formcontrolname='"+Field+"']");
//        actions.waitForVisibilityOfElement(ClaimedAreaField,30);
        driver.findElement(SideDrawerField).clear();
        actions.clickUsingJS(SideDrawerField);
        actions.sendKeys(SideDrawerField,Value);
    }


    // Click on the dropdown in the Side Drawer
    // Locator Arg ownershipStatus , parcelUse , organicStatus
    public void AgentOpenSideDrawerDropdown(String Arg0) {
        String Locator = "//mat-dialog-container/descendant::mat-select[@formcontrolname='"+Arg0+"']";
        By AddPlotDropdowns = By.xpath(Locator);
        actions.waitForVisibilityOfElement(AddPlotDropdowns, 30);
        actions.clickUsingJS(AddPlotDropdowns);
    }

    // Agent Select Value from Dropdown in Side Drawer
    public void AgentSelectValueFromSideDrawerDropdown(String Dropdown, String Value) {
        AgentOpenSideDrawerDropdown(Dropdown);
        By DropDownValue = By.xpath("//span[contains(text(),'"+Value+"')]/ancestor::mat-option");
        actions.waitForVisibilityOfElement(DropDownValue, 30);
        actions.clickUsingJS(DropDownValue);
    }

    // Agent Click on Buttons in Side Drawer
    // Locator Cancel, Save changes
    public void AgentClickOnSideDrawerButtons(String Arg0) {
        By SideDrawerButtons = By.xpath("//mat-dialog-container/descendant::button/span[text()=' "+Arg0+" ']");
        actions.waitForVisibilityOfElement(SideDrawerButtons,30);
        actions.clickUsingJS(SideDrawerButtons);
    }


    // Agent Check for Over Claim Warning
    public void AgentCheckForOverClaimWarning() {
        By OverClaimWarning = By.xpath("//div[contains(text(),'A parcel of land has an overclaim warning.')]");
        Boolean ClaimWarning = driver.findElement(OverClaimWarning).isDisplayed();
        List<WebElement> ClaimWarningVisibility = driver.findElements(OverClaimWarning);
        if (ClaimWarningVisibility.isEmpty()) {
            System.out.println("Overclaim Warning not displayed");
        }
        else {
            System.out.println("Overclaim Warning displayed");
        }
    }
    // endregion

    // Parcel or Plot List Methods

    //region Agent Click on any Action Column Button


    // Execution of Click Actions button by isolating the Switch Case logic to Action Class
    public void AgentClickActionButtonLogic(String ParcelNo, int ColumnCase, String ActionsColumnButton) throws InterruptedException {
        WebElement ActionsButtonColumn = actions.ClickActionsButton(ParcelNo,ColumnCase,ActionsColumnButton);
        actions.clickWebElementUsingJS(ActionsButtonColumn);
        Thread.sleep(5000);
        //        JavascriptExecutor executor = (JavascriptExecutor)driver;
//        executor.executeScript("arguments[0].click();", ActionsButtonColumn);
        //        WebElement ActionsButtonColumn = ClickActionsButton(ParcelNo,ColumnCase, ActionsColumnButton);
        //        actions.waitForVisibilityOfWebElement(ActionsButtonColumn,30);
        //        actions.clickWebElementUsingJS(ActionsButtonColumn);
    }

    // Click on the button in the Land Details page
    // Actions Column Locators : Open map, Subdivide parcel, Undo deletion
    // Agent find the row number of the parcel to be deleted
    public void RowNumberContainingParcelAndAction(String ParcelNo, String ActionsColumnButton) {
        List<WebElement> ParcelList = driver.findElements(By.xpath("//td[contains(@class,'cdk-column-parcelRef')]"));
        int NumberOfParcel = ParcelList.size();
        for (int n = 0; n <= NumberOfParcel; n++) {
            String ParcelNum = ParcelList.get(n).getText();
            if (ParcelNum.equals(ParcelNo))
            {
                n = n+1;
                List<WebElement> ParcelActionButton = driver.findElements(By.xpath("(//td[contains(@class,'cdk-column-options')])["+n+"]/descendant::button[contains(@title,'"+ActionsColumnButton+"')]"));
                if(ParcelActionButton.isEmpty())
                {
                    System.out.println(ActionsColumnButton+" is not present");
                    break;
                }
                else
                {
                    actions.ClickLandDetailsAction(n,ActionsColumnButton);
                    break;
                }
            }
        }
    }

    // Undo Deletion
    public void UndoDeletionOfParcel() {
        By UndoDeletion = By.xpath("//td/descendant::button[contains(@title,'Undo deletion')]");
        actions.waitForVisibilityOfElement(UndoDeletion,50);
        actions.clickUsingJS(UndoDeletion);
    }

        /**
//    public void PrintTheRowNumber(String ParcelNo) {
//        System.out.println("Parcel is present in the row : " + RowNumberContainingParcel(ParcelNo));
//    }
         N1010991
    // Agent Click on any Action Button for a particular Parcel (Main method to be called in stepdefinition)
    // ParcelNo : Pass the desired Parcel Number
    // Actions Column : map , delete , content_cut(subdivide parcel), undo
//    public void AgentClickOnActionsButtonInParcelList(String ParcelNo, String ActionsColumn) throws InterruptedException {
//        Boolean CommonageFraction = ! driver.findElements(By.xpath("//td[contains(@class,'mat-column-commonageFraction')]")).isEmpty();
//        Boolean AgriculturalActivity = ! driver.findElements(By.xpath("//td[contains(@class,'mat-column-maintenance')]")).isEmpty();
//        Boolean OrganicColumn = ! driver.findElements(By.xpath("//td[contains(@class,'mat-column-organicStatus')]")).isEmpty();
//        Boolean AncColumn = ! driver.findElements(By.xpath("//td[contains(@class,'mat-column-anc')]")).isEmpty();
//        Boolean Acres = ! driver.findElements(By.xpath("//td[contains(@class,'mat-column-acres')]")).isEmpty();
//
//        // New Logic with 5 Optional Columns
//        //00000
//        if (CommonageFraction.equals(false) && AgriculturalActivity.equals(false) && OrganicColumn.equals(false) && AncColumn.equals(false) && Acres.equals(false)) {
//            AgentClickActionButtonLogic(ParcelNo,0,ActionsColumn);
//        }
//        //00001
//        //00010
//        //00011
//        //00100
//        //00101
//        //00110
//        //00111
//        //01000
//        //01001
//        //01010
//        //01011
//        //01100
//        //01101
//        //01110
//        //01111
//        //10000
//        //10001
//        //10010
//        //10011
//        //10100
//        //10101
//        //10110
//        //10111
//        //11000
//        //11001
//        //11010
//        //11011
//        //11100
//        //11101
//        //11110
//        //11111
//
//
//        // Old Logic with four optional columns
//        //0000
//        if(CommonageFraction.equals(false) && AgriculturalActivity.equals(false) && OrganicColumn.equals(false) && AncColumn.equals(false)) {
//            AgentClickActionButtonLogic(ParcelNo,0,ActionsColumn);
//        }
//
//        //0001
//        else if(CommonageFraction.equals(false) && AgriculturalActivity.equals(false) && OrganicColumn.equals(false) && AncColumn.equals(true)) {
//            AgentClickActionButtonLogic(ParcelNo,1,ActionsColumn);
//        }
//
//        //0010
//        else if(CommonageFraction.equals(false) && AgriculturalActivity.equals(false) && OrganicColumn.equals(true) && AncColumn.equals(false)) {
//            AgentClickActionButtonLogic(ParcelNo,2,ActionsColumn);
//        }
//
//        //0011
//        else if(CommonageFraction.equals(false) && AgriculturalActivity.equals(false) && OrganicColumn.equals(true) && AncColumn.equals(true)) {
//            AgentClickActionButtonLogic(ParcelNo,3,ActionsColumn);
//        }
//
//        //0100
//        else if(CommonageFraction.equals(false) && AgriculturalActivity.equals(true) && OrganicColumn.equals(false) && AncColumn.equals(false)) {
//            AgentClickActionButtonLogic(ParcelNo,4,ActionsColumn);
//        }
//
//        //0101
//        else if(CommonageFraction.equals(false) && AgriculturalActivity.equals(true) && OrganicColumn.equals(false) && AncColumn.equals(true)) {
//            AgentClickActionButtonLogic(ParcelNo,5,ActionsColumn);
//        }
//
//        //0110
//        else if(CommonageFraction.equals(false) && AgriculturalActivity.equals(true) && OrganicColumn.equals(true) && AncColumn.equals(false)) {
//            AgentClickActionButtonLogic(ParcelNo,6,ActionsColumn);
//        }
//
//        //0111
//        else if(CommonageFraction.equals(false) && AgriculturalActivity.equals(true) && OrganicColumn.equals(true) && AncColumn.equals(true)) {
//            AgentClickActionButtonLogic(ParcelNo,7,ActionsColumn);
//        }
//
//        //1000
//        else if(CommonageFraction.equals(true) && AgriculturalActivity.equals(false) && OrganicColumn.equals(false) && AncColumn.equals(false)) {
//            AgentClickActionButtonLogic(ParcelNo,8,ActionsColumn);
//        }
//
//        //1001
//        else if(CommonageFraction.equals(true) && AgriculturalActivity.equals(false) && OrganicColumn.equals(false) && AncColumn.equals(true)) {
//            AgentClickActionButtonLogic(ParcelNo,9,ActionsColumn);
//        }
//
//        //1010
//        else if(CommonageFraction.equals(true) && AgriculturalActivity.equals(false) && OrganicColumn.equals(true) && AncColumn.equals(false)) {
//            AgentClickActionButtonLogic(ParcelNo,10,ActionsColumn);
//        }
//
//        //1011
//        else if(CommonageFraction.equals(true) && AgriculturalActivity.equals(false) && OrganicColumn.equals(true) && AncColumn.equals(true)) {
//            AgentClickActionButtonLogic(ParcelNo,11,ActionsColumn);
//        }
//
//        //1100
//        else if(CommonageFraction.equals(true) && AgriculturalActivity.equals(true) && OrganicColumn.equals(false) && AncColumn.equals(false)) {
//            AgentClickActionButtonLogic(ParcelNo,12,ActionsColumn);
//        }
//
//        //1101
//        else if(CommonageFraction.equals(true) && AgriculturalActivity.equals(true) && OrganicColumn.equals(false) && AncColumn.equals(true)) {
//            AgentClickActionButtonLogic(ParcelNo,13,ActionsColumn);
//        }
//
//        //1110
//        else if(CommonageFraction.equals(true) && AgriculturalActivity.equals(true) && OrganicColumn.equals(true) && AncColumn.equals(false)) {
//            AgentClickActionButtonLogic(ParcelNo,14,ActionsColumn);
//        }
//
//        //1111
//        else if(CommonageFraction.equals(true) && AgriculturalActivity.equals(true) && OrganicColumn.equals(true) && AncColumn.equals(true)) {
//            AgentClickActionButtonLogic(ParcelNo,15,ActionsColumn);
//        }
//    }
**/
    // endregion

        public void AgentSelectValueInParcelValueFieldInAddParcelOrPlotDialogDropDown(String Arg0, String Arg1) {
            By SearchParcelDropdowns = By.xpath("//lib-biss-select-search[@formcontrolname='"+Arg1+"']/descendant::mat-select");
            actions.waitForVisibilityOfElement(SearchParcelDropdowns,30);
            actions.clickUsingJS(SearchParcelDropdowns);
            By CountyOrTownland = By.xpath("//span[contains(text(),'"+Arg0+"')]/ancestor::mat-option");
            actions.waitForVisibilityOfElement(CountyOrTownland, 30);
            actions.clickUsingJS(CountyOrTownland);
            actions.waitforSeconds(2);
        }

    // region Fill Mandatory Ag Activity and Organic Information
    public void AgentFillInMandatoryAgriculturalActivityInformation() throws InterruptedException {
        By AgriculturalActivityColumnRow = By.xpath("(//td[contains(@class,'mat-column-maintenance')])[1]");
        //By.xpath("//mat-dialog-container/descendant::div[text()='Your application is missing mandatory information.']")
        List <WebElement> ParcelList = driver.findElements(By.xpath("//td[contains(@class,'mat-column-maintenance')]"));
        while(!ParcelList.isEmpty()) {
            actions.clickUsingJS(AgriculturalActivityColumnRow);
            Thread.sleep(3000);
            AgentSelectValueFromSideDrawerDropdown("agriculturalActivity","Grazing Livestock");
            AgentClickOnNextOrBackOrSubmitButton("Save changes");
            Thread.sleep(2000);
            ParcelList = driver.findElements(By.xpath("//td[contains(@class,'mat-column-maintenance')]"));
        }
    }

    By pageButton = By.xpath("//mat-select[@aria-haspopup='listbox']");
    By lastPage = By.xpath("(//mat-option/span)[4]");
    By ownershipStatus = By.xpath("//mat-icon[contains(text(),'error')]/ancestor::td/following-sibling::td[contains(@class,'mat-column-ownershipStatus')]");
    // region Fill Mandatory Information
    public void AgentFillInMandatoryOrganicInformation() throws InterruptedException {

//        By MandatoryInfoWarningMessage = By.xpath("//mat-dialog-container/descendant::div[text()='Your application is missing mandatory information.']");
//        Boolean WarningMessage = driver.findElement(MandatoryInfoWarningMessage).isDisplayed();
//        while(WarningMessage.equals(true)) {
//            AgentSelectValueFromSideDrawerDropdown("organicStatus","Conventional");
//            AgentClickOnNextOrBackOrSubmitButton("Save changes");
//            Thread.sleep(2000);
//            actions.clickUsingJS(OrganicColumnRow);
//            By NextMandatoryInfoWarningMessage = By.xpath("//mat-dialog-container/descendant::div[text()='Your application is missing mandatory information.']");
//            Boolean NextWarningMessage = driver.findElement(NextMandatoryInfoWarningMessage).isDisplayed();
//            Thread.sleep(2000);
//            WarningMessage = NextWarningMessage;
//        }
        if(!driver.findElements(pageButton).isEmpty()) {
            actions.waitforSeconds(3);
            actions.clickUsingJS(pageButton);
            actions.waitforSeconds(3);
            actions.click(lastPage);
        }
        By errors = By.xpath("//mat-icon[contains(text(),'error')]/ancestor::td/following-sibling::td[contains(@class,'mat-column-organicStatus')]");
        int n = driver.findElements(errors).size();
        while(!driver.findElements(errors).isEmpty()) {
            System.out.println(n);
            By OrganicColumnRow = By.xpath("(//mat-icon[contains(text(),'error')]/ancestor::td/following-sibling::td[contains(@class,'mat-column-organicStatus')])["+n+"]");
            actions.clickUsingJS(OrganicColumnRow);
            Thread.sleep(2000);
            AgentSelectDropdownValuesInParcelAndPlotModal("Conventional","organicStatus");
            try{
                AgentSelectValueInParcelValueFieldInAddParcelOrPlotDialogDropDown("Alfalfa","parcelUse");
            }
            catch (TimeoutException e){
                AgentSelectValueInParcelValueFieldInAddParcelOrPlotDialogDropDown("Forestry Eligible","parcelUse");
            }
            if(driver.findElement(ownershipStatus).getText().equals("Rented In")){
                AgentEnterValueInAddPlotOrParcelDialog("31/12/2027","leaseExpiryDate");
            }
            AgentClickOnNextOrBackOrSubmitButton(" Save changes ");
            actions.waitforSeconds(2);
            n=n-1;

//            By NextMandatoryInfoWarningMessage = By.xpath("//mat-dialog-container/descendant::div[text()='Your application is missing mandatory information.']");
//            Boolean NextWarningMessage = driver.findElement(NextMandatoryInfoWarningMessage).isDisplayed();
//            Thread.sleep(2000);
        }
    }
// endregion


    public void AgentFillInMandatoryAgActivityAndOrganicInformation() throws InterruptedException {
        By AgriculturalActivityColumnRow = By.xpath("(//td[contains(@class,'mat-column-organicStatus')])[1]");
        List <WebElement> ParcelList = driver.findElements(By.xpath("//td[contains(@class,'mat-column-organicStatus')]"));
        while(!ParcelList.isEmpty()) {
            actions.clickUsingJS(AgriculturalActivityColumnRow);
            Thread.sleep(3000);
            AgentSelectValueFromSideDrawerDropdown("organicStatus","Conventional");
            List <WebElement> WarningList = driver.findElements(By.xpath("//mat-dialog-container/descendant::div[text()='Your application is missing mandatory information.']"));
            if(WarningList.isEmpty()) {
                AgentClickOnNextOrBackOrSubmitButton("Save changes");
            }
            else {
                AgentSelectValueFromSideDrawerDropdown("agriculturalActivity","No Agricultural Activity");
                AgentClickOnNextOrBackOrSubmitButton("Save changes");
            }
            Thread.sleep(2000);
            ParcelList = driver.findElements(By.xpath("//td[contains(@class,'mat-column-organicStatus')]"));
        }
    }



    // endregion

    // region GAEC7

    // Staff Check Crop Diversification Summary Fields

    // Staff check Total Other Eligible Crop Area less than tillage area

    // Staff Check Crop Diversification Breakdown Fields

    // endregion

    // region GAEC8 Step

    // Agent Select GAEC8 Contribution for a parcel
    public void AgentSelectGAEC8ContributionForAParcel(String ParcelNo, String Contribution) {
        WebElement ParcelNumber = driver.findElement(By.xpath("//td/div[contains(text(),'"+ParcelNo+"')]"));
        WebElement ParcelUse = driver.findElement(By.xpath("//td[contains(@class,'cdk-column-parcelUse')]"));
        WebElement GAEC8contribution = driver.findElement(with(By.xpath("//td/descendant::mat-select"))
                .toRightOf(ParcelUse)
                .toRightOf(ParcelNumber));
//        actions.waitForVisibilityOfWebElement(GAEC8contribution,50);
        actions.clickWebElementUsingJS(GAEC8contribution);
        By ContributionType = By.xpath("//span[contains(text(),'"+Contribution+"')]/ancestor::mat-option");
//        actions.waitForVisibilityOfElement(ContributionType, 50);
        actions.clickUsingJS(ContributionType);
    }

    // Agent Click on the View Map Button for a Particular Parcel
    public void AgentClickOnViewMapForParcel(String ParcelNo) {
        WebElement ParcelNumber = driver.findElement(By.xpath("//td/div[contains(text(),'"+ParcelNo+"')]"));
        WebElement ParcelUse = driver.findElement(By.xpath("//td[contains(@class,'cdk-column-parcelUse')]"));
        WebElement GAEC8contribution = driver.findElement(By.xpath("//td/descendant::mat-select"));
        WebElement ObligationArea = driver.findElement(By.xpath("//td[contains(@class,'cdk-column-parcelArea')]"));
        WebElement GAEC8Area = driver.findElement(By.xpath("//td[contains(@class,'cdk-column-totalSfnArea')]"));
        WebElement ClickMapButton = driver.findElement(with(By.xpath("//td/descendant::button[@aria-label='View map']"))
                .toRightOf(GAEC8Area)
                .toRightOf(ObligationArea)
                .toRightOf(GAEC8contribution)
                .toRightOf(ParcelUse)
                .toRightOf(ParcelNumber));
        ClickMapButton.click();
//        actions.waitForVisibilityOfWebElement(ClickMapButton,30);
//        actions.clickWebElementUsingJS(ClickMapButton);
    }

    // Agent Expand the Parcel In the List
    public void AgentExpandParcelInList(String Arg0) {
        WebElement ParcelNumber = driver.findElement(By.xpath("//td/div[contains(text(),'"+Arg0+"')]"));
        WebElement ParcelUse = driver.findElement(By.xpath("//td[contains(@class,'cdk-column-parcelUse')]"));
        WebElement GAEC8contribution = driver.findElement(By.xpath("//td/descendant::mat-select"));
        WebElement ObligationArea = driver.findElement(By.xpath("//td[contains(@class,'cdk-column-parcelArea')]"));
        WebElement GAEC8Area = driver.findElement(By.xpath("//td[contains(@class,'cdk-column-totalSfnArea')]"));
        WebElement MapButton = driver.findElement(By.xpath("//td/descendant::button[@aria-label='View map']"));
        WebElement ClickExpandButton = driver.findElement(with(By.xpath("//td[@title='Expand/Collapse']"))
                .toRightOf(MapButton)
                .toRightOf(GAEC8Area)
                .toRightOf(ObligationArea)
                .toRightOf(GAEC8contribution)
                .toRightOf(ParcelUse)
                .toRightOf(ParcelNumber));
        ClickExpandButton.click();
//        actions.waitForVisibilityOfWebElement(ClickExpandButton,30);
//        actions.clickWebElementUsingJS(ClickExpandButton);
    }

    // Agent hover over the information buttons to show detailed widget
    // locator Arg "sfn-status-contribution" , "sfn-area-info-block" , "land-table-container"
    public void AgentHoverOverInformationWidget(String Status) {
        Actions act = new Actions(driver);
        By InfoButton = By.xpath("(//td[contains(@class,'mat-column-amsStatus')]/descendant::mat-icon[@data-mat-icon-name='"+Status+"'])[1]");
//        WebElement InfoButton = driver.findElement(By.xpath("(//td[contains(@class,'mat-column-amsStatus')]/descendant::mat-icon[@data-mat-icon-name='"+Status+"'])[1]"));
        if(driver.findElements(InfoButton).isEmpty()) {
            System.out.println(Status + "icon not found for current Herd");
        }
        else {
            WebElement InfoElement = driver.findElement(By.xpath("(//td[contains(@class,'mat-column-amsStatus')]/descendant::mat-icon[@data-mat-icon-name='"+Status+"'])[1]"));
            act.moveToElement(InfoElement);
            System.out.println(Status + "icon found for current Herd");
        }
    }

    // Get the SFN Contribution Value
    public void CaptureSFNContributionValue() {
        WebElement ContributionValueText = driver.findElement(By.xpath("//div[@class='sfn-status-contribution-value']/descendant::span"));
        String ContributionValueString = ContributionValueText.getText();
        String[] Value = ContributionValueString.split("%");
        float ContributionValue = Float.parseFloat(Value[0]);
        Boolean ValueCheck = ContributionValue > 3;
        System.out.println(ValueCheck);
        if(ValueCheck.equals(true)) {
            System.out.println("Eligible for GAEC8");
        }
        else {
            System.out.println("Not Eligible for GAEC8");
        }
    }

    // endregion

    // region Eco Tab

    // Agent Select Checkbox for BISS Application without Eco-scheme
    public void AgentClickOnCheckBoxForNoEcoScheme() {
        By NoEcoCheckBox = By.xpath("//mat-card[contains(@class,'eco-opt-out')]/descendant::input[@type='checkbox']");
//        actions.waitForVisibilityOfElement(NoEcoCheckBox,30);
        actions.clickUsingJS(NoEcoCheckBox);
    }

    public void AgentCheckIfOptOutOfSchemePresentAndProceed() {
        List<WebElement> EcoSchemeOptOut = driver.findElements(By.xpath("//mat-card[contains(@class,'eco-opt-out')]/descendant::input[@type='checkbox']"));
        if(EcoSchemeOptOut.isEmpty()) {
            System.out.println("Agricultural Practices Selected");
        }
        else {
            By NoEcoCheckBox = By.xpath("//mat-card[contains(@class,'eco-opt-out')]/descendant::input[@type='checkbox']");
            Boolean ToggleStatus = driver.findElement(NoEcoCheckBox).isSelected();
            if(ToggleStatus.equals(true)){
                System.out.println("Eco Scheme Opted out Already");
            }
            else {
                AgentClickOnCheckBoxForNoEcoScheme();
            }
        }
    }

    // Toggle Switch for Eco Scheme Page
    public void EcoSchemeToggleClick(int n) {
        By ToggleButtonOfChoice = By.xpath("(//mat-slide-toggle)["+n+"]");
        actions.waitForVisibilityOfElement(ToggleButtonOfChoice,30);
        actions.clickUsingJS(ToggleButtonOfChoice);
    }

    // Agent Control Toggles in the Eco Page
    public void AgentControlTogglesInEcoPage(String EcoSchemeOption) {
//        WebElement OptionsForEcoHeading = driver.findElement(By.xpath("//td[contains(text(),'"+EcoSchemeOption+"')]"));
//        WebElement ToggleButton = driver.findElement(with(By.xpath("//mat-slide-toggle"))
//                .toRightOf(OptionsForEcoHeading));
//        actions.waitForVisibilityOfWebElement(ToggleButton,30);
//        actions.clickWebElementUsingJS(ToggleButton);
//

        switch (EcoSchemeOption) {
            case "AP1" : {
                int n = 1;
                EcoSchemeToggleClick(n);
                break;
            }
            case "AP2" : {
                int n = 2;
                EcoSchemeToggleClick(n);
                break;
            }
            case "AP4" : {
                int n = 3;
                EcoSchemeToggleClick(n);
                break;
            }
            case "AP5" : {
                int n = 4;
                EcoSchemeToggleClick(n);
                break;
            }
            case "AP6" : {
                int n = 5;
                EcoSchemeToggleClick(n);
                break;
            }
        }
    }

    // Agent Click on the Checkbox inside Eco Options
    public void AgentClickOnCheckBoxForEcoScheme(String EcoScheme) throws InterruptedException {
        if(EcoScheme.equals("ap6")){
            List <WebElement> CheckBoxes = driver.findElements(By.xpath("//div[contains(@class,'eco-"+EcoScheme+"-container')]/descendant::mat-checkbox/descendant::input[@type='checkbox']"));
            int Numofcheckboxes = CheckBoxes.size();
            System.out.println(Numofcheckboxes);
            for (int i=1;i<=Numofcheckboxes;i++) {
                By CheckBox = By.xpath("//div[contains(@class,'eco-"+EcoScheme+"-container')]/descendant::input["+i+"]");
//                actions.waitForVisibilityOfElement(CheckBox,50);
                actions.clickUsingJS(CheckBox);
            }
        }
        else {
            By CheckBox = By.xpath("//div[contains(@class,'eco-"+EcoScheme+"-container')]/descendant::mat-checkbox/descendant::input[@type='checkbox']");
            Thread.sleep(3000);
            actions.waitForVisibilityOfElement(CheckBox,30);
            actions.clickUsingJS(CheckBox);
        }
    }

    // Agent Click on Save and Select Button for Eco Options
    public void AgentClickOnSaveAndSelectButton(String EcoScheme) {
        By SaveAndSelectButton = By.xpath("//div[contains(@class,'eco-"+EcoScheme+"-container')]/descendant::button/span[contains(text(),'Save & Select')]");
        actions.waitForVisibilityOfElement(SaveAndSelectButton,50);
        actions.clickUsingJS(SaveAndSelectButton);
    }


    // Agent Click on Radio Button Options in AP4 Eco Scheme
    public void AgentClickOnRadioButtonInAP4Scheme(String Option) {
        By AP4SchemeRadioButtons = By.xpath("//input[@type='radio' and @value='"+Option+"']");
//        actions.waitForVisibilityOfElement(AP4SchemeRadioButtons,50);
        actions.clickUsingJS(AP4SchemeRadioButtons);
    }

    // Agent Select Fertiliser Spreader/Sprayer in AP5 Eco-Scheme
    public void AgentClickOnRadioButtonInAP5(String Type) throws InterruptedException {
        By AP5SchemeRadioButtons = By.xpath("//mat-radio-group[@formcontrolname='gpsType']/descendant::input[@value='"+Type+"']");
//        By AP5RadioButtons = By.xpath("//mat-radio-group[@formcontrolname='gpsType']");
        actions.scrollByUsingJS(AP5SchemeRadioButtons);
//        actions.waitForVisibilityOfElement(AP5SchemeRadioButtons,100);
        actions.clickUsingJS(AP5SchemeRadioButtons);
    }

    // Agent Select Approved Spreader for AP5
    // Locators Arg0 : selectedSpreaderManufacturer, spreaderModel
    // Locators Arg1 : Make or Model from dropdown
    public void AgentSelectDropdownValuesForApprovedSpreader(String Dropdown, String SpreaderChoice) {
        By SearchSpreaderDropdown = By.xpath("//mat-select[@formcontrolname='"+Dropdown+"']");
        actions.waitForVisibilityOfElement(SearchSpreaderDropdown,30);
        actions.clickUsingJS(SearchSpreaderDropdown);
        By ApprovedSpreader = By.xpath("//span[contains(text(),'"+SpreaderChoice+"')]/ancestor::mat-option");
        actions.waitForVisibilityOfElement(ApprovedSpreader, 30);
        actions.clickUsingJS(ApprovedSpreader);
        actions.waitforSeconds(4);
    }

    // Agent fill in Text Boxes in AP5 Scheme
    // Locators Arg : spreaderSerialNo, sprayerManufacturer, sprayerSerialNo, contractorName
    public void AgentFillInTheAP5TextBoxes(String Text, String AP5TextBoxType) {
        By AP5TextBoxes = By.xpath("//input[@formcontrolname='"+AP5TextBoxType+"']");
        actions.waitForVisibilityOfElement(AP5TextBoxes,50);
        actions.sendKeys(AP5TextBoxes,Text);
    }

    // Check Warning in Eco Page
    public void EcoWarningMessageCheck() {
        By EcoWarning = By.xpath("//span[contains(text(),'You must select 2 Agricultural Practices to proceed')]");
        List <WebElement> Warning = driver.findElements(EcoWarning);
        if(Warning.isEmpty()) {
            System.out.println("Eco Warning not Displayed");
        }
        else {
            System.out.println("Eco Warning Displayed");
        }
    }

    public Boolean CheckIfToggleEnabled() {
        By NoEcoCheckBox = By.xpath("//mat-card[contains(@class,'eco-opt-out')]/descendant::input[@type='checkbox']");
        Boolean ToggleStatus = driver.findElement(NoEcoCheckBox).isSelected();
        return ToggleStatus;
    }
    // endregion

    // region ACRES page
    public void CheckAcresPageAndClickNext() throws InterruptedException {
        By ACRESstepper = By.xpath("//mat-step-header/descendant::div[contains(text(),'ACRES')]");
        List<WebElement> ACRESvisibility = driver.findElements(ACRESstepper);
        if(ACRESvisibility.isEmpty()) {
            System.out.println("No ACRES Page");
        }
        else {
            AgentClickOnNextOrBackOrSubmitButton("Next");
        }
    }
    // endregion

    // region Review and Submit Tab

    // Agent Click on the Next Button in Review and Submit Screen
    public void AgentClickOnNextButtonInReviewAndSubmitScreen() throws InterruptedException {
        By NextButtonCounter = By.xpath("//button/descendant::span[contains(text(),'Next')]");
        int Arg0 = driver.findElements(NextButtonCounter).size();
        for(int i=1;i<=Arg0;i++)
        {
            By ReviewNextButton = By.xpath("(//button/descendant::span[contains(text(),'Next')])["+i+"]");
//            actions.waitForVisibilityOfElement(ReviewNextButton,30);
            actions.clickUsingJS(ReviewNextButton);
            Thread.sleep(3000);
        }
        Thread.sleep(5000);
    }

    // Agent Click on Terms and Conditions CheckBox
    public void AgentClickOnTermsAndConditionsCheckBox() {
        By TermsAndConditions = By.xpath("//mat-card[contains(@class,'terms-conditions')]/descendant::label[contains(text(),'I have read and accept the')]");
        actions.waitForVisibilityOfElement(TermsAndConditions,30);
        actions.clickUsingJS(TermsAndConditions);
    }

    // Submit Button code found in Common Area

    // endregion

    // region Documents Page post after Submitted Application

    // Upload Documentation Button
    // Can use the Submit button method

    // Application Summary Button
    // Can use the Submit Button

    // Application Summary Back Button
    // Can use common Back Button

    // Element from List of Letters
    // Arg : BISS Application Form
    public void AgentSelectFromListOfDocuments(String ListItem) {
        By ItemFromList = By.xpath("//b[contains(text(),'+"+ListItem+"')]");
        actions.waitForVisibilityOfElement(ItemFromList,50);
        actions.clickUsingJS(ItemFromList);
    }



   // region My Correspondence Page
    public String GetDateOfAmendmentApplication() {
        By AmendmentDateLoc = By.xpath("(//td[contains(@class,'cdk-column-dateIssued')])[1]");
        String AmendmentDate = driver.findElement(AmendmentDateLoc).getText();
        System.out.println("Amended Date : "+AmendmentDate);
        return AmendmentDate;
    }

    // endregion




    // region Junk Code (Used earlier and commented out now)

    // DB Code
//    public void getDBvalues() throws ClassNotFoundException, SQLException {
//        Class.forName("com.oracle.jdbc.Driver");
//        String url = "Connection String";
//        String username = "DPS_DATA";
//        String password = "DPS_DATA";
//
//        Connection conn = DriverManager.getConnection(url,username,password);
//        Statement stmnt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
//        ResultSet rs = stmnt.executeQuery("SQL Query");
//        rs.last();
//
//        int rows = rs.getRow();
//        System.out.println("No. of rows"+rows);
//
//        ResultSetMetaData rsmd = rs.getMetaData();
//        int cols = rsmd.getColumnCount();
//        System.out.println("No. of rows"+cols);
//
//        String data[][] = new String[rows][cols];
//
//        int i=0;
//        rs.beforeFirst();
//        while (rs.next())
//        {
//            for(int j=0;j<cols;j++)
//            {
//                data[i][j]=rs.getString(j+1);
//                System.out.println(data[i][j]);
//            }
//            i++;
//        }
//    }
//
//    // DB Code 2
//    protected static Connection conn = null;
//    protected static Statement stmnt = null;
//    protected static ResultSetMetaData rsmd = null;
//    protected static ResultSet rs1 = null;
//    protected static ResultSet rs2 = null;
//    protected static String query_Total_Row = "SQL Query";
//    protected static String query_ALL_RECORDS = "sql qUERY";
//    protected static int columnNumber;
//    protected static int rowNumber;
//    protected static SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
//
//    public static void main(String[] args) throws SQLException, IOException
//    {
//        try {
//        }
//        finally {
//
//        }
//    }
//            System.out.println("Connecting to Database..."+"\n"+df.format(new Date()))+""
//                    +"\n------------------------------------------------------------------------";
//            Cl
//        }
//    }

    // Locators

    //    By PlotReference = By.xpath("//input[@formcontrolname='plotReference']");
    //    By ParcelSearchTextBox = By.xpath("//label[contains(text(),'Parcel Search')]/parent::div/descendant::input");
    //    By AddPlotAddButton = By.xpath("//button//child::span[text()='Add']");

    // Methods

    // Agent Click on Delete Button for a particular Parcel
    //    public void AgentClickOnDeleteInParcelList(String Arg0) {
    //        By PlotReference = By.xpath("//td[contains(text(),'"+Arg0+"')]");
    //        WebElement PlotRef = driver.findElement(PlotReference);
    //        WebElement CommonageFractionColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-commonageFraction')]"));
    //        WebElement EligibleHectareColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-eligibleHectare')]"));
    //        WebElement ClaimedAreaColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-claimedArea')]"));
    //        WebElement OwnershipStatusColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-ownershipStatus')]"));
    //        WebElement ParcelUseColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-parcelUse')]"));
    //        WebElement AgriculturalActivityColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-maintenance')]"));
    //        WebElement DeleteParcelButtonColumn = driver.findElement(with(By.xpath("//td/descendant::button/descendant::mat-icon[text()='delete']"))
    //                .toRightOf(AgriculturalActivityColumn)
    //                .toRightOf(ParcelUseColumn)
    //                .toRightOf(OwnershipStatusColumn)
    //                .toRightOf(ClaimedAreaColumn)
    //                .toRightOf(EligibleHectareColumn)
    //                .toRightOf(CommonageFractionColumn)
    //                .toRightOf(PlotRef));
    //        actions.waitForVisibilityOfWebElement(DeleteParcelButtonColumn,30);
    //        actions.clickWebElementUsingJS(DeleteParcelButtonColumn);
    //    }

    //    // Entering data in Add Plot/Parcel Modal Input Fields
    //    public void AgentEnterDataInPlotModalInputFields(String Arg0, String Arg1) {
    //        By PlotInput = By.xpath("//input[@formcontrolname='"+Arg0+"']");
    //        actions.waitForVisibilityOfElement(PlotInput, 30);
    //        actions.sendKeys(PlotInput, String.valueOf(Arg1));
    //    }

    //    // Clicking on the Add Plot/Parcel Buttons
    //    public void AgentClickOnAddPlotOrParcelButtons(String Arg0) {
    //        By AddPlotButtons = By.xpath("//button//child::span[contains(text(),'"+Arg0+"')]");
    //        actions.waitForVisibilityOfElement(AddPlotButtons,30);
    //        actions.clickUsingJS(AddPlotButtons);
    //    }

    //    // Enter Parcel Number to be Searched
    //    public void AgentEnterParcelToBeSearched(String Arg0) {
    //        actions.waitForVisibilityOfElement(ParcelSearchTextBox,30);
    //        actions.sendKeys(ParcelSearchTextBox,Arg0);
    //    }

    //    // Click on the Add Parcel Button
    //    public void AgentClickOnAddParcelButton() {
    //        actions.waitForVisibilityOfElement(AddPlotAddButton,30);
    //        actions.clickUsingJS(AddPlotAddButton);
    //    }

    //endregion

    //endregion

    // region Multiple Agents Login

    // endregion

    // region Agent Add Parcels And Plots
    public void AgentAddParcelsAndPlots() {

    }

    public void AddInvalidParcel() throws InterruptedException {
        AgentClickOnApplicationStepper("Land Details");
        AgentClickOnAddPlotOrAddParcelButton("Add parcel");
        AgentEnterValueInAddPlotOrParcelDialog("Invalid789","parcelInput");
        AgentClickOnDialogBoxButton("Claim");
        Thread.sleep(3000);
        AgentClickOnDialogBoxButton("Cancel");
    }

    public void AddArchivedParcel() {
        AgentClickOnApplicationStepper("Land Details");
        AgentClickOnAddPlotOrAddParcelButton("Add parcel");
        AgentEnterValueInAddPlotOrParcelDialog("H19112055","parcelInput");
        AgentClickOnDialogBoxButton("Claim");
        AgentCheckForArchivedParcelMessage();
        AgentClickOnDialogBoxButton("Cancel");
    }

    public void AddParcelToBatch(String ParcelNumber) {
        AgentClickOnApplicationStepper("Land Details");
        AgentClickOnAddPlotOrAddParcelButton("Add parcel");
        AgentEnterValueInAddPlotOrParcelDialog(ParcelNumber,"parcelInput");
        AgentClickOnDialogBoxButton("Claim");
        By EligibleHa = By.xpath("//span[@aria-label='Eligible hectare']");
        int Value = Integer.parseInt(driver.findElement(EligibleHa).getText())-1;
        String ClaimedArea = String.valueOf(Value);
        AgentEnterValueInAddPlotOrParcelDialog(ClaimedArea,"ClaimedArea");
        AgentSelectDropdownValuesInParcelAndPlotModal("Owned","ownershipStatus");
        AgentSelectDropdownValuesInParcelAndPlotModal("Apples","parcelUse");
        AgentSelectDropdownValuesInParcelAndPlotModal("Conventional","organicStatus");
        AgentClickOnDialogBoxButton("Add");
    }

    public void AddPlotToBatch(String County, String Plot, String RefNumber) {
        AgentClickOnApplicationStepper("Land Details");
        AgentClickOnAddPlotOrAddParcelButton("Add plot");
        AgentSelectDropdownValuesInParcelAndPlotModal(County,"county");
        AgentSelectDropdownValuesInParcelAndPlotModal(Plot,"townland");
        AgentEnterValueInAddPlotOrParcelDialog(RefNumber,"plotReference");
        AgentSelectDropdownValuesInParcelAndPlotModal("Owned","ownershipStatus");
        AgentSelectDropdownValuesInParcelAndPlotModal("Conventional","organicStatus");;
        AgentEnterValueInAddPlotOrParcelDialog("10","ClaimedArea");
        AgentSelectDropdownValuesInParcelAndPlotModal("Blackcurrants","plotUse");   
        AgentClickOnRadioButtonsInDialogBox("Submit Paper Map By Post");
        AgentClickOnDialogBoxButton("Next");
        AgentClickOnSideDrawerButtons("Cancel");
    }

    // endregion

    // endregion

    // region GAEC 7

    // Agent Check GAEC 7 Status
    public String AgentCheckGAEC7Status() {
        By Status = By.xpath("//span[contains(@class,'status-heading')]");
        return driver.findElement(Status).getText();
    }

    // Agent Check if Crop Diversification Summary Table has Total Eligible Area
    public void AgentCheckTotalEligibleAreaValuesInCropDiversificationTables() {
        By TotalEhColumn = By.xpath("//td[contains(@class,'cdk-column-totalEligible')] ");
        boolean TotalEhColumnPresent = driver.findElements(TotalEhColumn).isEmpty();
        if(!TotalEhColumnPresent) {
            System.out.println("Total eligible (Ha) displayed");
        }
        else {
            System.out.println("Total eligible (Ha) not displayed");
        }
    }
    // endregion

    // region Crop Diversification

    // Agent Check Values in the Crop Diversification Summary Table
    public void AgentCheckValuesInCropDiversificationSummaryTable() {
        By TotalAgriculturalAreaPercent = By.xpath("//table[@aria-label='Crop diversification table']/descendant::th[contains(@class,'cdk-column-totalAgricultural')]");
        By TotalAgriculturalArea = By.xpath("//table[@aria-label='Crop diversification table']/descendant::td[contains(text(),'Total agricultural area')]");
        By TotalGrasslandArea = By.xpath("//table[@aria-label='Crop diversification table']/descendant::td[contains(text(),'Total grassland area')]");
        By TotalTillageArea = By.xpath("//table[@aria-label='Crop diversification table']/descendant::td[contains(text(),'Total tillage area')]");
        By TotalOtherEligibleCropArea = By.xpath("//table[@aria-label='Crop diversification table']/descendant::td[contains(text(),'Total other eligible crop area')]");

        boolean TotalAgriculturalAreaPercentPresent = driver.findElements(TotalAgriculturalAreaPercent).isEmpty();
        if(!TotalAgriculturalAreaPercentPresent) {
            System.out.println("Total Agricultural Area Percent displayed");
        }
        else {
            System.out.println("Total Agricultural Area Percent not displayed");
        }

        boolean TotalAgriculturalAreaPresent = driver.findElements(TotalAgriculturalArea).isEmpty();
        if(!TotalAgriculturalAreaPresent) {
            System.out.println("Total Agricultural Area displayed");
        }
        else {
            System.out.println("Total Agricultural Area not displayed");
        }

        boolean TotalGrasslandAreaPresent = driver.findElements(TotalGrasslandArea).isEmpty();
        if(!TotalGrasslandAreaPresent) {
            System.out.println("Total Grassland Area displayed");
        }
        else {
            System.out.println("Total Grassland Area not displayed");
        }

        boolean TotalTillageAreaPresent = driver.findElements(TotalTillageArea).isEmpty();
        if(!TotalTillageAreaPresent) {
            System.out.println("Total Tillage Area displayed");
        }
        else {
            System.out.println("Total Tillage Area not displayed");
        }

        boolean TotalOtherEligibleCropAreaPresent = driver.findElements(TotalOtherEligibleCropArea).isEmpty();
        if(!TotalOtherEligibleCropAreaPresent) {
            System.out.println("Total Other Eligible Crop Area displayed");
        }
        else {
            System.out.println("Total Other Eligible Crop Area not displayed");
        }
    }

    // Agent Check Value of Other Total Eligible Crop Area
    public void AgentCheckOtherTotalEligibleCropAreaValue() {
        By OtherEligibleCropArea = By.xpath("//table[@aria-label='Crop diversification table']/descendant::td[contains(text(),'Total other eligible crop area')]/parent::tr/td[3]");
        By AgriculturalArea = By.xpath("//table[@aria-label='Crop diversification table']/descendant::td[contains(text(),'Total agricultural area')]/parent::tr/td[3]");
        By GrasslandArea = By.xpath("//table[@aria-label='Crop diversification table']/descendant::td[contains(text(),'Total grassland area')]/parent::tr/td[3]");
        By TillageArea = By.xpath("//table[@aria-label='Crop diversification table']/descendant::td[contains(text(),'Total tillage area')]/parent::tr/td[3]");
        System.out.println("Total Other Eligible Crop Area : " + driver.findElement(OtherEligibleCropArea).getText());
        System.out.println("Total Agricultural Area : " + driver.findElement(AgriculturalArea).getText());
        System.out.println("Total Grassland Area : " + driver.findElement(GrasslandArea).getText());
        System.out.println("Total Tillage Area : " + driver.findElement(TillageArea).getText());
    }

    // Agent Check Total Eligible Values in Breakdown Table
    public void AgentCheckTotalEhValuesInBreakdownTable() {
        By TotalEhValues = By.xpath("//table[@aria-label='Crop diversification breakdown table']/descendant::td[contains(@class,'cdk-column-totalEligible')]");
        boolean TotalEhValuePresent = driver.findElements(TotalEhValues).isEmpty();
        if(!TotalEhValuePresent) {
            System.out.println("Total Eligible Area displayed");
        } else {
            System.out.println("Total Eligible Area not displayed");
        }
    }

    // Agent Check Total Arable Land Percentage Values in Breakdown Table
    public void AgentCheckTotalArableLandValuesInBreakdownTable() {
        By TotalArableLandValues = By.xpath("//table[@aria-label='Crop diversification breakdown table']/descendant::td[contains(@class,'cdk-column-totalEligible')]");
        boolean TotalArableLandValuesPresent = driver.findElements(TotalArableLandValues).isEmpty();
        if(!TotalArableLandValuesPresent) {
            System.out.println("Total Arable Land Percentage displayed");
        } else {
            System.out.println("Total Arable Land Percentage not displayed");
        }
    }

    // endregion

    // region AMS
    By ViewButton = By.xpath("(//a[contains(text(),'View')])[1]");
    By AMSStatusIconRed = By.xpath("(//mat-icon[@data-mat-icon-name='ams-status-red'])[1]");

    // Agent click on the first View Button in the Pending List
    public void AgentClickOnViewButtonForFarmer() {
            actions.clickUsingJS(ViewButton);
    }

    // Agent click on Parcel with AMS Status Pending
    public void AgentClickOnFirstParcelWithAMSStatusPending() {
        actions.clickUsingJS(AMSStatusIconRed);
    }

    // Agent Click On Agree or Disagree option in the AMS Side Drawer
    public void AgreeOrDisagreeInSideDrawer(String Arg0) {
        By AgreeDisagreeButton = By.xpath("//mat-radio-group[@formcontrolname='userAgrees']/descendant::span[contains(text(),'"+Arg0+"')]");
        actions.clickUsingJS(AgreeDisagreeButton);
    }

    // Agent Click On Disagree Reason option in the AMS Side Drawer
    public void DisagreeReasonInSideDrawer(String Arg0) {
        By AgreeDisagreeButton = By.xpath("//mat-radio-group[@formcontrolname='reasonDescription']/descendant::span[contains(text(),'"+Arg0+"')]");
        actions.clickUsingJS(AgreeDisagreeButton);
    }
    // endregion

    // Admin Inspection


    // endregion

    // region SIM
//    By NoSIMParcel = By.xpath("//table[@aria-label='SIM lands table']/descendant::td[contains(text(),'S1250500027')]");
    By SIMPanel = By.xpath("//mat-card[contains(@class,'scheme-selected')]");

    public void AgentScrollToNoHerdParcel(String Parcel) throws InterruptedException {
        By NoSIMParcel = By.xpath("//table[@aria-label='SIM lands table']/descendant::td[contains(text(),'"+Parcel+"')]");
        actions.scrollByUsingJS(NoSIMParcel);
    }

    // Staff Scroll to Dropdown
    public void StaffScrollToDropdown(String ParcelRef) {
        By ReductionReasonLocator = By.xpath("//td[contains(text(),'"+ParcelRef+"')]/ancestor::tr/descendant::td[contains(@class,'cdk-column-reductionReason')]");
    }

    // Staff Check if SIM Panel Selected
    public Boolean SelectedSIMPanelVisibility() {
        actions.waitForVisibilityOfElement(SIMPanel,50);
        return driver.findElement(SIMPanel).isDisplayed();
    }

    // Staff Open and Check Parcel Edit Drawers
    public void ClickOnParcelToOpenDrawer(String Row) {
        By ParcelRow = By.xpath("(//table[@aria-label='SIM lands table']/tbody/descendant::tr)["+Row+"]");
        actions.clickUsingJS(ParcelRow);
    }

    private static String NoSIMparcelNumber;

    // Staff Close the Side Drawer
    public void SelectSIMNotCheckedParcel() throws InterruptedException {
        By NoSIMParcel = By.xpath("//input[@type='checkbox' and @aria-checked='false']/ancestor::tr/td[contains(@class,'cdk-column-parcelRef')]");
//        actions.clickUsingJS(NoSIMParcel);
        List<WebElement> NoSIMParcels = driver.findElements(NoSIMParcel);
        System.out.println(NoSIMParcels.size());
        NoSIMparcelNumber = NoSIMParcels.get(4).getText();
        actions.clickWebElementUsingJS(NoSIMParcels.get(4));
        Thread.sleep(5000);
    }

    // Staff Open Side Drawer for No SIM Parcel
    public void StaffOpenSideDrawerForSIMCheck(String Parcel) {
        By NoSIMParcel = By.xpath("//table[@aria-label='SIM lands table']/descendant::td[contains(text(),'"+Parcel+"')]");
        actions.clickUsingJS(NoSIMParcel);
    }

    // Staff Click On the SIM Indicator CheckBox
    public void StaffClickOnSIMIndicatorCheckBox() throws InterruptedException {
        By SIMIndicator = By.xpath("//mat-checkbox[@formcontrolname='simIndicator']/descendant::span[contains(text(),'SIM Current')]");
        actions.scrollByUsingJS(SIMIndicator);
        Thread.sleep(2000);
        actions.clickUsingJS(SIMIndicator);
    }



    // Staff add 1 to SIM Found Area Value and close side Drawer
    public void AgentChangeSIMFoundArea(String Field) throws InterruptedException {
        By SideDrawerField = By.xpath("//mat-dialog-container/descendant::input[@formcontrolname='"+Field+"']");
        By ClaimedArea = By.xpath("//span[@aria-label='Eligible Hectares']");
        BigDecimal ClaimedAreaText = new BigDecimal(driver.findElement(ClaimedArea).getText());
        Thread.sleep(2000);
        BigDecimal Constant = BigDecimal.valueOf(1);
        Thread.sleep(2000);
        BigDecimal UpdatedValue = Constant.add(ClaimedAreaText);
        Thread.sleep(2000);
        actions.sendKeys(SideDrawerField, String.valueOf(UpdatedValue));
    }

    // Staff Check the Overclaim Warning
    public String StaffCheckOverClaimWarning() {
        By OverClaimWarning = By.xpath("//mat-error/descendant::span[contains(text(),'value must be equal or less than EH')]");
        return driver.findElement(OverClaimWarning).getText();
    }

    // Staff Check the Missing Note Warning
    public String StaffCheckMissingNoteWarning() {
        By OverClaimWarning = By.xpath("//mat-error/descendant::span[contains(text(),'Missing SIM Application comment/note')]");
        return driver.findElement(OverClaimWarning).getText();
    }

    // Staff Enter notes for SIM Application
    public void StaffAddNoteToSIMApplication(String Value) {
        By SIMnoteArea = By.xpath("//textarea[@formcontrolname='simNotes']");
        actions.sendKeys(SIMnoteArea,Value);
    }
    // endregion


    // region BISS Application Summary Screen

    // Get Values from Submission Details Section
    public void StaffGetSubmissionDetailValues(String Label) {
        By SubmissionValue = By.xpath("//mat-card-title[contains(text(),'Submission Details')]/ancestor::mat-card/descendant::p/b[text()='"+Label+"']/parent::p/following-sibling::p");
        System.out.println(Label +" Value = "+ driver.findElement(SubmissionValue).getText());
    }

    // Verify Values from Submission Details Section
    public String StaffPrintandVerifySubmissionDetailValues(String Label) {
        By SubmissionValue = By.xpath("//mat-card-title[contains(text(),'Submission Details')]/ancestor::mat-card/descendant::p/b[text()='"+Label+"']/parent::p/following-sibling::p");
        System.out.println(Label +" Value = "+ driver.findElement(SubmissionValue).getText());
        return driver.findElement(SubmissionValue).getText();
    }

    //endregion

}

