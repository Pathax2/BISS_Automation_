
Feature: TC_S20 - Regression Pack for CISYF Late Penalty Display by Role on Payments Screen

  # ──────────────────────────────────────────────────────────────────────────
  # Purpose:
  #   Validates that BISS, CRISS and CISYF payment headers and sub-amounts
  #   (bissAmount, crissAmount, cisyfAmount) are visible on the Payments screen
  #   for each authorised BISS staff role (TC01-TC12), all roles combined
  #   with Total DPS Payment check (TC13), and all Reduction Type row headers (TC14).
  #
  # Common Background:
  #   No shared Background login as each TC block starts with agr0043 (SSO Admin)
  #   configuring roles for agr0191, then agr0191 (or agr0191 with all roles in TC13)
  #   verifies the Payments screen.
  #
  # DB Data:
  #   20 herds with payments resolved from Oracle DB at runtime.
  #   Each TC uses a different row from the pool to ensure independent data.
  #
  # Notes:
  #   1. The role assignment pattern per TC:
  #        a) Login as agr0043 → SSO Admin
  #        b) Strip all roles from agr0191
  #        c) Assign single target role
  #        d) Sign out → login as agr0191 → verify BISS/CRISS/CISYF headers
  #   2. TC13 assigns all major roles and additionally verifies the Total DPS Payment row.
  #   3. TC14 verifies all 13 Reduction Type row headers — no SSO Admin step needed.
  #   4. Reduction Type header types (1,2,3,4) correspond to distinct DOM element
  #      variants on the Payments page — handled internally by step definitions.
  #
  # Author  : Aniket Pathare | aniket.pathare@government.ie
  # Created : 2026-05-14
  # ──────────────────────────────────────────────────────────────────────────

  Background:
    Given the staff user is on the staff login page
    Then Get 20 Herds with Payments from DB

  @tmsLink=BISSAGL-14747 @tmsLink=BISSAGL-14746 @tmsLink=BISSAGL-14743 @tmsLink=BISSAGL-14742
  @tmsLink=BISSAGL-14741 @tmsLink=BISSAGL-14740 @tmsLink=BISSAGL-14739 @tmsLink=BISSAGL-14738
  @tmsLink=BISSAGL-14737 @tmsLink=BISSAGL-14736 @tmsLink=BISSAGL-14735 @tmsLink=BISSAGL-14734
  @tmsLink=BISSAGL-14733 @tmsLink=BISSAGL-14732 @regression
  Scenario: TC_S20 - CISYF Late Penalty by Role end-to-end regression

    # ── TC01: BISS Co-ordination 1 ────────────────────────────────────────────
    When "agr0043" strips all roles from "agr0191" and assigns role "BISS Co-ordination 1"
    Then "agr0191" opens herd with payments from row 1 for scheme year "2024" and the BISS, CRISS and CISYF payment headers with sub-amounts should be visible

    # ── TC02: BISS Co-ordination 2 ────────────────────────────────────────────
    When "agr0043" strips all roles from "agr0191" and assigns role "BISS Co-ordination 2"
    Then "agr0191" opens herd with payments from row 2 for scheme year "2024" and the BISS, CRISS and CISYF payment headers with sub-amounts should be visible

    # ── TC03: BISS Processing 1 ───────────────────────────────────────────────
    When "agr0043" strips all roles from "agr0191" and assigns role "BISS Processing 1"
    Then "agr0191" opens herd with payments from row 3 for scheme year "2023" and the BISS, CRISS and CISYF payment headers with sub-amounts should be visible

    # ── TC04: BISS Processing 2 ───────────────────────────────────────────────
    When "agr0043" strips all roles from "agr0191" and assigns role "BISS Processing 2"
    Then "agr0191" opens herd with payments from row 4 for scheme year "2024" and the BISS, CRISS and CISYF payment headers with sub-amounts should be visible

    # ── TC05: BISS Processing 3 ───────────────────────────────────────────────
    When "agr0043" strips all roles from "agr0191" and assigns role "BISS Processing 3"
    Then "agr0191" opens herd with payments from row 5 for scheme year "2024" and the BISS, CRISS and CISYF payment headers with sub-amounts should be visible

    # ── TC06: BISS Inspections 1 ──────────────────────────────────────────────
    When "agr0043" strips all roles from "agr0191" and assigns role "BISS Inspections 1"
    Then "agr0191" opens herd with payments from row 6 for scheme year "2024" and the BISS, CRISS and CISYF payment headers with sub-amounts should be visible

    # ── TC07: BISS Inspections 2 ──────────────────────────────────────────────
    When "agr0043" strips all roles from "agr0191" and assigns role "BISS Inspections 2"
    Then "agr0191" opens herd with payments from row 7 for scheme year "2023" and the BISS, CRISS and CISYF payment headers with sub-amounts should be visible

    # ── TC08: BISS Inspections 3 ──────────────────────────────────────────────
    When "agr0043" strips all roles from "agr0191" and assigns role "BISS Inspections 3"
    Then "agr0191" opens herd with payments from row 8 for scheme year "2024" and the BISS, CRISS and CISYF payment headers with sub-amounts should be visible

    # ── TC09: BISS EMS User ───────────────────────────────────────────────────
    When "agr0043" strips all roles from "agr0191" and assigns role "BISS EMS User"
    Then "agr0191" opens herd with payments from row 9 for scheme year "2024" and the BISS, CRISS and CISYF payment headers with sub-amounts should be visible

    # ── TC10: BISS Risk Management 1 User ────────────────────────────────────
    When "agr0043" strips all roles from "agr0191" and assigns role "BISS Risk Management 1 User"
    Then "agr0191" opens herd with payments from row 10 for scheme year "2024" and the BISS, CRISS and CISYF payment headers with sub-amounts should be visible

    # ── TC11: BISS Risk Management 2 User ────────────────────────────────────
    When "agr0043" strips all roles from "agr0191" and assigns role "BISS Risk Management 2 User"
    Then "agr0191" opens herd with payments from row 11 for scheme year "2024" and the BISS, CRISS and CISYF payment headers with sub-amounts should be visible

    # ── TC12: BISS Risk Management 2 User (regression path 12) ──────────────
    When "agr0043" strips all roles from "agr0191" and assigns role "BISS Risk Management 2 User"
    Then "agr0191" opens herd with payments from row 12 for scheme year "2024" and the BISS, CRISS and CISYF payment headers with sub-amounts should be visible

    # ── TC13: All roles — verify headers and Total DPS Payment row ────────────
    When "agr0043" strips all roles from "agr0191" and assigns all Co-ordination, Processing, Inspections, EMS and Risk roles
    Then "agr0191" opens herd with payments from row 7 for scheme year "2024" and the BISS, CRISS and CISYF headers with sub-amounts should be visible
    And the Total DPS Payment row should be present in the Payments summary table

    # ── TC14: All Reduction Type row headers present ──────────────────────────
    When "agr0191" opens herd with payments from row 7 for scheme year "2024" and navigates to Payments
    Then the Payments screen should have 2 Reduction Type column sections
    And the following Reduction Type row headers should all be visible on the Payments screen
      | Gross Claim | Overclaim | Overclaim Penalty | Gross Balance Held | Interim Payment |
      | Late Penalty | Non Declared Parcels | Between 60000-100000 | Amount Exceeding 100000 |
      | Financial Discipline | CISYF Inspection Penalty | Conditionality Penalty | Net Payment Amount |
