Feature: TC_08 - My Clients Table End-to-End Regression

  # --------------------------------------------------------------------------------------------------------------------
  # Purpose:
  #   Single end-to-end regression journey covering the My Clients page structure,
  #   sorting controls, pagination, Transfers sub-tab, and farmer dashboard verification.
  #  #
  #   Section 1 : My Clients column header verification — sortable vs non-sortable
  #   Section 2 : Dashboard name match after herd selection
  #   Section 3 : Transfers sub-tab — column headers + pagination
  #   Section 4 : Dashboard name, herd number, and greeting verification
  #
  # Migrated from: TC_08.feature (3 separate scenarios merged into 1 E2E)
  #   Sprint BISS_23.1.3 TC1  (BISSAGL-54)  → Sections 1 + 2
  #   Sprint BPS/BISS PI_22.4.6 TC1 (BISSAGL-827) → Section 3
  #   Sprint BISS_23.1.3 TC2  (BISSAGL-905) → Section 4
  #
  # Notes:
  #   1. Herd data is resolved from DB via Hooks.RUNTIME_HERD — no Excel row references.
  #   2. "GAEC 8" header is excluded — column removed from the UI.
  #   3. "Herd Expired" has no sort control by design.
  #
  # Author : Aniket Pathare | aniket.pathare@government.ie
  # Created: 01-04-2026
  # --------------------------------------------------------------------------------------------------------------------

  Background:
    Given the agent user is on the login page
    When the agent logs into the application with valid credentials and OTP
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    And the agent navigates to the "Home" and "My Clients" Left Menu Link

  @regression @e2e
  Scenario: AT-TC-08-E2E - Agent validates My Clients table structure, sorting, pagination and dashboard

    # ===========================================
    # SECTION 1 : My Clients column headers
    # Covers: BISSAGL-54 (Sprint BISS_23.1.3 TC1)
    # ===========================================
    Given the agent should land on the BISS Home page

    Then the following columns should have sorting enabled
      | Name        |
      | Herd Number |

    And the following columns should have sorting disabled
      | Farmer Status           |
      | Herd Expired            |
      | Eco Space for Nature    |
      | BISS Application Status |

    # ===========================================
    # SECTION 2 : Dashboard name match Dashboard name, herd and greeting
    # Covers: BISSAGL-54 (Sprint BISS_23.1.3 TC1 continued)
    # ===========================================
    When the agent opens a farmer dashboard using herd data
    Then the agent verifies the name on the dashboard matches the selected row
    Then the agent verifies the name and herd number on the dashboard
    And the agent verifies the personalised greeting message is displayed
    # ===========================================
    # SECTION 3 : Transfers sub-tab headers + pagination
    # Covers: BISSAGL-827 (Sprint BPS/BISS PI_22.4.6 TC1)
    # ===========================================
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    Given the agent should land on the BISS Home page
    When the agent switches to the "Transfers" tab on the My Clients page

    Then the following columns should have sorting enabled
      | Name     |
      | Address  |
      | Herd No. |

    And the following columns should have sorting disabled
      | Expired   |
      | Transfers |

    # --- Pagination ---
    And the agent changes the number of rows per page to "50"
    And the agent changes the number of rows per page to "20"
    Then the agent navigates to the last page using the pagination arrow