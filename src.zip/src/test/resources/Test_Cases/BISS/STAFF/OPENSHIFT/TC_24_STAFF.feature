Feature: TC_S24 - Regression Pack for iNet Preliminary Checks Agent Dashboard

  # ──────────────────────────────────────────────────────────────────────────
  # Purpose:
  #   Validates the Preliminary Checks (PC) agent dashboard page scenarios.
  #   Covers TC01-TC09 against herd P1751946 (2024):
  #     - TC01: BISS application loads after login
  #     - TC02: 10 herds loaded from DB for PC data
  #     - TC03: Responded tab count is accurate
  #     - TC04: Quick filter toggle shows correct results
  #     - TC05: No results state handled gracefully
  #     - TC06: Quick filters work correctly while searching
  #     - TC07: No duplicate PC entries are shown
  #     - TC08: BISS Applications label removed from PC page header
  #     - TC09: Clearing search data reloads the PC results
  #
  # Common Background:
  #   Staff login as agr4442 → open BISS application.
  #   herd P1751946 is used across all PC scenarios.
  #
  # DB Data:
  #   10 herds resolved from DB at runtime (TC02 step).
  #   No hardcoded herd numbers used in scenario steps.
  #
  # Notes:
  #   1. The AMS tab navigation in each TC block is a placeholder —
  #      full Preliminary Checks step definitions will replace these
  #      once the PC screen-specific steps are available.
  #   2. Each TC block navigates independently to the herd to simulate
  #      the separate legacy test flows.
  #
  # Author  : Aniket Pathare | aniket.pathare@government.ie
  # Created : 2026-05-14
  # ──────────────────────────────────────────────────────────────────────────

  Background:
    Given the staff user is on the staff login page
    When the staff user logs in with username "agr4442"
    And the staff user selects the data protection checkbox and clicks login
    And the staff user opens the "Basic Income Support for Sustainability" application

  @tmsLink=BISSAGL-14727 @tmsLink=BISSAGL-14603 @tmsLink=BISSAGL-14602 @tmsLink=BISSAGL-14600
  @tmsLink=BISSAGL-14601 @tmsLink=BISSAGL-14544 @tmsLink=BISSAGL-14545 @tmsLink=BISSAGL-14518
  @tmsLink=BISSAGL-14519 @regression
  Scenario: TC_S24 - iNet Prelim Checks Agent Dashboard end-to-end regression

    # ── TC01: BISS application home page loads after login ────────────────────
    Then the BISS application home page should be displayed and accessible

    # ── TC02: Resolve 10 herds from DB for Preliminary Checks data ────────────
    Then Get 10 Herds from DB

    # ── TC03: Responded tab count updates correctly ────────────────────────────
    When the staff user searches for herd "P1751946" for scheme year "2024" and navigates to the AMS Inspections tab
    Then the Responded tab count on the Preliminary Checks page should be accurate

    # ── TC04: Quick filter toggle displays matching results ───────────────────
    When the staff user searches for herd "P1751946" for scheme year "2024" and navigates to the AMS Inspections tab
    Then toggling between quick filters should display results matching the selected filter

    # ── TC05: No results state is handled gracefully ──────────────────────────
    When the staff user searches for herd "P1751946" for scheme year "2024" and navigates to the AMS Inspections tab
    Then a no-results state on the Preliminary Checks page should be handled without errors

    # ── TC06: Quick filters function correctly during search ──────────────────
    When the staff user searches for herd "P1751946" for scheme year "2024" and navigates to the AMS Inspections tab
    Then quick filters should continue working correctly while a search is active

    # ── TC07: No duplicate Preliminary Checks entries displayed ──────────────
    When the staff user searches for herd "P1751946" for scheme year "2024" and navigates to the AMS Inspections tab
    Then no duplicate Preliminary Checks entries should appear on the PC page

    # ── TC08: BISS Applications label not present on PC page ─────────────────
    When the staff user searches for herd "P1751946" for scheme year "2024" and navigates to the AMS Inspections tab
    Then the "BISS Applications" label should not be visible on the Preliminary Checks page

    # ── TC09: Clearing search data reloads PC results ─────────────────────────
    When the staff user searches for herd "P1751946" for scheme year "2024" and navigates to the AMS Inspections tab
    Then clearing the search field should reload the Preliminary Checks page with full results