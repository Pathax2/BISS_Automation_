package com.pages;

import com.base.ActionClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class BPSApplicationsPage {

    WebDriver driver;
    ActionClass actions;


    By BPSApplicationsSubmittedApplicationsTab = By.xpath("//a[contains(text(),'Submitted Applications')]");
    By BPSApplicationsDraftApplicationsTab = By.xpath("//a[contains(text(),'Draft Applications')]");
    By BPSApplicationsOutstandingApplicationsTab = By.xpath("//a[contains(text(),'Outstanding Applications')]");
    By BPSApplicationsPaidClientsTab = By.xpath("//a[contains(text(),'Paid Clients')]");
    By BPSApplicationsPrintPreviewButton = By.id("commonListPrintPreviewButton");
    By BPSApplicationsDownloadButton = By.xpath("//*[@id='clientInfoListProvider']/input[3]");
    By ClientRadioButton = By.id("optionsRadios1");
    By AgentViewClientButton = By.id("agentCommonListViewButton");
    By PaidClientsText = By.xpath("//td[contains(text(),'No Results Found')]");



    // Locators for future use

    public BPSApplicationsPage(WebDriver driver) {
        this.driver = driver;
        actions = new ActionClass(driver);
    }

    // Clicking on the Submitted Applications Tab
    public void AgentClickOnSubmittedApplicationsTab() {
        actions.waitForVisibilityOfElement(BPSApplicationsSubmittedApplicationsTab, 10);
        actions.click(BPSApplicationsSubmittedApplicationsTab);
    }

    // Clicking on the Draft Applications Tab
    public void AgentClickOnDraftApplicationsTab() {
        actions.waitForVisibilityOfElement(BPSApplicationsDraftApplicationsTab, 10);
        actions.click(BPSApplicationsDraftApplicationsTab);
    }

    // Clicking on the Outstanding Applications Tab
    public void AgentClickOnOutstandingApplicationsTab() {
        actions.waitForVisibilityOfElement(BPSApplicationsOutstandingApplicationsTab, 10);
        actions.click(BPSApplicationsOutstandingApplicationsTab);
    }

    // Clicking on the Paid Clients Tab
    public void AgentClickOnPaidClientsTab() {
        actions.waitForVisibilityOfElement(BPSApplicationsPaidClientsTab, 10);
        actions.click(BPSApplicationsPaidClientsTab);
    }

    // Clicking on the Print Preview Button
    public void AgentClickOnPrintPreviewButton() {
        actions.waitForVisibilityOfElement(BPSApplicationsPrintPreviewButton, 10);
        driver.findElement(BPSApplicationsPrintPreviewButton).click();
    }

    // Visibility of Print Preview Button
    public Boolean VisibilityOfPrintPreviewButton() {
        actions.waitForVisibilityOfElement(BPSApplicationsPrintPreviewButton, 10);
        Boolean PrintPreviewVisibility = driver.findElement(By.id("commonListPrintPreviewButton")).isDisplayed();
        return PrintPreviewVisibility;
    }

    // Clicking on the Download Button
    public void AgentClickOnDownloadButton() {
        actions.waitForVisibilityOfElement(BPSApplicationsDownloadButton, 10);
        driver.findElement(BPSApplicationsDownloadButton).click();
    }
    // Visibility of Download Button
    public Boolean VisibilityOfDownloadButton() {
        actions.waitForVisibilityOfElement(BPSApplicationsDownloadButton, 10);
        Boolean DownloadVisibility = driver.findElement(By.xpath("//*[@id='clientInfoListProvider']/input[3]")).isDisplayed();
        return DownloadVisibility;
    }

    // Clicking on the Client Radio button
    public void AgentClickOnBPSApplicationsClientRadioButton() {
        if(driver.findElements(ClientRadioButton).isEmpty()==false) {
            actions.waitForVisibilityOfElement(ClientRadioButton, 10);
            actions.click(ClientRadioButton);
        }
        else {
         System.out.println("There are no farmers displayed on this page");
        }
    }

    // Clicking on the View  button
    public void AgentClickOnBPSApplicationsViewButton() {
        if(driver.findElements(AgentViewClientButton).isEmpty()==false) {
            actions.waitForVisibilityOfElement(AgentViewClientButton, 10);
            actions.click(AgentViewClientButton);
        }
        else {
            System.out.println("No Farmers Displayed hence no View Button");
        }
    }

    // check if the No Clients Text Displayed
    public void CheckIfNoCLientsDisplayed() {
        actions.waitForVisibilityOfElement(PaidClientsText,15);
        String ExpectedText = "No Results Found";
        String NoClientsText = driver.findElement(By.xpath("//td[contains(text(),'No Results Found')]")).getText();
        //Boolean Checking = Assert.assertEquals(ExpectedText,NoClientsText);
        if (ExpectedText == NoClientsText)
        {
            System.out.println("No Clients Displayed");
        }
        else
        {
            System.out.println("Clients Present");
        }
    }
}

