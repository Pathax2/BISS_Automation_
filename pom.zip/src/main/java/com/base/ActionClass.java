package com.base;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.openqa.selenium.support.locators.RelativeLocator.with;

public class ActionClass {

    WebDriver driver;


    public ActionClass(WebDriver driver) {
        this.driver = driver;
    }

    public void waitForVisibilityOfWebElement(WebElement element, int timeinSec) {
        Wait wait = new FluentWait(driver).withTimeout(Duration.ofSeconds(timeinSec)).pollingEvery(Duration.ofSeconds(1))
                .ignoring(NoSuchElementException.class);
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated((By) element));
        } catch (Exception e) {
            throw e;
        }
    }


    public Boolean waitForVisibilityOfElement(By locator, int timeinSec) {
        Wait wait = new FluentWait(driver).withTimeout(Duration.ofSeconds(timeinSec)).pollingEvery(Duration.ofSeconds(3))
                .ignoring(NoSuchElementException.class);
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
        } catch (Exception e) {
            throw e;
        }
        return null;
    }

    public WebElement waitForVisibilityOfElement1(By Locator, int timeInSec){

       WebDriverWait wait=  new WebDriverWait(driver, Duration.ofSeconds(timeInSec));
        return wait.until(ExpectedConditions.visibilityOfElementLocated(Locator));
    }

    public void waitForVisibilityOfFrameAndSwitch(By locator, int timeinSec) {
        Wait wait = new FluentWait(driver).withTimeout(Duration.ofSeconds(timeinSec)).pollingEvery(Duration.ofSeconds(1))
                .ignoring(NoSuchElementException.class);
        try {
            wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(locator));
            String frameName = locator.toString();
            String[] frameNameArray = frameName.split(":");
            System.out.println("Switched to frame with id/name : " + frameNameArray[1]);
        } catch (Exception e) {
            throw e;
        }
    }

    public void waitforSeconds(long timeinSec) {
        try {
            Thread.sleep(1000*timeinSec);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void zoomScreenTo(String percentage){
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("document.body.style.zoom='"+percentage+"'");
    }

    public void click(By locator) {

        driver.findElement(locator).click();
    }

    public List<WebElement> findElemts(By locator) {

        return driver.findElements(locator);
    }

    private void highlightElement(WebElement element, JavascriptExecutor executor) {
        String originalStyle = element.getAttribute("style");
        // Apply highlight style (e.g., yellow background with red border)
        executor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);

        try {
            // Short pause so the human eye can actually see the highlight
            Thread.sleep(300);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        // Revert to original style
        executor.executeScript("arguments[0].setAttribute('style', '" + originalStyle + "');", element);
    }

    public void clickUsingJS(By loc){
        WebElement element = driver.findElement(loc);
        JavascriptExecutor executor = (JavascriptExecutor)driver;
        executor.executeScript("arguments[0].click();", element);
    }

    public void clickWebElementUsingJS(WebElement element) {
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        // Highlight the element
        highlightElement(element, executor);
        // Perform the click
        executor.executeScript("arguments[0].click();", element);
    }

    public void scrollByUsingJS(By loc) throws InterruptedException {
        WebElement element = driver.findElement(loc);
        JavascriptExecutor executor = (JavascriptExecutor)driver;
        executor.executeScript("arguments[0].scrollIntoView()", element);
        Thread.sleep(2000);
    }


    public void sendKeys(By locator,String arg0) {
        driver.findElement(locator).sendKeys(arg0);
    }

    public void clear(By locator) {

        driver.findElement(locator).clear();
    }

    // Map to avoid repetition of columns in each switch case of Clicking Action Buttons
    public Map<String, WebElement> PermanentColumns() {
        Map<String, WebElement> PermColumnMap = new HashMap<>();
        WebElement EligibleHectareColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-eligibleHectare')]"));
        WebElement ClaimedAreaColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-claimedArea')]"));
        WebElement OwnershipStatusColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-ownershipStatus')]"));
        PermColumnMap.put("OwnershipStatusColumn", OwnershipStatusColumn);
        PermColumnMap.put("ClaimedAreaColumn", ClaimedAreaColumn);
        PermColumnMap.put("EligibleHectareColumn", EligibleHectareColumn);
        return PermColumnMap;
    }


    public void ClickLandDetailsAction(int Rownumber,String ActionsColumnButton) {
        WebElement LandDetailsActionButton = driver.findElement(By.xpath("(//td/descendant::button[contains(@title,'"+ActionsColumnButton+"')])["+Rownumber+"]"));
        Object clickWebElementUsingJS;
        clickWebElementUsingJS(LandDetailsActionButton);
    }

    // Switch Case Logic Implementation depending on the combination of available columns
    // Locators : Open map, Subdivide parcel, Delete parcel
    public WebElement ClickActionsButton(String PlotNo, int ColumnCase, String ActionsColumnButton) {
        Map<String, WebElement> PermColumnMap = PermanentColumns();
        switch (ColumnCase) {
            case 0: {
                By PlotReference = By.xpath("//td[contains(text(),'" + PlotNo + "')]");
                WebElement PlotRef = driver.findElement(PlotReference);
                WebElement ParcelUseColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-parcelUse')]"));
                WebElement ActionsButtonColumn = driver.findElement(with(By.xpath("//td/descendant::button[@title='"+ActionsColumnButton+"']"))
                        .toRightOf(ParcelUseColumn)
                        .toRightOf(PermColumnMap.get("OwnershipStatusColumn"))
                        .toRightOf(PermColumnMap.get("ClaimedAreaColumn"))
                        .toRightOf(PermColumnMap.get("EligibleHectareColumn"))
                        .toRightOf(PlotRef));
                return ActionsButtonColumn;
            }
            case 1: {
                By PlotReference = By.xpath("//td[contains(text(),'" + PlotNo + "')]");
                WebElement PlotRef = driver.findElement(PlotReference);
                WebElement ParcelUseColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-parcelUse')]"));
                WebElement AncColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-anc')]"));
                WebElement ActionsButtonColumn = driver.findElement(with(By.xpath("//td/descendant::button[@aria-label='"+ActionsColumnButton+"']"))
                        .toRightOf(AncColumn)
                        .toRightOf(ParcelUseColumn)
                        .toRightOf(PermColumnMap.get("OwnershipStatusColumn"))
                        .toRightOf(PermColumnMap.get("ClaimedAreaColumn"))
                        .toRightOf(PermColumnMap.get("EligibleHectareColumn"))
                        .toRightOf(PlotRef));
                return ActionsButtonColumn;
            }
            case 2: {
                By PlotReference = By.xpath("//td[contains(text(),'" + PlotNo + "')]");
                WebElement PlotRef = driver.findElement(PlotReference);
                WebElement ParcelUseColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-parcelUse')]"));
                WebElement OrganicColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-organicStatus')]"));
                WebElement ActionsButtonColumn = driver.findElement(with(By.xpath("//td/descendant::button[@aria-label='"+ActionsColumnButton+"']"))
                        .toRightOf(OrganicColumn)
                        .toRightOf(ParcelUseColumn)
                        .toRightOf(PermColumnMap.get("OwnershipStatusColumn"))
                        .toRightOf(PermColumnMap.get("ClaimedAreaColumn"))
                        .toRightOf(PermColumnMap.get("EligibleHectareColumn"))
                        .toRightOf(PlotRef));
                return ActionsButtonColumn;
            }
            case 3: {
                By PlotReference = By.xpath("//td[contains(text(),'" + PlotNo + "')]");
                WebElement PlotRef = driver.findElement(PlotReference);
                WebElement ParcelUseColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-parcelUse')]"));
                WebElement OrganicColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-organicStatus')]"));
                WebElement AncColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-anc')]"));
                WebElement ActionsButtonColumn = driver.findElement(with(By.xpath("//td/descendant::button[@aria-label='"+ActionsColumnButton+"']"))
                        .toRightOf(AncColumn)
                        .toRightOf(OrganicColumn)
                        .toRightOf(ParcelUseColumn)
                        .toRightOf(PermColumnMap.get("OwnershipStatusColumn"))
                        .toRightOf(PermColumnMap.get("ClaimedAreaColumn"))
                        .toRightOf(PermColumnMap.get("EligibleHectareColumn"))
                        .toRightOf(PlotRef));
                return ActionsButtonColumn;
            }
            case 4: {
                By PlotReference = By.xpath("//td[contains(text(),'" + PlotNo + "')]");
                WebElement PlotRef = driver.findElement(PlotReference);
                WebElement ParcelUseColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-parcelUse')]"));
                WebElement AgriculturalActivityColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-maintenance')]"));
                WebElement ActionsButtonColumn = driver.findElement(with(By.xpath("//td/descendant::button[@aria-label='"+ActionsColumnButton+"']"))
                        .toRightOf(AgriculturalActivityColumn)
                        .toRightOf(ParcelUseColumn).toRightOf(PermColumnMap.get("OwnershipStatusColumn"))
                        .toRightOf(PermColumnMap.get("ClaimedAreaColumn"))
                        .toRightOf(PermColumnMap.get("EligibleHectareColumn"))
                        .toRightOf(PlotRef));
                return ActionsButtonColumn;
            }
            case 5: {
                By PlotReference = By.xpath("//td[contains(text(),'" + PlotNo + "')]");
                WebElement PlotRef = driver.findElement(PlotReference);
                WebElement ParcelUseColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-parcelUse')]"));
                WebElement AncColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-anc')]"));
                WebElement AgriculturalActivityColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-maintenance')]"));
                WebElement ActionsButtonColumn = driver.findElement(with(By.xpath("//td/descendant::button[@aria-label='"+ActionsColumnButton+"']"))
                        .toRightOf(AncColumn)
                        .toRightOf(AgriculturalActivityColumn)
                        .toRightOf(ParcelUseColumn)
                        .toRightOf(PermColumnMap.get("OwnershipStatusColumn"))
                        .toRightOf(PermColumnMap.get("ClaimedAreaColumn"))
                        .toRightOf(PermColumnMap.get("EligibleHectareColumn"))
                        .toRightOf(PlotRef));
                return ActionsButtonColumn;
            }
            case 6: {
                By PlotReference = By.xpath("//td[contains(text(),'" + PlotNo + "')]");
                WebElement PlotRef = driver.findElement(PlotReference);
                WebElement ParcelUseColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-parcelUse')]"));
                WebElement OrganicColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-organicStatus')]"));
                WebElement AgriculturalActivityColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-maintenance')]"));
                WebElement ActionsButtonColumn = driver.findElement(with(By.xpath("//td/descendant::button[@aria-label='"+ActionsColumnButton+"']"))
                        .toRightOf(OrganicColumn)
                        .toRightOf(AgriculturalActivityColumn)
                        .toRightOf(ParcelUseColumn)
                        .toRightOf(PlotRef));
                return ActionsButtonColumn;
            }
            case 7: {
                By PlotReference = By.xpath("//td[contains(text(),'" + PlotNo + "')]");
                WebElement PlotRef = driver.findElement(PlotReference);
                WebElement ParcelUseColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-parcelUse')]"));
                WebElement OrganicColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-organicStatus')]"));
                WebElement AncColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-anc')]"));
                WebElement AgriculturalActivityColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-maintenance')]"));
                WebElement ActionsButtonColumn = driver.findElement(with(By.xpath("//td/descendant::button[@aria-label='"+ActionsColumnButton+"']"))
                        .toRightOf(AncColumn)
                        .toRightOf(OrganicColumn)
                        .toRightOf(AgriculturalActivityColumn)
                        .toRightOf(ParcelUseColumn)
                        .toRightOf(PermColumnMap.get("OwnershipStatusColumn"))
                        .toRightOf(PermColumnMap.get("ClaimedAreaColumn"))
                        .toRightOf(PermColumnMap.get("EligibleHectareColumn"))
                        .toRightOf(PlotRef));
                return ActionsButtonColumn;
            }
            case 8: {
                By PlotReference = By.xpath("//td[contains(text(),'" + PlotNo + "')]");
                WebElement PlotRef = driver.findElement(PlotReference);
                WebElement CommonageFractionColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-commonageFraction')]"));
                WebElement ParcelUseColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-parcelUse')]"));
                WebElement ActionsButtonColumn = driver.findElement(with(By.xpath("//td/descendant::button[@aria-label='"+ActionsColumnButton+"']"))
                        .toRightOf(ParcelUseColumn)
                        .toRightOf(PermColumnMap.get("OwnershipStatusColumn"))
                        .toRightOf(PermColumnMap.get("ClaimedAreaColumn"))
                        .toRightOf(PermColumnMap.get("EligibleHectareColumn"))
                        .toRightOf(CommonageFractionColumn)
                        .toRightOf(PlotRef));
                return ActionsButtonColumn;
            }
            case 9: {
                By PlotReference = By.xpath("//td[contains(text(),'" + PlotNo + "')]");
                WebElement PlotRef = driver.findElement(PlotReference);
                WebElement CommonageFractionColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-commonageFraction')]"));
                WebElement ParcelUseColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-parcelUse')]"));
                WebElement AncColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-anc')]"));
                WebElement ActionsButtonColumn = driver.findElement(with(By.xpath("//td/descendant::button[@aria-label='"+ActionsColumnButton+"']"))
                        .toRightOf(AncColumn)
                        .toRightOf(ParcelUseColumn)
                        .toRightOf(PermColumnMap.get("OwnershipStatusColumn"))
                        .toRightOf(PermColumnMap.get("ClaimedAreaColumn"))
                        .toRightOf(PermColumnMap.get("EligibleHectareColumn"))
                        .toRightOf(CommonageFractionColumn)
                        .toRightOf(PlotRef));
                return ActionsButtonColumn;
            }
            case 10: {
                By PlotReference = By.xpath("//td[contains(text(),'" + PlotNo + "')]");
                WebElement PlotRef = driver.findElement(PlotReference);
                WebElement CommonageFractionColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-commonageFraction')]"));
                WebElement ParcelUseColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-parcelUse')]"));
                WebElement OrganicColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-organicStatus')]"));
                WebElement ActionsButtonColumn = driver.findElement(with(By.xpath("//td/descendant::button[@aria-label='"+ActionsColumnButton+"']"))
                        .toRightOf(OrganicColumn)
                        .toRightOf(ParcelUseColumn)
                        .toRightOf(PermColumnMap.get("OwnershipStatusColumn"))
                        .toRightOf(PermColumnMap.get("ClaimedAreaColumn"))
                        .toRightOf(PermColumnMap.get("EligibleHectareColumn"))
                        .toRightOf(CommonageFractionColumn)
                        .toRightOf(PlotRef));
                return ActionsButtonColumn;
            }
            case 11: {
                By PlotReference = By.xpath("//td[contains(text(),'" + PlotNo + "')]");
                WebElement PlotRef = driver.findElement(PlotReference);
                WebElement CommonageFractionColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-commonageFraction')]"));
                WebElement ParcelUseColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-parcelUse')]"));
                WebElement OrganicColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-organicStatus')]"));
                WebElement AncColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-anc')]"));
                WebElement ActionsButtonColumn = driver.findElement(with(By.xpath("//td/descendant::button[@aria-label='"+ActionsColumnButton+"']"))
                        .toRightOf(AncColumn)
                        .toRightOf(OrganicColumn)
                        .toRightOf(ParcelUseColumn)
                        .toRightOf(PermColumnMap.get("OwnershipStatusColumn"))
                        .toRightOf(PermColumnMap.get("ClaimedAreaColumn"))
                        .toRightOf(PermColumnMap.get("EligibleHectareColumn"))
                        .toRightOf(CommonageFractionColumn)
                        .toRightOf(PlotRef));
                return ActionsButtonColumn;
            }
            case 12: {
                By PlotReference = By.xpath("//td[contains(text(),'" + PlotNo + "')]");
                WebElement PlotRef = driver.findElement(PlotReference);
                WebElement CommonageFractionColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-commonageFraction')]"));
                WebElement ParcelUseColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-parcelUse')]"));
                WebElement AgriculturalActivityColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-maintenance')]"));
                WebElement ActionsButtonColumn = driver.findElement(with(By.xpath("//td/descendant::button[@aria-label='"+ActionsColumnButton+"']"))
                        .toRightOf(AgriculturalActivityColumn)
                        .toRightOf(ParcelUseColumn)
                        .toRightOf(PermColumnMap.get("OwnershipStatusColumn"))
                        .toRightOf(PermColumnMap.get("ClaimedAreaColumn"))
                        .toRightOf(PermColumnMap.get("EligibleHectareColumn"))
                        .toRightOf(CommonageFractionColumn)
                        .toRightOf(PlotRef));
                return ActionsButtonColumn;
            }
            case 13: {
                By PlotReference = By.xpath("//td[contains(text(),'"+PlotNo+"')]");
                WebElement PlotRef = driver.findElement(PlotReference);
                WebElement CommonageFractionColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-commonageFraction')]"));
                WebElement ParcelUseColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-parcelUse')]"));
                WebElement AncColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-anc')]"));
                WebElement AgriculturalActivityColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-maintenance')]"));
                WebElement ActionsButtonColumn = driver.findElement(with(By.xpath("//td/descendant::button[@aria-label='"+ActionsColumnButton+"']"))
                        .toRightOf(AncColumn)
                        .toRightOf(AgriculturalActivityColumn)
                        .toRightOf(ParcelUseColumn)
                        .toRightOf(PermColumnMap.get("OwnershipStatusColumn"))
                        .toRightOf(PermColumnMap.get("ClaimedAreaColumn"))
                        .toRightOf(PermColumnMap.get("EligibleHectareColumn"))
                        .toRightOf(CommonageFractionColumn)
                        .toRightOf(PlotRef));
                return ActionsButtonColumn;
            }
            case 14: {
                By PlotReference = By.xpath("//td[contains(text(),'"+PlotNo+"')]");
                WebElement PlotRef = driver.findElement(PlotReference);
                WebElement OwnershipStatusColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-ownershipStatus')]"));
                WebElement ParcelUseColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-parcelUse')]"));
                WebElement OrganicColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-organicStatus')]"));
                WebElement AgriculturalActivityColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-maintenance')]"));
                WebElement ActionsButtonColumn = driver.findElement(with(By.xpath("//td/descendant::button[@aria-label='"+ActionsColumnButton+"']"))
                        .toRightOf(OrganicColumn)
                        .toRightOf(AgriculturalActivityColumn)
                        .toRightOf(ParcelUseColumn)
                        .toRightOf(OwnershipStatusColumn)
                        .toRightOf(PermColumnMap.get("OwnershipStatusColumn"))
                        .toRightOf(PermColumnMap.get("ClaimedAreaColumn"))
                        .toRightOf(PermColumnMap.get("EligibleHectareColumn"))
                        .toRightOf(PlotRef));
                return ActionsButtonColumn;
            }
            case 15: {
                By PlotReference = By.xpath("//td[contains(text(),'" + PlotNo + "')]");
                WebElement PlotRef = driver.findElement(PlotReference);
                WebElement CommonageFractionColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-commonageFraction')]"));
                WebElement ParcelUseColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-parcelUse')]"));
                WebElement OrganicColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-organicStatus')]"));
                WebElement AncColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-anc')]"));
                WebElement AgriculturalActivityColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-maintenance')]"));
                WebElement ActionsButtonColumn = driver.findElement(with(By.xpath("//td/descendant::button[@aria-label='"+ActionsColumnButton+"']"))
                        .toRightOf(AncColumn)
                        .toRightOf(OrganicColumn)
                        .toRightOf(AgriculturalActivityColumn)
                        .toRightOf(ParcelUseColumn)
                        .toRightOf(PermColumnMap.get("OwnershipStatusColumn"))
                        .toRightOf(PermColumnMap.get("ClaimedAreaColumn"))
                        .toRightOf(PermColumnMap.get("EligibleHectareColumn"))
                        .toRightOf(CommonageFractionColumn)
                        .toRightOf(PlotRef));
                return ActionsButtonColumn;
            }
            default:
                return null;

        }
    }
    public boolean isElementPresent(WebDriver driver, By locator) {
        List<WebElement> elements = driver.findElements(locator);
        return !elements.isEmpty();
    }

}

