// ===================================================================================================================================
// File          : DashboardReport.java
// Package       : reporting
// Description   : The execution dashboard (Phase 1, 13-10-2026). Written once at the end of a run by TestRunner.
//
//                 Files written to Test_Report/html (folder of html.report.path), all with the same time stamp:
//                   BISS_Execution_Report_<ts>.html     team edition - tabs Overview, Data, Fragility, Test cases, with
//                                                       links to the Word reports and failure screenshots
//                   BISS_Stakeholder_Report_<ts>.html   stakeholder edition - same charts, herd numbers masked
//                                                       (D36...85), individual logins hidden, no screenshots / Word /
//                                                       trace links, no step logs
//                   BISS_Stakeholder_Report_<ts>.pdf    the stakeholder edition as a PDF (report.pdf.enabled)
//                   BISS_Execution_Report_<ts>.pdf      the team edition as a PDF (report.pdf.full, default off)
//                   BISS_Execution_Metrics_<ts>.json    everything ExecutionMetrics recorded, for other tools
//                   BISS_Herd_Ledger_<ts>.csv           the herd ledger, for Excel
//
//                 Light and dark theme: follows the Windows setting until the viewer presses the theme button; the
//                 choice is remembered in the browser. Printing (and the PDF) always uses the light theme and shows
//                 every tab one after the other.
//                 No external scripts, fonts or CDN - the page opens offline and from Jenkins.
//                 Farmer names are never in the report: ExecutionMetrics does not record them.
//                 One report for every module (14-10-2026): the title, the module line, the ledger roles and the charts
//                 follow what ran - a BISS-only run shows no ENTS cards (agent map, agent x agent, names refreshed),
//                 a mixed run adds "Results by module" and a module filter on the Test cases tab.
//
//                 Settings (application.properties):
//                   report.dashboard.enabled   true  - write the dashboard
//                   report.pdf.enabled         true  - stakeholder PDF
//                   report.pdf.full            false - team edition PDF as well
//                   report.legacy.html         false - also write the previous HtmlReportGenerator report
//
// Author        : Aniket Pathare | aniket.pathare@government.ie
// Date Created  : 13-10-2026
// ===================================================================================================================================

package reporting;

import reporting.ExecutionMetrics.DbCall;
import reporting.ExecutionMetrics.Failure;
import reporting.ExecutionMetrics.Flow;
import reporting.ExecutionMetrics.HerdRow;
import reporting.ExecutionMetrics.StepEvent;
import reporting.ExecutionMetrics.TestCaseInfo;
import reporting.ReportManager.StepResult;
import reporting.ReportManager.TestCaseResult;
import reporting.SvgCharts.Bar;
import reporting.SvgCharts.Stack;
import utilities.ConfigManager;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.logging.Logger;

public final class DashboardReport
{
    private static final Logger log = Logger.getLogger(DashboardReport.class.getName());

    enum Edition { TEAM, STAKEHOLDER }

    private DashboardReport() { }

    // ***************************************************************************************************************************************************************************************
    // Function Name : generateAll
    // Description   : Writes the team and stakeholder HTML, the PDFs, metrics.json and the herd ledger CSV.
    //                 Any part that fails is logged and skipped; the others are still written.
    // Returns       : String - path of the team edition HTML ("" when the dashboard is switched off)
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 13-10-2026
    // ***************************************************************************************************************************************************************************************
    public static String generateAll()
    {
        if (!ConfigManager.getBool("report.dashboard.enabled", true)) return "";

        String iStamp  = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
        Path   iDir    = Paths.get(System.getProperty("html.report.path", "Test_Report/html/BISS_Execution_Report.html")).toAbsolutePath().getParent();
        Path   iTeam   = iDir.resolve("BISS_Execution_Report_" + iStamp + ".html");
        Path   iStake  = iDir.resolve("BISS_Stakeholder_Report_" + iStamp + ".html");

        try
        {
            Files.createDirectories(iDir);
            write(iTeam,  build(Edition.TEAM, iDir, iStamp));
            write(iStake, build(Edition.STAKEHOLDER, iDir, iStamp));
            log.info("[DashboardReport] Team report        : " + iTeam);
            log.info("[DashboardReport] Stakeholder report : " + iStake);
        }
        catch (Exception e)
        {
            log.severe("[DashboardReport] HTML report failed : " + e.getMessage());
            return "";
        }

        try { write(iDir.resolve("BISS_Execution_Metrics_" + iStamp + ".json"), MetricsJson.build()); }
        catch (Exception e) { log.warning("[DashboardReport] metrics.json failed : " + e.getMessage()); }

        try { write(iDir.resolve("BISS_Herd_Ledger_" + iStamp + ".csv"), ledgerCsv()); }
        catch (Exception e) { log.warning("[DashboardReport] herd ledger CSV failed : " + e.getMessage()); }

        if (ConfigManager.getBool("report.pdf.enabled", true))
        {
            PdfExporter.export(iStake, iDir.resolve("BISS_Stakeholder_Report_" + iStamp + ".pdf"));
        }
        if (ConfigManager.getBool("report.pdf.full", false))
        {
            PdfExporter.export(iTeam, iDir.resolve("BISS_Execution_Report_" + iStamp + ".pdf"));
        }
        return iTeam.toString();
    }


    // ===============================================================================================================================
    //  PAGE
    // ===============================================================================================================================

    static String build(Edition pEdition, Path pDir, String pStamp)
    {
        boolean iTeam = pEdition == Edition.TEAM;
        Model   m     = new Model(pEdition, pDir);

        StringBuilder h = new StringBuilder(120_000);
        h.append("<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n")
         .append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n")
         .append("<title>").append(iTeam ? "BISS Execution Report" : "BISS Execution Summary").append("</title>\n")
         .append("<script>").append(ReportAssets.THEME_BOOT).append("</script>\n")
         .append("<style>").append(ReportAssets.CSS).append("</style>\n</head>\n<body>\n<div class=\"wrap\">\n");

        // ---- Header ----
        h.append("<header class=\"top\"><div><h1>").append(esc(m.title())).append(" &#8212; ").append(iTeam ? "Execution Report" : "Execution Summary").append("</h1>")
         .append("<div class=\"sub\">").append(esc(m.runLine())).append("</div></div>")
         .append("<div class=\"actions\">")
         .append(iTeam ? "" : "<span class=\"badge\">STAKEHOLDER EDITION &#183; HERDS MASKED</span>")
         .append("<button type=\"button\" class=\"btn\" id=\"themeBtn\" onclick=\"toggleTheme()\">Dark theme</button>")
         .append("<button type=\"button\" class=\"btn\" onclick=\"printReport()\">Print / Save as PDF</button>")
         .append("</div></header>\n");

        // ---- Tabs ----
        h.append("<nav class=\"tabs\" role=\"tablist\">");
        String[][] iTabs = {{"overview", "Overview"}, {"data", "Data"}, {"fragility", "Fragility"}, {"cases", "Test cases"}};
        for (int i = 0; i < iTabs.length; i++)
        {
            h.append("<button type=\"button\" role=\"tab\" class=\"tab").append(i == 0 ? " on" : "").append("\" data-tab=\"").append(iTabs[i][0])
             .append("\" onclick=\"showTab('").append(iTabs[i][0]).append("')\">").append(iTabs[i][1]).append("</button>");
        }
        h.append("</nav>\n");

        h.append(overview(m));
        h.append(dataTab(m));
        h.append(fragilityTab(m));
        h.append(casesTab(m));

        h.append("<footer class=\"foot\">Generated by the BISS automation framework (Playwright) at ").append(esc(m.endTime()))
         .append(" &#183; no external scripts &#183; ").append(iTeam ? "metrics JSON and herd ledger CSV saved beside this report" : "stakeholder edition: herd numbers masked, no evidence files")
         .append("</footer>\n</div>\n<script>").append(ReportAssets.JS).append("</script>\n</body>\n</html>\n");
        return h.toString();
    }


    // ===============================================================================================================================
    //  OVERVIEW TAB
    // ===============================================================================================================================

    private static String overview(Model m)
    {
        StringBuilder h = new StringBuilder();
        h.append("<section class=\"panel on\" id=\"tab-overview\" data-title=\"Overview\">\n");

        int iSelfHeals = m.selfHeals();
        h.append(kpis(new String[][]{
                {"Test cases", String.valueOf(m.results.size()), m.passed() + " passed &#183; " + m.failed() + " failed"},
                {"Pass rate", m.passRate(), m.results.isEmpty() ? "no test case ran" : "of " + m.results.size() + " test case(s)"},
                {"Steps run", String.valueOf(m.gherkinSteps()), m.gherkinPassed() + " passed &#183; " + m.gherkinSkipped() + " skipped"},
                {"Duration", esc(ReportManager.getSuiteDurationFormatted()), esc(m.slowestTestCase())},
                {"Herds used", String.valueOf(m.herdsUsed()), m.herdsConsumed() + " consumed &#183; " + m.loginsUsed() + " login(s) &#183; " + m.herdsBad() + " BAD"},
                {"Self-heals", String.valueOf(iSelfHeals), "JS clicks, replaced herds, refreshed names"}}, 6));

        // Row 1: time per test case | why tests failed | self-healing
        h.append("<div class=\"row r3\">");
        h.append(card("Where the time goes", "Seconds per test case: setup (DB, browser, data), scenarios, teardown (reports, trace, close)",
                SvgCharts.stackedHbars(m.timeRows(), new String[]{"Setup", "Scenarios", "Teardown"}, new String[]{"s1", "s2", "s3"}, 130, 620)));
        h.append(card("Why tests failed", "Every failed step, sorted by fixed rules (no AI)",
                SvgCharts.hbars(m.causeBars(), "s2", 200, 560)));
        h.append(card("Self-healing this run", "What the framework rescued without failing", m.selfHealTiles()));
        h.append("</div>\n");

        // Row 2: ledger excerpt | scenario stages (the screens of the application journey, slowest first)
        h.append("<div class=\"row r2w\">");
        h.append(card("Test data ledger", "Latest herds handed out - all of them are on the Data tab",
                ledgerTable(m, m.herds.size() > 8 ? m.herds.subList(m.herds.size() - 8, m.herds.size()) : m.herds, false)
                        + "<p class=\"foot\">Showing " + Math.min(8, m.herds.size()) + " of " + m.herds.size() + " row(s)</p>"));
        h.append(card("Slowest scenarios", "Average time per scenario (the stages of the journey), across every test case that ran it",
                SvgCharts.hbars(m.scenarioBars(8), "s3", 250, 620)));
        h.append("</div>\n");

        // Row 2b: results by module (when more than one ran) | agent map (only when ENTS transfers were submitted)
        boolean iModules = m.modules().size() > 1;
        boolean iFlows   = !m.flows.isEmpty();
        if (iModules || iFlows)
        {
            h.append("<div class=\"row r2\">");
            if (iModules) h.append(card("Results by module", "Test cases per application: BISS (agent, individual, partnership), ENTS, STAFF, DATA", m.moduleColumns()));
            if (iFlows)   h.append(card("Agent map - who transferred to whom", "ENTS: ribbon thickness = transfers submitted in this run (" + m.flows.size() + " in total)", m.flowMap()));
            else          h.append(card("Time per module", "Minutes spent in each application, setup and teardown included", SvgCharts.hbars(m.moduleTimeBars(), "s1", 90, 620)));
            h.append("</div>\n");
        }

        // Row 3: fragile locators | slowest DB queries
        h.append("<div class=\"row r2\">");
        h.append(card("Most fragile locators", "Actions that needed the JavaScript-click fallback or failed, by locator",
                SvgCharts.hbars(m.fragileBars(5), "s1", 230, 620)));
        h.append(card("Slowest database queries", "Longest single run per DBRouter label",
                SvgCharts.hbars(m.dbBars(6), "s1", 240, 620)));
        h.append("</div>\n</section>\n");
        return h.toString();
    }


    // ===============================================================================================================================
    //  DATA TAB
    // ===============================================================================================================================

    private static String dataTab(Model m)
    {
        StringBuilder h = new StringBuilder();
        h.append("<section class=\"panel\" id=\"tab-data\" data-title=\"Data\">\n");

        // Filters (the table rows carry data-tc / data-outcome / data-text)
        Set<String> iTcs = new LinkedHashSet<>();
        for (HerdRow r : m.herds) iTcs.add(r.testCase);
        h.append("<div class=\"filters noprint\"><input type=\"search\" id=\"ledgerSearch\" placeholder=\"Search herd, login, pool...\" oninput=\"filterLedger()\">")
         .append("<select id=\"ledgerTc\" onchange=\"filterLedger()\"><option value=\"\">All test cases</option>");
        for (String t : iTcs) h.append("<option>").append(esc(t)).append("</option>");
        h.append("</select><select id=\"ledgerOutcome\" onchange=\"filterLedger()\"><option value=\"\">All outcomes</option>");
        for (String o : new String[]{"USED", "REPLACED", "BAD", "RESERVED", "PICKED", "RELEASED"}) h.append("<option>").append(o).append("</option>");
        h.append("</select><span class=\"count\" id=\"ledgerCount\"></span></div>\n");

        h.append(kpis(new String[][]{
                {"Herds handed out", String.valueOf(m.herds.size()), esc(m.roleBreakdown())},
                {"Used", String.valueOf(m.countOutcome("USED")), "application or transfer went through"},
                {"Replaced", String.valueOf(m.countOutcome("REPLACED")), "dropped and another herd picked"},
                {"Marked BAD", String.valueOf(m.countOutcome("BAD")), "kept out of future runs"},
                m.hasModule("ENTS")
                        ? new String[]{"Names refreshed", String.valueOf(ExecutionMetrics.counter(ExecutionMetrics.NAMES_REFRESHED)), "ENTS: stored name differed from the DB"}
                        : new String[]{"Logins used", String.valueOf(m.loginsUsed()), "distinct agent / individual logins"}}, 5));

        h.append("<div class=\"row r1\">").append(card("Herd ledger", "One row per herd handed out, in the order it happened"
                + (m.team() ? ". Farmer names are never recorded." : ". Stakeholder edition: herd numbers masked, individual logins hidden."),
                ledgerTable(m, m.herds, true))).append("</div>\n");

        h.append("<div class=\"row r2\">");
        if (m.flows.isEmpty())
        {
            h.append(card("Herds per test case", "How many herds each test case needed (replacements and retries included)",
                    SvgCharts.hbars(m.herdsPerTestCase(), "s1", 130, 620)));
        }
        else
        {
            h.append(card("Agent &#215; agent", "ENTS transfers submitted - created by (rows) and accepted by (columns)", m.matrix()));
        }
        List<String> iRoles = m.roles();
        h.append(card("Herds per pool", "This run, by role", SvgCharts.stackedHbars(m.poolRows(iRoles), m.roleNames(iRoles), m.roleClasses(iRoles), 190, 620)));
        h.append("</div>\n</section>\n");
        return h.toString();
    }

    private static String ledgerTable(Model m, List<HerdRow> pRows, boolean pFilterable)
    {
        if (pRows.isEmpty()) return "<p class=\"empty\">No herd was handed out in this run (BISS herds from the sheet and pinned herds are not listed).</p>";
        StringBuilder h = new StringBuilder("<div class=\"scroll\"><table class=\"tbl\"").append(pFilterable ? " id=\"ledger\"" : "").append(">")
                .append("<thead><tr><th>Time</th><th>Test case</th><th>Section</th><th>Role</th><th>Herd</th><th>Agent / login</th><th>Pool</th>")
                .append("<th class=\"r\">Try</th><th>Outcome</th><th>Note</th></tr></thead><tbody>");
        for (HerdRow r : pRows)
        {
            String iHerd  = m.herd(r.herd);
            String iLogin = m.login(r.login);
            h.append("<tr data-tc=\"").append(esc(r.testCase)).append("\" data-outcome=\"").append(esc(r.outcome)).append("\" data-text=\"")
             .append(esc((iHerd + " " + iLogin + " " + m.pool(r.pool) + " " + r.purpose + " " + (m.team() ? r.note : maskText(r.note))).toLowerCase(Locale.ROOT))).append("\">")
             .append("<td class=\"mono\">").append(esc(r.time)).append("</td><td>").append(esc(r.testCase)).append("</td><td>").append(esc(r.purpose))
             .append("</td><td>").append(esc(r.role)).append("</td><td class=\"mono\">").append(esc(iHerd)).append("</td><td class=\"mono\">").append(esc(iLogin))
             .append("</td><td class=\"muted\">").append(esc(m.pool(r.pool))).append("</td><td class=\"r num\">").append(r.tryNo)
             .append("</td><td>").append(outcome(r.outcome)).append("</td><td class=\"muted\">").append(esc(m.team() ? r.note : maskText(r.note))).append("</td></tr>");
        }
        return h.append("</tbody></table></div>").toString();
    }

    private static String outcome(String pOutcome)
    {
        switch (pOutcome)
        {
            case "USED":     return "<span class=\"st good\">&#10003; USED</span>";
            case "BAD":      return "<span class=\"st crit\">&#10007; BAD</span>";
            case "REPLACED": return "<span class=\"st warn\">&#8635; REPLACED</span>";
            case "RESERVED": return "<span class=\"st warn\">&#9711; RESERVED</span>";
            case "RELEASED": return "<span class=\"st\">&#8617; RELEASED</span>";
            default:         return "<span class=\"st\">&#8226; " + esc(pOutcome) + "</span>";
        }
    }


    // ===============================================================================================================================
    //  FRAGILITY TAB
    // ===============================================================================================================================

    private static String fragilityTab(Model m)
    {
        StringBuilder h = new StringBuilder();
        h.append("<section class=\"panel\" id=\"tab-fragility\" data-title=\"Fragility\">\n");
        h.append(kpis(new String[][]{
                {"JS-click fallbacks", String.valueOf(ExecutionMetrics.counter(ExecutionMetrics.JS_FALLBACKS)), "normal click failed, JavaScript click used"},
                {"Failed steps", String.valueOf(m.failures.size()), m.failedTestCases() + " test case(s) affected"},
                {"Timeouts", String.valueOf(m.timeouts()), "actions that waited too long"},
                {"Handled actions", String.valueOf(ExecutionMetrics.counter(ExecutionMetrics.HANDLED_ACTIONS)), "optional element not there - by design"},
                {"Fragile locators", String.valueOf(m.fragileCount()), "fallback or failure in 20% or more of uses"}}, 5));

        h.append("<div class=\"row r1\">").append(card("Locator fragility", "Ranked by fallbacks + failures. The likely fix comes from the shape of the XPath.",
                m.locatorTable())).append("</div>\n");

        h.append("<div class=\"row r2\">");
        h.append(card("Failures this run", "Each failed step, the rule that classified it and the evidence", m.failureTable()));
        h.append(card("Failure causes per test case", "Which kind of problem stopped each test case", m.causeColumns()));
        h.append("</div>\n</section>\n");
        return h.toString();
    }


    // ===============================================================================================================================
    //  TEST CASES TAB
    // ===============================================================================================================================

    private static String casesTab(Model m)
    {
        StringBuilder h = new StringBuilder();
        h.append("<section class=\"panel\" id=\"tab-cases\" data-title=\"Test cases\">\n");
        h.append("<div class=\"filters noprint\"><input type=\"search\" id=\"caseSearch\" placeholder=\"Search test case or description...\" oninput=\"filterCases()\">")
         .append("<select id=\"caseStatus\" onchange=\"filterCases()\"><option value=\"\">All results</option><option>PASS</option><option>FAIL</option><option>ERROR</option></select>");
        if (m.modules().size() > 1)
        {
            h.append("<select id=\"caseModule\" onchange=\"filterCases()\"><option value=\"\">All modules</option>");
            for (String mod : m.modules().keySet()) h.append("<option>").append(esc(mod)).append("</option>");
            h.append("</select>");
        }
        h.append("</div>\n");

        h.append("<div class=\"cases\">");
        int i = 0;
        for (TestCaseResult r : m.results)
        {
            i++;
            TestCaseInfo info = ExecutionMetrics.testCase(r.iTestCaseID);
            String iStatus = r.iStatus == null ? "" : r.iStatus;
            String iModule = ExecutionMetrics.moduleOf(r.iTestCaseID);
            h.append("<details class=\"case ").append(iStatus.toLowerCase(Locale.ROOT)).append("\" data-status=\"").append(esc(iStatus))
             .append("\" data-module=\"").append(esc(iModule))
             .append("\" data-text=\"").append(esc((r.iTestCaseID + " " + r.iDescription + " " + iModule).toLowerCase(Locale.ROOT))).append("\">")
             .append("<summary><span class=\"idx\">").append(i).append("</span><span class=\"mod\">").append(esc(iModule)).append("</span><span class=\"tcid mono\">").append(esc(r.iTestCaseID)).append("</span>")
             .append("<span class=\"desc\">").append(esc(r.iDescription)).append("</span>")
             .append("<span class=\"meta\">").append(r.iSteps.size()).append(" steps &#183; ").append(esc(r.getDurationFormatted())).append("</span>")
             .append(statusBadge(iStatus)).append("</summary><div class=\"casebody\">");

            // Evidence
            if (m.team())
            {
                StringBuilder ev = new StringBuilder();
                if (!info.wordDoc.isEmpty())    ev.append("<a class=\"ev\" href=\"").append(esc(m.href(info.wordDoc))).append("\">&#128196; Word report</a>");
                String iShot = !info.screenshot.isEmpty() ? info.screenshot : r.iScreenshotPath;
                if (iShot != null && !iShot.isEmpty())
                {
                    ev.append("<a class=\"ev\" href=\"").append(esc(m.href(iShot))).append("\" target=\"_blank\">&#128247; Failure screenshot</a>");
                }
                if (!info.trace.isEmpty())
                {
                    ev.append("<span class=\"ev muted\" title=\"Traces hold typed passwords and cookies - kept on this machine only\">&#128274; Trace (local only): ")
                      .append(esc(Paths.get(info.trace).getFileName().toString())).append("</span>");
                }
                if (ev.length() > 0) h.append("<div class=\"evrow\">").append(ev).append("</div>");
                if (iShot != null && !iShot.isEmpty())
                {
                    h.append("<a href=\"").append(esc(m.href(iShot))).append("\" target=\"_blank\"><img class=\"thumb\" loading=\"lazy\" alt=\"Failure screenshot of ")
                     .append(esc(r.iTestCaseID)).append("\" src=\"").append(esc(m.href(iShot))).append("\"></a>");
                }
            }

            // Failure reason (without the trace path, which the old report appended)
            String iError = r.iErrorMessage == null ? "" : r.iErrorMessage.replaceAll("\\s*\\|?\\s*Trace: .*$", "");
            if (!iError.isEmpty())
            {
                h.append("<div class=\"err\"><b>Failure</b><pre>").append(esc(m.team() ? iError : maskText(iError))).append("</pre></div>");
            }

            if (m.team() && !r.iSteps.isEmpty())
            {
                h.append(stepsTable(r.iSteps));
            }
            h.append("</div></details>");
        }
        if (m.results.isEmpty()) h.append("<p class=\"empty\">No test case ran.</p>");
        h.append("</div>\n</section>\n");
        return h.toString();
    }

    private static String stepsTable(List<StepResult> pSteps)
    {
        StringBuilder h = new StringBuilder("<table class=\"tbl steps\"><thead><tr><th class=\"r\">#</th><th>Step</th><th class=\"r\">Time</th><th>Result</th></tr></thead><tbody>");
        String iScenario = null;
        int n = 0;
        for (StepResult s : pSteps)
        {
            if (!s.iScenario.isEmpty() && !s.iScenario.equals(iScenario))
            {
                iScenario = s.iScenario;
                h.append("<tr class=\"scen\"><td colspan=\"4\">Scenario: ").append(esc(iScenario)).append("</td></tr>");
            }
            n++;
            h.append("<tr class=\"").append(s.isFailed() ? "failrow" : "").append("\"><td class=\"r num\">").append(n).append("</td><td><b class=\"kw\">")
             .append(esc(s.iStepKeyword)).append("</b> ").append(esc(s.iStepText));
            if (!s.iErrorMessage.isEmpty()) h.append("<div class=\"steperr\">").append(esc(ExecutionMetrics.shorten(ExecutionMetrics.oneLine(s.iErrorMessage), 400))).append("</div>");
            h.append("</td><td class=\"r num\">").append(esc(s.getDurationFormatted())).append("</td><td>").append(statusBadge(s.iStatus)).append("</td></tr>");
        }
        return h.append("</tbody></table>").toString();
    }

    private static String statusBadge(String pStatus)
    {
        String s = pStatus == null ? "" : pStatus.toUpperCase(Locale.ROOT);
        switch (s)
        {
            case "PASS": return "<span class=\"pill good\">&#10003; PASS</span>";
            case "FAIL": return "<span class=\"pill crit\">&#10007; FAIL</span>";
            case "SKIP": return "<span class=\"pill\">&#8212; SKIP</span>";
            default:     return "<span class=\"pill warn\">&#9888; " + esc(s) + "</span>";
        }
    }


    // ===============================================================================================================================
    //  SMALL HTML HELPERS
    // ===============================================================================================================================

    private static String kpis(String[][] pItems, int pColumns)
    {
        StringBuilder h = new StringBuilder("<div class=\"kpis k").append(pColumns).append("\">");
        for (String[] k : pItems)
        {
            h.append("<div class=\"kpi\"><div class=\"k\">").append(k[0]).append("</div><div class=\"v\">").append(k[1])
             .append("</div><div class=\"d\">").append(k[2]).append("</div></div>");
        }
        return h.append("</div>\n").toString();
    }

    private static String card(String pTitle, String pHint, String pBody)
    {
        return "<div class=\"card\"><h3>" + pTitle + "</h3><p class=\"hint\">" + esc(pHint) + "</p>" + pBody + "</div>";
    }

    static String esc(String pText)
    {
        return SvgCharts.esc(pText);
    }

    // D3610485 -> D36...85 (stakeholder edition)
    static String maskHerd(String pHerd)
    {
        String h = pHerd == null ? "" : pHerd.trim();
        if (h.length() < 6) return h.isEmpty() ? "" : "•••";
        return h.substring(0, 3) + "•••" + h.substring(h.length() - 2);
    }

    // Masks every herd-number-looking word in a free text (stakeholder edition)
    static String maskText(String pText)
    {
        if (pText == null) return "";
        java.util.regex.Matcher mm = java.util.regex.Pattern.compile("\\b[A-Z]\\d{6}[0-9X]\\b").matcher(pText);
        StringBuffer sb = new StringBuffer();
        while (mm.find()) mm.appendReplacement(sb, java.util.regex.Matcher.quoteReplacement(maskHerd(mm.group())));
        mm.appendTail(sb);
        return sb.toString();
    }

    private static String ledgerCsv()
    {
        StringBuilder c = new StringBuilder("Time,TestCase,Section,Role,Herd,Login,Pool,Try,Outcome,Note\r\n");
        for (HerdRow r : ExecutionMetrics.herds())
        {
            c.append(csv(r.time)).append(',').append(csv(r.testCase)).append(',').append(csv(r.purpose)).append(',').append(csv(r.role)).append(',')
             .append(csv(r.herd)).append(',').append(csv(r.login)).append(',').append(csv(r.pool)).append(',').append(r.tryNo).append(',')
             .append(csv(r.outcome)).append(',').append(csv(r.note)).append("\r\n");
        }
        return c.toString();
    }

    private static String csv(String pValue)
    {
        String v = pValue == null ? "" : pValue;
        // a leading = + - @ would run as a formula in Excel
        if (!v.isEmpty() && "=+-@".indexOf(v.charAt(0)) >= 0) v = "'" + v;
        return "\"" + v.replace("\"", "\"\"") + "\"";
    }

    private static void write(Path pPath, String pText) throws IOException
    {
        Files.write(pPath, pText.getBytes(StandardCharsets.UTF_8));
    }


    // ===============================================================================================================================
    //  MODEL - everything the page needs, worked out once
    // ===============================================================================================================================

    static final class Model
    {
        final Edition              edition;
        final Path                 dir;
        final List<TestCaseResult> results  = ReportManager.getResults();
        final List<HerdRow>        herds    = ExecutionMetrics.herds();
        final List<Flow>           flows    = ExecutionMetrics.flows();
        final List<StepEvent>      steps    = ExecutionMetrics.steps();
        final List<Failure>        failures = ExecutionMetrics.failures();
        final List<DbCall>         db       = ExecutionMetrics.dbCalls();

        Model(Edition pEdition, Path pDir)
        {
            edition = pEdition;
            dir     = pDir;
        }

        boolean team() { return edition == Edition.TEAM; }

        String herd(String pHerd)   { return team() ? pHerd : maskHerd(pHerd); }

        // Agent logins (aga..., agr...) are test accounts; any other login belongs to a farmer
        String login(String pLogin)
        {
            if (team() || pLogin == null || pLogin.isEmpty()) return pLogin == null ? "" : pLogin;
            return pLogin.toLowerCase(Locale.ROOT).matches("ag[ar]\\d+") ? pLogin : "individual";
        }

        // Vault pool "POOL/key": the key is often a login, so the stakeholder edition masks it like a login
        String pool(String pPool)
        {
            if (pPool == null || pPool.isEmpty()) return "-";
            if (team()) return pPool;
            int iSlash = pPool.indexOf('/');
            return iSlash < 0 ? maskText(pPool) : pPool.substring(0, iSlash) + "/" + login(pPool.substring(iSlash + 1));
        }

        // Link from the report folder to an evidence file (relative, so it also works from Jenkins)
        String href(String pFile)
        {
            try
            {
                Path p = Paths.get(pFile).toAbsolutePath().normalize();
                String rel = dir.normalize().relativize(p).toString().replace('\\', '/');
                return rel.replace(" ", "%20").replace("#", "%23");
            }
            catch (Exception e)
            {
                return Paths.get(pFile).toAbsolutePath().toUri().toString();
            }
        }

        // Test cases per module, always in the order BISS, ENTS, STAFF, DATA
        Map<String, Integer> modules()
        {
            Map<String, Integer> counts = new LinkedHashMap<>();
            for (TestCaseResult r : results) counts.merge(ExecutionMetrics.moduleOf(r.iTestCaseID), 1, Integer::sum);
            Map<String, Integer> mods = new LinkedHashMap<>();
            for (String mod : new String[]{"BISS", "ENTS", "STAFF", "DATA"}) if (counts.containsKey(mod)) mods.put(mod, counts.get(mod));
            for (Map.Entry<String, Integer> e : counts.entrySet()) mods.putIfAbsent(e.getKey(), e.getValue());
            return mods;
        }

        boolean hasModule(String pModule) { return modules().containsKey(pModule); }

        // "BISS Automation" for a BISS-only run, "BISS / ENTS Automation" for a mixed one ...
        String title()
        {
            List<String> names = new ArrayList<>();
            for (String mod : modules().keySet()) if (!"DATA".equals(mod)) names.add(mod);
            if (names.isEmpty()) names.add("BISS");
            return String.join(" / ", names) + " Automation";
        }

        String moduleLine()
        {
            StringBuilder b = new StringBuilder();
            for (Map.Entry<String, Integer> e : modules().entrySet()) b.append(b.length() == 0 ? "" : ", ").append(e.getKey()).append(' ').append(e.getValue());
            return b.toString();
        }

        String runLine()
        {
            return "Run " + ReportManager.getSuiteStartTime() + " to " + ReportManager.getSuiteEndTime()
                    + (modules().isEmpty() ? "" : "  |  Modules: " + moduleLine())
                    + "  |  " + (ReportManager.getEnvironment().isEmpty() ? "Environment per test case" : ReportManager.getEnvironment())
                    + "  |  " + ReportManager.getBrowser()
                    + "  |  Build " + ReportManager.getBuildNumber()
                    + (team() ? "  |  " + ReportManager.getExecutedBy() : "");
        }

        String endTime() { return ReportManager.getSuiteEndTime(); }

        int passed()  { int n = 0; for (TestCaseResult r : results) if (r.isPassed()) n++; return n; }
        int failed()  { return results.size() - passed(); }

        String passRate()
        {
            return results.isEmpty() ? "-" : Math.round(100.0 * passed() / results.size()) + "%";
        }

        int gherkinSteps()   { int n = 0; for (TestCaseResult r : results) n += r.iSteps.size(); return n; }
        int gherkinPassed()  { int n = 0; for (TestCaseResult r : results) n += r.getStepPassCount(); return n; }
        int gherkinSkipped() { int n = 0; for (TestCaseResult r : results) n += r.getStepSkipCount(); return n; }

        String slowestTestCase()
        {
            TestCaseResult iMax = null;
            for (TestCaseResult r : results) if (iMax == null || r.iDurationMs > iMax.iDurationMs) iMax = r;
            return iMax == null ? "" : "longest: " + iMax.iTestCaseID + " " + iMax.getDurationFormatted();
        }

        int herdsUsed()
        {
            Set<String> s = new LinkedHashSet<>();
            for (HerdRow r : herds) if (!"REPLACED".equals(r.outcome) && !r.herd.isEmpty()) s.add(r.herd);
            return s.size();
        }

        int herdsConsumed()
        {
            Set<String> s = new LinkedHashSet<>();
            for (HerdRow r : herds) if ("USED".equals(r.outcome)) s.add(r.herd);
            return s.size();
        }

        int herdsBad()      { return countOutcome("BAD"); }
        int loginsUsed()    { Set<String> s = new LinkedHashSet<>(); for (HerdRow r : herds) if (!r.login.isEmpty()) s.add(r.login.toLowerCase(Locale.ROOT)); return s.size(); }

        int countOutcome(String pOutcome) { int n = 0; for (HerdRow r : herds) if (pOutcome.equals(r.outcome)) n++; return n; }

        // Roles seen in the ledger, most used first ("transferor", "BISS herd", "staff submitted herds" ...)
        List<String> roles()
        {
            Map<String, Integer> c = new LinkedHashMap<>();
            for (HerdRow r : herds) c.merge(r.role.isEmpty() ? "herd" : r.role, 1, Integer::sum);
            List<String> list = new ArrayList<>(c.keySet());
            list.sort((a, b) -> c.get(b) - c.get(a));
            return list;
        }

        String roleBreakdown()
        {
            Map<String, Integer> c = new LinkedHashMap<>();
            for (String role : roles()) c.put(role, 0);
            for (HerdRow r : herds) c.merge(r.role.isEmpty() ? "herd" : r.role, 1, Integer::sum);
            StringBuilder b = new StringBuilder();
            int shown = 0;
            for (Map.Entry<String, Integer> e : c.entrySet())
            {
                if (++shown > 3) { b.append(" \u00b7 ..."); break; }
                b.append(shown == 1 ? "" : " \u00b7 ").append(e.getValue()).append(' ').append(e.getKey());
            }
            return b.length() == 0 ? "none in this run" : b.toString();
        }

        // Chart series: the four most used roles, everything else as "Other"
        String[] roleNames(List<String> pRoles)
        {
            int n = Math.min(4, pRoles.size());
            String[] names = new String[n + 1];
            for (int i = 0; i < n; i++) names[i] = pRoles.get(i);
            names[n] = "Other";
            return names;
        }

        String[] roleClasses(List<String> pRoles)
        {
            String[] palette = {"s1", "s2", "s3", "s4"};
            int n = Math.min(4, pRoles.size());
            String[] classes = new String[n + 1];
            for (int i = 0; i < n; i++) classes[i] = palette[i];
            classes[n] = "sg";
            return classes;
        }

        // Average seconds per scenario name, slowest first - the stages of the BISS / ENTS journey
        List<Bar> scenarioBars(int pTop)
        {
            Map<String, long[]> m = new LinkedHashMap<>();
            for (TestCaseResult r : results)
            {
                Map<String, Long> perScenario = new LinkedHashMap<>();
                for (StepResult st : r.iSteps) perScenario.merge(st.iScenario.isEmpty() ? r.iDescription : st.iScenario, st.iDurationMs, Long::sum);
                for (Map.Entry<String, Long> e : perScenario.entrySet())
                {
                    long[] x = m.computeIfAbsent(e.getKey(), k -> new long[2]);
                    x[0]++; x[1] += e.getValue();
                }
            }
            List<Map.Entry<String, long[]>> list = new ArrayList<>(m.entrySet());
            list.sort((a, b) -> Double.compare((double) b.getValue()[1] / b.getValue()[0], (double) a.getValue()[1] / a.getValue()[0]));
            List<Bar> bars = new ArrayList<>();
            for (Map.Entry<String, long[]> e : list)
            {
                if (bars.size() >= pTop) break;
                double avg = e.getValue()[1] / 1000.0 / e.getValue()[0];
                String name = team() ? e.getKey() : maskText(e.getKey());
                bars.add(new Bar(ExecutionMetrics.shorten(name, 38), avg, String.format(Locale.ROOT, "%.0f s \u00b7 %d run(s)", avg, e.getValue()[0]), name));
            }
            return bars;
        }

        List<Bar> herdsPerTestCase()
        {
            Map<String, Integer> c = new LinkedHashMap<>();
            for (TestCaseResult r : results) c.put(r.iTestCaseID, 0);
            for (HerdRow r : herds) c.merge(r.testCase.isEmpty() ? "(no test case)" : r.testCase, 1, Integer::sum);
            List<Bar> bars = new ArrayList<>();
            for (Map.Entry<String, Integer> e : c.entrySet()) bars.add(new Bar(e.getKey(), e.getValue(), String.valueOf(e.getValue()), e.getKey() + ": " + e.getValue() + " herd(s)"));
            return bars;
        }

        List<Bar> moduleTimeBars()
        {
            Map<String, Long> ms = new LinkedHashMap<>();
            for (TestCaseResult r : results) ms.merge(ExecutionMetrics.moduleOf(r.iTestCaseID), r.iDurationMs, Long::sum);
            List<Bar> bars = new ArrayList<>();
            for (Map.Entry<String, Long> e : ms.entrySet())
            {
                double min = e.getValue() / 60000.0;
                bars.add(new Bar(e.getKey(), min, String.format(Locale.ROOT, "%.1f min", min), e.getKey() + ": " + modules().get(e.getKey()) + " test case(s)"));
            }
            return bars;
        }

        // Passed / failed test cases per module (stacked columns)
        String moduleColumns()
        {
            Map<String, Integer> mods = modules();
            String[] labels = mods.keySet().toArray(new String[0]);
            int[][] series = new int[2][labels.length];
            for (TestCaseResult r : results)
            {
                int i = java.util.Arrays.asList(labels).indexOf(ExecutionMetrics.moduleOf(r.iTestCaseID));
                if (i >= 0) series[r.isPassed() ? 0 : 1][i]++;
            }
            return SvgCharts.stackedColumns(labels, series, new String[]{"Passed", "Failed"}, new String[]{"s3", "s2"}, 620, 220);
        }

        int selfHeals()
        {
            return ExecutionMetrics.counter(ExecutionMetrics.JS_FALLBACKS) + ExecutionMetrics.counter(ExecutionMetrics.TRANSFEREES_REPLACED)
                    + ExecutionMetrics.counter(ExecutionMetrics.NAMES_REFRESHED);
        }

        // The two ENTS-only tiles (transferees replaced, names refreshed) give way to generic ones in a run without ENTS
        String selfHealTiles()
        {
            boolean ents = hasModule("ENTS");
            String[][] t = {
                    {String.valueOf(ExecutionMetrics.counter(ExecutionMetrics.JS_FALLBACKS)), "JS-click fallbacks"},
                    {String.valueOf(ExecutionMetrics.counter(ExecutionMetrics.HANDLED_ACTIONS)), "optional actions handled"},
                    ents ? new String[]{String.valueOf(ExecutionMetrics.counter(ExecutionMetrics.TRANSFEREES_REPLACED)), "transferees replaced"}
                         : new String[]{String.valueOf(countOutcome("REPLACED")), "herds replaced"},
                    ents ? new String[]{String.valueOf(ExecutionMetrics.counter(ExecutionMetrics.NAMES_REFRESHED)), "names refreshed from DB"}
                         : new String[]{String.valueOf(countOutcome("BAD")), "herds marked BAD for next time"}};
            StringBuilder h = new StringBuilder("<div class=\"mini\">");
            for (String[] x : t) h.append("<div><b>").append(x[0]).append("</b><span>").append(x[1]).append("</span></div>");
            return h.append("</div>").toString();
        }

        List<Stack> timeRows()
        {
            List<Stack> rows = new ArrayList<>();
            for (TestCaseResult r : results)
            {
                TestCaseInfo i = ExecutionMetrics.testCase(r.iTestCaseID);
                double setup = i.setupMs / 1000.0, scen = i.scenarioMs / 1000.0, down = i.teardownMs / 1000.0;
                if (setup + scen + down <= 0) scen = r.iDurationMs / 1000.0;
                rows.add(new Stack(r.iTestCaseID, new double[]{setup, scen, down}, r.getDurationFormatted()));
            }
            return rows;
        }

        List<Bar> causeBars()
        {
            Map<String, Integer> c = new LinkedHashMap<>();
            for (Failure f : failures) c.merge(f.cause, 1, Integer::sum);
            List<Bar> bars = new ArrayList<>();
            for (String cause : ExecutionMetrics.CAUSES)
            {
                Integer n = c.get(cause);
                if (n != null) bars.add(new Bar(cause, n, String.valueOf(n), cause + ": " + n + " failed step(s)"));
            }
            return bars;
        }

        int failedTestCases() { Set<String> s = new LinkedHashSet<>(); for (Failure f : failures) s.add(f.testCase); return s.size(); }

        int timeouts()
        {
            int n = 0;
            for (StepEvent e : steps) if ("FAIL".equals(e.status) && (e.rootCause.contains("TIMEOUT") || e.rootCause.contains("NOT_FOUND"))) n++;
            return n;
        }

        // Per-locator statistics, most fragile first
        List<LocatorStat> locatorStats()
        {
            Map<String, LocatorStat> m = new LinkedHashMap<>();
            for (StepEvent e : steps)
            {
                LocatorStat s = m.computeIfAbsent(e.locator, k -> new LocatorStat(e.locator, e.orKey));
                s.uses++;
                s.totalMs += e.ms;
                if (e.jsFallback) s.fallbacks++;
                if ("FAIL".equals(e.status)) s.failures++;
                s.testCases.add(e.testCase);
            }
            List<LocatorStat> list = new ArrayList<>(m.values());
            list.removeIf(s -> s.fallbacks + s.failures == 0);
            list.sort(Comparator.comparingInt((LocatorStat s) -> s.fallbacks + s.failures).reversed().thenComparing(s -> s.locator));
            return list;
        }

        int fragileCount()
        {
            int n = 0;
            for (LocatorStat s : locatorStats()) if (s.uses >= 3 && s.rate() >= 20) n++;
            return n;
        }

        List<Bar> fragileBars(int pTop)
        {
            List<Bar> bars = new ArrayList<>();
            for (LocatorStat s : locatorStats())
            {
                if (bars.size() >= pTop) break;
                int v = s.fallbacks + s.failures;
                bars.add(new Bar(s.name(), v, v + " of " + s.uses, s.locator + " | fallbacks " + s.fallbacks + ", failures " + s.failures + ", uses " + s.uses));
            }
            return bars;
        }

        String locatorTable()
        {
            List<LocatorStat> list = locatorStats();
            if (list.isEmpty()) return "<p class=\"empty\">No action needed a fallback or failed in this run.</p>";
            StringBuilder h = new StringBuilder("<div class=\"scroll\"><table class=\"tbl\"><thead><tr><th>Object Repository key / locator</th><th class=\"r\">Uses</th>")
                    .append("<th class=\"r\">JS fallbacks</th><th class=\"r\">Failures</th><th>Rate</th><th class=\"r\">Avg time</th><th>Test cases</th><th>Likely fix</th></tr></thead><tbody>");
            int iShown = 0;
            for (LocatorStat s : list)
            {
                if (++iShown > 40) break;
                h.append("<tr><td><b>").append(esc(s.orKey.isEmpty() ? "(not in the repository)" : s.orKey)).append("</b><div class=\"xp mono\">")
                 .append(esc(ExecutionMetrics.shorten(s.locator, 140))).append("</div></td><td class=\"r num\">").append(s.uses)
                 .append("</td><td class=\"r num\">").append(s.fallbacks).append("</td><td class=\"r num\">").append(s.failures)
                 .append("</td><td class=\"num\">").append(s.rate()).append("% ").append(SvgCharts.meter(s.rate(), "s2"))
                 .append("</td><td class=\"r num\">").append(String.format(Locale.ROOT, "%.1f s", s.totalMs / 1000.0 / Math.max(1, s.uses)))
                 .append("</td><td class=\"muted\">").append(esc(String.join(", ", s.testCases))).append("</td><td class=\"fix\">").append(esc(s.likelyFix())).append("</td></tr>");
            }
            return h.append("</tbody></table></div>").toString();
        }

        String failureTable()
        {
            if (failures.isEmpty()) return "<p class=\"empty\">No step failed in this run.</p>";
            StringBuilder h = new StringBuilder("<div class=\"scroll\"><table class=\"tbl\"><thead><tr><th>Test case</th><th>Step</th><th>Cause</th><th>Message</th>")
                    .append(team() ? "<th>Evidence</th>" : "").append("</tr></thead><tbody>");
            for (Failure f : failures)
            {
                TestCaseInfo info = ExecutionMetrics.testCase(f.testCase);
                h.append("<tr><td><b>").append(esc(f.testCase)).append("</b><div class=\"muted\">").append(esc(f.scenario)).append("</div></td><td>")
                 .append(esc(f.step)).append("</td><td><span class=\"chip\">").append(esc(f.cause)).append("</span></td><td class=\"muted msg\">")
                 .append(esc(team() ? f.message : maskText(f.message))).append("</td>");
                if (team())
                {
                    h.append("<td>");
                    if (!f.screenshot.isEmpty()) h.append("<a href=\"").append(esc(href(f.screenshot))).append("\" target=\"_blank\">screenshot</a><br>");
                    if (!info.wordDoc.isEmpty()) h.append("<a href=\"").append(esc(href(info.wordDoc))).append("\">Word report</a>");
                    h.append("</td>");
                }
                h.append("</tr>");
            }
            return h.append("</tbody></table></div>").toString();
        }

        String causeColumns()
        {
            if (failures.isEmpty()) return "<p class=\"empty\">No step failed in this run.</p>";
            List<String> tcs = new ArrayList<>();
            for (Failure f : failures) if (!tcs.contains(f.testCase)) tcs.add(f.testCase);
            List<String> causes = new ArrayList<>();
            for (String c : ExecutionMetrics.CAUSES) for (Failure f : failures) if (f.cause.equals(c) && !causes.contains(c)) causes.add(c);
            int[][] series = new int[causes.size()][tcs.size()];
            for (Failure f : failures) series[causes.indexOf(f.cause)][tcs.indexOf(f.testCase)]++;
            String[] classes = new String[causes.size()];
            String[] palette = {"s1", "s2", "s3", "s4", "s5", "sg", "sg"};
            for (int i = 0; i < classes.length; i++) classes[i] = palette[Math.min(i, palette.length - 1)];
            return SvgCharts.stackedColumns(tcs.toArray(new String[0]), series, causes.toArray(new String[0]), classes, 640, 240);
        }

        // Completed transfers, grouped per (created by, accepted by)
        String flowMap()
        {
            Map<String, Integer> pairs = new LinkedHashMap<>();
            for (Flow f : flows) pairs.merge(login(f.from) + "\u0000" + login(f.to), 1, Integer::sum);
            List<String> from = new ArrayList<>(), to = new ArrayList<>();
            List<Integer> count = new ArrayList<>();
            for (Map.Entry<String, Integer> e : pairs.entrySet())
            {
                String[] p = e.getKey().split("\u0000", 2);
                from.add(p[0]); to.add(p[1]); count.add(e.getValue());
            }
            return SvgCharts.flowMap(from, to, count, 620);
        }

        String matrix()
        {
            List<String> rows = new ArrayList<>(), cols = new ArrayList<>();
            for (Flow f : flows)
            {
                if (!rows.contains(login(f.from))) rows.add(login(f.from));
                if (!cols.contains(login(f.to)))   cols.add(login(f.to));
            }
            int[][] v = new int[rows.size()][cols.size()];
            int mx = 1;
            for (Flow f : flows)
            {
                int a = rows.indexOf(login(f.from)), b = cols.indexOf(login(f.to));
                v[a][b]++;
                mx = Math.max(mx, v[a][b]);
            }
            return (rows.isEmpty() ? "" : SvgCharts.rampLegend(mx)) + SvgCharts.heatMatrix(rows, cols, v, "ACCEPTED BY");
        }

        List<Stack> poolRows(List<String> pRoles)
        {
            int n = Math.min(4, pRoles.size());
            Map<String, double[]> m = new TreeMap<>();
            for (HerdRow r : herds)
            {
                String pool = r.pool.isEmpty() ? "(no vault pool)" : r.pool;
                double[] d = m.computeIfAbsent(pool, k -> new double[n + 1]);
                int i = pRoles.indexOf(r.role.isEmpty() ? "herd" : r.role);
                d[i >= 0 && i < n ? i : n]++;
            }
            List<Stack> rows = new ArrayList<>();
            for (Map.Entry<String, double[]> e : m.entrySet())
            {
                double total = 0;
                for (double v : e.getValue()) total += v;
                rows.add(new Stack(team() ? e.getKey() : maskPool(e.getKey()), e.getValue(), Math.round(total) + " herds"));
            }
            return rows;
        }

        // Agent pool keys (aga..., agr...) stay - test accounts; any other key is treated as a farmer login and hidden
        private String maskPool(String pPool) { return pPool.startsWith("(") ? pPool : pool(pPool); }

        List<Bar> dbBars(int pTop)
        {
            Map<String, long[]> m = new LinkedHashMap<>();
            for (DbCall d : db)
            {
                long[] x = m.computeIfAbsent(d.label, k -> new long[3]);
                x[0]++; x[1] += d.ms; x[2] = Math.max(x[2], d.ms);
            }
            List<Map.Entry<String, long[]>> list = new ArrayList<>(m.entrySet());
            list.sort((a, b) -> Long.compare(b.getValue()[2], a.getValue()[2]));
            List<Bar> bars = new ArrayList<>();
            for (Map.Entry<String, long[]> e : list)
            {
                if (bars.size() >= pTop) break;
                long[] x = e.getValue();
                bars.add(new Bar(e.getKey(), x[2] / 1000.0, String.format(Locale.ROOT, "%.1f s", x[2] / 1000.0),
                        e.getKey() + " | calls " + x[0] + ", total " + String.format(Locale.ROOT, "%.1f s", x[1] / 1000.0)));
            }
            return bars;
        }
    }

    // Statistics of one locator
    static final class LocatorStat
    {
        final String      locator;
        final String      orKey;
        int               uses, fallbacks, failures;
        long              totalMs;
        final Set<String> testCases = new LinkedHashSet<>();

        LocatorStat(String pLocator, String pOrKey) { locator = pLocator; orKey = pOrKey; }

        int rate() { return uses == 0 ? 0 : (int) Math.round(100.0 * (fallbacks + failures) / uses); }

        String name() { return orKey.isEmpty() ? ExecutionMetrics.shorten(locator, 40) : orKey; }

        // ***********************************************************************************************************************************************************************************
        // Function Name : likelyFix
        // Description   : A hint from the shape of the XPath (fixed rules, first match wins).
        // ***********************************************************************************************************************************************************************************
        String likelyFix()
        {
            String x = locator.toLowerCase(Locale.ROOT);
            if (x.matches(".*\\)\\[\\d+\\]\\s*$") || x.matches(".*//[a-z-]+\\[\\d+\\].*")) return "Position index - pick the element by its text, id or label instead";
            if (x.contains("mat-select"))                       return "Dropdown - click its trigger and wait for the open animation before choosing";
            if (x.contains("mat-radio") || x.contains("radio")) return "Often covered by a dialog that is still closing - wait for the overlay to go first";
            if (x.contains("contains(normalize-space(.)") && !x.contains("[@")) return "Matches any element with that text - scope it to its dialog or footer";
            if (x.contains("button"))                           return "Button may still be disabled or animating - wait until it is enabled";
            if (failures > 0 && fallbacks == 0)                 return "Never found in time - check the page actually reached this screen";
            return "Check for an overlay or spinner on top of the element";
        }
    }
}
