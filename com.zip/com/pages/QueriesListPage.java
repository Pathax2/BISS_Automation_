package com.pages;



public class QueriesListPage {



     String sql1 ="select * from vwbs_application_herd\n" +
            "where mde_abbrev = 'I'\n" +
            "and app_year = 2023\n" +
            "and not exists (select 1 from tdbs_application_land where apl_year = 2023 and apl_app_id = aph_app_id)\n" +
            "fetch first 5 rows only";


}

/* Dummy Code
"select * from vwbs_application_herd\n" +
                   "\n" +
                   "where mde_abbrev = 'I'\n" +
                   "\n" +
                   "and app_year = 2023\n" +
                   "\n" +
                   "and not exists (select 1 from tdbs_application_land where apl_year = 2023 and apl_app_id = aph_app_id)\n" +
                   "\n" +
                   "fetch first 5 rows only"

 */

