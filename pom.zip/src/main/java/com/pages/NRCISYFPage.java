package com.pages;

//import com.DB.storedprocedures.*;

import com.base.ActionClass;
import io.cucumber.java.eo.Se;
import org.apache.poi.sl.usermodel.Placeholder;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.math.BigDecimal;
import java.sql.*;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static java.lang.Thread.sleep;
import static org.openqa.selenium.support.locators.RelativeLocator.with;

public class NRCISYFPage {


    WebDriver driver;
    ActionClass actions;
    Actions action;

    public NRCISYFPage(WebDriver driver) {
        this.driver = driver;
        actions = new ActionClass(driver);
        action = new Actions(driver);
    }


    // region Common Code
    // Agent Click on Button
    public void AgentClickOnButton(String ButtonText) {
        By Button = By.xpath("//button/span[text()='"+ButtonText+"']");
        List<WebElement> buttons = driver.findElements(Button);
        if(buttons.isEmpty()){
            System.out.println(ButtonText+"Not present on page");
        }
        else{
            actions.clickUsingJS(Button);
        }
    }

    // Agent Click on NRCISYF Apply/Edit Button
    public void AgentClickOnNRCISYFApplyOrEditButton() {
        By ApplyButton = By.xpath("//button/span[text()='Apply']");
        List<WebElement> ApplyButtonVisibilityCheck = driver.findElements(ApplyButton);
        if (ApplyButtonVisibilityCheck.isEmpty()) {
            By EditButton = By.xpath("//button/span[text()='Edit']");
            actions.clickUsingJS(EditButton);
        }
        else {
            actions.clickUsingJS(ApplyButton);
        }
    }

    // Agent Click on NRCISYF BUtton
    public void AgentClickOnNRCISYFButton(String Button) {
        By ButtonName = By.xpath("//button[contains(text(),'"+Button+"')]");
        List<WebElement> buttons = driver.findElements(ButtonName);
        if(buttons.isEmpty()){
            System.out.println(Button+"Not present on page");
        }
        else{
            actions.clickUsingJS(ButtonName);
        }
        //actions.clickUsingJS(ButtonName);
    }

    // Agent Click on Cloe Button
    public void AgentClickOnCloseButton() {
        By Button = By.xpath("//button/span/span[text()='Close']");
        List<WebElement> buttons = driver.findElements(Button);
        if(buttons.isEmpty()){
            System.out.println(Button+"Not present on page");
        }
        else{
            actions.clickUsingJS(Button);
        }
       // actions.clickUsingJS(Button);
    }

    //Agent Select CheckBox
    public void AgentSelectCheckBox(String checkBoxNumber,String checkBoxOption) {
        By checkBoxSelected = By.xpath("(//mat-dialog-container/descendant::mat-checkbox/descendant::span/input)["+checkBoxNumber+"]");
        By CheckBox = By.xpath("//mat-dialog-container/descendant::mat-checkbox/descendant::span[contains(text(),'"+checkBoxOption+"')]");

        System.out.println(driver.findElement(checkBoxSelected).getAttribute("aria-checked"));
      //  List<WebElement> checkBoxSelection = driver.findElements(checkBoxSelected);
        if(driver.findElement(checkBoxSelected).getAttribute("aria-checked").equals("false")){
            actions.clickUsingJS(CheckBox);
            System.out.println(checkBoxOption + "Checkbox is enabled now");
        }
        else {
            System.out.println(checkBoxOption + "Checkbox is enabled already");
        }
    }

    // Agent Select Eleigible Farmer CheckBox
   /* public void AgentCheckEligibleFarmerCheckBox(String CheckBoxNumber) {
        By CheckBoxTickedOrNot = By.xpath("(//mat-checkbox[contains(@class,'mat-checkbox-checked')])["+CheckBoxNumber+"]");
        List<WebElement> CheckBoxSelection = driver.findElements(CheckBoxTickedOrNot);
        if(CheckBoxSelection.isEmpty()) {
            By TargetCheckBox = By.xpath("(//input[@type='checkbox'])["+CheckBoxNumber+"]");
            actions.clickUsingJS(TargetCheckBox);
        }
        else {
            System.out.println("Eligible Farmer CheckBox Selected");
        }
    }*/

    public void AgentCheckEligibleFarmerCheckBox(String CheckBoxNumber) {
        List<WebElement> checkboxes = driver.findElements(
                By.xpath("//input[contains(@class,'mdc-checkbox__native-control')]"));

        if (checkboxes.isEmpty()) {
            throw new AssertionError("No checkboxes found on the page.");
        }
        boolean isAnySelected = checkboxes.stream()
                .anyMatch(WebElement::isSelected);
        // If none selected → click first checkbox using JS (
        if (!isAnySelected) {
            By targetCheckBox = By.xpath(
                    "(//input[contains(@class,'mdc-checkbox__native-control')])[" + CheckBoxNumber + "]");
            ((JavascriptExecutor) driver)
                    .executeScript("arguments[0].click();", driver.findElement(targetCheckBox));
        }
        // Final validation
        boolean finalCheck = checkboxes.stream()
                .anyMatch(WebElement::isSelected);
        if (!finalCheck) {
            throw new AssertionError("Validation Failed: At least one checkbox must be selected.");
        }
        System.out.println("Validation Passed: At least one checkbox is selected.");
    }
    // Agent Check Status of Category Selection CheckBox and Click
    public void AgentSelectCategorySelectionCheckBoxStatusAndClick(String CheckBoxOption) {
//        By CheckBoxStatus = By.xpath("//span[text()='"+CheckBoxOption+"']/ancestor::mat-checkbox/descendant::input");
//        if (Boolean.valueOf(driver.findElement(CheckBoxStatus).getAttribute("aria-checked"))){
//            System.out.println("Category has already been selected");
//        }
//        else {
//            By CheckBox = By.xpath("//mat-dialog-container/descendant::mat-checkbox/descendant::span[contains(text(),'"+CheckBoxOption+"')]");
//            actions.clickUsingJS(CheckBox);
//        }
        By CheckBox =  By.xpath("//mat-dialog-container/descendant::mat-checkbox/descendant::label[contains(text(),'"+CheckBoxOption+"')]");
        actions.clickUsingJS(CheckBox);
    }

    // Agent UnCheck Status all Selection CheckBox
    public void agentUnchecksAllOptions() throws InterruptedException {
        By A = By.xpath("//mat-dialog-container/descendant::mat-checkbox/descendant::label[contains(text(),'A. National Reserve (as Young Farmer)')]");
        By B = By.xpath("//mat-dialog-container/descendant::mat-checkbox/descendant::label[contains(text(),'B. National Reserve (as New Farmer)')]");
        By C = By.xpath("//mat-dialog-container/descendant::mat-checkbox/descendant::label[contains(text(),'C. Complementary income Support for Young Farmers')]");
        List<WebElement> allSelectedCheckboxes = driver.findElements(By.xpath("//label/ancestor::mat-checkbox/descendant::input[@class='mdc-checkbox__native-control mdc-checkbox--selected']"));
        if (!allSelectedCheckboxes.isEmpty()) {
            for (WebElement i : allSelectedCheckboxes) {
                i.click();
            }
        } else {
            System.out.println("All checkboxes are unselected already");
        }
    }


        // Click on the dropdown
    public void AgentOpenDropdown(String Placeholder) {
        String Locator = "//span[contains(text(),'"+Placeholder+"')]/ancestor::mat-select";
        By AddPlotDropdowns = By.xpath(Locator);
        actions.clickUsingJS(AddPlotDropdowns);
    }

//    // Agent Select Farming Entity
//    public void AgentSelectFarmingEntityDropdownValue(String Placeholder, String Value) {
//        AgentOpenDropdown(Placeholder);
//        By DropDownValue = By.xpath("//span[contains(text(),'"+Value+"')]/ancestor::mat-option");
//        actions.clickUsingJS(DropDownValue);
//    }

    // Agent Select Value from Dropdown
    public void AgentSelectDropdownValue(String Value, String Dropdown) {
        By AddPlotDropdowns = By.xpath("//mat-select[@formcontrolname='"+Dropdown+"']");
        actions.clickUsingJS(AddPlotDropdowns);
        By DropDownValue = By.xpath("//span[contains(text(),'"+Value+"')]/ancestor::mat-option");
        actions.clickUsingJS(DropDownValue);
    }

    // Agent Click on Info Icon near checkbox
    public void AgentClickOnCategoryInfoButton(String IconNumber) {
        By Icon = By.xpath("//mat-checkbox[@id='mat-mdc-checkbox-"+IconNumber+"']/parent::div/child::mat-icon");
        actions.clickUsingJS(Icon);
    }

    // Individual Click on CheckBox in Submission Declaration
    public void IndividualClickOnCheckboxInSubmissionDeclaration(int Number) {
        // By CheckBox = By.xpath("//mat-dialog-container/descendant::mat-checkbox["+Number+"]");
        By CheckBox = By.xpath("(//mat-checkbox/descendant::input[@type= 'checkbox'])["+Number+"]");
        //By CheckBox = By.xpath("(//mat-checkbox/descendant::div[@class = 'mat-ripple mat-mdc-checkbox-ripple mat-mdc-focus-indicator'])['"+Number+"']");
        actions.clickUsingJS(CheckBox);
        actions.waitforSeconds(5);
    }

    // Agent Click on the Document Link in View Application Screen
    public void AgentClickOnDocLinkInViewApplicationScreen(String DocType) {
        By Link = By.xpath("//mat-card-title[contains(text(),'"+DocType+"')]/parent::mat-card/descendant::a[contains(text(),'Document Link')]");
        actions.clickUsingJS(Link);
    }

    // Agent Enter the college name in the Education Page Field
    public void AgentEnterCollegeNameNotInList(String FieldName, String Value) {
        By Field = By.xpath("//input[@formcontrolname='"+FieldName+"']");
        actions.sendKeys(Field,Value);
    }

    // Agent Check Education Institution Details
    public String AgentCheckEducationInstitutionDetails() {
        By EducationInstitution = By.xpath("//p[contains(text(),'Educational Institution Details:')]/ancestor::mat-card-content/descendant::b");
        String CollegeCheck = driver.findElement(EducationInstitution).getText();
        return CollegeCheck;
    }

    // Agent Check Education Qualification Details
    public String AgentCheckEducationQualificationDetails() {
        By Qualification = By.xpath("//p[contains(text(),'Qualification Details:')]/ancestor::mat-card-content/descendant::b");
        String QualificationCheck = driver.findElement(Qualification).getText();
        return QualificationCheck;
    }

    // Agent enter Values in Company Fields
    public void AgentEnterValuesInCompanyFields(String Value, String Field) {
        By CompanyField = By.xpath("(//input[@type='text'])["+Field+"]");
        driver.findElement(CompanyField).clear();
        actions.sendKeys(CompanyField,Value);
    }
    // endregion

    // region NRCISYF code
    // Agent check the Date in important information
    public String AgentCheckNRCISYFClosingDate() {
        By ImportantDate = By.xpath("//mat-card-title[contains(text(),'National Reserve/Complementary Income Support for Young Farmers')]/ancestor::mat-card/descendant::p/span[contains(text(),'15 May 2026')]");
        String Date = driver.findElement(ImportantDate).getText();
        return Date;
    }


    /// Status Screen
    // Agent Select Farming Entty
    public void AgentSelectFarmingEntityDropdownValue(String Value) {
        By AddPlotDropdowns = By.xpath("(//mat-select)[1]");
        actions.clickUsingJS(AddPlotDropdowns);
        By DropDownValue = By.xpath("//span[contains(text(),'"+Value+"')]/ancestor::mat-option");
        actions.clickUsingJS(DropDownValue);
    }

    // Agent Select Herd Group Type
    public void AgentSelectHerdGroupTypeDropdownValue(String Value) throws InterruptedException {
        By AddPlotDropdowns = By.xpath("(//mat-select)[2]");
        actions.clickUsingJS(AddPlotDropdowns);
        Thread.sleep(2000);
        By DropDownValue = By.xpath("//span[contains(text(),'"+Value+"')]/ancestor::mat-option");
        actions.clickUsingJS(DropDownValue);
    }

    // Agent Select Number of Group Members
    public void AgentSelectGroupMembersDropdownValue(String Value) throws InterruptedException {
        By AddPlotDropdowns = By.xpath("(//mat-select)[2]");
        actions.clickUsingJS(AddPlotDropdowns);
        Thread.sleep(2000);
        By DropDownValue = By.xpath("//span[contains(text(),'"+Value+"')]/ancestor::mat-option");
        actions.clickUsingJS(DropDownValue);
    }

    // Agent Select Number of Group Members for Joint Herd Owner
    public void AgentSelectGroupMembersJHDropdownValue(String Value) throws InterruptedException {
        By AddPlotDropdowns = By.xpath("(//mat-select)[3]");
        actions.clickUsingJS(AddPlotDropdowns);
        Thread.sleep(2000);
        By DropDownValue = By.xpath("//span[contains(text(),'"+Value+"')]/ancestor::mat-option");
        actions.clickUsingJS(DropDownValue);
    }

    // Agent Enter Date of Birth New and Simple method
    public void AgentEnterNewDateOfBirth(int DatePickerNumber, String Date, String Month, String Year) {
        By DateOfBirth = By.xpath("(//mat-datepicker-toggle/button[@aria-label='Open calendar'])["+DatePickerNumber+"]");
//        //input[contains(@class,'mat-datepicker-input')]
////        actions.sendKeys(DateOfBirth,Date);
//        String BirthDate = driver.findElement(DateOfBirth).getAttribute("value");
//        System.out.println(BirthDate);
//        if (Objects.equals(BirthDate, "")) {
//            actions.sendKeys(DateOfBirth,Date);
//        }
//        else {
//            System.out.println("Date has been selected");
//        }
        actions.clickUsingJS(DateOfBirth);
        System.out.println("Datepicker opened");
        By chooseMonthAndYear = By.xpath("//button[@aria-label='Choose month and year']");
        actions.clickUsingJS(chooseMonthAndYear);

        // Select a specific date, e.g., 27th of the current month
       By year = By.xpath("//button/span[contains(text(),'"+Year+"')]");
        By month = By.xpath("//button/span[contains(text(),'"+Month+"')]");
        By date = By.xpath("//button/span[contains(text(),'"+Date+"')]");
        actions.clickUsingJS(year);
        actions.waitforSeconds(2);
        actions.clickUsingJS(month);
        actions.waitforSeconds(2);
        actions.clickUsingJS(date);
        actions.waitforSeconds(2);

    }

    // Agent Enter Date in the Date of Birth Field
    public void AgentEnterDateOfBirth(int DatePickerNumber, String Date) {
        By DateOfBirth = By.xpath("(//input[contains(@class,'mat-datepicker-input')])["+DatePickerNumber+"]");
        //input[contains(@class,'mat-datepicker-input')]
//        actions.sendKeys(DateOfBirth,Date);
        if(driver.findElements(DateOfBirth).isEmpty()) {
//            DatePickerNumber = DatePickerNumber ++;
            By NewDateOfBirth = By.xpath("(//input[contains(@class,'mat-datepicker-input')])["+(DatePickerNumber+1)+"]");
            String BirthDate = driver.findElement(NewDateOfBirth).getAttribute("value");
            System.out.println(BirthDate);
            if (Objects.equals(BirthDate, "")) {
                actions.sendKeys(NewDateOfBirth,Date);
            }
            else {
                System.out.println("Date has been selected");
            }
        }
        else {
            String BirthDate = driver.findElement(DateOfBirth).getAttribute("value");
            System.out.println(BirthDate);
            if (Objects.equals(BirthDate, "")) {
                actions.sendKeys(DateOfBirth,Date);
            }
            else {
                System.out.println("Date has been selected");
            }
        }
    }



    // Agent Enter Member Name
    public void AgentEnterMemberName(String Value) {
        By MemberNameField = By.xpath("//table/descendant::input[@type='text']");
        actions.sendKeys(MemberNameField, Value);
    }

    /// Education Screen

    // Common Radio Button Method
    public void AgentSelectRadioButtonChoice(String Question ,String RadioChoice) {
        By RadioButton = By.xpath("//mat-radio-group[@formcontrolname='"+Question+"']/descendant::label[contains(text(),'"+RadioChoice+"')]");
        actions.clickUsingJS(RadioButton);
    }

    // Status Page Radio Button Selection
    public void AgentSelectStatusPageRadioButtonChoice(String Question ,String RadioChoice) {
//        By RadioButton = By.xpath("//mat-radio-group[@aria-labelledby='control-and-decision-making-radio-group-label']/descendant::span[contains(text(),'Yes')]");
        By RadioButton = By.xpath("//mat-radio-group[@role='"+Question+"']/descendant::label[contains(text(),'"+RadioChoice+"')]");
        actions.clickUsingJS(RadioButton);
    }



    // Agent Enter Date in the Date of Completion Field
    public void AgentEnterDateOfCompletion(String Date) throws InterruptedException {
        By datePicker = By.xpath("//mat-datepicker-toggle/button[@aria-label='Open calendar']");
        actions.clickUsingJS(datePicker);
        System.out.println("Datepicker opened");
        actions.waitforSeconds(2);
                driver.findElement(By.xpath("//button/span[contains(text(),'"+Date+"')]")).click();
        System.out.println("Date '1' selected from current month");
    }

    /// Summary Screen
//    public void AgentClickOnDocUploadButton(String DocType) {
//        if(DocType.equals("Education")) {
//            By FirstUpload = By.xpath("");
//            actions.clickUsingJS(FirstUpload);
//        }
//        else if(DocType.equals("Personal")) {
//            By SecondUpload = By.xpath("");
//            actions.clickUsingJS(SecondUpload);
//        }
//    }

    public void AgentClickOnSummaryDocUploadButton(String DocType) {
        //By DocName = By.xpath("//p[contains(text(),'"+DocType+"')]/parent::div/following-sibling::div/descendant::button");
        List<WebElement> DocName = driver.findElements(By.xpath("//p[contains(text(),'"+DocType+"')]/parent::div/following-sibling::div/descendant::button"));
        if (DocName.isEmpty()){
            System.out.println(DocType+" is already done");
        }
        else {
            actions.clickUsingJS(By.xpath("//p[contains(text(),'"+DocType+"')]/parent::div/following-sibling::div/descendant::button"));
        }

    }

    public void UploadDocumentForNRCISYF() {
       // List<WebElement> Choosefile = driver.findElements(By.xpath("//input[@type='file']"));
        // Has to be enabled while running on Grid if not in Driver Manager
        //((RemoteWebElement)driver).setFileDetector(new LocalFileDetector());
        // Path for Local Run
//        if(Choosefile.isEmpty()){
//            System.out.println("Uploaded Already");
//        }
//        else{
//            String FilePath = getPath();
//            Choosefile.get(0).sendKeys(FilePath);
//        }

        // Path for Remote run
//        if(Choosefile.isEmpty()){
//            System.out.println("Uploaded Already");
//        }
//        else{Choosefile.get(0).sendKeys("C:/Users/Akanksha.Singh/Desktop/Selenium/TestData/download.pdf");}
      // Choosefile.sendKeys("C:/Users/Akanksha.Singh/Desktop/Selenium/TestData/download.pdf");
        if (driver instanceof RemoteWebDriver) {
            ((RemoteWebDriver) driver).setFileDetector(new LocalFileDetector());
        }
        WebElement Choosefile = driver.findElement(By.xpath("//input[@type='file']"));
        String FilePath = getPath();
        Choosefile.sendKeys(FilePath);
    }

    public void UploadWrongDocumentForNRCISYF() {
        WebElement Choosefile = driver.findElement(By.xpath("//input[@type='file']"));
        // Has to be enabled while running on Grid if not in Driver Manager
        //((RemoteWebElement)driver).setFileDetector(new LocalFileDetector());
        // Path for Local Run
//        String FilePath = getWrongFilePath();
//        Choosefile.sendKeys(FilePath);
        // Path for Remote run
        Choosefile.sendKeys("C:/Selenium/TestData/download.docx");
    }

    public String getPath() {
        return new File("src/main/resources/TestData/download.pdf").getAbsolutePath();
    }

    String getWrongFilePath() {
        return new File("src/main/resources/TestData/download.docx").getAbsolutePath();
    }

    // Individual check for Error Message
    public String IndividualCheckErrorMessage() {
        By Error = By.xpath("//mat-error");
        String ErrorText = driver.findElement(Error).getText();
        return ErrorText;
    }


    // Agent check the Covid Message on the Education page
    public Boolean AgentCheckCovidMessageOnEducationPage() {
        By CovidMessage = By.xpath("//p[contains(text(),'As you have not yet completed your Agricultural Qualification please download the ')]");
        Boolean Message = driver.findElement(CovidMessage).isDisplayed();
        return Message;
    }
    // endregion


    // region ENTS code
    // Click on the View button for searched herd
    public void AgentClickOnViewLinkForSearchedHerd() {
        By Link = By.xpath("(//a[contains(text(),'View')])[1]");
        actions.clickUsingJS(Link);
    }

    // Click on ETF Button in Screen
    public void AgentClickOnETFButton() {
        By ETFButton = By.xpath("//button/span[text()=' Access an application using Transfer Key ']");
        actions.clickUsingJS(ETFButton);
    }

    // Click on button in dialog box
    // Arg : Create Transfer Application, View
    public void AgentClickOnButtonInDialog(String Button) {
        By ButtonName = By.xpath("//mat-dialog-container/descendant::button[contains(text(),'"+Button+"')]");
        actions.clickUsingJS(ButtonName);
    }

    // Click on button in NRCISYF dialog box
    // Arg : Submit Application
    public void AgentClickOnButtonInNRCISYFDialog(String Button) {
        By ButtonName = By.xpath("//mat-dialog-container/descendant::button/span[contains(text(),'"+Button+"')]");
        actions.clickUsingJS(ButtonName);
    }

//    // Click on button in screen
//    // Arg : Add
//    public void AgentClickOnEntitlementsButton(String Button) {
//        By ButtonName = By.xpath("//button[contains(text(),'"+Button+"')]");
//        actions.clickUsingJS(ButtonName);
//    }



    // Agent Enter Text in Transferee Search Dialog
    // Arg : txeeHerd, txeeName
    public void AgentEnterTextInDialog(String Field, String Value) {
        By TextBox = By.xpath("//input[@formcontrolname='"+Field+"']");
        actions.sendKeys(TextBox,Value);
    }



    // Agent Select the Transfer Type
    // Arg : Inheritance - 201, Gift - 202, Merger - 203, Division - 204, Change Reg - 205, Change Ent - 206, Lease - 211, Sale - 212
    public void AgentSelectTransferType(String TransferType) {
        By RadioButton = By.xpath("//mat-radio-button/descendant::input[@value='"+TransferType+"']");
        actions.clickUsingJS(RadioButton);
    }



    By HerdSearchField = By.xpath("//input[@data-placeholder='Address, Name or Herd Number']");

    // Agent Search for a particular herd
    public void AgentSearchForHerdField(String Arg0) {
        //actions.waitForVisibilityOfElement(HerdSearch,30);
        actions.sendKeys(HerdSearchField,Arg0);
    }

    /* Entitlements Tab*/
    // Agent Click on Add Entitlements button
    public void AgentClickOnAddEntitlements() {
        By FirstAddButton = By.xpath("(//td/button[contains(text(),'Add')])[1]");
        actions.clickUsingJS(FirstAddButton);
    }

    // Agent Check if Entitlements not present
    public Boolean AgentCheckEntitlementsNotPresent() {
        By FirstAddButton = By.xpath("//td/button[contains(text(),'Add')]");
        List<WebElement> AddButton = driver.findElements(FirstAddButton);
        return AddButton.isEmpty();
    }

    /* Summary Tab */
    // Agent Add notes to the Transfer of Entitlements Application
    public void AgentAddNotesToEntitlements(String Notes) throws InterruptedException {
        //By TextBox = By.xpath("//textarea");
        List<WebElement> TextBoxCheck = driver.findElements(By.xpath("//textarea"));
        if(TextBoxCheck.isEmpty())
        {
            By RemoveSelectedEntitlement = By.xpath("//button[contains(text(),'Remove')]");
            actions.clickUsingJS(RemoveSelectedEntitlement);
            sleep(2000);
            By ConfirmRemove = By.xpath("//app-transfer-entitlement-remove-popup/descendant::button[contains(text(),'Remove')]");
            actions.clickUsingJS(ConfirmRemove);
            sleep(2000);
            By SecondAddButton = By.xpath("(//td/button[contains(text(),'Add')])[2]");
            actions.clickUsingJS(SecondAddButton);
            sleep(2000);
            AgentEnterTextInDialog("itsNumEntsTx", "1");
            sleep(2000);
            AgentClickOnButtonInDialog("Add");
            sleep(2000);
            AgentClickOnButton(" Next ");
            sleep(2000);
            actions.sendKeys(By.xpath("//textarea"),Notes);
        }
        else {
            actions.sendKeys(By.xpath("//textarea"),Notes);
        }
    }

    // Agent access the Transferor Form
    public void AgentClickOnLink(String LinkText) {
        By Link = By.xpath("//a[contains(text(),'"+LinkText+"')]");
        actions.clickUsingJS(Link);
    }

    /*Transferee Screen*/
    // Click on the View button in the Transferee Home Screen
    //J1320531
    public void TransfereeViewButtonClick(String TransfereeHerdNumber) {
        //(//button[contains(text(),'View')])[1]
        By TransferorReferenceNumber = By.xpath("//td[contains(text(),'"+TransfereeHerdNumber+"')]");
        List<WebElement> HerdNumbers = driver.findElements(TransferorReferenceNumber);
        int HerdNumberCount = HerdNumbers.size();
//        WebElement TransferorHerdNumber = HerdNumbers.get(HerdNumberCount-1);
//        By TransferorHerdNumber = By.xpath("(//td[contains(text(),'"+TransfereeHerdNumber+"')])["+HerdNumberCount+"]");
//        By TransferType = By.xpath("//td[contains(@class,'cdk-column-transferType')"); // and contains(text(),'Change of Legal Entity')]
//        By TransferStatus = By.xpath("//td[contains(@class,'cdk-column-transferStatus')"); // and contains(text(),'Awaiting Acceptance by Transferee')]
//        By TransferKey = By.xpath("//td[contains(@class,'cdk-column-transferKey')");
//        By LastModified = By.xpath("//td[contains(@class,'cdk-column-lastModified')");
//        By ViewButton = By.xpath("//button[contains(text(),'View')]");
//        WebElement TransfereeViewButton = driver.findElement(with(ViewButton)
//                .toRightOf(LastModified)
//                .toRightOf(TransferKey)
//                .toRightOf(TransferStatus)
//                .toRightOf(TransferType)
//                .toRightOf(TransferorHerdNumber));
//        WebElement TransfereeViewButton = driver.findElement(TransfereeLastViewButton);
//        TransfereeViewButton.click();
        By TransfereeLastViewButton = By.xpath("(//td[contains(text(),'J1320531')]/ancestor::tr/descendant::button[contains(text(),'View')])["+HerdNumberCount+"]");
        actions.clickUsingJS(TransfereeLastViewButton);
//        actions.clickUsingJS(TransfereeViewButton.get(ButtonCount-1));
    }


    // Click on View Button in Transferee Screen
    public void AgentClickOnViewButtonInTransfereeScreen() {
        By ViewButton = By.xpath("//mat-card-title[contains(text(),'Transfers In Applications 2024')]/ancestor::mat-card/descendant::button[contains(text(),'View')]");
        List<WebElement> TransfereeViewButton = driver.findElements(ViewButton);
        int ButtonCount = TransfereeViewButton.size();
        actions.clickWebElementUsingJS(TransfereeViewButton.get(ButtonCount-1));
    }

    // Upload Document
    // RemoteWebElement Line has to be commented out to run locally but when pushing in code has to be uncommented
//    public void UploadDocumentForTransfer() {
//        WebElement Choosefile = driver.findElement(By.xpath("//input[@type='file']"));
//        // Has to be enabled while running on Grid if not in Driver Manager
//        //((RemoteWebElement)driver).setFileDetector(new LocalFileDetector());
//        // Path for Local Run
////        String FilePath = getPath();
////        Choosefile.sendKeys(FilePath);
//        // Path for Remote run
//        Choosefile.sendKeys("C:/Users/Surya.Radhakrishnan/Desktop/Selenium JARs/TestData/download.pdf");
//    }



    // Agent Select Type of Document in the Upload Doc Dialog
    public void AgentSelectDocumentTypeInDropdown(String DropdownName, String DocType) {
        By SearchParcelDropdowns = By.xpath("//mat-select[@id='"+DropdownName+"']");
        actions.clickUsingJS(SearchParcelDropdowns);
        actions.waitforSeconds(2);
        By DocumentType = By.xpath("//mat-option/span[contains(text(),'"+DocType+"')]");
        actions.clickUsingJS(DocumentType);
        actions.waitforSeconds(6);
    }

    // Agent Accept Terms and Conditions for Transfer
    public void AgentClickOnTermsAndConditionsCheckBoxForTransfers() {
        By CheckBox = By.xpath("//input[@type='checkbox']");
        actions.clickUsingJS(CheckBox);
    }

    private String TransferKeyText;

    // Agent Capture the Transfer Application Key
    public void AgentCaptureTransferKey() {
        By ApplicationKeyLink = By.xpath("//u[contains(@class,'ApplicationKey')]");
        TransferKeyText = driver.findElement(ApplicationKeyLink).getText();
        System.out.println(TransferKeyText);
    }

    // Agent Enter Text in Transferee Search Dialog
    public void AgentEnterTransferKeyInDialog(String Field) {
        By TextBox = By.xpath("//input[@formcontrolname='"+Field+"']");
        actions.sendKeys(TextBox,TransferKeyText);
    }
    // endregion

    //Staff will enter value in Text Box
    public void agentEnterValueInTextBox(String FieldName, String Value) throws InterruptedException {
        By FieldLocator = By.xpath("//input[@placeholder='"+FieldName+"']");
        driver.findElement(FieldLocator).clear();
        actions.sendKeys(FieldLocator, Value);
        Thread.sleep(3000);
    }
}

