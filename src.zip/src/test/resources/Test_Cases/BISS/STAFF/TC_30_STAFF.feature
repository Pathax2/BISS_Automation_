Feature: TC_S30 - Regression Pack for Openshift Amend Application Cases

  # ──────────────────────────────────────────────────────────────────────────
  # Purpose:
  #   Validates amendment submission and Force Majeure interaction for Openshift.
  #   Covers:
  #     - TC01: SIM-opted-in herd amendment submitted without scheme changes
  #     - TC02: Force Majeure toggled, navigate to Payments and back, verify no impact
  #
  # Common Background:
  #   Openshift staff login as agr4442 → open BISS application.
  #
  # DB Data:
  #   5 herds with Submission and SIM Opted In resolved from Oracle DB at runtime.
  #   Row 2 used in TC01, row 3 in TC02.
  #
  # Notes:
  #   1. TC01 verifies the amendment can be submitted (Next → Submit Changes)
  #      without changing any scheme selection, confirming no regression.
  #   2. TC02 checks if Force Majeure is already selected before toggling —
  #      this prevents flipping an active Force Majeure state unintentionally.
  #
  # Author  : Aniket Pathare | aniket.pathare@government.ie
  # Created : 2026-05-14
  # ──────────────────────────────────────────────────────────────────────────

  Background:
    Given the staff user is on the Openshift staff login page
    When the staff user logs in with username "agr4442"
    And the staff user selects the data protection checkbox and clicks login
    And the staff user opens the "Basic Income Support for Sustainability" application
    Then Get 5 Herds with Submission and SIM Opted In from DB

  @tmsLink=BISSAGL-18551 @tmsLink=BISSAGL-18553 @regression
  Scenario: TC_S30 - Openshift Amend Application end-to-end regression

    # ── TC01: SIM opted-in amendment submitted without scheme changes ─────────
    When the staff user opens herd with SIM opted in from row 2 for scheme year "2024" and submits the amendment without making any scheme changes
    Then the amendment should be submitted successfully

    # ── TC02: Force Majeure toggle — Payments navigation unaffected ───────────
    When the staff user opens herd with SIM opted in from row 3 for scheme year "2023" and views the application
    And the staff user navigates to Payments and back to BISS Application
    And the staff user checks the current Force Majeure state and toggles it if not already selected
    Then navigating to Payments should load correctly after the Force Majeure toggle