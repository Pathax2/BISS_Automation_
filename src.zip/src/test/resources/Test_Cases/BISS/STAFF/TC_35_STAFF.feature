Feature: TC_S35 - Regression Pack for Active Farmer System Notes in History Screen

  # ──────────────────────────────────────────────────────────────────────────
  # Purpose:
  #   Validates that system-generated notes are correctly recorded in the History
  #   tab after each Active Farmer admin check action. Covers:
  #     - TC01: Start admin check → History shows Stop Applied with correct comment
  #     - TC02: Approve admin check → History shows Stop Lifted with correct comment
  #     - TC03: Reject → appeal → upload document → approve → History shows Stop Lifted
  #
  # Common Background:
  #   Staff login as agr4442 → open BISS application.
  #
  # DB Data:
  #   5 herds with Admin Check Not Started resolved from Oracle DB at runtime.
  #   Row 2 used in TC01 and TC02. Row 4 used in TC03.
  #
  # Notes:
  #   1. The History tab entry text is verified verbatim — exact string matching
  #      is intentional to catch any wording regressions in the audit trail.
  #   2. TC01 and TC02 both use row 2. In practice TC02 assumes TC01 has
  #      already run and the herd is in an "In Progress" state.
  #      If running in isolation, ensure the admin check is started first.
  #   3. TC03 performs a full reject → appeal → document upload → approve cycle.
  #      The "Upload document" step opens the file upload dialog — the test
  #      framework uploads a predefined test document.
  #
  # Author  : Aniket Pathare | aniket.pathare@government.ie
  # Created : 2026-05-14
  # ──────────────────────────────────────────────────────────────────────────

  Background:
    Given the staff user is on the staff login page
    When the staff user logs in with username "agr4442"
    And the staff user selects the data protection checkbox and clicks login
    And the staff user opens the "Basic Income Support for Sustainability" application
    Then Get 5 Herds with Admin Check Not Started from DB

  @tmsLink=BISSAGL-14850 @tmsLink=BISSAGL-14842 @tmsLink=BISSAGL-14840 @regression
  Scenario: TC_S35 - Active Farmer System Notes in History Screen end-to-end regression

    # ── TC01: Start admin check — History should show Stop Applied ─────────
    When the staff user opens herd with admin check not started from row 2 for scheme year "2024" and navigates to the Active Farmer section
    And the staff user starts the admin check and sends the notification
    Then the History tab should contain the entry "Active Farmer Admin Check in Progress Stop has been Applied with comment: Admin check started manually"

    # ── TC02: Approve admin check — History should show Stop Lifted ──────────
    When the staff user opens herd with admin check not started from row 2 for scheme year "2024" and navigates to the Active Farmer section
    And the staff user approves the admin check with admin notes "Test Note"
    Then the History tab should contain the entry "Active Farmer Admin Check in Progress Stop has been Lifted with comment: Test Note"

    # ── TC03: Reject → appeal → upload document → approve — Stop Lifted ───────
    When the staff user opens herd with admin check not started from row 4 for scheme year "2024" and navigates to the Active Farmer section
    And the staff user starts the admin check and sends the notification
    And the staff user rejects the admin check with notes "Test Note" and starts the appeal process
    And the staff user uploads an appeal document and approves with notes "Appeal Approved"
    Then the History tab should contain the entry "Active Farmer Admin Check in Progress Stop has been Lifted with comment: Appeal Approved"