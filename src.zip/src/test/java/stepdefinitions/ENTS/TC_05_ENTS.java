// ===================================================================================================================================
// File          : TC_05_ENTS.java
// Package       : stepdefinitions.ENTS
// Description   : Step definitions for TC_05_ENTS - Transfer Application E2E (Agent to Individual).
//
//                 Only the steps unique to an Agent-to-Individual transfer live here. The difference from the
//                 agent-to-agent flow (TC_03_ENTS / TC_04_ENTS):
//                   - the transferee logs in with their OWN individual login (e.g. "PAUDYFROG"), not an agent login
//                   - a personal details dialog can be shown after the individual logs in
//                   - the individual opens "Transfers" from the farmer side navigation (no My Clients tab switch)
//                   - the individual sees the transfer on their own Transfers page, so there is no herd search
//
//                 Steps in this file (2):
//                   1. the agent logs out and re-logs in as the individual transferee {string}
//                   2. the individual completes the transferee acceptance flow (DataTable)
//
//                 Every other step of TC_05_ENTS.feature / TC_06_ENTS.feature is already defined:
//                   login / portal navigation / side navigation -> stepdefinitions.TC_03
//                   tab switching                               -> stepdefinitions.TC_06
//                   login as a named user                       -> stepdefinitions.ENTS.TC_08_ENTS
//                   create / upload / send / key / submit       -> stepdefinitions.ENTS.TC_01_ENTS
//                   transferor re-login between sections        -> stepdefinitions.ENTS.TC_03_ENTS
//
//                 Playwright edition (30-09-2026):
//                   - Same step texts, same ObjectRepository keys, same flow.
//                   - The copied login block (username, PIN loop, new-user Next screens, T&C, TOTP, Account Expired)
//                     is replaced by the shared EntsSession.loginAs / EntsSession.logout. loginAs also fills the
//                     mobile number form when Keycloak asks for it.
//                   - Account Expired: Selenium called Hooks.markAgentExpired for the BISS runtime agent (a different
//                     user) and logged in again as the same expired individual. loginAs now fails the step with the
//                     login in the message.
//                   - The personal details dialog is closed when shown (EntsSession.closePersonalDetailsIfShown). The
//                     Selenium notes mentioned it but the code never closed it.
//                   - The key comes from TC_01_ENTS.iCapturedTransferKey and is checked before it is typed.
//                   - Thread.sleep, WebDriverWait, findElement and the private isVisible are gone (Playwright waits).
//                   - The unused private handlePostLoginOTP() and the local performLogout() copy are gone.
//                   - Runtime data: the individual login is the token {transferee.login}, picked together with the
//                     transferee herd from the Individual Login query (utilities.EntsTestData.nextAgentToIndividualPair).
//                     A plain login such as "PAUDYFROG" still works, to pin a user for debugging.
//
// Author        : Aniket Pathare | aniket.pathare@government.ie
// Date Created  : 31-03-2026 | Updated: 30-09-2026 (Playwright + runtime ENTS data)
// ===================================================================================================================================

package stepdefinitions.ENTS;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;
import org.junit.jupiter.api.Assertions;
import utilities.ConfigManager;
import utilities.EntsTestData;

import java.util.Map;
import java.util.logging.Logger;

public class TC_05_ENTS
{
    private static final Logger log = Logger.getLogger(TC_05_ENTS.class.getName());


    // ===================================================================================================================================
    //  INDIVIDUAL LOGIN - log out of the agent session, log in as the individual
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent logs out and re-logs in as the individual transferee {string}
    // Description   : Logs out of the current session and logs in as the individual transferee:
    //                   username -> Continue -> password (TD:Password) -> Login -> PIN / mobile number / TOTP / T&C,
    //                   or OTP only (EntsSession.loginAs, same sequence as the Selenium copy).
    //                 Then closes the personal details dialog when it is shown (waits up to ents.personal.details.seconds,
    //                 default 5).
    // Parameters    : pUsername (String) - individual login, e.g. "PAUDYFROG", or {transferee.login}
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 30-09-2026 (Playwright, shared login)
    // ***************************************************************************************************************************************************************************************
    @When("the agent logs out and re-logs in as the individual transferee {string}")
    public void theAgentLogsOutAndReLogsInAsTheIndividualTransferee(String pUsername)
    {
        String iUsername = EntsTestData.resolve(pUsername);
        log.info("[STEP] When the agent logs out and re-logs in as the individual transferee: " + iUsername);

        Assertions.assertFalse(iUsername == null || iUsername.isEmpty(),
                "No individual login to use. Give a login in the feature file or use {transferee.login} after the create step.");

        EntsSession.logout();
        EntsSession.loginAs(iUsername, "[LOGIN-INDIVIDUAL]");
        EntsSession.closePersonalDetailsIfShown(ConfigManager.getInt("ents.personal.details.seconds", 5));

        log.info("Logged in as the individual transferee: " + iUsername);
    }


    // ===================================================================================================================================
    //  INDIVIDUAL TRANSFEREE ACCEPTANCE
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the individual completes the transferee acceptance flow (DataTable)
    // Description   : The individual is on their own Transfers page (side navigation step), so there is no herd search.
    //                 The screens themselves are EntsSession.acceptWithTransferKey (ETF button or View, key, notes,
    //                 Submit Application to DAFM, T&C, confirm), shared with TC_07 and TC_08.
    //
    //                 DataTable keys:
    //                   transfereeHerd (String) - herd number, or {transferee.herd} (log only - no search on this page)
    //                   notes          (String) - transferee notes, e.g. "Approved Test"
    //
    //                 Depends on the key captured by TC_01_ENTS "the transfer key should be captured".
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 30-09-2026 (Playwright + runtime ENTS data)
    // ***************************************************************************************************************************************************************************************
    @And("the individual completes the transferee acceptance flow")
    public void theIndividualCompletesTheTransfereeAcceptanceFlow(DataTable pDataTable)
    {
        log.info("[STEP] And the individual completes the transferee acceptance flow");

        Map<String, String> iData = EntsTestData.resolveTable(pDataTable.asMap(String.class, String.class));

        String iTransfereeHerd = iData.getOrDefault("transfereeHerd", "").trim();
        String iNotes          = iData.get("notes").trim();
        String iTransferKey    = TC_01_ENTS.iCapturedTransferKey;

        Assertions.assertFalse(iTransferKey == null || iTransferKey.isEmpty(), "Transfer key must have been captured in the Transferor flow before the individual can accept.");

        EntsSession.acceptWithTransferKey(iTransferKey, iNotes);

        log.info("Individual transferee acceptance completed for herd: " + iTransfereeHerd + " | login=" + EntsTestData.loggedInUser());
    }
}