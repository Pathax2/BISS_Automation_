package com.stepdefinitions;

import com.base.ConfigReader;
import com.base.DriverManager;
import com.pages.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

public class NRCISYFSteps {


        LoginPage loginPage;
        BPSdashboardPage bpsdashboardPage;
        NRCISYFPage nrcisyfPage;
        WebDriver driver;
        Properties prop;
        ConfigReader configReader;
        DriverManager driverManager;
        DatabaseQueriesPage databaseQueriesPage;
        MyClientsPage myClientsPage;

        public NRCISYFSteps(DriverManager driverManager){
            try {
//            driver = driverManager.getDriver();
                this.driverManager=driverManager;
                driver=driverManager.getDriverInstance();
                loginPage = new LoginPage(driver);
                bpsdashboardPage = new BPSdashboardPage(driver);
                nrcisyfPage = new NRCISYFPage(driver);
                configReader = new ConfigReader();
                prop = configReader.init_prop();
                databaseQueriesPage = new DatabaseQueriesPage(driver);
                myClientsPage = new MyClientsPage(driver);
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }


    // region ENTS Steps
    @And("Agent Check if {string} is NRCISYF close date")
    public void AgentCheckNRCISYFCloseDate(String Date) throws InterruptedException {
            Assert.assertEquals(nrcisyfPage.AgentCheckNRCISYFClosingDate(),Date);
            Thread.sleep(2000);
    }

    @Then("Agent Click on the NRCISYF {string} button")
    public void AgentClickOnNRCISYFButton(String Button) throws InterruptedException {
        nrcisyfPage.AgentClickOnButton(Button);
        Thread.sleep(4000);
    }

    @Then("Agent Click on the NRCISYF Apply or Edit button")
    public void AgentClickOnNRCISYFEntryButton() throws InterruptedException {
        nrcisyfPage.AgentClickOnNRCISYFApplyOrEditButton();
        Thread.sleep(4000);
    }

    @Then("Agent Click on the NRCISYF Stepper {string} button")
    public void AgentClickOnNRCISYFStepperButton(String Button) throws InterruptedException {
        nrcisyfPage.AgentClickOnNRCISYFButton(Button);
        Thread.sleep(5000);
    }

    @Then("Agent Click on the NRCISYF Close button")
    public void AgentClickOnNRCISYFCloseButton() throws InterruptedException {
        nrcisyfPage.AgentClickOnCloseButton();
        Thread.sleep(4000);
    }

    @And("Agent Select {string} {string} CheckBox Option in the Dialog")
    public void AgentSelectCheckBox(String labelNumber,String Option) throws InterruptedException {
         nrcisyfPage.AgentSelectCheckBox(labelNumber, Option);
         Thread.sleep(2000);
    }

    @And("Agent Check Status of Eligible Framer CheckBox {string} and Tick")
    public void EligibleFarmerCheckBoxSelect(String CheckBoxNumber) {
            nrcisyfPage.AgentCheckEligibleFarmerCheckBox(CheckBoxNumber);
    }

    @And("Agent Check Status of {string} CheckBox Option in the Dialog and Select")
    public void AgentCheckCategoryStatusAndSelectCheckBox(String Option) throws InterruptedException {
        nrcisyfPage.AgentSelectCategorySelectionCheckBoxStatusAndClick(Option);
        Thread.sleep(2000);
    }

    @And("Agent Select the Farming Entity dropdown value as {string}")
    public void AgentSelectFarmingEntityDropdownValue(String Value) {
            nrcisyfPage.AgentSelectFarmingEntityDropdownValue(Value);
    }


    @And("Agent Select the Herd Group Type dropdown value as {string}")
    public void AgentSelectHerdGroupTypeDropdownValue(String Value) throws InterruptedException {
            Thread.sleep(2000);
        nrcisyfPage.AgentSelectHerdGroupTypeDropdownValue(Value);
    }

    @And("Agent Select the Number of Members dropdown value as {string}")
    public void AgentSelectNumberOfMembersDropdownValue(String Value) throws InterruptedException {
        Thread.sleep(2000);
        nrcisyfPage.AgentSelectGroupMembersDropdownValue(Value);
    }



    @And("Agent Select the Number of Members for Joint HerdOwner dropdown value as {string}")
    public void AgentSelectNumberOfMembersJHDropdownValue(String Value) throws InterruptedException {
        Thread.sleep(2000);
        nrcisyfPage.AgentSelectGroupMembersJHDropdownValue(Value);
        Thread.sleep(2000);
    }

    @And("Agent Select {string} option for the {string} Question")
    public void AgentClickOnYesOrNoRadioOption(String Question, String Radiochoice) throws InterruptedException {
            Thread.sleep(2000);
            nrcisyfPage.AgentSelectRadioButtonChoice(Radiochoice, Question);
            Thread.sleep(2000);
    }


    @And("Agent Select {string} option on Status Page for the {string} Question")
    public void AgentClickOnStatusPageRadioOption(String Question, String Radiochoice) throws InterruptedException {
        nrcisyfPage.AgentSelectStatusPageRadioButtonChoice(Radiochoice, Question);
        Thread.sleep(3000);
    }

    @Then("Agent Enter Date of completion as {string}")
    public void AgentEnterDateOfCompletion(String Date) throws InterruptedException {
            nrcisyfPage.AgentEnterDateOfCompletion(Date);
        Thread.sleep(2000);
    }

    @Then("Agent Enter Date of Birth in DatePicker {int} as {string} {string} {string}")
    public void AgentEnterDateOfBirth(int DatePickerNumber, String Date, String Month, String Year) {
        nrcisyfPage.AgentEnterNewDateOfBirth(DatePickerNumber,Date, Month, Year);
    }

    @And("Agent Select Value as {string} for the {string} dropdown")
    public void AgentSelectOptionFromDropdown(String Value, String Dropdown) {
            nrcisyfPage.AgentSelectDropdownValue(Value, Dropdown);
    }

    @Then("Agent Click on the {string} Upload Button")
    public void AgentClickOnSummaryUploadButton(String DocType) {
            nrcisyfPage.AgentClickOnSummaryDocUploadButton(DocType);
    }

    @And("Upload Document for NRCISYF")
    public void AgentUploadDocumentForNRCISYF() throws InterruptedException {
        nrcisyfPage.UploadDocumentForNRCISYF();
        Thread.sleep(2000);
    }

    @And("Upload Wrong Document Format for NRCISYF")
    public void AgentUploadWrongDocumentForNRCISYF() throws InterruptedException {
        nrcisyfPage.UploadWrongDocumentForNRCISYF();
        Thread.sleep(2000);
    }

    @Then("Agent Click on Info Button {string} from Category Dialog")
    public void AgentClickOnCategoryInfo(String Info) throws InterruptedException {
            nrcisyfPage.AgentClickOnCategoryInfoButton(Info);
            Thread.sleep(3000);
    }

    @And("Agent Check Error Message for B")
    public void AgentCheckErrorMessageforB() {
            Assert.assertEquals(nrcisyfPage.IndividualCheckErrorMessage()," You may not select 'B. National Reserve (as New Farmer)' with 'A. National Reserve (as Young Farmer)'. Please uncheck category A before selecting this. ");
    }

    @And("Agent Check Error Message for A")
    public void AgentCheckErrorMessageforA() {
        Assert.assertEquals(nrcisyfPage.IndividualCheckErrorMessage()," You may not select 'A. National Reserve (as Young Farmer)' with 'B. National Reserve (as New Farmer)'. Please uncheck category B before selecting this. ");
    }

    @Then("Agent Click on checkbox {int} in the Submission Declaration dialog")
    public void IndividualClickOnCheckBox(int CheckBox) {
            nrcisyfPage.IndividualClickOnCheckboxInSubmissionDeclaration(CheckBox);
    }

    @And("Agent Click On {string} Button in Dialog Box")
    public void AgentClickOnButtonInDialog(String Button) {
            nrcisyfPage.AgentClickOnButtonInDialog(Button);
    }

    @And("Agent Click On NRCISYF {string} Button in Dialog Box")
    public void AgentClickOnButtonInNRCISYFDialog(String Button) {
            nrcisyfPage.AgentClickOnButtonInNRCISYFDialog(Button);
    }

    @Then("Agent click on {string} Navbar Button")
    public void AgentClickOnNavBarButton(String Button) {
            bpsdashboardPage.AgentClickOnDashboardSidenavElements(Button);
    }

    @Then("Agent Check Covid Message")
    public void AgentCheckCovidMessage() {
            nrcisyfPage.AgentCheckCovidMessageOnEducationPage();
    }

    @And("Agent Click On {string} Document Link")
    public void AgentClickOnDocumentLink(String DocType) {
            nrcisyfPage.AgentClickOnDocLinkInViewApplicationScreen(DocType);
    }

    @Then("Agent Enter Value as {string} in the {string} field")
    public void AgentEnterCollegeNameNotInList(String Value, String FieldName) {
            nrcisyfPage.AgentEnterCollegeNameNotInList(FieldName, Value);
    }

    @And("Agent Verify if {string} is Educational Institution")
    public void AgentCheckEducationalInstitution(String College) {
            Assert.assertEquals(nrcisyfPage.AgentCheckEducationInstitutionDetails(),College);
    }

    @And("Agent Verify if {string} is Qualification")
    public void AgentCheckQualification(String Qualification) {
        Assert.assertEquals(nrcisyfPage.AgentCheckEducationQualificationDetails(),Qualification);
    }

    @Then("Agent Enter Value as {string} in field {string}")
    public void AgentEnterValueInCompanyFields(String Value, String Field) {
            nrcisyfPage.AgentEnterValuesInCompanyFields(Value, Field);
    }

    @When("Agent Enter Value as Herd Number with no NR_CISYF submission from row {int} in the {string} field")
    public void agentEnterValueAsHerdNumberWithNoNRCISYFSubmissionFromRowInTheField(int Value, String FieldName) throws IOException, InterruptedException {
        String HerdWithNoSubmission = "./src/main/resources/TestData/Herd With No NRCISYF Submission.xls";
        nrcisyfPage.agentEnterValueInTextBox(FieldName, databaseQueriesPage.getHerdNumberFromSpecifiedFile(Value,HerdWithNoSubmission));

    }

    @And("Uncheck all options in the Dialog box")
    public void uncheckAllOptionsInTheDialogBox() throws InterruptedException {
        nrcisyfPage.agentUnchecksAllOptions();
    }

//    @And("Get agent of row {int} from Herd List and put in the {string} field in login page")
//    public void getAgentsFromDataBase(int agent, String FieldName) throws InterruptedException, SQLException, IOException {
//        // myclientsPage.agentUsername(FieldName,databaseQueriesPage.runQueryForAgents(agent));
//
//        String agentWithNoSubmission = "./src/main/resources/TestData/Agent of Herd With No NRCISYF Submission.xls";
//        myClientsPage.agentUsername(FieldName, databaseQueriesPage.getAgentNumberFromSpecifiedFile(agent,agentWithNoSubmission));
//        //nrcisyfPage.agentEnterValueInTextBox(FieldName, databaseQueriesPage.getHerdNumberFromSpecifiedFile(agent,agentWithNoSubmission));
//
//    }
    // endregion
}
