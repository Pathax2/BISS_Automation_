Feature: TC_23_ENTS - Verify Appeal submission for Category C

  # --------------------------------------------------------------------------------------------------------------------
  # Purpose:
  #   One NR/CISYF application for Category C - Complementary Income Support for Young Farmers, Individual, submitted by the agent, followed by an Appeal.
  #
  #   Flow: My Clients -> NR/CISYF tab -> open the herd -> Apply -> categories -> farming entity -> qualification ->
  #         summary + documents -> declaration -> submit -> Appeal.
  #
  # Test data (02-10-2026):
  #   The herd and its agent come from utilities.NrcisyfTestData (Hooks @tc13): vault pool ENTS_YOUNG_FARMER filled by
  #   TC_00_DATA from Simon's "ENTS Young Farmer herds" query, else the live query, else the Selenium BISS lookup.
  #   One herd per application - the herd is marked USED in the vault after the submission.
  #
  # Step reuse:
  #   Login / navigation / tabs                        -> stepdefinitions.TC_03, TC_06
  #   NR/CISYF steps                                   -> stepdefinitions.ENTS.TC_13_ENTS
  #   Validate if Appeal can be made sucessfully       -> stepdefinitions.ENTS.TC_01_ENTS
  #
  # Author : Aniket Pathare | aniket.pathare@government.ie
  # Created: 31-03-2026 | Updated: 02-10-2026 (header, Young Farmer data)
  # --------------------------------------------------------------------------------------------------------------------

  Background:
    Given the agent user is on the login page
    When the agent logs into the application with valid credentials and OTP
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "NR/CISYF" tab on the My Clients page

  @regression @nrcisyf @appeal @tc13
  Scenario: AT-ENTS-Appeal-E2E - Verify Appeal submission for Category C

    And the agent searches for the NRCISYF herd and opens the application
    And the agent opens the NRCISYF Apply or Edit dialog
    And the agent resets all category selections
    And the agent selects NRCISYF categories
      | C. Complementary income Support for Young Farmers |
    And the agent proceeds past the category selection

    And the agent selects farming entity "Individual"
    And the agent proceeds to the qualification step
    When the agent completes the qualification details
      | hasQualification   | Yes                             |
      | dateOfCompletion   | 01/01/2026                      |
      | certificateAwarded | Yes                             |
      | college            | Athlone Institute of Technology |
      | qualification      | FETAC Certificate in Farming    |

    And the agent proceeds to the summary step
    When the agent uploads NRCISYF documents
      | Upload Invoice/Receipt                                             |
      | Upload Bank Statement Extract with Invoice/Receipt Passing through |
      | Qualifications certificate or Confirmation of Education Form       |
      | Personal and Sensitive Documentation                               |

    And the agent saves and proceeds to the declaration step
    And the agent submits the NRCISYF application with declaration
    Then the NRCISYF application should be submitted successfully
    And Validate if Appeal can be made sucessfully