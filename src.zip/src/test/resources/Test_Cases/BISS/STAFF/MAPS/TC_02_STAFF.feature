  # ====================================================================================================================================
# TC_02_STAFF.feature
# ====================================================================================================================================
  @maps @regression @staff
  Feature: TC_02_STAFF - Map Printing by Parcel Number

  # Migrated from legacy "Regression Suite for Map Printing with Parcel"
  # (AT-TC-01, 02, 04, 05, 07-14). Legacy AT-TC-03 and AT-TC-06 were commented out as
  # depleted cases and are not carried forward.
  #
  # BUSINESS FLOW
  #   An internal map printing user searches by LPIS parcel rather than herd, selects a map
  #   layout - either a preset (Ortho / Inspection Discovery) or a custom composition of
  #   imagery, raster and vector layers - and requests generation. Every field required by
  #   the chosen layout must be enforced before generation is allowed.
  #
  # WHAT THIS VALIDATES
  #   1. Preset and custom layouts both generate, at A3 and A4, for single and all parcels.
  #   2. Each mandatory selection raises its own error when omitted: parcel number, parcel
  #      selection, map type, imagery layer, vector layer.
  #   3. The Map Printing tab is not visible to a non-internal user.


  Background:
  Given the staff user is logged in to the BISS internal portal as "agr11612"
  And the staff user is on the Map Printing screen


  @e2e @map-generation @validation
  Scenario: Staff generates parcel maps across layouts and is blocked on every missing field

    # SECTION 1 - AT-TC-01 (BISSAGL-14997)
    # Validates: the Inspection Discovery preset generates for a single parcel.
  When the staff user searches Map Printing for the next submitted herd for scheme year "2024"
  And the staff user requests a map with the following settings
  | parcels | single               |
  | mapType |Inspection Discovery A4|
  | legend  | yes                  |
  Then the map generation request should be accepted

    # SECTION 2 - AT-TC-02 (BISSAGL-14996)
    # Validates: a custom layout generates when imagery, raster and vector are all supplied.
  When the staff user searches Map Printing for the next submitted herd for scheme year "2024"
  And the staff user requests a map with the following settings
  | parcels | single               |
  | mapType | Custom Layer A4      |
  | imagery | 2009 Low Flown Ortho |
  | raster  | Raster 1:5000        |
  | vector  | default              |
  Then the map generation request should be accepted

    # SECTION 3 - AT-TC-04 (BISSAGL-14993)
    # Validates: the Full Colour Ortho A4 preset generates for a single parcel.
  When the staff user searches Map Printing for the next submitted herd for scheme year "2024"
  And the staff user requests a map with the following settings
  | parcels | single              |
  | mapType | Full Color Ortho A4 |
  | legend  | yes                 |
  Then the map generation request should be accepted

    # SECTION 4 - AT-TC-05 (BISSAGL-14988)
    # Validates: the parcel number is mandatory when searching by parcel.
  When the staff user searches Map Printing with no parcel number
  Then the staff user should see the validation error "Parcel number required."

    # SECTION 5 - AT-TC-07 (BISSAGL-14986)
    # Validates: A3 generates across all parcels returned by a parcel search - the multi
    # parcel path at a different page size from Section 3.
  When the staff user searches Map Printing for the next submitted herd for scheme year "2024"
  And the staff user requests a map with the following settings
  | parcels | all                 |
  | mapType | Full Color Ortho A3 |
  | legend  | yes                 |
  Then the map generation request should be accepted

    # SECTION 6 - AT-TC-08 (BISSAGL-14983)
    # Validates: a custom layout generates across all parcels, combining the custom-layer
    # path of Section 2 with the all-parcels path of Section 5.
  When the staff user searches Map Printing for the next submitted herd for scheme year "2024"
  And the staff user requests a map with the following settings
  | parcels | all                  |
  | mapType | Custom Layer A4      |
  | imagery | 2008 Low Flown Ortho |
  | raster  | Raster 1:5000        |
  | vector  | default              |
  Then the map generation request should be accepted

    # SECTION 7 - AT-TC-09 (BISSAGL-14982)
    # Legacy carries the note "Fix case by next week" and has NO assertion - it searches a
    # future scheme year and stops. The intended check ("no results warning") is commented
    # out in legacy. Reproduced as a search only; the warning assertion needs writing.
  When the staff user searches Map Printing for the next submitted herd for scheme year "2025"

    # SECTION 8 - AT-TC-10 (BISSAGL-14981)
    # Validates: opening and dismissing the parcel selector without choosing a parcel
    # raises the selection error.
  When the staff user searches Map Printing for the next submitted herd for scheme year "2024"
  And the staff user opens and dismisses the "parcelSelect" selector without choosing a value
  Then the staff user should see the validation error "select a parcel required"

    # SECTION 9 - AT-TC-11 (BISSAGL-14980)
    # Validates: with a parcel chosen, dismissing the map type selector raises its error.
  When the staff user searches Map Printing for the next submitted herd for scheme year "2024"
  And the staff user requests a map with the following settings
  | parcels | single |
  And the staff user opens and dismisses the "mapTypeSelect" selector without choosing a value
  Then the staff user should see the validation error "select a map type required"

    # SECTION 10 - AT-TC-12 (BISSAGL-14979)
    # Validates: a custom layout requires an imagery layer - dismissing it raises its error.
  When the staff user searches Map Printing for the next submitted herd for scheme year "2024"
  And the staff user requests a map with the following settings
  | parcels | single          |
  | mapType | Custom Layer A4 |
  And the staff user opens and dismisses the "imagerySelect" selector without choosing a value
  Then the staff user should see the validation error "select an imagery layer required"

    # SECTION 11 - AT-TC-13 (BISSAGL-14978)
    # Validates: a custom layout requires a vector layer even once imagery is chosen.
  When the staff user searches Map Printing for the next submitted herd for scheme year "2024"
  And the staff user requests a map with the following settings
  | parcels | single               |
  | mapType | Custom Layer A4      |
  | imagery | 2009 Low Flown Ortho |
  And the staff user opens and dismisses the "vectorSelect" selector without choosing a value
  Then the staff user should see the validation error "select a vector layer required"

    # SECTION 12 - AT-TC-14 (BISSAGL-14977)
    # Validates: Map Printing is restricted by role - a non-internal user cannot see the tab.
  When the staff user re-logs in to the BISS internal portal as "agr5033"
  Then the staff user should not have access to the "Map Printing" tab