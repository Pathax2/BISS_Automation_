Feature: TC_S34 - Regression Pack for AMS Internal Screen Status Display Rules

  # ──────────────────────────────────────────────────────────────────────────
  # Purpose:
  #   Validates the rules governing AMS status display on the AMS internal screen.
  #   Covers:
  #     - TC01: Parcel No column header sort toggle works correctly for a SIM Opted In herd
  #
  # Common Background:
  #   Staff login as agr4442 → open BISS application.
  #
  # DB Data:
  #   10 herds with Submission and SIM Opted In resolved from Oracle DB at runtime.
  #   Row 1 used for TC01.
  #
  # Notes:
  #   1. The Parcel No header is clicked twice to verify both ascending and
  #      descending sort toggling without errors.
  #   2. SIM Opted In herds are specifically required because the AMS status
  #      rules apply differently for herds with active SIM participation.
  #
  # Author  : Aniket Pathare | aniket.pathare@government.ie
  # Created : 2026-05-14
  # ──────────────────────────────────────────────────────────────────────────

  Background:
    Given the staff user is on the staff login page
    When the staff user logs in with username "agr4442"
    And the staff user selects the data protection checkbox and clicks login
    And the staff user opens the "Basic Income Support for Sustainability" application
    Then Get 10 Herds with Submission and SIM Opted In from DB

  @tmsLink=BISSAGL-14749 @regression
  Scenario: TC_S34 - AMS Status Display Rules end-to-end regression

    # ── TC01: Parcel No column sort toggle for a SIM Opted In herd (row 1) ───
    When the staff user opens herd with SIM opted in from row 1 for scheme year "2024" and navigates to the AMS Inspections tab
    And the staff user clicks the Parcel No column header to sort ascending
    And the staff user clicks the Parcel No column header again to sort descending
    Then the AMS table sort should toggle correctly without errors