// ===================================================================================================================================
// File          : Hooks.java
// Package       : stepdefinitions
// Description   : Cucumber lifecycle hooks - PLAYWRIGHT edition.
//
//                 Changes versus the Selenium Hooks:
//                   - killProcessByName("chrome"/"chromedriver") moved to utilities.BrowserProcessCleaner, called by
//                     PlaywrightFactory before every launch (browser.cleanup.before.start; skipped in containers)
//                   - Browser launched through CommonFunctions.launchBrowser -> PlaywrightFactory
//                   - URL can be overridden with -Dapp.url / BISS_APP_URL (container network names differ)
//                   - DB herd bootstrap can be switched off with -Ddb.bootstrap=false / BISS_DB_BOOTSTRAP=false
//                     (sheet values are used - needed for TC_01 POC and for containers without Oracle access)
//                   - Failure screenshot is also attached to the Cucumber scenario (visible in Cucumber HTML report)
//                   - Playwright trace zip kept for failed test cases (Test_Report/traces)
//                   - ReportManager.setWordDocPath(...) call removed (method does not exist in ReportManager)
//                   - All DB resolution logic (@preliminary, @tc13, markAgentExpired, blacklist) UNCHANGED
//
// Author        : Aniket Pathare | aniket.pathare@government.ie
// Date Created  : 10-03-2026
// Updated       : 15-09-2026 - Selenium to Playwright migration
// Updated       : 18-09-2026 - [TIMING] line per test case: setup (DB, cleanup, browser), scenarios, teardown
// Updated       : 17-09-2026 - Fail-fast: after a failed scenario the rest of the test case is skipped (execution.fail.fast)
//                              Word report / ReportIndex status now follows the Cucumber result
// Updated       : 25-09-2026 - Individual end-to-end (TC_03_IND): test case IDs containing "_IND" take the herd from
//                              DATA "List of not started individual herds with CISYF flag" and the login from
//                              INET "Get Individual Login for herd". markAgentExpired re-resolves an individual pair too.
// Updated       : 01-10-2026 - Test Data Vault (utilities.TestDataVault, filled by TC_00_DATA):
//                                - the BISS herd + login come from the vault first (pool BISS_NOT_STARTED / BISS_IND_CISYF);
//                                  the DATA + INET lookup below runs only when the vault has nothing for the test case
//                                - the vault row is marked USED when the test case passes, BAD when it fails
//                                - markAgentExpired marks the login EXPIRED in the vault and takes the next vault row
//                                - test case IDs containing "_DATA" (TC_00_DATA) open no browser, read no TestData.xlsx
//                                  row and write no Word report
// ===================================================================================================================================

package stepdefinitions;

import commonFunctions.CommonFunctions;
import io.cucumber.java.After;
import io.cucumber.java.AfterAll;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.Scenario;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import reporting.ReportManager;
import utilities.ConfigManager;
import utilities.ExcelUtilities;
import utilities.RetryAnalyser;
import utilities.ScreenshotManager;
import utilities.SoftAssertManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.Set;

public class Hooks
{
    public static XWPFDocument iDocument    = null;
    public static String       iDocPath     = null;
    public static String       iTestCaseID  = null;
    public static String       iEnvironment = null;
    public static String       iUrl         = null;
    private static final StringBuilder iAccumulatedErrors  = new StringBuilder();
    private static String              iLastScreenshotPath = "";
    private static long                iScenarioStartTime  = 0L;
    private static boolean             iAnyScenarioFailed  = false;
    private static String              iFirstFailedScenario = "";
    private static long                iTestCaseStartMs      = 0L;
    private static long                iSetupMs              = 0L;
    private static long                iScenarioMs           = 0L;
    private boolean                    iSkippedByFailFast   = false;

    private static final String iTestDataFilePath  = ConfigManager.getOrDefault("test.data.file.path", "src/test/resources/Test_Data/TestData.xlsx");
    private static final String iTestDataSheetName = ConfigManager.getOrDefault("test.data.sheet.name", "Data");
    private static final String iConfigSheetName   = "Config";
    private static final String iDefaultBrowser    = "CHROME";

    // Standard runtime herd / username (used by TC_03 through TC_17)
    public static String RUNTIME_HERD     = null;
    public static String RUNTIME_USERNAME = null;

    // Preliminary Checks runtime data (used by TC_18, TC_19, TC_20)
    public static String OVERCLAIM_HERD         = null;
    public static String OVERCLAIM_USERNAME     = null;
    public static String DUAL_CLAIM_HERD        = null;
    public static String DUAL_CLAIM_USERNAME    = null;
    public static String AGRI_ACTIVITY_HERD     = null;
    public static String AGRI_ACTIVITY_USERNAME = null;

    // TC_13 NRCISYF runtime data
    public static String CISYF_HERD     = null;
    public static String CISYF_USERNAME = null;

    // Blacklisted herds - re-fetch if we land on one of these
    public static final Set<String> BLACKLISTED_HERDS = Set.of(
            "R1230577","C2280025","C1281036","Q1060377","M1391623","M1701886","D1160614",
            "X1120993","P1261051","E209434X","D1174054","H2621144","B1240361","G1930639",
            "G194082X","B1560048","R1050781","D201078X","M1952021","W1040563","J1770847","J1710089","B1150150",
            "B1380562","C129112X","G1221786","T209028X","A1030615","T1790688","G1280928","G1930167",
            "Y1070492","Y1791564","R1040514","C1430554","C1289029","D4040032","B1014078","D2450985"
    );

    // Expired agents - populated at runtime when "Account Expired" is detected on screen
    public static final Set<String> EXPIRED_AGENTS = new HashSet<>();

    private static boolean isDbBootstrapEnabled()
    {
        // ENTS test cases log in with the users named in the feature file and get their herds from
        // utilities.EntsTestData, so the BISS herd + agent lookup (DATA + INET) is skipped for them by default.
        if (isEntsTestCase())
        {
            return ConfigManager.getBool("db.bootstrap.ents", false);
        }
        return ConfigManager.getBool("db.bootstrap", true);
    }

    // True for ENTS test case IDs, e.g. TC_01_ENTS
    private static boolean isEntsTestCase()
    {
        return iTestCaseID != null && iTestCaseID.toUpperCase(java.util.Locale.ROOT).contains("_ENTS");
    }

    // True for individual end-to-end test case IDs, e.g. TC_03_IND - the herd owner logs in, not an agent
    private static boolean isIndividualTestCase()
    {
        return iTestCaseID != null && iTestCaseID.toUpperCase(java.util.Locale.ROOT).contains("_IND");
    }

    // True for the data extraction test case (TC_00_DATA): no browser, no TestData.xlsx row, no Word report
    private static boolean isDataTestCase()
    {
        return iTestCaseID != null && iTestCaseID.toUpperCase(java.util.Locale.ROOT).contains("_DATA");
    }

    // The vault row the BISS herd came from ("" when it came from the live DB lookup or the sheet)
    private static String iVaultHerd = "";

    // ***************************************************************************************************************************************************************************************
    // Function Name : takeFromVault
    // Description   : Takes the BISS herd + login for this test case from the Test Data Vault (filled by TC_00_DATA).
    //                 Pool BISS_IND_CISYF for individual test cases, BISS_NOT_STARTED otherwise; key = herd.year.
    //                 Blacklisted herds and EXPIRED_AGENTS logins are skipped. Returns false when the vault is off,
    //                 empty for this pool or has nothing usable left - the caller then runs the live lookup as before.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 01-10-2026
    // ***************************************************************************************************************************************************************************************
    private static boolean takeFromVault()
    {
        if (!utilities.TestDataVault.isEnabled()) return false;

        String iPool = isIndividualTestCase() ? utilities.TestDataVault.POOL_BISS_IND_CISYF : utilities.TestDataVault.POOL_BISS_NOT_STARTED;
        String iYear = System.getProperty("herd.year", "2026").trim();

        if (!utilities.TestDataVault.hasPool(iPool, iYear))
        {
            CommonFunctions.log.info("[BOOT] Vault has no pool " + iPool + "/" + iYear + " (run TC_00_DATA first) - using the live DB lookup.");
            return false;
        }

        utilities.TestDataVault.Row iRow = utilities.TestDataVault.reserve(iPool, iYear, BLACKLISTED_HERDS, EXPIRED_AGENTS, iTestCaseID, "BISS bootstrap");
        if (iRow == null)
        {
            CommonFunctions.log.warning("[BOOT] Vault pool " + iPool + "/" + iYear + " has no available row left - using the live DB lookup.");
            return false;
        }

        RUNTIME_HERD     = iRow.herd;
        RUNTIME_USERNAME = iRow.login;
        iVaultHerd       = iRow.herd;
        System.setProperty("TD:HerdNumber", RUNTIME_HERD);
        System.setProperty("TD:Username",   RUNTIME_USERNAME);
        CommonFunctions.log.info("[BOOT] From vault: Herd=" + RUNTIME_HERD + " | Username=" + RUNTIME_USERNAME + " (" + iPool + ")");
        return true;
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : markAgentExpired
    // Description   : Adds the agent to EXPIRED_AGENTS and re-resolves a fresh herd+agent pair (unchanged logic).
    // Parameters    : pExpiredUsername - the agent username that showed Account Expired
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 05-05-2026
    // ***************************************************************************************************************************************************************************************
    public static void markAgentExpired(String pExpiredUsername)
    {
        if (pExpiredUsername == null || pExpiredUsername.isBlank()) return;

        EXPIRED_AGENTS.add(pExpiredUsername.trim());
        CommonFunctions.log.warning("[EXPIRED-AGENT] SSO Account Expired detected for: "
                + pExpiredUsername + " - added to EXPIRED_AGENTS. Re-resolving herd+agent.");

        // NR/CISYF (@tc13, 02-10-2026): the replacement must be another Young Farmer herd + its agent, not a BISS herd.
        // Before this, an expired NR/CISYF agent was replaced by a BISS herd and CISYF_HERD kept the old agent's herd.
        if (CISYF_HERD != null && CISYF_USERNAME != null && CISYF_USERNAME.trim().equalsIgnoreCase(pExpiredUsername.trim()))
        {
            if (utilities.TestDataVault.isEnabled())
            {
                utilities.TestDataVault.markLoginExpired(pExpiredUsername, "Account Expired on the Keycloak login page");
                utilities.TestDataVault.markBad(CISYF_HERD, "agent " + pExpiredUsername + " expired");
            }
            String[] iNext = utilities.NrcisyfTestData.nextHerd("", BLACKLISTED_HERDS, EXPIRED_AGENTS, "agent expired");
            if (iNext != null)
            {
                CISYF_HERD       = iNext[0];
                CISYF_USERNAME   = iNext[1];
                RUNTIME_HERD     = iNext[0];
                RUNTIME_USERNAME = iNext[1];
                CommonFunctions.log.info("[EXPIRED-AGENT] Next Young Farmer herd: " + CISYF_HERD + " | agent=" + CISYF_USERNAME);
                return;
            }
            CommonFunctions.log.warning("[EXPIRED-AGENT] No Young Farmer herd left - using the BISS lookup below (Selenium behaviour).");
        }

        // Vault: remember the expired login, give the current row back as BAD and take the next one
        if (utilities.TestDataVault.isEnabled())
        {
            utilities.TestDataVault.markLoginExpired(pExpiredUsername, "Account Expired on the Keycloak login page");
            if (!iVaultHerd.isEmpty())
            {
                utilities.TestDataVault.markBad(iVaultHerd, "login " + pExpiredUsername + " expired");
                iVaultHerd = "";
            }
            if (takeFromVault()) return;
        }

        // Individual test case: the replacement must be another individual herd + its own login
        if (isIndividualTestCase())
        {
            if (!resolveIndividualHerdAndUser())
            {
                throw new RuntimeException("[EXPIRED-INDIVIDUAL] Could not find a replacement individual herd+login after marking "
                        + pExpiredUsername + " as expired. Try -Dherd.limit=100 or check the individual queries.");
            }
            return;
        }

        String iYear  = System.getProperty("herd.year",  "2026").trim();
        String iLimit = System.getProperty("herd.limit", "25").trim();

        boolean iFound = false;

        for (int iAttempt = 1; iAttempt <= 5 && !iFound; iAttempt++)
        {
            int iNewLimit = Integer.parseInt(iLimit) + (iAttempt * 10);
            database.DBRouter.runDB("DATA", "List of herds with no errors at all", iYear, String.valueOf(iNewLimit));

            List<Map<String, Object>> iRows = database.DBRouter.getRows();
            if (iRows == null || iRows.isEmpty()) continue;

            List<String> iCandidates = new ArrayList<>();
            for (Map<String, Object> r : iRows)
            {
                String h = Objects.toString(r.get("APP_HERD_NO"), "").trim();
                if (!h.isEmpty()) iCandidates.add(h);
            }
            Collections.shuffle(iCandidates, new Random(System.nanoTime()));

            for (String iCandidate : iCandidates)
            {
                if (BLACKLISTED_HERDS.contains(iCandidate)) continue;

                database.DBRouter.runDB("INET", "Get Login Id for herd", iCandidate);
                String iUser = database.DBRouter.getValue("USERNAME");

                if (iUser == null || iUser.isBlank()) continue;
                iUser = iUser.trim();

                if (EXPIRED_AGENTS.contains(iUser))
                {
                    CommonFunctions.log.warning("[EXPIRED-AGENT] Candidate agent " + iUser + " is also expired - skipping.");
                    continue;
                }

                RUNTIME_HERD     = iCandidate;
                RUNTIME_USERNAME = iUser;
                iFound = true;

                CommonFunctions.log.info("[EXPIRED-AGENT] Re-resolved: Herd=" + RUNTIME_HERD + " | Username=" + RUNTIME_USERNAME);
                break;
            }
        }

        if (!iFound)
        {
            throw new RuntimeException("[EXPIRED-AGENT] Could not find a replacement herd+agent after marking "
                    + pExpiredUsername + " as expired. All candidates exhausted. Try -Dherd.limit=50 or check DB data.");
        }
    }

    private static void rerunIfBlacklisted()
    {
        int retries = 0;

        while (RUNTIME_HERD != null && BLACKLISTED_HERDS.contains(RUNTIME_HERD) && retries < 50)
        {
            retries++;
            CommonFunctions.log.warning("[HOOKS] Blacklisted herd detected: " + RUNTIME_HERD + " - re-fetching (attempt " + retries + ")");

            database.DBRouter.runDB("DATA", "List of herds with no errors at all",
                    String.valueOf(java.time.Year.now().getValue()), String.valueOf(10 + retries));

            List<Map<String, Object>> rows = database.DBRouter.getRows();
            if (rows == null || rows.isEmpty())
            {
                throw new RuntimeException("[HOOKS] Re-fetch returned no rows - cannot find replacement herd.");
            }

            boolean replaced = false;
            for (Map<String, Object> r : rows)
            {
                String h = Objects.toString(r.get("APP_HERD_NO"), "").trim();
                if (!h.isEmpty() && !BLACKLISTED_HERDS.contains(h))
                {
                    RUNTIME_HERD = h;
                    CommonFunctions.log.info("[HOOKS] Replacement herd selected: " + RUNTIME_HERD);
                    replaced = true;
                    break;
                }
            }

            if (!replaced)
            {
                CommonFunctions.log.warning("[HOOKS] No non-blacklisted herd found - retrying...");
            }
        }

        if (RUNTIME_HERD != null && BLACKLISTED_HERDS.contains(RUNTIME_HERD))
        {
            throw new RuntimeException("[HOOKS] Could not resolve a non-blacklisted herd after " + retries + " retries. Last herd=" + RUNTIME_HERD);
        }
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : bootstrapRuntimeHerdAndUser
    // Description   : DATA -> INET herd/username resolution (logic moved unchanged out of beforeAllExecution).
    // Parameters    : pHerdFromSheet  - HerdNumber column from TestData.xlsx
    //                 pUnameFromSheet - Username column from TestData.xlsx
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 10-03-2026 | Updated: 15-09-2026 (extracted method)
    // ***************************************************************************************************************************************************************************************
    private static void bootstrapRuntimeHerdAndUser(String pHerdFromSheet, String pUnameFromSheet)
    {
        // Individual test case (TC_03_IND): individual herd + the herd owner's own login
        if (isIndividualTestCase())
        {
            bootstrapIndividualHerdAndUser(pHerdFromSheet, pUnameFromSheet);
            return;
        }

        String herdYear         = System.getProperty("herd.year",  "2026").trim();
        String herdLimit        = System.getProperty("herd.limit", "25").trim();
        String herdRetry        = System.getProperty("herd.retry", "3").trim();
        String usernameOverride = System.getProperty("usernameOverride", "").trim();

        if (!usernameOverride.isEmpty())
        {
            RUNTIME_USERNAME = usernameOverride;
            RUNTIME_HERD     = pHerdFromSheet;
            CommonFunctions.log.info("[BOOT] Using usernameOverride=" + RUNTIME_USERNAME + ", herd(sheet)=" + RUNTIME_HERD);
            rerunIfBlacklisted();
            return;
        }

        // Test Data Vault first (TC_00_DATA filled it); the DATA + INET lookup below is the fallback
        if (takeFromVault())
        {
            rerunIfBlacklisted();
            return;
        }

        final int maxAttempts = Integer.parseInt(herdRetry);
        final int limit       = Integer.parseInt(herdLimit);
        boolean   found       = false;

        for (int attempt = 1; attempt <= maxAttempts && !found; attempt++)
        {
            database.DBRouter.runDB("DATA", "List of herds with no errors at all", herdYear, String.valueOf(limit), "");
            List<Map<String, Object>> rows = database.DBRouter.getRows();
            if (rows == null || rows.isEmpty())
            {
                throw new RuntimeException("Runtime DB (DATA) returned no herds for year=" + herdYear + ", limit=" + limit);
            }

            List<String> candidates = new ArrayList<>();
            for (Map<String, Object> r : rows)
            {
                String h = Objects.toString(r.get("APP_HERD_NO"), "").trim();
                if (!h.isEmpty() && !candidates.contains(h)) candidates.add(h);
            }
            Collections.shuffle(candidates, new Random(System.nanoTime()));

            CommonFunctions.log.info("[BOOT] Attempt " + attempt + "/" + maxAttempts + " - trying " + candidates.size()
                    + " randomized candidate(s) from DATA (year=" + herdYear + ", limit=" + limit + ")");

            int idx = 0;
            for (String candidate : candidates)
            {
                idx++;
                CommonFunctions.log.info("[BOOT] Candidate [" + idx + "/" + candidates.size() + "] : " + candidate);

                database.DBRouter.runDB("INET", "Get Login Id for herd", candidate);
                String candidateUser = database.DBRouter.getValue("USERNAME");

                if (candidateUser != null && !candidateUser.isBlank())
                {
                    if (EXPIRED_AGENTS.contains(candidateUser.trim()))
                    {
                        CommonFunctions.log.warning("[BOOT] Agent " + candidateUser.trim()
                                + " is in EXPIRED_AGENTS (SSO account expired) - skipping herd=" + candidate);
                        continue;
                    }

                    RUNTIME_HERD     = candidate;
                    RUNTIME_USERNAME = candidateUser.trim();
                    CommonFunctions.log.info("[BOOT] SELECTED Herd=" + RUNTIME_HERD + " | Username=" + RUNTIME_USERNAME);

                    rerunIfBlacklisted();
                    found = true;
                    break;
                }
                else
                {
                    CommonFunctions.log.warning("[BOOT] INET: no USERNAME for herd=" + candidate + " - next candidate...");
                }
            }

            if (!found)
            {
                CommonFunctions.log.warning("[BOOT] No mapped USERNAME found in attempt " + attempt
                        + ". Re-running DATA query to get a fresh set of " + limit + " candidates...");
            }
        }

        if (!found)
        {
            if (!pUnameFromSheet.isBlank())
            {
                RUNTIME_USERNAME = pUnameFromSheet;
                RUNTIME_HERD     = (RUNTIME_HERD == null || RUNTIME_HERD.isBlank()) ? pHerdFromSheet : RUNTIME_HERD;
                CommonFunctions.log.warning("[BOOT] Falling back to Username from sheet: " + RUNTIME_USERNAME + " | Herd=" + RUNTIME_HERD);
                rerunIfBlacklisted();
            }
            else
            {
                throw new RuntimeException("Runtime DB (INET) returned no USERNAME after " + herdRetry
                        + " attempt(s). Try -Dherd.limit=10 or set -DusernameOverride=... for this run.");
            }
        }
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : bootstrapIndividualHerdAndUser
    // Description   : Individual version of bootstrapRuntimeHerdAndUser (TC_03_IND). Same rules as the agent version:
    //                 -DusernameOverride wins, then the DB lookup, then the Username / HerdNumber columns of the sheet.
    // Parameters    : pHerdFromSheet  - HerdNumber column from TestData.xlsx
    //                 pUnameFromSheet - Username column from TestData.xlsx
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 25-09-2026
    // ***************************************************************************************************************************************************************************************
    private static void bootstrapIndividualHerdAndUser(String pHerdFromSheet, String pUnameFromSheet)
    {
        String usernameOverride = System.getProperty("usernameOverride", "").trim();
        if (!usernameOverride.isEmpty())
        {
            RUNTIME_USERNAME = usernameOverride;
            RUNTIME_HERD     = pHerdFromSheet;
            CommonFunctions.log.info("[BOOT-IND] Using usernameOverride=" + RUNTIME_USERNAME + ", herd(sheet)=" + RUNTIME_HERD);
            return;
        }

        // Test Data Vault first (TC_00_DATA filled it); the DATA + INET lookup is the fallback
        if (takeFromVault())
        {
            return;
        }

        if (resolveIndividualHerdAndUser())
        {
            return;
        }

        if (!pUnameFromSheet.isBlank())
        {
            RUNTIME_USERNAME = pUnameFromSheet;
            RUNTIME_HERD     = pHerdFromSheet;
            CommonFunctions.log.warning("[BOOT-IND] Falling back to Username from sheet: " + RUNTIME_USERNAME + " | Herd=" + RUNTIME_HERD);
            return;
        }

        throw new RuntimeException("[BOOT-IND] No individual herd with a login found. Check DATA \"List of not started individual herds "
                + "with CISYF flag\" (herd.year) and INET \"Get Individual Login for herd\", or set -DusernameOverride=... for this run.");
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : resolveIndividualHerdAndUser
    // Description   : Picks a random Not Started CISYF individual herd and its own login:
    //                   DATA "List of not started individual herds with CISYF flag" (herd.year, herd.limit)
    //                     -> shuffled, blacklisted herds and the current herd skipped
    //                   INET "Get Individual Login for herd" for each candidate
    //                     -> first login not in EXPIRED_AGENTS is used (a herd can have more than one login)
    //                 The DATA query is re-run with a larger limit up to herd.retry times (default 3).
    //                 Sets RUNTIME_HERD / RUNTIME_USERNAME and the TD:HerdNumber / TD:Username properties.
    // Returns       : true when a herd + login was found
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 25-09-2026
    // ***************************************************************************************************************************************************************************************
    private static boolean resolveIndividualHerdAndUser()
    {
        String iYear     = System.getProperty("herd.year",  "2026").trim();
        int    iLimit    = Integer.parseInt(System.getProperty("herd.limit", "25").trim());
        int    iAttempts = Integer.parseInt(System.getProperty("herd.retry", "3").trim());
        String iPrevious = RUNTIME_HERD == null ? "" : RUNTIME_HERD;

        for (int iAttempt = 1; iAttempt <= iAttempts; iAttempt++)
        {
            int iRows = iLimit * iAttempt;
            database.DBRouter.runDB("DATA", "List of not started individual herds with CISYF flag", iYear, String.valueOf(iRows));

            List<String> iCandidates = new ArrayList<>();
            for (Map<String, Object> r : database.DBRouter.getRows())
            {
                String h = Objects.toString(r.get("APP_HERD_NO"), "").trim();
                if (!h.isEmpty() && !iCandidates.contains(h) && !h.equals(iPrevious) && !BLACKLISTED_HERDS.contains(h))
                {
                    iCandidates.add(h);
                }
            }
            Collections.shuffle(iCandidates, new Random(System.nanoTime()));

            CommonFunctions.log.info("[BOOT-IND] Attempt " + iAttempt + "/" + iAttempts + " - " + iCandidates.size()
                    + " individual candidate(s) (year=" + iYear + ", limit=" + iRows + ")");

            for (String iCandidate : iCandidates)
            {
                database.DBRouter.runDB("INET", "Get Individual Login for herd", iCandidate);

                for (Map<String, Object> r : database.DBRouter.getRows())
                {
                    String iLogin = Objects.toString(r.get("LOGIN"), "").trim();
                    if (iLogin.isEmpty()) continue;

                    if (EXPIRED_AGENTS.contains(iLogin))
                    {
                        CommonFunctions.log.warning("[BOOT-IND] Login " + iLogin + " of herd " + iCandidate + " is expired - skipping.");
                        continue;
                    }

                    RUNTIME_HERD     = iCandidate;
                    RUNTIME_USERNAME = iLogin;
                    System.setProperty("TD:HerdNumber", RUNTIME_HERD);
                    System.setProperty("TD:Username",   RUNTIME_USERNAME);
                    CommonFunctions.log.info("[BOOT-IND] SELECTED Herd=" + RUNTIME_HERD + " | Username=" + RUNTIME_USERNAME);
                    return true;
                }

                CommonFunctions.log.warning("[BOOT-IND] INET: no usable login for herd=" + iCandidate + " - next candidate...");
            }
        }
        return false;
    }

    // =================================================================================================
    // BEFORE ALL - runs once before any scenario in the test run
    // =================================================================================================
    @BeforeAll
    public static void beforeAllExecution()
    {
        iTestCaseStartMs = System.currentTimeMillis();

        try
        {
            iTestCaseID  = System.getProperty("testcase",    "").trim();
            iEnvironment = System.getProperty("environment", "").trim();

            if (iTestCaseID.isEmpty())  { throw new RuntimeException("TestCase_ID system property missing."); }
            if (iEnvironment.isEmpty()) { throw new RuntimeException("Environment system property missing."); }

            iAccumulatedErrors.setLength(0);
            iLastScreenshotPath = "";
            iAnyScenarioFailed  = false;
            iFirstFailedScenario = "";
            iDocument           = null;
            iDocPath            = "";

            CommonFunctions.log.info("========== EXECUTION START : " + iTestCaseID + " ==========");
            CommonFunctions.loadDescriptionCache();
            CommonFunctions.clearStepLog();

            iVaultHerd       = "";
            RUNTIME_HERD     = null;
            RUNTIME_USERNAME = null;

            // TC_00_DATA: database only - no TestData.xlsx row, no browser, no Word report
            if (isDataTestCase())
            {
                iUrl = ConfigManager.getOrDefault("app.url", "");
                System.setProperty("TD:HerdNumber", "");
                System.setProperty("TD:Username",   "");
                iSetupMs = System.currentTimeMillis() - iTestCaseStartMs;
                CommonFunctions.log.info("[BOOT] Data test case - no browser is opened. BeforeAll complete.");
                return;
            }

            ExcelUtilities iTestDataExcel = new ExcelUtilities(iTestDataFilePath);
            iTestDataExcel.loadCurrentTestDataRow(iTestDataSheetName, iTestCaseID);

            int iConfigRow = iTestDataExcel.findRow(iConfigSheetName, "Env", iEnvironment);
            if (iConfigRow == -1) { throw new RuntimeException("Environment not found in Config sheet : " + iEnvironment); }

            iUrl = ConfigManager.getOrDefault("app.url", "");
            if (iUrl.isEmpty())
            {
                iUrl = iTestDataExcel.getCellValue(iConfigSheetName, iConfigRow, "URL").trim();
            }
            else
            {
                CommonFunctions.log.info("[BOOT] URL overridden by app.url : " + iUrl);
            }
            if (iUrl.isEmpty()) { throw new RuntimeException("URL blank for environment : " + iEnvironment); }

            String herdFromSheet  = "";
            String unameFromSheet = "";
            try { herdFromSheet  = ExcelUtilities.getCurrentTestDataValue("HerdNumber"); } catch (Exception ignored) {}
            try { unameFromSheet = ExcelUtilities.getCurrentTestDataValue("Username");   } catch (Exception ignored) {}

            RUNTIME_HERD     = null;
            RUNTIME_USERNAME = null;

            if (isDbBootstrapEnabled())
            {
                bootstrapRuntimeHerdAndUser(herdFromSheet, unameFromSheet);
            }
            else
            {
                RUNTIME_HERD     = herdFromSheet;
                RUNTIME_USERNAME = unameFromSheet;
                CommonFunctions.log.info("[BOOT] " + (isEntsTestCase() ? "ENTS test case (db.bootstrap.ents=false)" : "db.bootstrap=false")
                        + " - using sheet values | Herd=" + RUNTIME_HERD + " | Username=" + RUNTIME_USERNAME);
            }

            System.setProperty("TD:HerdNumber", RUNTIME_HERD == null ? "" : RUNTIME_HERD);
            System.setProperty("TD:Username",   RUNTIME_USERNAME == null ? "" : RUNTIME_USERNAME);

            if (isDbBootstrapEnabled() && ConfigManager.getBool("testdata.writeback.enabled", true))
            {
                try
                {
                    int dataRowIdx = iTestDataExcel.findRow(iTestDataSheetName, "TestCase_ID", iTestCaseID);
                    if (dataRowIdx != -1)
                    {
                        iTestDataExcel.setCellValue(iTestDataSheetName, dataRowIdx, "HerdNumber", RUNTIME_HERD == null ? "" : RUNTIME_HERD);
                        iTestDataExcel.setCellValue(iTestDataSheetName, dataRowIdx, "Username", RUNTIME_USERNAME == null ? "" : RUNTIME_USERNAME);
                        CommonFunctions.log.info("[BOOT->Excel] Data updated: HerdNumber=" + RUNTIME_HERD + ", Username=" + RUNTIME_USERNAME);
                    }
                    else
                    {
                        CommonFunctions.log.warning("[BOOT->Excel] Row not found for TestCase_ID=" + iTestCaseID + " (skipped write-back)");
                    }
                }
                catch (Exception e)
                {
                    CommonFunctions.log.warning("[BOOT->Excel] Persist failed: " + e.getMessage());
                }
            }

            String iBrowserType = System.getProperty("browser", iDefaultBrowser).trim().toUpperCase();
            CommonFunctions.launchBrowser(iBrowserType, iUrl);

            Object[] iReportObjects = CommonFunctions.startWordReport(iTestCaseID);
            iDocument = (XWPFDocument) iReportObjects[0];
            iDocPath  = String.valueOf(iReportObjects[1]);

            iSetupMs = System.currentTimeMillis() - iTestCaseStartMs;
            CommonFunctions.log.info("BeforeAll complete | URL=" + iUrl + " | Report=" + iDocPath
                    + " | Setup took " + (iSetupMs / 1000) + " s (DB bootstrap + browser cleanup + browser start)");
        }
        catch (Exception iException)
        {
            throw new RuntimeException("BeforeAll failed for [" + iTestCaseID + "] : " + iException.getMessage(), iException);
        }
    }

    // ***************************************************************************************************************************************************************************************
    // @Before("@preliminary") - unchanged logic
    // ***************************************************************************************************************************************************************************************
    @Before("@preliminary")
    public void resolveRuntimePreliminaryHerds(Scenario pScenario)
    {
        final int    MAX_ATTEMPTS = 100;
        final String YEAR         = System.getProperty("herd.year", "2026").trim();

        CommonFunctions.log.info("[PRELIM-HOOK] Resolving preliminary herds for: " + pScenario.getName());

        boolean iAllResolved = false;

        for (int iOffset = 0; iOffset < MAX_ATTEMPTS; iOffset++)
        {
            CommonFunctions.log.info("[PRELIM-HOOK] Attempt " + (iOffset + 1) + "/" + MAX_ATTEMPTS + " - offset=" + iOffset);

            database.DBRouter.runDB("DATA", "Preliminary checks herds", YEAR, String.valueOf(iOffset));

            List<Map<String, Object>> iRows = database.DBRouter.getRows();
            if (iRows == null || iRows.isEmpty())
            {
                CommonFunctions.log.warning("[PRELIM-HOOK] No rows from DB at offset=" + iOffset + ". Stopping.");
                break;
            }

            String iOverclaimHerd    = null; String iOverclaimUser    = null;
            String iDualClaimHerd    = null; String iDualClaimUser    = null;
            String iAgriActivityHerd = null; String iAgriActivityUser = null;

            for (Map<String, Object> iRow : iRows)
            {
                String iLvc  = Objects.toString(iRow.get("LVC_DESC"),    "").trim();
                String iHerd = Objects.toString(iRow.get("LVL_HERD_NO"), "").trim();
                if (iHerd.isEmpty()) continue;

                database.DBRouter.runDB("INET", "Get Login Id for herd", iHerd);
                String iUsername = database.DBRouter.getValue("USERNAME");

                if (iUsername == null || iUsername.isBlank())
                {
                    CommonFunctions.log.warning("[PRELIM-HOOK] No INET agent for " + iLvc + " herd=" + iHerd + " - retrying next offset.");
                    continue;
                }

                iUsername = iUsername.trim();
                CommonFunctions.log.info("[PRELIM-HOOK] DB+INET resolved: " + iLvc + " -> " + iHerd + " / " + iUsername);

                switch (iLvc)
                {
                    case "Overclaim":
                        iOverclaimHerd    = iHerd; iOverclaimUser    = iUsername; break;
                    case "Dual claim":
                        iDualClaimHerd    = iHerd; iDualClaimUser    = iUsername; break;
                    case "Agricultural Activity":
                        iAgriActivityHerd = iHerd; iAgriActivityUser = iUsername; break;
                    default:
                        break;
                }
            }

            if (iOverclaimHerd != null && iDualClaimHerd != null && iAgriActivityHerd != null)
            {
                OVERCLAIM_HERD     = iOverclaimHerd;    OVERCLAIM_USERNAME     = iOverclaimUser;
                DUAL_CLAIM_HERD    = iDualClaimHerd;    DUAL_CLAIM_USERNAME    = iDualClaimUser;
                AGRI_ACTIVITY_HERD = iAgriActivityHerd; AGRI_ACTIVITY_USERNAME = iAgriActivityUser;

                CommonFunctions.log.info("[PRELIM-HOOK] All 3 resolved:");
                CommonFunctions.log.info("[PRELIM-HOOK]  Overclaim     -> " + OVERCLAIM_HERD + " / " + OVERCLAIM_USERNAME);
                CommonFunctions.log.info("[PRELIM-HOOK]  Dual claim    -> " + DUAL_CLAIM_HERD + " / " + DUAL_CLAIM_USERNAME);
                CommonFunctions.log.info("[PRELIM-HOOK]  Agri Activity -> " + AGRI_ACTIVITY_HERD + " / " + AGRI_ACTIVITY_USERNAME);

                if (pScenario.getSourceTagNames().contains("@TC_18") || pScenario.getSourceTagNames().contains("@TC_15"))
                {
                    RUNTIME_USERNAME = OVERCLAIM_USERNAME;
                }
                else if (pScenario.getSourceTagNames().contains("@TC_19") || pScenario.getSourceTagNames().contains("@TC_16"))
                {
                    RUNTIME_USERNAME = DUAL_CLAIM_USERNAME;
                }
                else if (pScenario.getSourceTagNames().contains("@TC_20") || pScenario.getSourceTagNames().contains("@TC_17"))
                {
                    RUNTIME_USERNAME = AGRI_ACTIVITY_USERNAME;
                }

                CommonFunctions.log.info("[PRELIM-HOOK] RUNTIME_USERNAME synced -> " + RUNTIME_USERNAME + " | Background login will use this agent.");

                iAllResolved = true;
                break;
            }

            CommonFunctions.log.warning("[PRELIM-HOOK] Not all 3 resolved at offset=" + iOffset
                    + " - Overclaim=" + (iOverclaimHerd != null ? "Y" : "N")
                    + " DualClaim="   + (iDualClaimHerd != null ? "Y" : "N")
                    + " AgriAct="     + (iAgriActivityHerd != null ? "Y" : "N"));
        }

        if (!iAllResolved)
        {
            throw new RuntimeException("[PRELIM-HOOK] Could not resolve all 3 preliminary check herds after " + MAX_ATTEMPTS + " attempts for year=" + YEAR);
        }
    }

    // ***************************************************************************************************************************************************************************************
    // @Before("@tc13")
    // Description   : Picks the NR/CISYF herd and its agent for the scenario (Hooks.CISYF_HERD / CISYF_USERNAME, also
    //                 RUNTIME_HERD / RUNTIME_USERNAME for the Background login).
    //                 02-10-2026: first utilities.NrcisyfTestData - vault pool ENTS_YOUNG_FARMER, then the live
    //                 "ENTS Young Farmer herds" query (herd + agent in one query, ENTS database). Only when both have
    //                 nothing, the Selenium lookup below runs unchanged (BISS_DATA herds + one BISS_INET login query per
    //                 candidate, up to 50 attempts). nrcisyf.herd.source=legacy goes straight to the Selenium lookup.
    // ***************************************************************************************************************************************************************************************
    @Before("@tc13")
    public void resolveRuntimeCISYFHerd(Scenario pScenario)
    {
        final String YEAR      = System.getProperty("herd.year", "2026").trim();
        final int    MAX_TRIES = 50;

        String[] iYoungFarmer = utilities.NrcisyfTestData.nextHerd("", BLACKLISTED_HERDS, EXPIRED_AGENTS, "@tc13 hook");
        if (iYoungFarmer != null)
        {
            CISYF_HERD       = iYoungFarmer[0];
            CISYF_USERNAME   = iYoungFarmer[1];
            RUNTIME_HERD     = iYoungFarmer[0];
            RUNTIME_USERNAME = iYoungFarmer[1];
            CommonFunctions.log.info("[TC13-HOOK] Young Farmer herd resolved: Herd=" + CISYF_HERD + " | Username=" + CISYF_USERNAME);
            return;
        }

        CommonFunctions.log.info("[TC13-HOOK] Resolving random CISYF J-prefix herd for: " + pScenario.getName());

        boolean iFound = false;

        for (int iAttempt = 1; iAttempt <= MAX_TRIES && !iFound; iAttempt++)
        {
            int iLimit = 50 + ((iAttempt - 1) * 25);

            CommonFunctions.log.info("[TC13-HOOK] Attempt " + iAttempt + "/" + MAX_TRIES + " - querying BISS_DATA (year=" + YEAR + ", limit=" + iLimit + ")");

            database.DBRouter.runDB("DATA", "LIST OF NOT STARTED INDIVIDUAL HERDS ELIGIBLE FOR CISYF", YEAR, String.valueOf(iLimit));

            List<Map<String, Object>> iRows = database.DBRouter.getRows();

            if (iRows == null || iRows.isEmpty())
            {
                CommonFunctions.log.warning("[TC13-HOOK] BISS_DATA returned no CISYF herds at limit=" + iLimit + ". Retrying...");
                continue;
            }

            List<String> iCandidates = new ArrayList<>();
            for (Map<String, Object> iRow : iRows)
            {
                String iHerd = Objects.toString(iRow.get("APP_HERD_NO"), "").trim();
                if (!iHerd.isEmpty()) iCandidates.add(iHerd);
            }
            Collections.shuffle(iCandidates, new Random(System.nanoTime()));

            int iIdx = 0;
            for (String iCandidate : iCandidates)
            {
                iIdx++;

                if (BLACKLISTED_HERDS.contains(iCandidate))
                {
                    CommonFunctions.log.warning("[TC13-HOOK] Candidate [" + iIdx + "] " + iCandidate + " is blacklisted - skipping.");
                    continue;
                }

                database.DBRouter.runDB("INET", "Get Login Id for herd", iCandidate);
                String iUsername = database.DBRouter.getValue("USERNAME");

                if (iUsername == null || iUsername.isBlank())
                {
                    CommonFunctions.log.warning("[TC13-HOOK] Candidate [" + iIdx + "] " + iCandidate + " - no INET agent found. Skipping.");
                    continue;
                }

                iUsername = iUsername.trim();

                if (EXPIRED_AGENTS.contains(iUsername))
                {
                    CommonFunctions.log.warning("[TC13-HOOK] Candidate [" + iIdx + "] " + iCandidate + " - agent " + iUsername + " is in EXPIRED_AGENTS. Skipping.");
                    continue;
                }

                CISYF_HERD       = iCandidate;
                CISYF_USERNAME   = iUsername;
                RUNTIME_HERD     = iCandidate;
                RUNTIME_USERNAME = iUsername;
                iFound = true;

                CommonFunctions.log.info("[TC13-HOOK] CISYF herd resolved: Herd=" + CISYF_HERD + " | Username=" + CISYF_USERNAME);
                break;
            }

            if (!iFound)
            {
                CommonFunctions.log.warning("[TC13-HOOK] No valid candidate in attempt " + iAttempt + " - retrying with larger limit.");
            }
        }

        if (!iFound)
        {
            throw new RuntimeException("[TC13-HOOK] Could not resolve a CISYF J-prefix herd after " + MAX_TRIES + " attempts for year=" + YEAR
                    + ". Verify the query returns rows in BISS_DATA for this environment.");
        }
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : skipRestOfTestCaseAfterFailure
    // Description   : Fail-fast. Runs first, before every other @Before hook (order 0).
    //                 When an earlier scenario of this test case has failed, this scenario is SKIPPED: no DB lookup,
    //                 no steps. Cucumber then finishes the feature, AfterAll closes the browser and writes the report,
    //                 and TestRunner marks the row FAIL and starts the next test case in ExecutionControl.xlsx.
    //                 Inside one scenario nothing extra is needed: Cucumber already skips every step after a failed step.
    //                 execution.fail.fast=false switches this off (all scenarios run, as before).
    // Parameters    : pScenario (Scenario) - the scenario about to start
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 17-09-2026
    // ***************************************************************************************************************************************************************************************
    @Before(order = 0)
    public void skipRestOfTestCaseAfterFailure(Scenario pScenario)
    {
        iSkippedByFailFast = false;

        if (iAnyScenarioFailed && ConfigManager.getBool("execution.fail.fast", true))
        {
            iSkippedByFailFast = true;
            CommonFunctions.log.warning("---------- Scenario SKIPPED (fail-fast) : " + pScenario.getName()
                    + " | earlier failure in [" + iFirstFailedScenario + "] ----------");

            // Cucumber reports a TestAbortedException as SKIPPED (not as another failure)
            throw new org.opentest4j.TestAbortedException("Skipped: scenario [" + iFirstFailedScenario
                    + "] of " + iTestCaseID + " already failed (execution.fail.fast=true)");
        }
    }

    // =================================================================================================
    // BEFORE - runs before every scenario
    // =================================================================================================
    @Before
    public void beforeScenarioExecution(Scenario pScenario)
    {
        SoftAssertManager.reset();
        RetryAnalyser.clearRetryState();
        utilities.EntsTestData.resetScenario();
        iScenarioStartTime = System.currentTimeMillis();
        CommonFunctions.log.info("---------- Scenario START : " + pScenario.getName() + " ----------");

        String iScenarioTags = String.join(" ", pScenario.getSourceTagNames());
        ReportManager.beginTestCase(iTestCaseID, pScenario.getName(), iScenarioTags);
    }

    // =================================================================================================
    // AFTER - runs after every scenario
    // =================================================================================================
    @After
    public void afterScenarioExecution(Scenario pScenario)
    {
        if (iSkippedByFailFast)
        {
            // Nothing ran in this scenario - no soft assertions, screenshot or divider to write
            iAccumulatedErrors.append("Scenario [").append(pScenario.getName()).append("] SKIPPED (fail-fast)\n");
            return;
        }

        boolean iSoftAssertFailed = false;
        try
        {
            SoftAssertManager.assertAll();
        }
        catch (AssertionError iSoftFailure)
        {
            // Soft assertion failures fail the scenario, but Cucumber only records that after this hook ends
            iSoftAssertFailed = true;
            throw iSoftFailure;
        }
        finally
        {
            boolean iScenarioFailed   = pScenario.isFailed() || iSoftAssertFailed;
            long    iScenarioDuration = System.currentTimeMillis() - iScenarioStartTime;
            iScenarioMs += iScenarioDuration;
            ScreenshotManager.appendScenarioDivider(iDocument, pScenario.getName(), !iScenarioFailed, iScenarioDuration);

            try
            {
                if (iScenarioFailed)
                {
                    if (!iAnyScenarioFailed)
                    {
                        iFirstFailedScenario = pScenario.getName();
                    }
                    iAnyScenarioFailed = true;
                    CommonFunctions.log.severe("---------- Scenario FAILED : " + pScenario.getName() + " ----------");

                    iAccumulatedErrors.append("Scenario [").append(pScenario.getName())
                            .append("] FAILED. Status=").append(iSoftAssertFailed ? "SOFT_ASSERTION" : pScenario.getStatus().name()).append("\n");

                    byte[] iPng = ScreenshotManager.captureBytes(CommonFunctions.getPage());
                    if (iPng != null)
                    {
                        pScenario.attach(iPng, "image/png", "Failure - " + pScenario.getName());
                    }

                    try
                    {
                        if (iDocument != null && iDocPath != null && !iDocPath.isEmpty())
                        {
                            iLastScreenshotPath = CommonFunctions.addScreenshotToReport(iDocument, iDocPath, iTestCaseID);
                        }
                        else
                        {
                            String iSafeName = iTestCaseID + "_" + pScenario.getName().replaceAll("[^a-zA-Z0-9]", "_");
                            iLastScreenshotPath = CommonFunctions.takeScreenshot(iSafeName);
                        }
                    }
                    catch (Exception iShotException)
                    {
                        CommonFunctions.log.severe("Screenshot failed : " + iShotException.getMessage());
                    }
                }
                else
                {
                    CommonFunctions.log.info("---------- Scenario PASSED : " + pScenario.getName() + " ----------");
                }
            }
            catch (Exception iException)
            {
                CommonFunctions.log.severe("After hook error : " + iException.getMessage());
            }
        }
    }

    // =================================================================================================
    // AFTER ALL - runs once after all scenarios complete
    // =================================================================================================
    @AfterAll
    public static void afterAllExecution()
    {
        // Vault: the BISS herd of this test case is finished with - USED when it passed, BAD (with the reason) when not
        try
        {
            if (!iVaultHerd.isEmpty())
            {
                if (iAnyScenarioFailed)
                {
                    utilities.TestDataVault.markBad(iVaultHerd, "test case " + iTestCaseID + " failed in [" + iFirstFailedScenario + "]");
                }
                else
                {
                    utilities.TestDataVault.markUsed(iVaultHerd);
                }
                iVaultHerd = "";
            }

            // NR/CISYF (02-10-2026): Young Farmer herds picked but never submitted go back to AVAILABLE after a pass
            if (!iAnyScenarioFailed) utilities.NrcisyfTestData.releaseUntouched();
        }
        catch (Exception iException)
        {
            CommonFunctions.log.warning("[VAULT] Could not update the vault row : " + iException.getMessage());
        }

        try
        {
            if (iAccumulatedErrors.length() > 0)
            {
                System.setProperty("lastFailureReason." + iTestCaseID, iAccumulatedErrors.toString().trim());
            }
            if (!iLastScreenshotPath.isEmpty())
            {
                System.setProperty("lastScreenshotPath." + iTestCaseID, iLastScreenshotPath);
            }
        }
        catch (Exception iException)
        {
            CommonFunctions.log.severe("Failed to publish failure properties : " + iException.getMessage());
        }

        try
        {
            if (iDocument != null && iDocPath != null && !iDocPath.isEmpty())
            {
                // Status = Cucumber result, the same PASS/FAIL the console and ExecutionControl.xlsx show
                CommonFunctions.finalizeWordReport(iDocument, iDocPath, iAnyScenarioFailed ? "FAIL" : "PASS");
            }
        }
        catch (Exception iException)
        {
            CommonFunctions.log.severe("Word report finalization failed : " + iException.getMessage());
        }

        try
        {
            String iTrace = CommonFunctions.closeBrowser(iAnyScenarioFailed, iTestCaseID);
            if (!iTrace.isEmpty())
            {
                System.setProperty("lastTracePath." + iTestCaseID, iTrace);
            }
        }
        catch (Exception iException)
        {
            CommonFunctions.log.severe("Browser close failed : " + iException.getMessage());
        }

        long iTotalMs    = System.currentTimeMillis() - iTestCaseStartMs;
        long iTeardownMs = Math.max(0L, iTotalMs - iSetupMs - iScenarioMs);

        // Where the time went. Setup = DB herd lookup + browser cleanup + Chrome start + Word report.
        // Scenarios = the steps themselves. Teardown = report finalize + trace + closing Chrome.
        CommonFunctions.log.info("[TIMING] " + iTestCaseID
                + " | total=" + (iTotalMs / 1000) + "s"
                + " | setup=" + (iSetupMs / 1000) + "s"
                + " | scenarios=" + (iScenarioMs / 1000) + "s"
                + " | teardown=" + (iTeardownMs / 1000) + "s");

        iSetupMs    = 0L;
        iScenarioMs = 0L;

        CommonFunctions.log.info("========== EXECUTION END : " + iTestCaseID + " ==========");
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : captureStep
    // Description   : On-demand screenshot method for step definitions (unchanged call surface).
    // Parameters    : pStepLabel (String) - describes what is being captured, shown as caption
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 26-03-2026
    // ***************************************************************************************************************************************************************************************
    public static void captureStep(String pStepLabel)
    {
        CommonFunctions.captureStepScreenshot(iDocument, iDocPath, pStepLabel);
    }
}
