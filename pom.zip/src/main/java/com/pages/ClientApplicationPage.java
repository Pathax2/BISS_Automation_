package com.pages;

import com.base.ActionClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

public class ClientApplicationPage {

    WebDriver driver;
    ActionClass actions;



//    // Applications and payments summary
//
//    By PreviousAppSearchSchemeYear = By.id("previousAppSearchSchemeYear");
//    By ViewButton = By.id("previousAppSearchView");

    // Locators for future use
    public ClientApplicationPage(WebDriver driver) {
        this.driver = driver;
        actions = new ActionClass(driver);
    }

    //region Client Application Navlinks

    // Client Page
    By ApplicationsNavLink = By.xpath("//body/nav[1]/div[1]/div[1]/div[2]/ul[1]/li[4]/a[1]");
    By FarmDetailsNavLink = By.xpath("//body/nav[1]/div[1]/div[1]/div[2]/ul[1]/li[5]/a[1]");
    By CorrespondenceNavLink = By.xpath("//body/nav[1]/div[1]/div[1]/div[2]/ul[1]/li[6]/a[1]");

    // Clicking on the Applications NavLink
    public void AgentClickOnApplicationsNavLink() {
        actions.waitForVisibilityOfElement(ApplicationsNavLink, 10);
        driver.findElement(ApplicationsNavLink).click();
    }

    // Clicking on the Farm Details NavLink
    public void AgentClickOnFarmDetailsNavLink() {
        actions.waitForVisibilityOfElement(FarmDetailsNavLink, 10);
        driver.findElement(FarmDetailsNavLink).click();
    }

    // Clicking on the Correspondence NavLink
    public void AgentClickOnCorrespondenceNavLink() {
        actions.waitForVisibilityOfElement(CorrespondenceNavLink, 10);
        driver.findElement(CorrespondenceNavLink).click();
    }
    //endregion

    //region Application Navlink
    /*** Applications Navlink ***/

    //Application NavLink
    By AgentStartAmendment = By.id("navigationNewAmendmentLink");
    By AgentStartApplication = By.id("navigationNewApplicationLink");
    By AgentTransferOfEntitlementsApplications = By.xpath("//a[contains(text(),'Transfer of Entitlements Applications')]");
    By AgentNationalReserveAndYoungFarmerSchemeApplciation = By.xpath("//a[contains(text(),'National Reserve and Young Farmer Scheme Application')]");

    // Clicking on the Start Amendment
    public void AgentClickOnStartAmendment() {
        actions.waitForVisibilityOfElement(AgentStartAmendment, 10);
        driver.findElement(AgentStartAmendment).click();
    }

    // Visibility of Start Amendment
    public Boolean VisibilityOfAgentStartAmendment() {
//        actions.waitForVisibilityOfElement(AgentStartAmendment, 10);
        List<WebElement> AgentStartAmendmentList = driver.findElements(AgentStartAmendment);
        Boolean VisibilityAgentStartAmendment = (driver.findElements(AgentStartAmendment).isEmpty());
        return VisibilityAgentStartAmendment;


//        if(driver.findElements(AgentStartAmendment).isEmpty()==false) {
//            System.out.println("Start Amendment 2022 is present");
//        }
//        else {
//            System.out.println("Start Amendment 2022 is not present");
//        }
    }

    // Visibility of Start Application
    public Boolean VisibilityOfAgentStartApplication() {
        actions.waitForVisibilityOfElement(AgentStartApplication, 10);
        Boolean VisibilityAgentStartApplication = driver.findElement(AgentStartApplication).isDisplayed();
        return VisibilityAgentStartApplication;
    }

    // Clicking on the Transfer Of Entitlements Applications
    public void AgentClickOnTransferOfEntitlementsApplications() {
        actions.waitForVisibilityOfElement(AgentTransferOfEntitlementsApplications, 10);
        driver.findElement(AgentTransferOfEntitlementsApplications).click();
    }

    // Visibility of Transfer Of Entitlements Applications
    public Boolean VisibilityOfAgentTransferOfEntitlementsApplications() {
//        actions.waitForVisibilityOfElement(AgentTransferOfEntitlementsApplications, 10);
        Boolean VisibilityAgentTransferOfEntitlementsApplications = (driver.findElements(AgentTransferOfEntitlementsApplications).isEmpty());
        return VisibilityAgentTransferOfEntitlementsApplications;
    }

    // Clicking on the National Reserve And Young Farmer Scheme Application
    public void AgentClickOnNationalReserveAndYoungFarmerSchemeApplication() {
        actions.waitForVisibilityOfElement(AgentNationalReserveAndYoungFarmerSchemeApplciation, 10);
        driver.findElement(AgentNationalReserveAndYoungFarmerSchemeApplciation).click();
    }

    // Visibility of National Reserve And Young Farmer Scheme Application
    public Boolean VisibilityOfAgentNationalReserveAndYoungFarmerSchemeApplciation() {
//        actions.waitForVisibilityOfElement(AgentNationalReserveAndYoungFarmerSchemeApplciation, 10);
        Boolean VisibilityYoungFarmer = driver.findElements(AgentNationalReserveAndYoungFarmerSchemeApplciation).isEmpty();
        return VisibilityYoungFarmer;
    }

    //endregion

    //region Farm Details Navlink
    /*** Farm Details Navlink ***/

    // Farm Details Navlink
    By PersonalDetails = By.xpath("//a[contains(text(),'Personal Details')]");
    By EntitlementPosition2022 = By.xpath("//a[contains(text(),'Entitlement Position 2022')]");
    By EntitlementPosition2022Hidden = By.xpath("//a[contains(text(),'Entitlement Position 2022')]/parent::li[not(contains(@style,'display: none'))]");
    By EntitlementPosition2021 = By.xpath("//a[contains(text(),'Entitlement Position 2021')]");
    By EntitlementPosition2021Hidden = By.xpath("//a[contains(text(),'Entitlement Position 2021')]/parent::li[not(contains(@style,'display: none'))]");
    By EntitlementPosition2020 = By.xpath("//a[contains(text(),'Entitlement Position 2020')]");
    By EntitlementPosition2020Hidden = By.xpath("//a[contains(text(),'Entitlement Position 2020')]/parent::li[not(contains(@style,'display: none'))]");
    By EntitlementPosition2015To2019 = By.xpath("//a[contains(text(),'Entitlement Position 2015-2019')]");
    By EntitlementPosition2015To2019Hidden = By.xpath("//a[contains(text(),'Entitlement Position 2015-2019')]/parent::li[not(contains(@style,'display: none'))]");
    By UsagePosition = By.xpath("//a[contains(text(),'Usage Position')]");
    By UsagePositionHidden = By.xpath("//a[contains(text(),'Usage Position')]/parent::li[not(contains(@style,'display: none'))]");
    By ParcelSearch = By.xpath("//a[contains(text(),'Parcel Search')]");
    By ViewNitrates = By.xpath("//a[contains(text(),'View Nitrates')]");
    By ApplicationsAndPaymentsSummary = By.xpath("//a[contains(text(),'Applications and Payments Summary')]");

    // Clicking on the Personal Details
    public void AgentClickOnPersonalDetails() {
        actions.waitForVisibilityOfElement(PersonalDetails, 10);
        driver.findElement(PersonalDetails).click();
    }

    // Visibility of Personal Details
    public Boolean VisibilityOfPersonalDetails() {
//        actions.waitForVisibilityOfElement(PersonalDetails, 10);
        Boolean PersonalDetailsVisibility = (driver.findElements(PersonalDetails).isEmpty());
        return PersonalDetailsVisibility;
    }

    // Clicking on the Entitlement Position 2022
    public void AgentClickOnEntitlementPosition2022() {
        actions.waitForVisibilityOfElement(EntitlementPosition2022, 10);
        driver.findElement(EntitlementPosition2022).click();
    }

    // Visibility of Entitlement Position 2022
    public Boolean VisibilityOfEntitlementPosition2022() {
//        actions.waitForVisibilityOfElement(EntitlementPosition2022, 10);
//        List<WebElement> EntitlementPositionList = driver.findElements(EntitlementPosition2022Hidden);
//        Boolean EntitlementPosition2022Visibility = EntitlementPositionList.get(0).isEnabled();
        Boolean EntitlementPosition2022Visibility = driver.findElements(EntitlementPosition2022Hidden).isEmpty();
        return EntitlementPosition2022Visibility;
    }

    // Clicking on the Entitlement Position 2021
    public void AgentClickOnEntitlementPosition2021() {
        actions.waitForVisibilityOfElement(EntitlementPosition2021, 10);
        driver.findElement(EntitlementPosition2021).click();
    }

    // Visibility of Entitlement Position 2021
    public Boolean VisibilityOfEntitlementPosition2021() {
//        actions.waitForVisibilityOfElement(EntitlementPosition2021, 10);
        Boolean EntitlementPosition2021Visibility = driver.findElements(EntitlementPosition2021Hidden).isEmpty();
        return EntitlementPosition2021Visibility;
    }

    // Clicking on the Entitlement Position 2020
    public void AgentClickOnEntitlementPosition2020() {
        actions.waitForVisibilityOfElement(EntitlementPosition2020, 10);
        driver.findElement(EntitlementPosition2020).click();
    }

    // Visibility of Entitlement Position 2020
    public Boolean VisibilityOfEntitlementPosition2020() {
//        actions.waitForVisibilityOfElement(EntitlementPosition2020, 10);
        Boolean EntitlementPosition2020Visibility = driver.findElements(EntitlementPosition2020Hidden).isEmpty();
        return EntitlementPosition2020Visibility;
    }

    // Clicking on the Entitlement Position 2015-2019
    public void AgentClickOnEntitlementPosition2015To2019() {
//        actions.waitForVisibilityOfElement(EntitlementPosition2015To2019, 10);
        if(driver.findElements(EntitlementPosition2015To2019Hidden).isEmpty()==true) {
            System.out.println("Entitlement Position 2015 To 2019 option is not present");
            AgentClickOnFarmDetailsNavLink();
        }
        else {
            driver.findElement(EntitlementPosition2015To2019).click();
        }
    }

    // Visibility of Entitlement Position 2015 to 2019
    public Boolean VisibilityOfEntitlementPosition2015To2019() {
//        actions.waitForVisibilityOfElement(EntitlementPosition2015To2019, 10);
        Boolean EntitlementPosition2015To2019Visibility = driver.findElements(EntitlementPosition2015To2019Hidden).isEmpty();
        return EntitlementPosition2015To2019Visibility;
    }

    // Clicking On Usage Position
    public void AgentClickOnUsagePosition() {
        actions.waitForVisibilityOfElement(UsagePosition, 10);
        driver.findElement(UsagePosition).click();
    }

    // Visibility of Usage Position
    public Boolean VisibilityOfUsagePosition() {
//        actions.waitForVisibilityOfElement(UsagePosition, 10);
        Boolean UsagePositionVisibility = driver.findElements(UsagePositionHidden).isEmpty();
        return UsagePositionVisibility;
    }

    // Clicking On Parcel Search
    public void AgentClickOnParcelSearch() {
        actions.waitForVisibilityOfElement(ParcelSearch, 10);
        driver.findElement(ParcelSearch).click();
    }

    // Visibility of Parcel Search
    public Boolean VisibilityOfParcelSearch() {
//        actions.waitForVisibilityOfElement(ParcelSearch, 10);
        Boolean ParcelSearchVisibility = driver.findElements(ParcelSearch).isEmpty();
        return ParcelSearchVisibility;
    }

    // Clicking On View Nitrates
    public void AgentClickOnViewNitrates() {
        actions.waitForVisibilityOfElement(ViewNitrates, 10);
        driver.findElement(ViewNitrates).click();
    }

    // Visibility of View Nitrates
    public Boolean VisibilityOfViewNitrates() {
//        actions.waitForVisibilityOfElement(ViewNitrates, 10);
        Boolean ViewNitratesVisibility = driver.findElements(ViewNitrates).isEmpty();
        return ViewNitratesVisibility;
    }

    // Clicking On Applications And Payments Summary
    public void AgentClickOnApplicationsAndPaymentsSummary() {
        actions.waitForVisibilityOfElement(ApplicationsAndPaymentsSummary, 10);
        driver.findElement(ApplicationsAndPaymentsSummary).click();
    }

    // Visibility of Applications And Payments Summary
    public Boolean VisibilityOfApplicationsAndPaymentsSummary() {
//        actions.waitForVisibilityOfElement(ApplicationsAndPaymentsSummary, 10);
        Boolean ApplicationsAndPaymentsSummaryVisibility = driver.findElements(ApplicationsAndPaymentsSummary).isEmpty();
        return ApplicationsAndPaymentsSummaryVisibility;
    }

    //endregion

    //region Correspondence Navlink
    /*** Correspondence Navlink ***/

    // Correspondence Navlink
    By MyCorrespondence = By.xpath("//a[contains(text(),'My Correspondence')]");
    By UploadDocument = By.xpath("//a[contains(text(),'Upload Document')]");
    By PrintCoverLetter = By.xpath("//a[contains(text(),'Print Cover Letter')]");

    // Clicking On My Correspondence
    public void AgentClickOnMyCorrespondence() {
        actions.waitForVisibilityOfElement(MyCorrespondence, 10);
        driver.findElement(MyCorrespondence).click();
    }

    // Visibility of My Correspondence
    public Boolean VisibilityOfMyCorrespondence() {
        actions.waitForVisibilityOfElement(MyCorrespondence, 10);
        Boolean MyCorrespondenceVisibility = driver.findElement(MyCorrespondence).isDisplayed();
        return MyCorrespondenceVisibility;
    }

    // Clicking On Upload Document
    public void AgentClickOnUploadDocument() {
        actions.waitForVisibilityOfElement(UploadDocument, 10);
        driver.findElement(UploadDocument).click();
    }

    // Visibility of Upload Document
    public Boolean VisibilityOfUploadDocument() {
        actions.waitForVisibilityOfElement(UploadDocument, 10);
        Boolean UploadDocumentVisibility = driver.findElement(UploadDocument).isDisplayed();
        return UploadDocumentVisibility;
    }

    // Clicking On Print Cover Letter
    public void AgentClickOnPrintCoverLetter() {
        if(driver.findElements(PrintCoverLetter).isEmpty()==false) {
            actions.waitForVisibilityOfElement(PrintCoverLetter, 10);
            driver.findElement(PrintCoverLetter).click();
        }
        else {
            System.out.println("No Print Cover Letter Option Displayed");
        }
    }

    // Visibility of Print Cover Letter
    public Boolean VisibilityOfPrintCoverLetter() {
//        actions.waitForVisibilityOfElement(PrintCoverLetter, 10);
        Boolean PrintCoverLetterVisibility = driver.findElements(PrintCoverLetter).isEmpty();
        return PrintCoverLetterVisibility;
    }
    //endregion

    //region Parcel Search Page

    // Parcel Search Page
    By ParcelIDTextBox = By.id("parcelSearch");
    By ParcelSearchButton = By.id("parcelSearchButton");

    // Agent Enter the Parcel Number
    public void AgentEnterParcelNumber(String Arg0) {
        actions.waitForVisibilityOfElement(ParcelIDTextBox, 30);
        actions.sendKeys(ParcelIDTextBox, String.valueOf(Arg0));
    }

    // Click On The Parcel Search Button
    public void AgentClickOnParcelSearchButton() {
        actions.waitForVisibilityOfElement(ParcelSearchButton,15);
        actions.clickUsingJS(ParcelSearchButton);
    }
    //endregion

    // region Applications And Payments Summary Page

    // Applications and payments summary
    By LandDetailsTab = By.xpath("//a[contains(text(),'Land Details')]");
    By ViewMapButton = By.xpath("//body[1]/div[3]/span[1]/div[1]/div[1]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[12]/form[1]/button[1]");

    // Click On The Land Details Tab
    public void AgentClickOnLandDetailsTab() {
        actions.waitForVisibilityOfElement(LandDetailsTab,15);
        actions.clickUsingJS(LandDetailsTab);
    }

    // Click On The View Map Button
    public void AgentClickOnViewMapButton() {
        actions.waitForVisibilityOfElement(ViewMapButton,15);
        actions.clickUsingJS(ViewMapButton);
    }
    // endregion

    //region Correspondence Page

    // My Correspondence Page
    By MyCorrespondenceSchemeYear = By.id("schemeYear");
    By GetCorrespondenceButton = By.id("correspondenceGetCorrespondenceButton");
    By CorrespondenceViewButton = By.id("correspondenceViewButton");

    // Selecting Correspondence Scheme Year
    public void AgentSelectCorrespondenceSchemeYear(int Arg0) {
        WebElement CorrespondenceSchemeYear = driver.findElement(MyCorrespondenceSchemeYear);
        actions.waitForVisibilityOfElement(MyCorrespondenceSchemeYear, 30);
        Select dropdown = new Select(CorrespondenceSchemeYear);
        dropdown.selectByIndex(Arg0);
    }

    // Click on Get Correspondence Button
    public void AgentClickOnGetCorrespondenceButton() {
        actions.waitForVisibilityOfElement(GetCorrespondenceButton,15);
        actions.clickUsingJS(GetCorrespondenceButton);
    }

    // Click on View Correspondence Button
    public void AgentClickOnViewCorrespondenceButton() {
        actions.waitForVisibilityOfElement(CorrespondenceViewButton,15);
        actions.clickUsingJS(CorrespondenceViewButton);
    }
    // endregion

//    // Clicking on the Applications And Payments Summary NavLink
//    public void AgentClickOnApplicationsAndPaymentsSummary() {
//        actions.waitForVisibilityOfElement(ApplicationsAndPaymentsSummary, 10);
//        actions.click(ApplicationsAndPaymentsSummary);
//    }
//
//
//    // Selecting Applications and Payments Summary Year
//    public void AgentSelectApplicationsAndSummarySchemeYear(String Arg0) {
//        WebElement DofUSchemeYear = driver.findElement(PreviousAppSearchSchemeYear);
//
//        actions.waitForVisibilityOfElement(PreviousAppSearchSchemeYear, 30);
//        Select dropdown = new Select(DofUSchemeYear);
//        dropdown.selectByValue(Arg0);
//    }
//
//    // Clicking on the Applications And Payments Summary View Button
//    public void AgentClickOnApplicationsAndPaymentsSummaryViewButton() {
//        actions.waitForVisibilityOfElement(ViewButton, 10);
//        actions.click(ViewButton);
//    }
}

