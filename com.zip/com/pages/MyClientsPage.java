package com.pages;

import com.base.ActionClass;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.Collections;

import java.io.IOException;
import java.util.List;

import static org.openqa.selenium.support.locators.RelativeLocator.*;

public class MyClientsPage extends ExcelPage{

    WebDriver driver;
    ActionClass actions;

    // region BPS Code

    By ClientRadioButton = By.id("optionsRadios2");
    By AgentViewButton = By.id("agentCommonListViewButton");


    // Client Page
    By ApplicationsNavLink = By.xpath("//body/nav[1]/div[1]/div[1]/div[2]/ul[1]/li[4]/a[1]");
    By FarmDetailsNavLink = By.xpath("//body/nav[1]/div[1]/div[1]/div[2]/ul[1]/li[5]/a[1]");
    By CorrespondenceNavLink = By.xpath("//body/nav[1]/div[1]/div[1]/div[2]/ul[1]/li[6]/a[1]");


    // Applications and payments summary
    By ApplicationsAndPaymentsSummary = By.xpath("//a[contains(text(),'Applications and Payments Summary')]");
    By PreviousAppSearchSchemeYear = By.id("previousAppSearchSchemeYear");
    By ViewButton = By.id("previousAppSearchView");

//    public MyClientsPage(WebDriver driver) {
//        super(driver);
//    }

    // Locators for future use
    public MyClientsPage(WebDriver driver) {
        this.driver = driver;
        actions = new ActionClass(driver);
    }

    // Clicking on the Client Checkbox button
    public void AgentClickOnClientRadioButton() {
        actions.waitForVisibilityOfElement(ClientRadioButton, 10);
        actions.click(ClientRadioButton);
    }

    // Clicking on the View Button
    public void AgentClickOnViewButton() {
        actions.waitForVisibilityOfElement(AgentViewButton, 10);
        driver.findElement(AgentViewButton).click();
    }

    // Visibility of the Applications NavLink
    public Boolean AgentVisibilityApplicationsNavLink() {
        actions.waitForVisibilityOfElement(ApplicationsNavLink, 10);
        Boolean ApplicationsNavlinkVisible = driver.findElement(ApplicationsNavLink).isDisplayed();
        return ApplicationsNavlinkVisible;
    }

    // Visibility of the Farm Details NavLink
    public Boolean AgentVisibilityFarmDetailsNavLink() {
        actions.waitForVisibilityOfElement(FarmDetailsNavLink, 10);
        Boolean FarmDetailsNavlinkVisible =  driver.findElement(FarmDetailsNavLink).isDisplayed();
        return FarmDetailsNavlinkVisible;
    }

    // Visibility of the Correspondence NavLink
    public Boolean AgentVisibilityCorrespondenceNavLink() {
        actions.waitForVisibilityOfElement(CorrespondenceNavLink, 10);
        Boolean CorrespondenceNavlinkVisibility = driver.findElement(CorrespondenceNavLink).isDisplayed();
        return CorrespondenceNavlinkVisibility;
    }

    // Clicking on the Applications And Payments Summary NavLink
    public void AgentClickOnApplicationsAndPaymentsSummary() {
        actions.waitForVisibilityOfElement(ApplicationsAndPaymentsSummary, 10);
        actions.click(ApplicationsAndPaymentsSummary);
    }

    // Selecting Applications and Payments Summary Year
    public void AgentSelectApplicationsAndSummarySchemeYear(int Arg0) {
        actions.waitForVisibilityOfElement(PreviousAppSearchSchemeYear, 30);
        WebElement PreviousAppSchemeYear = driver.findElement(PreviousAppSearchSchemeYear);
        Select dropdown = new Select(PreviousAppSchemeYear);
//        if(driver.findElement(PreviousAppSearchSchemeYear).getText()!="2021")
        dropdown.selectByIndex(Arg0);
    }

    // Clicking on the Applications And Payments Summary View Button
    public void AgentClickOnApplicationsAndPaymentsSummaryViewButton() {
        actions.waitForVisibilityOfElement(ViewButton, 10);
        actions.click(ViewButton);
    }

    // endregion

    // region BISS Code

    // region Common Methods

    // Get the Herd number before starting application and store in Excel
    public void StoreHerdNumberInExcel() throws IOException {
        By CurrentHerd = By.xpath("//div[contains(@class,'dashboard-user-information')]/descendant::span[4]");
        String CurrentHerdNumber = driver.findElement(CurrentHerd).getText();
        try {
            WriteHerdToFile1(CurrentHerdNumber);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Get the Agent Number and store in Excel
    public void StoreAgentNumberInExcel(String AgentNumber) throws IOException {
        try {
            WriteAgentToFile(AgentNumber);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Get the last Agent Number to determine parcels to be used
    public void GetPreviousAgentNumber() {
        try {
            GetLastAgentNumber();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    public List<String> PickParcelsAndPlotsForAgent(int CaseNumber) throws IOException {
        List<String> ParcelsAndPlots = null;
        switch (CaseNumber) {
            case 0: {
                // ha = 2
                ParcelsAndPlots.add("J1591700019");
                ParcelsAndPlots.add("");
                return ParcelsAndPlots;
            }
            case 1: {
                int n=2;
                return ParcelsAndPlots;
            }
            default:
                return null;
        }
    }

    // endregion

    // region Helpdesk Code
    // Staff Enter value in field
    public void StaffEnterValueInField(String Value, String FieldName) {
        By Field = By.xpath("//input[@id='search-form-username']");
        actions.sendKeys(Field,Value);
    }
    // endregion

    //Locators
    By PresentClient = By.xpath("//td[contains(text(),'B1021694')]");
    By PresentClientViewButton = By.xpath("(//td[contains(text(),'B1021694')])[2]/ancestor::tr/descendant::button/child::span[contains(text(),'View')]");
    By HerdSearch = By.xpath("//input[@placeholder='Name or Herd Number']");

    //Switching between tabs in My Clients
    // Locators Arg "BISS applications" , "Transfers" , "NR/CISYF, No Herd Number, AMS"
    public void AgentSwitchMyClientsTabs(String Arg0) throws InterruptedException {
        By Tabs = By.xpath("//div[@role='tab']/descendant::div[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(Tabs,30);
        actions.clickUsingJS(Tabs);
        Thread.sleep(3000);
        actions.clickUsingJS(Tabs);
    }

    // Agent Search for a particular herd
    public void AgentSearchForHerd(String Arg0) {
        actions.waitForVisibilityOfElement(HerdSearch,30);
        actions.sendKeys(HerdSearch,Arg0);
    }

    public String TransferKeyText;

    public String agentSearchInactiveHerdNumber(){
        By inactiveFarmerHerdNumber = By.xpath("(//mat-icon[@title='Inactive']/preceding::td[1])[1]");
        actions.sendKeys(HerdSearch, driver.findElement(inactiveFarmerHerdNumber).getText());
        TransferKeyText = driver.findElement(inactiveFarmerHerdNumber).getText();
        System.out.println(TransferKeyText);
        return driver.findElement(inactiveFarmerHerdNumber).getText();
    }

    public void StaffEnterInactiveFarmerValueInField(String FieldName) throws InterruptedException {
        By FieldLocator = By.xpath("//input[@formcontrolname='"+FieldName+"']");
        driver.findElement(FieldLocator).clear();
        System.out.println(TransferKeyText);
        actions.sendKeys(FieldLocator, TransferKeyText);
        Thread.sleep(3000);
    }

    // Agent Select various Quick Filters
    // Locators Arg "ViewAll" , "NotStarted", "Draft" , "Submitted" , "HerdExpired" , "Multiherd"
    public void AgentSelectQuickFilters(String Arg0) {
        By QuickFilters = By.xpath("//mat-button-toggle[@value='"+Arg0+"']/button");
//        actions.waitForVisibilityOfElement(QuickFilters,50);
        actions.clickUsingJS(QuickFilters);
    }

    // Agent sorting Clients
    // Locators Arg "Name" , "Herd Number"
    public void AgentSortClients(String Arg0) {
        By SortHeading = By.xpath("//th/descendant::div[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(SortHeading,30);
        actions.clickUsingJS(SortHeading);
    }

    // Agent expand the Client Row
    // Locators Arg "Herd Number"
    public void AgentExpandClientRow(String Arg0) {
        By Client = By.xpath("//tr/descendant::td[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(Client,30);
        actions.clickUsingJS(Client);
    }

    // Agent Click on the first Client in the Not Started List
    public void AgentClickOnFirstClientInList() {
        By FirstHerd = By.xpath("(//td[contains(@class,'cdk-column-displayName')]/a)[1]");
        actions.clickUsingJS(FirstHerd);
    }

    // Agent Navigate to Expanded Row Client
    public void AgentClickOnViewDashboard() throws IOException,InterruptedException {
        By VewDashboardButton = By.xpath("//tr[contains(@class,'client-list-expanded-row')]//following-sibling::tr[1]/descendant::span[contains(text(),'View dashboard')]");
        actions.waitForVisibilityOfElement(VewDashboardButton,30);
        actions.clickUsingJS(VewDashboardButton);
        Thread.sleep(3000);
        StoreHerdNumberInExcel();
    }

    // Agent navigate to client directly
    public void AgentNavigateToClient(String Arg0) {
        WebElement Client = driver.findElement(By.xpath("//td[contains(text(),'"+Arg0+"')]"));
        WebElement ClientName = driver.findElement(with(By.tagName("a"))
                .toLeftOf(Client));
        actions.waitForVisibilityOfElement((By) ClientName,30);
        JavascriptExecutor executor = (JavascriptExecutor)driver;
        executor.executeScript("arguments[0].click();", ClientName);
    }

    // Agent handling Pagination
    // Locators
    By NumberOfRowsDisplayed = By.xpath("//mat-select[contains(@aria-labelledby,'mat-paginator-page-size')]");

    // Change the value of the number of rows displayed in the page
    public void ChangeNumberOfRowsDisplayedInPage(String Arg0) {
        actions.waitForVisibilityOfElement(NumberOfRowsDisplayed, 30);
        actions.clickUsingJS(NumberOfRowsDisplayed);
        By NoOfRows = By.xpath("//span[contains(text(),'"+Arg0+"')]/ancestor::mat-option");
        actions.waitForVisibilityOfElement(NoOfRows, 30);
        actions.clickUsingJS(NoOfRows);
    }

    // Agent use the pagination navigation buttons
    // Agent switch between news in News Section
    // Locators Arg First page, Next page, Previous page, Last page
    public void AgentClickOnPaginationAndNewsNavigationButtons(String Arg0) {
        By PaginationNavButton = By.xpath("//button[@aria-label='"+Arg0+"']");
        actions.waitForVisibilityOfElement(PaginationNavButton,30);
        actions.clickUsingJS(PaginationNavButton);
    }


    // region My Correspondence Page
    By UploadDocsAccordion = By.xpath("//mat-accordion/descendant::span[contains(text(),'Upload Documents')]");
    By ChooseFileButton = By.xpath("//input[contains(@formcontrolname,'file')]");

    public void AgentClickOnUploadDocAccordion() {
       actions.waitForVisibilityOfElement(UploadDocsAccordion,30);
       actions.clickUsingJS(UploadDocsAccordion);
    }

    public void AgentSelectDocumentTypeInDropdown(String DropdownName, String DocType) {
        By SearchParcelDropdowns = By.xpath("//mat-select[@id='"+DropdownName+"']");
        actions.waitForVisibilityOfElement(SearchParcelDropdowns,30);
        actions.clickUsingJS(SearchParcelDropdowns);
        By DocumentType = By.xpath("//mat-option[contains(text(),'"+DocType+"')]");
        actions.waitForVisibilityOfElement(DocumentType, 30);
        actions.clickUsingJS(DocumentType);
        actions.waitforSeconds(6);
    }

    // Upload Document
    // RemoteWebElement Line has to be commented out to run locally but when pushing in code has to be uncommented
    public void UploadDocument() {
        //actions.waitForVisibilityOfElement(ChooseFileButton,15);
        WebElement Choosefile = driver.findElement(By.xpath("//input[@type='file']"));
        // Has to be enabled while running on Grid if not in Driver Manager
        //((RemoteWebElement)driver).setFileDetector(new LocalFileDetector());
        Choosefile.sendKeys("C:/Users/Akanksha.Singh/Desktop/Selenium/TestData/Cover_Letter.pdf");
        // Path for Local Run
      //  Choosefile.sendKeys("C:/Users/akanksha.singh/BISS_Internal/BISS_Staff_DR_Scenarios_CENTEST/biss-staff-dr-scenarios-automation-centest/src/main/resources/TestData/Cover_Letter.pdf");
    }


    // endregion
    public List<String>  herdsOfCurrentAgentStrings;
    By herdsOfAgent = By.xpath("//div[contains(text(),'Not Started')]/preceding::td[4]");

    By pageDropdown = By.xpath("//mat-card-content/lib-biss-paginator/div/mat-paginator/div/div/div[1]/mat-form-field");
    By lastPage =   By.xpath("//mat-option[4]");
    public void agentPicksFirstHerdInList() throws InterruptedException {


        actions.waitforSeconds(5);
        driver.findElement(pageDropdown).click();
//        Select sl = new Select(driver.findElement(pageDropdown));
//        sl.selectByIndex(4);
        driver.findElement(lastPage).click();
        actions.waitforSeconds(5);
        List<WebElement> herdsOfCurrentAgent = driver.findElements(herdsOfAgent);
        //add string value from herdsOfCurrentAgent to herdsOfCurrentAgentStrings
        herdsOfCurrentAgentStrings = new ArrayList<>();
        for(WebElement iterator : herdsOfCurrentAgent){
            herdsOfCurrentAgentStrings.add(iterator.getText());
        }
        System.out.println(herdsOfCurrentAgentStrings);
        Thread.sleep(10000);
        By herdExpiredTab = By.xpath("//button/span[contains(text(),' Herd Expired ')]");
        actions.clickUsingJS(herdExpiredTab);
        Thread.sleep(5000);
        List<WebElement> expiredHerdsOfCurrentAgent = driver.findElements(herdsOfAgent);
        //add string value from submittedHerdsOfCurrentAgent to herdsOfCurrentAgentStrings
        List<String> expiredHerdsOfCurrentAgentStrings = new ArrayList<>();
        for(WebElement iterator : expiredHerdsOfCurrentAgent){
            expiredHerdsOfCurrentAgentStrings.add(iterator.getText());
        }
        System.out.println("Expired Herds : "+ expiredHerdsOfCurrentAgentStrings);
        //compare two list and remove submitted herd
        herdsOfCurrentAgentStrings.removeIf(expiredHerdsOfCurrentAgentStrings :: contains);
        System.out.println("After Removing Expired Herds : "+ herdsOfCurrentAgentStrings);
     //   System.out.println(expiredHerdsOfCurrentAgentStrings);
        driver.findElement(herdExpiredTab).click();
//        if(driver.findElement(expiredHerd).getText().equals("Herd expired")){
////            for(arg = 1;driver.findElement(expiredHerd).getText().equals("Herd expired");arg++){
////                while(driver.findElement(expiredHerd).getText().isEmpty()){
////                    expiredHerd = By.xpath("(//div[contains(text(),'Not Started')]/preceding::td[2]/span)["+arg+"]");
////                    herdsOfAgent = By.xpath("(//div[contains(text(),'Not Started')]/preceding::td[4])["+arg+"]");
////                    System.out.println(driver.findElement(herdsOfAgent).getText());
////                }
////
////            }
//            arg++;
//            herdsOfAgent = By.xpath("(//div[contains(text(),'Not Started')]/preceding::td[4])["+arg+"]");
//            herdsOfCurrentAgentStrings = driver.findElement(herdsOfAgent).getText();
//            System.out.println(herdsOfCurrentAgentStrings);
//            System.out.println("herd was expired and new herd was picked");
//            actions.clickUsingJS(herdsOfAgent);
//        }else{
//            herdsOfCurrentAgentStrings = driver.findElement(herdsOfAgent).getText();
//            System.out.println(herdsOfCurrentAgentStrings);
//            System.out.println("herd was not expired and herd was picked");
//            actions.clickUsingJS(herdsOfAgent);
//
//        }

    }

    // Agent Search for a particular herd
    public void AgentSearchForHerd() throws InterruptedException {
        actions.waitForVisibilityOfElement(HerdSearch,30);
        actions.sendKeys(HerdSearch,herdsOfCurrentAgentStrings.get(0));
        Thread.sleep(3000);
        actions.clickUsingJS(herdsOfAgent);
    }

    // Staff Enter Same Herd Value from agent in search bar
    public void StaffEnterSameValueInField(String FieldName) throws InterruptedException {
        System.out.println(herdsOfCurrentAgentStrings);
        By FieldLocator = By.xpath("//input[@formcontrolname='"+FieldName+"']");
        driver.findElement(FieldLocator).clear();
        actions.sendKeys(FieldLocator, herdsOfCurrentAgentStrings.get(0));
        Thread.sleep(3000);
    }

    // endregion

    public void AgentClickOnAngelaOsullivan() {

    }


    public List<String> GetAgentNumbers() throws IOException {
        return GetAgentNumberAsArray();
    }



    public void AgentSelectFirstHerdInList(int n) throws InterruptedException {
        By FirstHerd = By.xpath("(//td[contains(@class,'cdk-column-displayName')]/a)["+n+"]");
        actions.waitForVisibilityOfElement(FirstHerd,50);
        actions.clickUsingJS(FirstHerd);
        Thread.sleep(2000);
//        By StartApplicationbutton = By.xpath("//button/descendant::span[contains(text(),'Start application')]");
//        List<WebElement> StartApplicationVisibility = driver.findElements(StartApplicationbutton);
////        Boolean StartApplicationVisibility = actions.waitForVisibilityOfElement(StartApplicationbutton,30);
//        while(StartApplicationVisibility.isEmpty()){
//            By MyClientsButton = By.xpath("//a/descendant::mat-icon[@aria-label='My Clients']");
//            actions.clickUsingJS(MyClientsButton);
//            AgentSelectQuickFilters("NotStarted");
//            n++;
//        }
//        By Herd = By.xpath("(//td[contains(@class,'cdk-column-displayName')]/a)["+n+"]");
//        actions.clickUsingJS(Herd);

//        if(StartApplicationVisibility.equals(true)) {
//            actions.clickUsingJS(StartApplicationbutton);
//        }
//        else {
//            By MyClientsButton = By.xpath("//a/descendant::mat-icon[@aria-label='My Clients']");
//            actions.clickUsingJS(MyClientsButton);
//
//            while(StartApplicationVisibility.equals(false)) {
//                n++;
//                By Herd = By.xpath("(//td[contains(@class,'cdk-column-displayName')])["+n+"]");
//
//            }
//        }
    }
}

