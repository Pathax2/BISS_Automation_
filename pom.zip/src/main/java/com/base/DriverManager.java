package com.base;

import org.openqa.selenium.Platform;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Reporter;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.time.Duration;

public class DriverManager {
    private RemoteWebDriver driver;
    DesiredCapabilities cap = null;

//    public static Connection getConnection(String url) {
//        return null;
//    }

    public WebDriver getDriver() throws MalformedURLException {
        String browser = null;
        if (Reporter.getCurrentTestResult() != null) {
            browser = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("browser");
        }
        if (browser == null) {
            browser = "chrome";
        }
        switch (browser.toLowerCase()) {
            case "edge":
                System.setProperty("webdriver.edge.driver", "src/main/resources/drivers/msedgedriver.exe");
                EdgeOptions edgeOptions = new EdgeOptions();
                edgeOptions.addArguments("--disable-extensions");
                edgeOptions.addArguments("disable-infobars");
                edgeOptions.addArguments("start-maximized");
                edgeOptions.addArguments("--disable-gpu");
                driver = new EdgeDriver(edgeOptions);
                driver.manage().deleteAllCookies();
                driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
                driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(60));
                break;
            case "chrome":
                System.setProperty("webdriver.chrome.driver", "src/main/resources/drivers/chromedriver.exe");
                ChromeOptions options1 = new ChromeOptions();
                options1.addArguments("--remote-allow-origins=*");
                options1.addArguments("--disable-extensions");
                options1.addArguments("disable-infobars");
                options1.addArguments("start-maximized");
                options1.addArguments("--disable-gpu");
                options1.addArguments("--disable-search-engine-choice-screen");
                driver = new ChromeDriver(options1);
                driver.manage().deleteAllCookies();
                driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
                driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(60));
                break;

            case "firefox":

                System.setProperty("webdriver.gecko.driver", "src/main/resources/drivers/geckodriver.exe");
                FirefoxOptions firefoxOptions = new FirefoxOptions();
                firefoxOptions.addArguments("--disable-extensions");
                firefoxOptions.addArguments("disable-infobars");
                firefoxOptions.addArguments("start-maximized");
                firefoxOptions.addArguments("--disable-gpu");
                driver = new FirefoxDriver(firefoxOptions);
                driver.manage().deleteAllCookies();
                driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
                driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(60));
                break;

            case "gridchrome":

                HttpURLConnection connection = null;
                try {
//                    URL u = new URL("http://10.2.19.230:4444/ui/index.html#/");
//                    URL u = new URL("http://10.2.22.80:4444/ui/index.html#/");
                    URL u = new URL("http://10.2.67.210:4444/ui/index.html#/");
                    connection = (HttpURLConnection) u.openConnection();
                    connection.setRequestMethod("HEAD");
                    int code = connection.getResponseCode();
                    System.out.println("status code :" + code);
                    // You can determine on HTTP return code received. 200 is success.
                } catch (MalformedURLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } finally {
                    if (connection != null) {
                        connection.disconnect();
                    }
                }

                System.setProperty("webdriver.chrome.driver", "src/main/resources/drivers/chromedriver.exe");
                ChromeOptions chromeOptions = new ChromeOptions();
                chromeOptions.addArguments("--ignore-certificate-errors",
                        "--allow-insecure-localhost","--disable-gpu","--disable-search-engine-choice-screen");
                chromeOptions.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.DISMISS);
                cap = new DesiredCapabilities();
                cap.setBrowserName("chrome");
                cap.setPlatform(Platform.ANY);
                cap.setCapability("platform", Platform.ANY);
                cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS,true);
                cap.setCapability(ChromeOptions.CAPABILITY,chromeOptions);
                System.out.println("before remote");
//                driver=new RemoteWebDriver(new URL("http://10.2.19.230:4444/wd/hub"),cap);
//                driver=new RemoteWebDriver(new URL("http://10.2.22.80:4444/wd/hub"),cap);
                driver=new RemoteWebDriver(new URL("http://10.2.67.210:4444/wd/hub"),cap);
                //((RemoteWebDriver)driver).setFileDetector(new LocalFileDetector());
                driver.setFileDetector(new LocalFileDetector());
                driver.manage().window().maximize();
                driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
                driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(60));

        }

        return driver;
    }

    public WebDriver getDriverInstance() {

        return driver;
    }

    public void closeBrowser() {
        driver.quit();
    }

}
