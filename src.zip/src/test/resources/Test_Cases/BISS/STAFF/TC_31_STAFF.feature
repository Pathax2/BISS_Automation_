Feature: TC_S31 - Regression Pack for Openshift Active Farmer Approve and Reject

  # ──────────────────────────────────────────────────────────────────────────
  # Purpose:
  #   Validates Active Farmer admin check initiation for the reject flow (TC01)
  #   and the approve flow (TC02) on the Openshift environment.
  #
  # Common Background:
  #   Openshift staff login as agr4442 → open BISS application.
  #
  # DB Data:
  #   5 herds with Admin Check Not Started resolved from Oracle DB at runtime.
  #   Row 2 used for TC01, row 3 for TC02.
  #
  # Notes:
  #   1. Both TCs start the admin check and send the notification.
  #   2. TC01 is the reject flow initiation and TC02 is the approve flow initiation.
  #   3. The distinction between approve and reject paths will be implemented
  #      in the step definition by checking the dialog context after "Send" is clicked.
  #
  # Author  : Aniket Pathare | aniket.pathare@government.ie
  # Created : 2026-05-14
  # ──────────────────────────────────────────────────────────────────────────

  Background:
    Given the staff user is on the Openshift staff login page
    When the staff user logs in with username "agr4442"
    And the staff user selects the data protection checkbox and clicks login
    And the staff user opens the "Basic Income Support for Sustainability" application
    Then Get 5 Herds with Admin Check Not Started from DB

  @tmsLink=BISSAGL-18613 @tmsLink=BISSAGL-18616 @regression
  Scenario: TC_S31 - Openshift Active Farmer Approve and Reject end-to-end regression

    # ── TC01: Start admin check and send notification (reject path initiation) ─
    When the staff user opens herd with admin check not started from row 2 for scheme year "2024" and navigates to Active Farmer
    And the staff user starts the admin check and sends the notification
    Then the admin check notification should be confirmed and the application updated

    # ── TC02: Start admin check and send notification (approve path initiation)
    When the staff user opens herd with admin check not started from row 3 for scheme year "2024" and navigates to Active Farmer
    And the staff user starts the admin check and sends the notification
    Then the admin check notification should be confirmed and the application updated