Feature: TC_08_ENTS - Transfer Application E2E Regression Pack (Individual to Agent)

  # --------------------------------------------------------------------------------------------------------------------
  # Purpose:
  #   Single end-to-end regression journey covering Transfer of Entitlements flows where the Transferor is an
  #   Individual (own login) and the Transferee is a client herd of agent aga6325.
  #     - the individual opens "Transfers" from the farmer side navigation and goes straight to Create Transfer
  #       (no herd search); the agent then searches the transferee herd in Transfer Out and accepts with the key
  #
  #   Transfer types covered:
  #     Section 1 : Change of Legal Entity (206)  - Selenium: FARMBLUE        to Z1114042 (Owens Mart Ltd)     + signature upload
  #     Section 2 : Inheritance            (201)  - Selenium: JAMESSKEHILL    to Z2170744 (Hugh Patrick Gore)
  #     Section 3 : Gift                   (202)  - Selenium: EUGENECARR      to Z1180657 (Patrick Keenan)
  #     Section 4 : Lease                  (211)  - Selenium: CATHERINEMORAN2 to Z1190016 (Brendan Fitzjohn)   + lease year
  #     Section 5 : Merger                 (203)  - Selenium: HNOW1280483     to Z1270559 (Thomas Cooke)
  #     Section 6 : Division               (204)  - Selenium: ANGELAMCGLYNN   to Z1330942 (Joanne Moroney)
  #     Section 7 : Sale                   (212)  - Selenium: JHARKIN1        to Z1334069 (Ronan O'Neill)
  #     Section 8 : Change of Registration (205)  - Selenium: SOUTHVIEW1      to Z2120933 (Richard Keenan)
  #
  # Migrated from: TC_08_ENTS.feature (legacy 8 separate scenarios)
  #
  # Runtime data (Playwright, 30-09-2026):
  #   The login step runs before the create step, so the pair is built in two halves (EntsTestData):
  #     "the individual logs in as transferor {transferor.login}" picks an unused herd from the Individual Login query
  #       (holder has their own online login) and logs its owner in
  #     the create step then picks the transferee: an unused herd from the Agent Login pool of the agent in the
  #       transfereeAgent row (completePairWithAgentTransferee)
  #     {transferor.login}  {transferee.herd}  {transferee.name}  {transferee.agent}
  #   Every pick is written to runtime-data/ents_used_herds.csv and never reused. Put a herd number, name or login back
  #   in any cell to pin it for debugging (the Selenium values are in the comments of each section).
  #
  # Step reuse:
  #   Background login / navigation / side navigation -> stepdefinitions.TC_03
  #   Individual login + create, agent login + acceptance -> stepdefinitions.ENTS.TC_08_ENTS
  #   Upload / send / key / submit                    -> stepdefinitions.ENTS.TC_01_ENTS
  #   Agent logout + login (transferee)               -> stepdefinitions.ENTS.TC_03_ENTS
  #   Tab switching                                   -> stepdefinitions.TC_06
  #
  # Author : Aniket Pathare | aniket.pathare@government.ie
  # Created: 31-03-2026 | Updated: 30-09-2026 (Playwright + runtime ENTS data)
  # --------------------------------------------------------------------------------------------------------------------

  Background:
    Given the agent user is on the login page
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |

  @regression @transfers @individual-to-agent @e2e
  Scenario: AT-ENTS-TRANSFERS-E2E-08 - Individual completes all transfer types to Agent

    # ===========================================
    # SECTION 1 : Change of Legal Entity (206)
    # Selenium: FARMBLUE to Z1114042 (Owens Mart Ltd)
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual creates a transfer application with the following details
      | transfereeHerd  | {transferee.herd}      |
      | transfereeName  | {transferee.name}      |
      | transfereeAgent | aga6325                |
      | transferType    | Change of Legal Entity |
      | entitlements    | 0.01                   |
      | notes           | Test Notes             |
    And the agent uploads the transferor signature document
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Agent) ---
    When the agent logs out and re-logs in as the transferee agent "{transferee.agent}"
    And the agent opens the "Basic Income Support for Sustainability" application
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 2 : Inheritance (201)
    # Selenium: JAMESSKEHILL to Z2170744 (Hugh Patrick Gore)
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual creates a transfer application with the following details
      | transfereeHerd  | {transferee.herd}           |
      | transfereeName  | {transferee.name}           |
      | transfereeAgent | aga6325                     |
      | transferType    | Inheritance of Entitlements |
      | entitlements    | 0.01                        |
      | notes           | Test Notes                  |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Agent) ---
    When the agent logs out and re-logs in as the transferee agent "{transferee.agent}"
    And the agent opens the "Basic Income Support for Sustainability" application
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 3 : Gift of Entitlements (202)
    # Selenium: EUGENECARR to Z1180657 (Patrick Keenan)
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual creates a transfer application with the following details
      | transfereeHerd  | {transferee.herd}    |
      | transfereeName  | {transferee.name}    |
      | transfereeAgent | aga6325              |
      | transferType    | Gift of Entitlements |
      | entitlements    | 0.01                 |
      | notes           | Test Notes           |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Agent) ---
    When the agent logs out and re-logs in as the transferee agent "{transferee.agent}"
    And the agent opens the "Basic Income Support for Sustainability" application
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 4 : Lease of Entitlements (211)
    # Selenium: CATHERINEMORAN2 to Z1190016 (Brendan Fitzjohn)
    # NOTE: Lease includes lease year selection
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual creates a transfer application with the following details
      | transfereeHerd  | {transferee.herd}     |
      | transfereeName  | {transferee.name}     |
      | transfereeAgent | aga6325               |
      | transferType    | Lease of Entitlements |
      | entitlements    | 0.01                  |
      | leaseYear       | Yes                   |
      | notes           | Test Notes            |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Agent) ---
    When the agent logs out and re-logs in as the transferee agent "{transferee.agent}"
    And the agent opens the "Basic Income Support for Sustainability" application
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 5 : Merger of Entitlements (203)
    # Selenium: HNOW1280483 to Z1270559 (Thomas Cooke)
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual creates a transfer application with the following details
      | transfereeHerd  | {transferee.herd}                                                       |
      | transfereeName  | {transferee.name}                                                       |
      | transfereeAgent | aga6325                                                                 |
      | transferType    | Merger of 2 or more holdings (forming an unregistered Farm Partnership) |
      | entitlements    | 0.01                                                                    |
      | notes           | Test Notes                                                              |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Agent) ---
    When the agent logs out and re-logs in as the transferee agent "{transferee.agent}"
    And the agent opens the "Basic Income Support for Sustainability" application
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 6 : Division of Entitlements (204)
    # Selenium: ANGELAMCGLYNN to Z1330942 (Joanne Moroney)
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual creates a transfer application with the following details
      | transfereeHerd  | {transferee.herd}                   |
      | transfereeName  | {transferee.name}                   |
      | transfereeAgent | aga6325                             |
      | transferType    | Division of Entitlements (Scission) |
      | entitlements    | 0.01                                |
      | notes           | Test Notes                          |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Agent) ---
    When the agent logs out and re-logs in as the transferee agent "{transferee.agent}"
    And the agent opens the "Basic Income Support for Sustainability" application
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 7 : Sale of Entitlements (212)
    # Selenium: JHARKIN1 to Z1334069 (Ronan O'Neill)
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual creates a transfer application with the following details
      | transfereeHerd  | {transferee.herd}    |
      | transfereeName  | {transferee.name}    |
      | transfereeAgent | aga6325              |
      | transferType    | Sale of Entitlements |
      | entitlements    | 0.01                 |
      | notes           | Test Notes           |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Agent) ---
    When the agent logs out and re-logs in as the transferee agent "{transferee.agent}"
    And the agent opens the "Basic Income Support for Sustainability" application
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 8 : Change of Registration (205)
    # Selenium: SOUTHVIEW1 to Z2120933 (Richard Keenan)
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual creates a transfer application with the following details
      | transfereeHerd  | {transferee.herd}              |
      | transfereeName  | {transferee.name}              |
      | transfereeAgent | aga6325                        |
      | transferType    | Change of Registration Details |
      | entitlements    | 0.01                           |
      | notes           | Test Notes                     |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Agent) ---
    When the agent logs out and re-logs in as the transferee agent "{transferee.agent}"
    And the agent opens the "Basic Income Support for Sustainability" application
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully