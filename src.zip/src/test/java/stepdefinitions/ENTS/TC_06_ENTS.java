// ===================================================================================================================================
// File          : TC_06_ENTS.java
// Package       : stepdefinitions.ENTS
// Description   : Step definitions for TC_06_ENTS - Transfer Application E2E (Agent 6 to Individual).
//
//                 THIS FILE CONTAINS NO STEP DEFINITIONS.
//                 Every step of TC_06_ENTS.feature is already defined elsewhere; the file is kept as the traceability
//                 anchor for the test case, and as the place for any TC_06-only step added later.
//
//                 Reuse map (Playwright, 30-09-2026):
//                   the agent user is on the login page                              -> stepdefinitions.TC_03
//                   the individual logs in as transferor {string}                    -> stepdefinitions.ENTS.TC_08_ENTS
//                   the agent opens the {string} application                         -> stepdefinitions.TC_03
//                   the agent should land on the BISS Home page                      -> stepdefinitions.TC_03
//                   the agent navigates to ... Left Menu Link                        -> stepdefinitions.TC_03
//                   the agent navigates through the farmer side navigation tabs      -> stepdefinitions.TC_03
//                   the agent switches to the {string} tab ...                       -> stepdefinitions.TC_06
//                   the agent creates a transfer application with the following...   -> stepdefinitions.ENTS.TC_01_ENTS
//                   the agent uploads the transferor signature document              -> stepdefinitions.ENTS.TC_01_ENTS
//                   the agent sends the transfer for acceptance                      -> stepdefinitions.ENTS.TC_01_ENTS
//                   the transfer key should be captured                              -> stepdefinitions.ENTS.TC_01_ENTS
//                   the transfer should be submitted successfully                    -> stepdefinitions.ENTS.TC_01_ENTS
//                   the agent logs out and re-logs in as the transferee agent        -> stepdefinitions.ENTS.TC_03_ENTS
//                   the agent logs out and re-logs in as the individual transferee   -> stepdefinitions.ENTS.TC_05_ENTS
//                   the individual completes the transferee acceptance flow          -> stepdefinitions.ENTS.TC_05_ENTS
//
//                 Transfer types covered, all through the same parameterised steps:
//                   Merger | Division | Sale | Change of Legal Entity
//
//                 Runtime data (30-09-2026): the transferor herd comes from the agent's Agent Login pool and the
//                 transferee herd + login from the Individual Login query (a "transfereeType | Individual" row in the
//                 create table - utilities.EntsTestData.nextAgentToIndividualPair). The Selenium version used the
//                 fixed individuals DANIELPAUL (Y1310159), TERENCE1 (Y1041344) and PAUDYFROG (Y104069X); any of them
//                 can still be pinned in the feature file for debugging.
//
//                 If TC_06_ENTS ever needs a step of its own, add it here rather than to TC_01_ENTS or TC_05_ENTS.
//
// Author        : Aniket Pathare | aniket.pathare@government.ie
// Date Created  : 31-03-2026 | Updated: 30-09-2026 (Playwright + runtime ENTS data)
// ===================================================================================================================================

package stepdefinitions.ENTS;

public class TC_06_ENTS
{
    // Cucumber scans the whole glue path, so the steps of TC_06_ENTS.feature bind from the classes listed above.
    // No step definitions are needed here.
}