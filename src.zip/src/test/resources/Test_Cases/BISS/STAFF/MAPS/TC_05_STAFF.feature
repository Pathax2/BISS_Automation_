# ====================================================================================================================================
# TC_05_STAFF.feature
# ====================================================================================================================================
@maps @regression @staff
Feature: TC_05_STAFF - Maps on the Correspondence Screen

  # Migrated from legacy "Regression Pack for Maps in Correspondence" (BISSAGL-3161 / 3162).
  # Both legacy @tmslink tags were commented out.
  #
  # BUSINESS FLOW
  #   A map generated for a herd should be saved against the application and viewable from
  #   the Correspondence screen alongside the herd's other documents.
  #
  # WHAT THIS VALIDATES
  #   Currently: nothing beyond the searches completing.
  #
  # LEGACY COVERAGE WARNING
  #   Both scenarios are searches with their assertions commented out:
  #     AT-TC-01 - "Staff Scroll to Documents Section" disabled, note reads
  #                "Expected Link not found / Clicking on Links throws issues".
  #     AT-TC-02 - "Click on Correspondence Quick Link in Navbar" disabled.
  #   The Correspondence link appears to have been broken or moved when these were written.
  #   Reproduced faithfully as searches. ACTION: confirm the current Correspondence UI and
  #   write the document-visibility assertion this pack is named for.
  #
  # TEST DATA NOTE
  #   O1020191 is the hardcoded correspondence fixture - kept as a literal.


  Background:
    Given the staff user is logged in to the BISS internal portal as "agr2332"

  @e2e @correspondence
  Scenario: Staff searches a herd and generates a parcel map intended for Correspondence

    # SECTION 1 - AT-TC-01
    # Legacy asserts nothing - the Documents section step is commented out.
    When the staff user searches the Home screen for herd "O1020191" for scheme year "2023"

    # SECTION 2 - AT-TC-02
    # Legacy asserts nothing - the Correspondence navigation step is commented out.
    When the staff user is on the Map Printing screen
    When the staff user searches Map Printing with no parcel number
    When the staff user searches Map Printing for partnership parcel "K1360100094" for scheme year "2023"