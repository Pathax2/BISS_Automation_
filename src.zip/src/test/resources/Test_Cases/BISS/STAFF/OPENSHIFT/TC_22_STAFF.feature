Feature: TC_S22 - Regression Pack for AMS Internal Screen

  # ──────────────────────────────────────────────────────────────────────────
  # Purpose:
  #   Validates the AMS internal screen read-only view and tooltip interactions.
  #   Covers:
  #     - TC01: SSO Admin role setup (all AMS/Co-ord/Processing/Inspections/Risk/Digitising)
  #             then verify AMS screen columns, partner herd tabs and pagination
  #     - TC02: Direct login as agr0191 (roles assumed set) — re-verify AMS screen
  #     - TC03: Hover over all four AMS status colour indicators (yellow, green, red, grey)
  #
  # Common Background:
  #   No shared login — TC01 starts with agr0043 (SSO Admin), then switches to agr0191.
  #   TC02 and TC03 login directly as agr0191.
  #
  # DB Data:
  #   No DB pool step required. Fixed partnership herd IFP10100 has known AMS data.
  #
  # Notes:
  #   1. agr0043 is the Helpdesk admin for SSO role configuration.
  #   2. agr0191 is the test staff user.
  #   3. IFP10100 is a fixed partnership farmer herd with known partner herds
  #      I1330645 and I1020085 — tab switching verifies partnership navigation.
  #   4. Tooltip content cannot be asserted as tooltips are transient on hover.
  #      TC03 verifies the hover action triggers without error.
  #   5. AMS column header case differs slightly between TC01 and TC02
  #      ("AMS finding" vs "AMS Finding") — each is matched as reported in legacy.
  #
  # Author  : Aniket Pathare | aniket.pathare@government.ie
  # Created : 2026-05-14
  # ──────────────────────────────────────────────────────────────────────────

  Background:
    Given the staff user is on the staff login page

  @tmsLink=BISSAGL-14750 @tmsLink=BISSAGL-14748 @tmsLink=BISSAGL-14724 @regression
  Scenario: TC_S22 - AMS Internal Screen end-to-end regression

    # ── TC01: Full role setup via SSO Admin then verify AMS screen ────────────
    When "agr0043" logs in and assigns all AMS, Co-ordination, Processing, Inspections, Risk and Digitising roles to "agr0191"
    And "agr0191" logs in, opens herd "IFP10100" for scheme year "2024" and navigates to the AMS Inspections tab
    Then the AMS screen should display Partnership Farmer and Herd Number client details
    And switching between partner herd tabs "I1330645" and "I1020085" should work correctly
    And the AMS table should contain all expected column headers
      | Townland | Parcel no. | AMS status | Scheme | AMS finding | AMS monitoring status |
      | Claimed area (ha) | Updated claimed area (ha) | Parcel use | Updated parcel use | Inspected crop found |
    And AMS table pagination controls should function correctly

    # ── TC02: Direct login as agr0191 and re-verify AMS screen ───────────────
    When "agr0191" logs in, opens herd "IFP10100" for scheme year "2024" and navigates to the AMS Inspections tab
    Then the AMS screen should display Partnership Farmer and Herd Number client details
    And switching between partner herd tabs "I1330645" and "I1020085" should work correctly
    And the AMS table should contain all expected column headers
      | Townland | Parcel no. | AMS status | Scheme | AMS Finding | AMS monitoring status |
      | Claimed area (ha) | Updated claimed area (ha) | Parcel use | Updated parcel use | Inspected crop found |
    And AMS table pagination controls should function correctly

    # ── TC03: Hover over all four AMS status indicators ───────────────────────
    When "agr0191" logs in, opens herd "IFP10100" for scheme year "2024" and navigates to the AMS Inspections tab
    Then hovering over the yellow, green, red and grey AMS status indicators should trigger their respective tooltips without error