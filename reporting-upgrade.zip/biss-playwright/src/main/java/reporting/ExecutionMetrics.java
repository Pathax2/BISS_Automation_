// ===================================================================================================================================
// File          : ExecutionMetrics.java
// Package       : reporting
// Description   : Records what happened during a run, for the dashboard report (DashboardReport) and metrics.json.
//                 The framework feeds it directly while the tests run - nothing is read back from the log files.
//
//                 What is recorded                               Fed by
//                   every iAction (action, locator, ms, result)    CommonFunctions.iAction / clickWithFallback
//                   JavaScript-click fallbacks                     CommonFunctions.clickWithFallback
//                   herds handed out, replaced, BAD, USED          EntsTestData, TestDataVault
//                   completed transfers (agent -> agent)           EntsTestData.markCurrentPairUsed
//                   database query times                           DBRouter.runDB
//                   failed Gherkin steps                           CucumberStepListener
//                   Word report, failure screenshot, trace, timing Hooks
//
//                 Farmer names are NOT recorded anywhere in here (privacy by design). Herd numbers and logins are,
//                 because the team needs them; the stakeholder edition of the report masks them.
//
//                 Every method is static and synchronized; a failure inside it is swallowed, so reporting can never
//                 fail a test.
//
// Author        : Aniket Pathare | aniket.pathare@government.ie
// Date Created  : 13-10-2026
// ===================================================================================================================================

package reporting;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Logger;

public final class ExecutionMetrics
{
    private static final Logger log = Logger.getLogger(ExecutionMetrics.class.getName());
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm:ss");

    private ExecutionMetrics() { }

    // ===============================================================================================================================
    //  DATA MODEL
    // ===============================================================================================================================

    // One iAction call
    public static final class StepEvent
    {
        public String  testCase = "";
        public String  action   = "";
        public String  locator  = "";
        public String  orKey    = "";
        public long    ms;
        public String  status   = "";     // PASS | FAIL (a FAIL inside a passing Gherkin step becomes HANDLED)
        public boolean jsFallback;
        public String  rootCause = "";
    }

    // One herd handed out to a test case (one row per test case + herd + role)
    public static final class HerdRow
    {
        public String time     = "";
        public String testCase = "";
        public String purpose  = "";      // transfer type / section, e.g. "Lease of Entitlements"
        public String role     = "";      // transferor | transferee | BISS herd | ...
        public String herd     = "";
        public String login    = "";      // agent or individual login that used the herd
        public String pool     = "";      // vault pool/key, e.g. ENTS_AGENT/aga6335 ("" = live query or pinned)
        public String outcome  = "PICKED";// PICKED | RESERVED | USED | BAD | REPLACED | RELEASED
        public String note     = "";
        public int    tryNo    = 1;
    }

    // One completed transfer
    public static final class Flow
    {
        public String testCase = "";
        public String from     = "";
        public String to       = "";
        public String purpose  = "";
    }

    // One database query
    public static final class DbCall
    {
        public String label = "";
        public String db    = "";
        public long   ms;
        public int    rows;
    }

    // One failed Gherkin step
    public static final class Failure
    {
        public String testCase   = "";
        public String scenario   = "";
        public String step       = "";
        public String cause      = "";
        public String message    = "";
        public String screenshot = "";
    }

    // Files and timing of one test case
    public static final class TestCaseInfo
    {
        public String testCase   = "";
        public String module     = "";    // BISS | ENTS | STAFF | DATA - from the test case ID (moduleOf)
        public String wordDoc    = "";
        public String screenshot = "";
        public String trace      = "";
        public long   setupMs;
        public long   scenarioMs;
        public long   teardownMs;
        public int    scenarios;
        public boolean failed;
    }

    private static final List<StepEvent>             STEPS    = new ArrayList<>();
    private static final List<HerdRow>               HERDS    = new ArrayList<>();
    private static final List<Flow>                  FLOWS    = new ArrayList<>();
    private static final List<DbCall>                DB       = new ArrayList<>();
    private static final List<Failure>               FAILURES = new ArrayList<>();
    private static final Map<String, TestCaseInfo>   TCS      = new LinkedHashMap<>();
    private static final Map<String, Integer>        COUNTERS = new LinkedHashMap<>();
    private static final ThreadLocal<Boolean>        FALLBACK = ThreadLocal.withInitial(() -> Boolean.FALSE);
    private static       Map<String, String>         OR_KEYS  = null;
    private static final String                      RUN_STARTED = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"));

    // Counter names (also shown in the report)
    public static final String JS_FALLBACKS          = "JS-click fallbacks";
    public static final String TRANSFEREES_REPLACED  = "Transferees replaced";
    public static final String NAMES_REFRESHED       = "Names refreshed from DB";
    public static final String SCENARIO_RETRIES      = "Scenario retries";
    public static final String HANDLED_ACTIONS       = "Optional actions handled";


    // ===============================================================================================================================
    //  RECORDING (called by the framework)
    // ===============================================================================================================================

    // The test case running now (TestRunner sets the "testcase" system property before each one)
    private static String tc()
    {
        return System.getProperty("testcase", "").trim();
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : noteJsFallback
    // Description   : The normal click failed and a JavaScript click is used instead. Counted, and the iAction that is
    //                 running is flagged so the locator shows up on the Fragility tab.
    // Parameters    : pLocator (String) - locator text
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 13-10-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized void noteJsFallback(String pLocator)
    {
        try
        {
            FALLBACK.set(Boolean.TRUE);
            count(JS_FALLBACKS, 1);
        }
        catch (RuntimeException e) { quiet(e); }
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : step
    // Description   : One iAction finished. pStatus PASS or FAIL; the JavaScript-fallback flag of this thread is
    //                 attached and cleared.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 13-10-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized void step(String pAction, String pLocator, long pMs, String pStatus, String pRootCause)
    {
        try
        {
            StepEvent e = new StepEvent();
            e.testCase   = tc();
            e.action     = n(pAction).toUpperCase(Locale.ROOT);
            e.locator    = n(pLocator);
            e.orKey      = orKey(e.locator);
            e.ms         = pMs;
            e.status     = n(pStatus).toUpperCase(Locale.ROOT);
            e.rootCause  = n(pRootCause);
            e.jsFallback = Boolean.TRUE.equals(FALLBACK.get());
            FALLBACK.set(Boolean.FALSE);
            STEPS.add(e);
        }
        catch (RuntimeException e) { quiet(e); }
    }

    // A passing Gherkin step caught pCount failed actions on purpose (CommonFunctions.markGherkinStepPassed)
    public static synchronized void stepsHandled(int pCount)
    {
        try
        {
            if (pCount <= 0) return;
            int iLeft = pCount;
            for (int i = STEPS.size() - 1; i >= 0 && iLeft > 0; i--)
            {
                if ("FAIL".equals(STEPS.get(i).status)) { STEPS.get(i).status = "HANDLED"; iLeft--; }
            }
            count(HANDLED_ACTIONS, pCount);
        }
        catch (RuntimeException e) { quiet(e); }
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : herdPicked
    // Description   : A herd was handed out by EntsTestData. pRole "not-found" means the herd was dropped (replaced).
    // Parameters    : pRole, pHerd, pLogin (agent / individual login), pPurpose (transfer type or reason)
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 13-10-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized void herdPicked(String pRole, String pHerd, String pLogin, String pPurpose)
    {
        try
        {
            String iRole = n(pRole);
            if ("not-found".equalsIgnoreCase(iRole))
            {
                HerdRow iRow = latest(pHerd);
                if (iRow == null)
                {
                    iRow = newRow(pHerd);
                    iRow.role  = "transferee";
                    iRow.login = n(pLogin);
                    HERDS.add(iRow);
                }
                iRow.outcome = "REPLACED";
                iRow.note    = shorten(n(pPurpose), 160);
                return;
            }

            HerdRow iRow = newRow(pHerd);
            iRow.role    = iRole;
            iRow.login   = n(pLogin);
            iRow.purpose = n(pPurpose);
            // A transferee picked straight after one or more were replaced in the same section is try 2, 3 ...
            // (walk back over this role's rows; the first row that was not replaced ends the run of retries)
            int iTry = 1;
            for (int i = HERDS.size() - 1; i >= 0; i--)
            {
                HerdRow r = HERDS.get(i);
                if (!r.testCase.equals(iRow.testCase) || !r.role.equals(iRow.role) || !r.purpose.equals(iRow.purpose)) continue;
                if (!"REPLACED".equals(r.outcome)) break;
                iTry++;
            }
            iRow.tryNo = iTry;
            HERDS.add(iRow);
        }
        catch (RuntimeException e) { quiet(e); }
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : herdStatus
    // Description   : The Test Data Vault changed a herd's status (RESERVED, USED, BAD, AVAILABLE). Adds the pool to the
    //                 ledger row and keeps its outcome up to date. A vault reserve with no EntsTestData row (the BISS
    //                 herd of an agent test case) creates its own row.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 13-10-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized void herdStatus(String pHerd, String pPool, String pLogin, String pNewStatus, String pReason, String pPurpose)
    {
        try
        {
            String  iStatus = n(pNewStatus).toUpperCase(Locale.ROOT);
            HerdRow iRow    = latest(pHerd);

            if (iRow == null)
            {
                if (!"RESERVED".equals(iStatus)) return;
                iRow = newRow(pHerd);
                iRow.role    = n(pPurpose).toLowerCase(Locale.ROOT).contains("bootstrap") ? "BISS herd" : "herd";
                iRow.login   = n(pLogin);
                iRow.purpose = n(pPurpose);
                HERDS.add(iRow);
            }

            if (!n(pPool).isEmpty()) iRow.pool = n(pPool);
            if (iRow.login.isEmpty()) iRow.login = n(pLogin);

            switch (iStatus)
            {
                case "RESERVED":
                    if ("PICKED".equals(iRow.outcome)) iRow.outcome = "RESERVED";
                    break;
                case "USED":
                    iRow.outcome = "USED";
                    break;
                case "BAD":
                    if (!"REPLACED".equals(iRow.outcome)) iRow.outcome = "BAD";
                    if (iRow.note.isEmpty()) iRow.note = shorten(n(pReason), 160);
                    break;
                case "AVAILABLE":
                    // reusable pools go back to AVAILABLE after a successful use; a plain release keeps RELEASED
                    iRow.outcome = n(pReason).startsWith("used ") ? "USED" : "RELEASED";
                    break;
                default:
                    break;
            }
        }
        catch (RuntimeException e) { quiet(e); }
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : herdInUse
    // Description   : The herd a test case runs on (BISS application herd, preliminary-check herd, Young Farmer herd,
    //                 staff pool value). When the vault already created the row for this test case (reserve), that row
    //                 is completed; otherwise a new PICKED row is added. Safe to call more than once.
    // Parameters    : pRole (e.g. "BISS herd"), pHerd, pLogin, pPurpose (section shown in the ledger)
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 14-10-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized void herdInUse(String pRole, String pHerd, String pLogin, String pPurpose)
    {
        try
        {
            if (n(pHerd).isEmpty()) return;
            String  iTc   = tc();
            String  iHerd = n(pHerd).toUpperCase(Locale.ROOT);
            HerdRow iRow  = null;
            for (int i = HERDS.size() - 1; i >= 0; i--)
            {
                HerdRow r = HERDS.get(i);
                if (r.herd.equals(iHerd) && r.testCase.equals(iTc)) { iRow = r; break; }
            }
            if (iRow == null)
            {
                iRow = newRow(pHerd);
                HERDS.add(iRow);
            }
            if (!n(pRole).isEmpty())    iRow.role    = n(pRole);
            if (iRow.login.isEmpty())   iRow.login   = n(pLogin);
            if (!n(pPurpose).isEmpty()) iRow.purpose = n(pPurpose);
        }
        catch (RuntimeException e) { quiet(e); }
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : closeTestCase
    // Description   : Hooks.afterAllExecution: every herd of this test case still PICKED or RESERVED becomes USED when
    //                 the test case passed (the application / transfer went through). After a failure the rows keep
    //                 their outcome and get the failed scenario as a note (the vault marks its own rows BAD separately).
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 14-10-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized void closeTestCase(boolean pFailed, String pFailedScenario)
    {
        try
        {
            String iTc = tc();
            for (HerdRow r : HERDS)
            {
                if (!r.testCase.equals(iTc)) continue;
                boolean iOpen = "PICKED".equals(r.outcome) || "RESERVED".equals(r.outcome);
                if (!pFailed && iOpen) r.outcome = "USED";
                if (pFailed && iOpen && r.note.isEmpty()) r.note = shorten("test case failed in [" + n(pFailedScenario) + "]", 160);
            }
        }
        catch (RuntimeException e) { quiet(e); }
    }

    // A pool herd was given its current holder name from the database (EntsTestData.withCurrentName)
    public static synchronized void nameRefreshed(String pHerd)
    {
        try
        {
            count(NAMES_REFRESHED, 1);
            HerdRow iRow = latest(pHerd);
            if (iRow != null && !iRow.note.contains("name refreshed")) iRow.note = (iRow.note.isEmpty() ? "" : iRow.note + "; ") + "name refreshed from DB";
        }
        catch (RuntimeException e) { quiet(e); }
    }

    // A transferee was dropped and another one picked (EntsTestData.replaceTransferee)
    public static synchronized void transfereeReplaced()
    {
        count(TRANSFEREES_REPLACED, 1);
    }

    // A transfer was submitted: pFrom created it, pTo accepted it
    public static synchronized void transferCompleted(String pFrom, String pTo, String pPurpose)
    {
        try
        {
            Flow f = new Flow();
            f.testCase = tc();
            f.from     = n(pFrom);
            f.to       = n(pTo).isEmpty() ? n(pFrom) : n(pTo);
            f.purpose  = n(pPurpose);
            FLOWS.add(f);
        }
        catch (RuntimeException e) { quiet(e); }
    }

    // One DBRouter label ran
    public static synchronized void dbQuery(String pDb, String pLabel, long pMs, int pRows)
    {
        try
        {
            DbCall d = new DbCall();
            d.db    = n(pDb);
            d.label = n(pLabel).toUpperCase(Locale.ROOT);
            d.ms    = pMs;
            d.rows  = pRows;
            DB.add(d);
        }
        catch (RuntimeException e) { quiet(e); }
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : stepFailed
    // Description   : A Gherkin step failed (CucumberStepListener). The cause is classified by fixed rules (classify).
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 13-10-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized void stepFailed(String pScenario, String pStep, Throwable pError)
    {
        try
        {
            Failure f = new Failure();
            f.testCase = tc();
            f.scenario = n(pScenario);
            f.step     = n(pStep);
            f.message  = shorten(oneLine(pError == null ? "" : (pError.getClass().getSimpleName() + ": " + pError.getMessage())), 600);
            f.cause    = classify(pError);
            FAILURES.add(f);
        }
        catch (RuntimeException e) { quiet(e); }
    }

    // Hooks saved a failure screenshot for the scenario that just failed
    public static synchronized void failureScreenshot(String pPath)
    {
        try
        {
            String iTc = tc();
            for (int i = FAILURES.size() - 1; i >= 0; i--)
            {
                Failure f = FAILURES.get(i);
                if (f.testCase.equals(iTc) && f.screenshot.isEmpty()) { f.screenshot = n(pPath); break; }
            }
            info(iTc).screenshot = n(pPath);
        }
        catch (RuntimeException e) { quiet(e); }
    }

    // Hooks: one scenario finished
    public static synchronized void scenarioFinished(boolean pFailed)
    {
        try
        {
            TestCaseInfo i = info(tc());
            i.scenarios++;
            if (pFailed) i.failed = true;
        }
        catch (RuntimeException e) { quiet(e); }
    }

    // Hooks.afterAllExecution: files and timing of the test case
    public static synchronized void testCaseFinished(String pWordDoc, String pTrace, long pSetupMs, long pScenarioMs, long pTeardownMs)
    {
        try
        {
            TestCaseInfo i = info(tc());
            i.wordDoc    = n(pWordDoc);
            i.trace      = n(pTrace);
            i.setupMs    = pSetupMs;
            i.scenarioMs = pScenarioMs;
            i.teardownMs = pTeardownMs;
        }
        catch (RuntimeException e) { quiet(e); }
    }

    public static synchronized void count(String pCounter, int pBy)
    {
        COUNTERS.merge(pCounter, pBy, Integer::sum);
    }


    // ===============================================================================================================================
    //  FAILURE CLASSIFICATION (fixed rules, first match wins)
    // ===============================================================================================================================

    public static final String CAUSE_DATA      = "Test data";
    public static final String CAUSE_BACKEND   = "Backend (HTTP 4xx/5xx)";
    public static final String CAUSE_LOGIN     = "Login / OTP";
    public static final String CAUSE_DATABASE  = "Database";
    public static final String CAUSE_ASSERTION = "Assertion";
    public static final String CAUSE_LOCATOR   = "Locator / timeout";
    public static final String CAUSE_OTHER     = "Other";

    public static final String[] CAUSES = { CAUSE_DATA, CAUSE_LOCATOR, CAUSE_BACKEND, CAUSE_LOGIN, CAUSE_DATABASE, CAUSE_ASSERTION, CAUSE_OTHER };

    // ***************************************************************************************************************************************************************************************
    // Function Name : classify
    // Description   : Sorts a failure into one cause by looking at the exception type and message - no AI, the same
    //                 message always gives the same cause. Order matters: a timeout caused by missing test data
    //                 ("Transferee Search found no match") is a test data problem, not a locator problem.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 13-10-2026
    // ***************************************************************************************************************************************************************************************
    public static String classify(Throwable pError)
    {
        StringBuilder iText = new StringBuilder();
        boolean iAssertion = false;
        for (Throwable t = pError; t != null; t = t.getCause())
        {
            if (t instanceof AssertionError) iAssertion = true;
            iText.append(' ').append(t.getClass().getSimpleName()).append(' ').append(n(t.getMessage()));
            if (t.getCause() == t) break;
        }
        String m = iText.toString().toLowerCase(Locale.ROOT);

        if (has(m, "no match", "transferee search found", "no unused herd", "not in the transfer out list", "no live holder",
                "entitlement set", "vault pool", "pool came back empty", "no available row", "returned no", "has no herd",
                "no herd left", "cannot add manual entitlement")) return CAUSE_DATA;
        if (has(m, "http 4", "http 5", " 403", " 500", " 502", " 503", "forbidden", "internal server error",
                "cannot transfer out", "failed to fetch", "api call failed")) return CAUSE_BACKEND;
        if (has(m, "account expired", "[login", "keycloak", "otp", " pin ", "username box", "totp", "password")) return CAUSE_LOGIN;
        if (has(m, "ora-", "db (", "sqlexception", "jdbc", "dbrouter")) return CAUSE_DATABASE;
        if (iAssertion || has(m, "verifytext failed", "verifyelement failed", "assertion", "expected")) return CAUSE_ASSERTION;
        if (has(m, "timeout", "waitvisible", "waiting for locator", "iaction failed", "not visible", "intercepts pointer",
                "not attached", "detached", "not enabled", "no result within")) return CAUSE_LOCATOR;
        return CAUSE_OTHER;
    }

    private static boolean has(String pText, String... pParts)
    {
        for (String p : pParts) if (pText.contains(p)) return true;
        return false;
    }


    // ===============================================================================================================================
    //  READING (DashboardReport)
    // ===============================================================================================================================

    public static synchronized List<StepEvent>          steps()     { return new ArrayList<>(STEPS); }
    public static synchronized List<HerdRow>            herds()     { return new ArrayList<>(HERDS); }
    public static synchronized List<Flow>               flows()     { return new ArrayList<>(FLOWS); }
    public static synchronized List<DbCall>             dbCalls()   { return new ArrayList<>(DB); }
    public static synchronized List<Failure>            failures()  { return new ArrayList<>(FAILURES); }
    public static synchronized Map<String, Integer>     counters()  { return new LinkedHashMap<>(COUNTERS); }
    public static synchronized TestCaseInfo             testCase(String pId)
    {
        TestCaseInfo i = TCS.get(n(pId).toUpperCase(Locale.ROOT));
        return i == null ? new TestCaseInfo() : i;
    }
    public static String runStarted() { return RUN_STARTED; }

    // ***************************************************************************************************************************************************************************************
    // Function Name : moduleOf
    // Description   : Which application a test case belongs to, from its ID: _ENTS -> ENTS, _STAFF -> STAFF (internal
    //                 portal), _DATA -> DATA (vault fill), everything else -> BISS (agent, individual and partnership
    //                 applications, login, preliminary checks, NR/CISYF). The report groups by this.
    // ***************************************************************************************************************************************************************************************
    public static String moduleOf(String pTestCaseId)
    {
        String id = n(pTestCaseId).toUpperCase(Locale.ROOT);
        if (id.contains("_ENTS"))  return "ENTS";
        if (id.contains("_STAFF")) return "STAFF";
        if (id.contains("_DATA"))  return "DATA";
        return "BISS";
    }

    public static synchronized int counter(String pName)
    {
        return COUNTERS.getOrDefault(pName, 0);
    }


    // ===============================================================================================================================
    //  HELPERS
    // ===============================================================================================================================

    private static TestCaseInfo info(String pId)
    {
        String iKey = n(pId).toUpperCase(Locale.ROOT);
        return TCS.computeIfAbsent(iKey, k -> { TestCaseInfo t = new TestCaseInfo(); t.testCase = n(pId); t.module = moduleOf(pId); return t; });
    }

    private static HerdRow newRow(String pHerd)
    {
        HerdRow r = new HerdRow();
        r.time     = LocalDateTime.now().format(TIME);
        r.testCase = tc();
        r.herd     = n(pHerd).toUpperCase(Locale.ROOT);
        return r;
    }

    // Newest ledger row of this herd in the running test case (then in any test case)
    private static HerdRow latest(String pHerd)
    {
        String iHerd = n(pHerd).toUpperCase(Locale.ROOT);
        String iTc   = tc();
        HerdRow iAny = null;
        for (int i = HERDS.size() - 1; i >= 0; i--)
        {
            HerdRow r = HERDS.get(i);
            if (!r.herd.equals(iHerd)) continue;
            if (r.testCase.equals(iTc)) return r;
            if (iAny == null) iAny = r;
        }
        return iTc.isEmpty() ? iAny : null;
    }

    // Object Repository key of a locator (reverse lookup, built once). "" when the locator is not in the repository.
    private static String orKey(String pLocator)
    {
        if (OR_KEYS == null)
        {
            OR_KEYS = new HashMap<>();
            try
            {
                for (String iKey : utilities.ObjReader.getAllKeys())
                {
                    try { OR_KEYS.putIfAbsent(utilities.ObjReader.getLocator(iKey).trim(), iKey); }
                    catch (RuntimeException ignored) { }
                }
            }
            catch (RuntimeException | ExceptionInInitializerError e)
            {
                log.fine("[ExecutionMetrics] Object Repository not readable for key lookup: " + e.getMessage());
            }
        }
        String iLocator = n(pLocator);
        if (OR_KEYS.containsValue(iLocator)) return iLocator;      // a caller passed the key itself
        return OR_KEYS.getOrDefault(iLocator, "");
    }

    static String n(String pText)
    {
        return pText == null ? "" : pText.trim();
    }

    static String oneLine(String pText)
    {
        return n(pText).replaceAll("\\s+", " ");
    }

    static String shorten(String pText, int pMax)
    {
        String s = n(pText);
        return s.length() <= pMax ? s : s.substring(0, pMax - 3) + "...";
    }

    private static void quiet(RuntimeException pError)
    {
        log.fine("[ExecutionMetrics] ignored: " + pError.getMessage());
    }
}
