package com.stepdefinitions;

import com.base.ConfigReader;
import com.base.DriverManager;
import com.pages.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import org.codehaus.plexus.util.cli.Arg;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Action;
import org.testng.Assert;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Properties;
import java.util.Date;

public class CreateBPSApplicationSteps {


        LoginPage loginPage;
        ApplicationPortalPage applicationportalPage;
        BPSdashboardPage bpSdashboardPage;
        DatabaseQueriesPage databaseQueriesPage;
        WebDriver driver;
        Properties prop;
        ConfigReader configReader;
        DriverManager driverManager;

        public CreateBPSApplicationSteps(DriverManager driverManager){
            try {
//            driver = driverManager.getDriver();
                this.driverManager=driverManager;
                driver=driverManager.getDriverInstance();
                loginPage = new LoginPage(driver);
                applicationportalPage = new ApplicationPortalPage(driver);
                bpSdashboardPage = new BPSdashboardPage(driver);
                databaseQueriesPage = new DatabaseQueriesPage(driver);
                configReader = new ConfigReader();
                prop = configReader.init_prop();
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }

    // region DB Query Implementation

    @Then("Get {int} Herds from DB")
    public void DataBaseQueryTest(int NumberOfHerds) throws SQLException {
            databaseQueriesPage.CentestBissDataScript(NumberOfHerds);
    }

    @Given("Get {int} Herds with Payments from DataBase")
    public void HerdWithPaymentsQueryRunner(int NumberOfHerds) {
        // FilePaths
        String HerdWithPayments = "./src/main/resources/TestData/Herd With Payments.xls";
        databaseQueriesPage.RunQueryForHerdWithPayment(NumberOfHerds, HerdWithPayments);
    }

    @Given("Get {int} Herds with Submission from DataBase")
    public void HerdWithSubmissionsQueryRunner(int NumberOfHerds) {
        // FilePaths
        String HerdWithSubmissions = "./src/main/resources/TestData/Herd With Submissions.xls";
        databaseQueriesPage.RunQueryForHerdWithSubmission(NumberOfHerds, HerdWithSubmissions);
    }

    @Given("Get {int} Herds with Submission And Penalty from DataBase")
    public void HerdWithSubmissionsAndPenaltyQueryRunner(int NumberOfHerds) {
        // FilePaths
        String HerdWithSubmissionsAndPenalty = "./src/main/resources/TestData/Herd With Submissions and Penalty.xls";
        databaseQueriesPage.RunQueryForHerdWithSubmissionAndPenalty(NumberOfHerds, HerdWithSubmissionsAndPenalty);
    }

    @Given("Get {int} Herds with Submission and no Amendments from DataBase")
    public void HerdWithSubmissionsAndNoAmendQueryRunner(int NumberOfHerds) {
        // FilePaths
        String HerdWithSubmissionsAndNoAmend = "./src/main/resources/TestData/Herd With Submissions and No Amend.xls";
        databaseQueriesPage.RunQueryForHerdWithSubmissionAndNoAmend(NumberOfHerds, HerdWithSubmissionsAndNoAmend);
    }

    @Given("Get {int} LPIS Parcels from Database")
    public void LPISparcelQueryRunner(int NumberOfParcels) {
            String LPISParcels = "./src/main/resources/TestData/LPIS Parcels.xls";
            databaseQueriesPage.RunQueryForLPISParcels(NumberOfParcels,LPISParcels);
    }

    @Then("Get {int} Reference Numbers from Database")
    public void RefNumberQueryRunner(int RefNumCount) {
          String RefNumbers = "./src/main/resources/TestData/Reference Number with 2023 Applications.xls";
          databaseQueriesPage.RunQueryForRefNumberWithSubmission(RefNumCount, RefNumbers);
    }

    @Given("Get {int} Herds with Submission and SIM Opted In from DataBase")
    public void HerdWithSubmissionsAndSimOptedInQueryRunner(int NumberOfHerds) {
        // FilePaths
        String HerdWithSubmissionsAndSimOptedIn = "./src/main/resources/TestData/Herd With Submissions and SIM Opted In.xls";
        databaseQueriesPage.RunQueryForHerdWithPaymentWithSimOptedIn(NumberOfHerds, HerdWithSubmissionsAndSimOptedIn);
    }

    @Then("Get {int} Herds with Admin Check Not Started from Database")
    public void HerdWithSubmissionAndAdminCheckNotStarted(int NumberofHerds) {
        String HerdWithSubmissionsAndAdminCheckNotStarted = "./src/main/resources/TestData/Herd With Submissions and No Admin Check.xls";
            databaseQueriesPage.RunQueryForHerdWithAdminCheckNotStarted(NumberofHerds,HerdWithSubmissionsAndAdminCheckNotStarted);
    }

    @Then("Get {int} Herds with Query Letter Not Started from Database")
    public void HerdWithSubmissionAndQueryLetterNotStarted(int NumberofHerds) {
        String HerdWithSubmissionAndQueryLetterNotStarted = "./src/main/resources/TestData/Herd With Submissions and No Query Letter.xls";
        databaseQueriesPage.HerdWithSubmissionAndQueryLetterNotStarted(NumberofHerds,HerdWithSubmissionAndQueryLetterNotStarted);
    }

    @Then("Get {int} Herds with Reference Number from Database")
    public void HerdWithReferenceNumber(int NumberofHerds) {
        String HerdWithReferenceNumber = "./src/main/resources/TestData/Herd With Reference Number.xls";
        databaseQueriesPage.RunQueryForRefNumberWithSubmission(NumberofHerds,HerdWithReferenceNumber);
    }

//    @Then("Get Agent for Herd {int} from the Database")
//    public void getAgentsfromDatabase(int HerdRow) throws IOException {
//            String AgentForHerd = "./src/main/resources/TestData/Herd With Submissions and No Admin Check.xls";
//            databaseQueriesPage.RunQueryToGetAgentforHerdNumber(HerdRow,AgentForHerd);
//    }
    // endregion

    // region BISS Steps

    @And("Agent Click On {string} Farmer Dashboard Button")
    public void AgentClickOnContinueApplicationButton(String Arg0) throws InterruptedException {
            applicationportalPage.AgentClickOnButtonsInFarmerDashboard(Arg0);
            Thread.sleep(6000);
    }

    @And("Delete Draft if exists")
    public void deleteDraftIfExists() {
        applicationportalPage.deleteDraftIfExists();
    }

    @And("Agent Click On Start or Continue Application Farmer Dashboard Button")
    public void AgentClickOnStartOrContinueApplicationButton() throws InterruptedException {
        applicationportalPage.AgentClickOnStartOrContinue();
        Thread.sleep(4000);
    }

    @Then("Agent Click on {string} Stepper")
    public void AgentClickOnApplicationStepper(String Arg0) throws InterruptedException {
            applicationportalPage.AgentClickOnApplicationStepper(Arg0);
            Thread.sleep(2000);
    }

    @When("Agent Check the Active Farmer Status and opts under {string} farming practice {string} activity")
    public void AgentCheckActiveFarmerStatus(String FarmingActivity, String GrasslandOrTillageActivity) throws InterruptedException {
            applicationportalPage.AgentCheckActivityStatusLabelText(FarmingActivity, GrasslandOrTillageActivity);
            Thread.sleep(4000);
    }

    @And("Agent Click on the {string} CheckBox")
    public void AgentClickOnActiveFarmerCheckBox(String Arg0) throws InterruptedException {
        applicationportalPage.AgentClickOnCheckbox(Arg0);
        Thread.sleep(5000);
    }

    @Then("Agent Enter Note as {string} for Other Option in Active Farmer")
    public void AgentEnterOtherNotesText(String Note) {
            applicationportalPage.AgentEnterTextInOtherNotes(Note);
    }

    @Then("Agent Click on the {string} scheme card")
    public void AgentClickOnSchemeCard(String Arg0) {
        applicationportalPage.AgentClickOnSchemeCard(Arg0);
    }

    @And("Agent Click on Application Stepper {string} Button")
    public void AgentClickOnApplicationStepperNextOrBackOrSubmitButton(String Arg0) throws InterruptedException {
        applicationportalPage.AgentClickOnNextOrBackOrSubmitButton(Arg0);
        Thread.sleep(5000);
    }

    @And("Agent Verify Application Stepper {string} Button")
    public void AgentVerifyOnApplicationStepperNextOrBackOrSubmitButton(String Arg0) throws InterruptedException {
        Assert.assertTrue(applicationportalPage.AgentVerifyNextOrBackOrSubmitButton(Arg0));
        Thread.sleep(6000);
    }

    @Then("Agent Click on the {string} dialog box button")
    public void AgentClickOnDialogBoxButtons(String Arg0) throws InterruptedException {
        applicationportalPage.AgentClickOnDialogBoxButton(Arg0);
        Thread.sleep(3000);
    }


    @And("Agent Navigate to {string} tab on the SideNavBar")
    public void AgentClickOnSideNavBarTab(String Arg0) throws InterruptedException {
        applicationportalPage.AgentNavigateToPagesUsingSideNavBar(Arg0);
        Thread.sleep(5000);
    }


    @And("Agent Click on the {string} Actions Column Button for parcel {string}")
    public void AgentClickOnActionsColumnButtonInParcelList(String Action, String ParcelNo) throws InterruptedException {
//        applicationportalPage.AgentClickOnActionsButtonInParcelList(ParcelNo, Action);
    }

    @And("Agent Click on {string} button in the GIS Map Application NavLink")
    public void AgentClickOnGISAppNavlinks(String Arg0) throws InterruptedException {
        applicationportalPage.AgentClickOnNavLinksInMap(Arg0);
        Thread.sleep(3000);
    }

    @Given("Agent is on BISS Farmer Dashboard Screen")
    public void AgentOnFarmerDashboardScreen() {
        String title = driver.getTitle();
        System.out.println("Title of Farmer Dashboard Page is : " + title);
    }

    @Given("Agent is on AMS Screen")
    public void AgentOnAMSScreen() {
        String title = driver.getTitle();
        System.out.println("Title of Farmer Dashboard Page is : " + title);
    }

    @And("Agent Click on the {string} Button in land details page")
    public void AgentClickOnAddParcelOrPlotButtonInLandDetailsPage(String Arg0) {
            applicationportalPage.AgentClickOnAddPlotOrAddParcelButton(Arg0);
    }

    @And("Agent Click on Next Button in Review and Submit Page")
    public void AgentClickOnNextButtonInReviewAndSubmitPage() throws InterruptedException {
        applicationportalPage.AgentClickOnNextButtonInReviewAndSubmitScreen();
    }

    @Then("Agent Click on Terms & Conditions CheckBox")
    public void AgentClickOnTermsAndConditionsCheckBox() throws InterruptedException {
            applicationportalPage.AgentClickOnTermsAndConditionsCheckBox();
            Thread.sleep(6000);
    }

    @And("Agent Clear value in the {string} Add Parcel or Plot Dialog Box")
    public void AgentClearValueInAddParcelOrPlotDialogTextBox(String Arg1) {
        applicationportalPage.AgentClearValueInAddPlotOrParcelDialog(Arg1);
    }

    @Then("Agent Enter Value {string} in the {string} Add Parcel Or Plot Dialog TextBox")
    public void AgentEnterValueInAddParcelOrPlotDialogTextBox(String Arg0, String Arg1) {
            applicationportalPage.AgentEnterValueInAddPlotOrParcelDialog(Arg0,Arg1);
    }

    @And("Agent Click on the {string} option to submit changes to Map")
    public void AgentSelectMapChangesOption(String Arg0) {
            applicationportalPage.AgentClickOnRadioButtonsInDialogBox(Arg0);
    }

    @Then("Agent Select Value {string} in the {string} Add Parcel Or Plot Dialog Dropdown")
    public void AgentSelectValueInAddParcelOrPlotDialogDropDown(String Arg0, String Arg1) throws InterruptedException {
        applicationportalPage.AgentSelectDropdownValuesInParcelAndPlotModal(Arg0,Arg1);
    }

    @And("Check for Invalid Parcel Warning Message")
    public void AgentCheckInvalidParcelWarningMessage() {
            Assert.assertEquals(applicationportalPage.AgentCheckWarningMessageInDialog(),"Please enter a valid parcel number");
    }

    @And("Check for Claimed Parcel Warning Message")
    public void AgentCheckClaimedParcelWarningMessage() {
        Assert.assertEquals(applicationportalPage.AgentCheckBissPanelWarningMessages(),"You have already claimed this parcel. To modify a claim on a parcel, please return to the land details list and amend the parcels details.");
    }

    @And("Agent Click On {string} Tool Option inb GIS Application")
    public void AgentClickOnSelectFeatureTool(String Arg0) {
        applicationportalPage.AgentClickOnSelectFeatureToolInGIS(Arg0);
    }

    @And("Agent Click on Parcel from the Map")
    public void AgentClickOnParcel007FromMap() {
        applicationportalPage.AgentSelectParcelOnMapScreen();
    }

    @And("Agent Click on the Map Page Claim Button in GIS")
    public void AgentClickOnMapPageClaimButtoninGIS() {
        applicationportalPage.AgentClickOnMapPageClaimParcelButton();
    }

    @And("Agent Click on Plot Reference {string} to open Side Drawer")
    public void AgentClickOnPlotReferenceInList(String PlotRef) {
            applicationportalPage.AgentClickOnPlotReferenceToOpenSideDrawer(PlotRef);
    }

    @And("Agent Click on First Plot Reference to open Side Drawer")
    public void AgentClickOnFirstPlotReferenceInList() throws InterruptedException {
        applicationportalPage.AgentClickOnFirstPlotReferenceToOpenStaffSideDrawer();
        Thread.sleep(2000);
    }


    @And("Agent Click on Plot Reference {string} to open Staff Side Drawer")
    public void AgentClickOnPlotReferenceInStaffList(String PlotRef) {
        applicationportalPage.AgentClickOnPlotReferenceToOpenStaffSideDrawer(PlotRef);
    }

    // Change the dropdown value in the Side Drawer
    @And("Agent select the value as {string} in the Side Drawer {string} dropdown")
    public void AgentChangeDropdownValueInSideDrawer(String Dropdown, String Value) {
        applicationportalPage.AgentSelectValueFromSideDrawerDropdown(Dropdown, Value);
    }

    // Edit Parcel Drawer
    @And("Agent Click on CheckBox to request Eh Change")
    public void AgentClickOnReqEhChangeCheckBox() throws InterruptedException {
        Thread.sleep(4000);
            applicationportalPage.AgentClickOnReqEhChangeCheckBox();
    }

    @Then("Agent do Request for EhChange in Side Drawer with reason as {string}")
    public void AgentDoRequestForEhChangeInSideDrawer(String Reason) throws InterruptedException {
            applicationportalPage.AgentEnterReasonForEhChange(Reason);
    }

    // Check if the row number being found properly
    @Then("Agent picks the {string} parcel and performs {string} action")
    public void RowNumberCheckAndPerformAction(String ParcelNo, String ActionsColumnButton) throws InterruptedException {
            applicationportalPage.RowNumberContainingParcelAndAction(ParcelNo, ActionsColumnButton);
            Thread.sleep(4000);
    }

    // Undo Deletion of the Parcel
    @Then("Agent performs Undo action for Deletion of the Parcel")
    public void AgentUndoDeletionOfParcel() throws InterruptedException {
            applicationportalPage.UndoDeletionOfParcel();
            Thread.sleep(3000);
    }

    // Check Map for a Parcel in GAEC8 Page
    @And("Agent check Map for the parcel {string} in GAEC8 Page")
    public void AgentOpenMapForParcelINGAEC8Page(String ParcelNo) {
            applicationportalPage.AgentClickOnViewMapForParcel(ParcelNo);
    }

    // Change the GAEC8 Contribution Type
    @And("Agent change GAEC8 contribution type to {string} for the parcel {string}")
    public void AgentChangeGAEC8ContributionType(String Contribution, String ParcelNo) {
            applicationportalPage.AgentSelectGAEC8ContributionForAParcel(ParcelNo, Contribution);
    }

    // Get the SFN Contribution Value
    @And("Agent check SFN Value and Eligibilty")
    public void AgentCheckSFNValueAndEligibility() {
            applicationportalPage.CaptureSFNContributionValue();
    }


    /// ECO Page
    // Agent Select option for Eco Scheme
    @And("Agent Select the {string} Scheme Option in Eco Page")
    public void AgentSelectECOSchemeOption(String EcoSchemeOption) throws InterruptedException {
            applicationportalPage.AgentControlTogglesInEcoPage(EcoSchemeOption);
            Thread.sleep(2000);
    }

    // Agent CheckBox for Any Scheme
    @Then("Agent Click on CheckBox for {string} Scheme in Eco Page")
    public void AgentClickOnAPSchemeEcoCheckBox(String EcoScheme) throws InterruptedException {
            applicationportalPage.AgentClickOnCheckBoxForEcoScheme(EcoScheme);
            Thread.sleep(2000);
    }

    // Agent Click on Stocking Density Save and Select for AP2
    @Then("Agent Click on Save & Select for {string} Scheme in Eco Page")
    public void AgentClickOnAP2SchemeEcoSaveAndSelect(String EcoScheme) throws InterruptedException {
        applicationportalPage.AgentClickOnSaveAndSelectButton(EcoScheme);
        Thread.sleep(3000);
    }

    @And("Agent Click on AP4 Scheme {string} Radio Button")
    public void AgentClickOnAP4SchemeRadioButton(String Option) throws InterruptedException {
        applicationportalPage.AgentClickOnRadioButtonInAP4Scheme(Option);
        Thread.sleep(1000);
    }

    @And("Agent Selects the {string} Approved Spreader Type from the {string} dropdown")
    public void AgentSelectApprovedSpreaderTypeFromDropDown(String ApprovedSpreader, String Dropdown) {
            applicationportalPage.AgentSelectDropdownValuesForApprovedSpreader(Dropdown, ApprovedSpreader);
    }

//    AgentClickOnRadioButtonInAP5
    @And("Agent Click on {string} as Choice of Fertiliser Application Equipment")
    public void AgentChooseFertilisationApplicationMode(String Type) throws InterruptedException {
            applicationportalPage.AgentClickOnRadioButtonInAP5(Type);
    }

    @And("Agent enters data {string} in the {string} textbox")
    public void AgentEnterSerialNumberInTextBox(String Text, String AP5TextBox) {
            applicationportalPage.AgentFillInTheAP5TextBoxes(Text,AP5TextBox);
    }

    @And("Agent Click on Application without Eco Checkbox")
    public void AgentClickOnNoEcoSchemeCheckbox() throws InterruptedException {
        applicationportalPage.AgentClickOnCheckBoxForNoEcoScheme();
        Thread.sleep(3000);
    }

    //region AMS
    @Then("Agent Click On View Button for first Farmer")
    public  void AgentClickOnFirstViewButton() throws InterruptedException {
        applicationportalPage.AgentClickOnViewButtonForFarmer();
        Thread.sleep(2000);
    }

    @And("Agent Click On the first AMS Parcel with Response Pending Status")
    public void AgentClickOnFirstResponsePendingParcel() throws InterruptedException {
            applicationportalPage.AgentClickOnFirstParcelWithAMSStatusPending();
            Thread.sleep(2000);
    }

    @And("Agent Click on the {string} button in the AMS Side Drawer")
    public void AgentClickOnAgreeOrDisagreeButtonInSideDrawer(String Arg0) {
            applicationportalPage.AgreeOrDisagreeInSideDrawer(Arg0);
    }
    @And("Agent Click on the {string} disagree reason option in the AMS Side Drawer")
    public void AgentClickOnDisagreeReasonButtonInSideDrawer(String Arg0) {
        applicationportalPage.DisagreeReasonInSideDrawer(Arg0);
    }

    @Then("Agent Change Claimed Area of Parcel with reason {string}")
    public void AgentChecgeClaimedAreaOfParcel(String Reason) throws InterruptedException {
            applicationportalPage.AgentClickOnReqEhChangeCheckBox();
            applicationportalPage.AgentEnterReasonForEhChange(Reason);
            applicationportalPage.AgentChangeClaimedAreaInAMS();
    }

    @And("Agent Select {string} Quick Filter")
    public void AgentClickOnQuickFilter(String Filter) {
        applicationportalPage.AgentClickOnQuickFilter(Filter);
    }

    @Then("Agent Fill in Mandatory Agricultural Activity Information")
    public void AgentFillInMandatoryAgriculturalActivityInformation() throws InterruptedException {
        applicationportalPage.AgentFillInMandatoryAgriculturalActivityInformation();
    }

    @Then("Agent Fill in Mandatory Organic Status Information")
    public void AgentFillInMandatoryOrganicStatusInformation() throws InterruptedException {
        applicationportalPage.AgentFillInMandatoryOrganicInformation();
    }


    @Then("Agent Fill in Mandatory Organic Status and Agricultural Activity Information")
    public void AgentFillInMandatoryOrganicStatusAndAgriculturalActivityInformation() throws InterruptedException {
        applicationportalPage.AgentFillInMandatoryAgActivityAndOrganicInformation();
    }
    // endregion

    // region GAEC 7
    @Then("Agent Check GAEC 7 Status")
    public void AgentcheckGAEC7Status() {
        System.out.println(applicationportalPage.AgentCheckGAEC7Status());
    }

    @And("Agent Check if Total Eligible Hectare Values Displayed")
    public void AgentCheckTotalEligibleHectareDisplayStatus() {
            applicationportalPage.AgentCheckTotalEligibleAreaValuesInCropDiversificationTables();
    }

    @Then("Agent Check if Crop Diversification Summary Table has data populated")
    public void AgentCheckIfCropDiversificationTableHasDataPopulated() {
            applicationportalPage.AgentCheckValuesInCropDiversificationSummaryTable();
    }

    @Then("Agent Check Total Other Eligible Crop Area Value")
    public void AgentCheckOtherEligibleCropAreaValue() {
            applicationportalPage.AgentCheckOtherTotalEligibleCropAreaValue();
    }

    @And("Agent Check Total Eligible ha values in Breakdown Table")
    public void AgentCheckTotalEhInBreakdownTable() {
            applicationportalPage.AgentCheckTotalEhValuesInBreakdownTable();
    }


    @And("Agent Check Total Arable Land Percentage values in Breakdown Table")
    public void AgentCheckTotalArableLandsInBreakdownTable() {
        applicationportalPage.AgentCheckTotalArableLandValuesInBreakdownTable();
    }

    //region BISS Application Summary Screen

    @Then("Staff capture and print {string} value")
    public void StaffPrintSubmissionDetailsValue(String Label) {
            applicationportalPage.StaffGetSubmissionDetailValues(Label);
    }

    @Then("Staff capture and verify {string} value is {string}")
    public void StaffPrintSubmissionDetailsValue(String Label, String Value) {
        Assert.assertEquals(applicationportalPage.StaffPrintandVerifySubmissionDetailValues(Label),Value);
    }

    @Then("Staff capture and check {string} value")
    public void StaffCheckSubmissionDetailsValue(String Label) {
        // Create object of SimpleDateFormat class and decide the format
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        // Get current Date Time with Date
        Date date = new Date();
        // Format the Date
        String currentdate = dateFormat.format(date);
        System.out.println(currentdate);
        Assert.assertEquals(applicationportalPage.StaffPrintandVerifySubmissionDetailValues(Label),"09/03/2024");
    }

    @Then("Staff capture and verify no error {string} value")
    public void StaffPrintAndVerifyNoErrorSubmissionDetailsValue(String Label) {
       Assert.assertEquals(applicationportalPage.StaffPrintandVerifySubmissionDetailValues(Label),"0 %");
    }

    @Then("Staff capture and verify error {string} value")
    public void StaffPrintAndVerifyErrorSubmissionDetailsValue(String Label) {
        Assert.assertNotEquals(applicationportalPage.StaffPrintandVerifySubmissionDetailValues(Label),"0 %");
    }

    @And("Agent Click On Start or Continue amendment Farmer Dashboard Button")
    public void agentClickOnStartOrContinueAmendmentFarmerDashboardButton() {
        applicationportalPage.AgentClickOnStartOrContinueAmendment();
    }

    @And("Agent gives reason for late amendment")
    public void agentGivesReasonForLateAmendment() {
        applicationportalPage.AgentClickOnStartOrContinueAmendment();
    }

    @Then("Agent Fill in Mandatory Information")
    public void AgentFillInMandatoryInformation() throws InterruptedException {
        applicationportalPage.AgentFillInMandatoryOrganicInformation();
    }
    // endregion

    // endregion
    // endregion
}
