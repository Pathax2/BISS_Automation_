package utilities;

import commonFunctions.CommonFunctions;
import database.DBRouter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.Set;

// =====================================================================================================================================
// File          : EntsTestData.java
// Package       : utilities
// Description   : Runtime test data for the ENTS (Transfer of Entitlements) test cases.
//
//                 Replaces the herd numbers and names that were typed into the ENTS feature files. The feature file now
//                 carries a token such as {transferor.herd}; the step that creates the transfer asks this class for a
//                 fresh pair of herds, and every later step in the same section reads the same pair.
//
//                 How a pair is picked (same-agent transfers):
//                   1. The Agent Login query runs ONCE per agent per run on the ENTS_DATA connection (DBRouter "ENTS").
//                      Up to ents.pool.size rows come back in random order and are kept in memory for the whole run.
//                   2. The rows are shuffled again, and every herd already listed in the used-herds file is skipped.
//                   3. The first unused herd becomes the transferor, the next unused herd becomes the transferee.
//                   4. Both herds are written to the used-herds file straight away, so a failed run does not hand the
//                      same (possibly half-transferred) herds to the next run.
//
//                 Tokens understood by resolve():
//                   {transferor.herd}  {transferor.name}  {transferor.address}
//                   {transferee.herd}  {transferee.name}  {transferee.address}
//                   {agent}              - the transferor agent (the logged-in agent)
//                   {transferee.agent}   - the transferee's agent; the same as {agent} for a same-agent transfer
//                   {transferor.agent}   - same as {agent}
//                   {transferee.login}   - the user who logs in to accept: the transferee agent, or the individual's own
//                                          login for an agent-to-individual transfer (TC_05_ENTS / TC_06_ENTS)
//                   {transferor.login}   - the user who creates the transfer: the agent, or the individual's own login
//                                          when the transferor is an individual (TC_08 / TC_09 / TC_10_ENTS)
//                   {auto.agent}         - the agent with the MOST usable herds, other than the logged-in agent
//                                          (01-10-2026). Use it in the transfereeAgent row and in the re-login step
//                                          instead of hard-coding an agent with few herds (aga6325 has 5). Picked once
//                                          per scenario, so every step of the scenario gets the same agent. Ranking:
//                                          vault stock (ENTS_AGENT pools), else the ranking TC_00_DATA stored, else
//                                          the live query "ENTS Top agents". Expired logins are skipped.
//                   {auto.agent.2}       - the second best agent, {auto.agent.3} the third, and so on
//                 Any other value is returned unchanged, so a feature file can still pin a herd for debugging.
//
//                 Negative case (TC_02_ENTS Section 2): nextNoEntitlementPair picks the transferor from the agent's herds
//                 that hold NO entitlements (query "ENTS Agent herds without entitlements") and the transferee from the
//                 usual Agent Login pool. The same tokens are used.
//
//                 Cross-agent transfers (TC_04_ENTS): nextCrossAgentPair picks the transferor from the logged-in agent's
//                 Agent Login pool and the transferee from the OTHER agent's pool (one query per agent, cached for the
//                 run). {transferee.agent} then returns the other agent, for the login-swap step.
//
//                 Agent-to-individual transfers (TC_05_ENTS / TC_06_ENTS): nextAgentToIndividualPair picks the transferor
//                 from the logged-in agent's Agent Login pool and the transferee from the Individual Login query (herds
//                 whose holder has their own online login). {transferee.login} returns that individual's login.
//
//                 Individual as transferor (TC_08_ENTS / TC_09_ENTS / TC_10_ENTS): the login step runs BEFORE the create
//                 step, so the pair is built in two halves. nextIndividualTransferor picks the individual (herd + login)
//                 and makes it the current pair with NO transferee yet; {transferor.login} logs that individual in. The
//                 create step then completes the pair with completePairWithAgentTransferee (a client herd of the named
//                 agent, TC_08 / TC_10) or completePairWithIndividualTransferee (another individual, TC_09).
//
//                 Pinned transferor (TC_11_ENTS): nextTransfereeForFixedTransferor keeps a transferor herd typed in the
//                 feature file and picks only the transferee from the named agent's pool.
//
//                 Settings (application.properties):
//                   ents.pool.size          - rows fetched per query (default 200)
//                   ents.skip.used.herds    - true = never reuse a herd listed in the used-herds file (default true)
//                   ents.used.herds.file    - the used-herds file (default runtime-data/ents_used_herds.csv)
//                   ents.scheme.year        - only herds with entitlements in this year (blank = all years)
//                   ents.cust.type          - only herds of this customer type, e.g. Individual (blank = all types)
//                   ents.name.two.words     - true = only herds whose DB name is exactly two words (default true)
//                   ents.individual.pool.size - rows fetched by the Individual Login query (default ents.pool.size)
//
// Author        : Aniket Pathare | aniket.pathare@government.ie
// Date Created  : 22-09-2026 | Updated: 23-09-2026 (nextNoEntitlementPair for TC_02_ENTS)
//                                       29-09-2026 (nextCrossAgentPair and {transferee.agent} for TC_04_ENTS)
//                                       30-09-2026 (nextAgentToIndividualPair and {transferee.login} for TC_05/06_ENTS)
//                                       30-09-2026 (individual transferor, two-half pairs, pinned transferor: TC_07 to TC_11_ENTS)
//                                       01-10-2026 (Test Data Vault: pools come from utilities.TestDataVault when TC_00_DATA
//                                                   filled it; the live query stays as the fallback and refills the vault)
//
//                 Test Data Vault (01-10-2026): agentPool / noEntitlementPool / individualPool first look in the vault
//                 (pools ENTS_AGENT / ENTS_NO_ENTS / ENTS_INDIVIDUAL). When the vault has AVAILABLE rows for the pool they
//                 are used and the query is NOT run; when it has none, the query runs exactly as before and its rows are
//                 also stored in the vault for the next run. Every herd handed out is marked RESERVED in the vault,
//                 markNotFound marks it BAD with the reason, and markCurrentPairUsed (called by the submit step) marks
//                 both herds USED. Three BAD herds in a row from one pool make the pool refetch itself (live query).
// =====================================================================================================================================

public final class EntsTestData
{
    private EntsTestData() { }

    // =================================================================================================
    // DATA HOLDERS
    // =================================================================================================

    // One herd returned by an ENTS query
    public static final class Herd
    {
        public final String herdNumber;
        public final String name;
        public final String address;

        Herd(String pHerdNumber, String pName, String pAddress)
        {
            herdNumber = pHerdNumber;
            name       = pName;
            address    = pAddress;
        }

        @Override
        public String toString() { return herdNumber + " (" + name + ")"; }
    }

    // The herds used by one transfer section
    public static final class TransferPair
    {
        public final String agent;            // login that creates the transfer: the agent, or the individual's own login
        public final Herd   transferor;
        public final Herd   transferee;       // null until the create step completes a two-half pair (individual transferor)
        public final String transfereeAgent;  // who accepts: agent of the transferee herd (same as agent unless
        // cross-agent), or the individual's own login (agent-to-individual)

        TransferPair(String pAgent, Herd pTransferor, Herd pTransferee)
        {
            this(pAgent, pTransferor, pTransferee, pAgent);
        }

        TransferPair(String pAgent, Herd pTransferor, Herd pTransferee, String pTransfereeAgent)
        {
            agent           = pAgent;
            transferor      = pTransferor;
            transferee      = pTransferee;
            transfereeAgent = (pTransfereeAgent == null || pTransfereeAgent.isBlank()) ? pAgent : pTransfereeAgent.trim();
        }

        public boolean isCrossAgent()
        {
            return !agent.equalsIgnoreCase(transfereeAgent);
        }
    }

    // =================================================================================================
    // STATE
    // =================================================================================================

    private static final String LOG_PREFIX = "[ENTS-DATA] ";
    private static final String CSV_HEADER = "timestamp,testcase,role,herd,login,purpose";

    // Agent login -> rows of the Agent Login query (fetched once per run, the query takes several seconds)
    private static final Map<String, List<Herd>> AGENT_POOLS = new HashMap<>();

    // {auto.agent}: picked once per scenario (index -> login), ranking cached for the run
    private static final Map<Integer, String> AUTO_AGENTS   = new HashMap<>();
    private static       List<String>         RANKED_AGENTS = null;

    // Agent login -> herds of that agent with NO entitlements in the scheme year (TC_02_ENTS negative case)
    private static final Map<String, List<Herd>> NO_ENTS_POOLS = new HashMap<>();

    // Rows of the Individual Login query (fetched once per run) and the login of each of those herds
    private static List<Herd>                    INDIVIDUAL_POOL   = null;
    private static final Map<String, String>     INDIVIDUAL_LOGINS = new HashMap<>();

    // Herds handed out in this run (covers ents.skip.used.herds=false, where the file is not consulted)
    private static final Set<String> USED_THIS_RUN = new HashSet<>();
    // Reuse mode: herds whose transfer was confirmed in this run - free to be picked again (data.reuse.herds=true)
    private static final Set<String> COMPLETED_THIS_RUN = new HashSet<>();
    // Transfer type of the last herd handed out - markCurrentPairUsed needs it to spot a lease
    private static       String      iLastPurpose = "";

    private static TransferPair iCurrentPair   = null;
    private static String       iLoggedInUser  = "";

    // =================================================================================================
    // SCENARIO LIFECYCLE
    // =================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Function Name : resetScenario
    // Description   : Clears the pair of the previous scenario. Called from Hooks before every scenario.
    //                 The query results stay cached for the whole run.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 22-09-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized void resetScenario()
    {
        iCurrentPair  = null;
        iLoggedInUser = "";
        AUTO_AGENTS.clear();
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : setLoggedInUser / loggedInUser
    // Description   : The ENTS login steps record who is logged in, so a same-agent transfer knows which agent's herds
    //                 to use without repeating the login in the feature file.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 22-09-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized void setLoggedInUser(String pUsername)
    {
        iLoggedInUser = pUsername == null ? "" : pUsername.trim();
    }

    public static synchronized String loggedInUser()
    {
        return iLoggedInUser;
    }

    public static synchronized TransferPair currentPair()
    {
        return iCurrentPair;
    }

    // =================================================================================================
    // TOKENS
    // =================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Function Name : hasToken / tableHasToken
    // Description   : True when a value (or any value of a DataTable map) is a runtime token such as {transferor.herd}
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 22-09-2026
    // ***************************************************************************************************************************************************************************************
    public static boolean hasToken(String pValue)
    {
        if (pValue == null) return false;
        String iValue = pValue.trim();
        return iValue.startsWith("{") && iValue.endsWith("}");
    }

    public static boolean tableHasToken(Map<String, String> pTable)
    {
        if (pTable == null) return false;
        for (String iValue : pTable.values())
        {
            if (hasToken(iValue)) return true;
        }
        return false;
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : resolve
    // Description   : Replaces a runtime token with the value of the current pair. Plain values come back unchanged.
    //                 Throws with a clear message when a token is used before any pair was picked, or is misspelt.
    // Parameters    : pValue (String) - DataTable cell, e.g. "{transferee.herd}" or "C1010148"
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 22-09-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized String resolve(String pValue)
    {
        if (pValue == null) return null;
        if (!hasToken(pValue)) return pValue.trim();
        if (isAutoAgentToken(pValue)) return resolveAgent(pValue);

        String iToken = pValue.trim().toLowerCase(Locale.ROOT);

        if (iCurrentPair == null)
        {
            throw new IllegalStateException(LOG_PREFIX + "Token " + pValue.trim() + " used before a transfer pair was picked. "
                    + "The step that creates the transfer must run first in this section.");
        }

        if (iCurrentPair.transferee == null && iToken.startsWith("{transferee."))
        {
            throw new IllegalStateException(LOG_PREFIX + "Token " + pValue.trim() + " used before the transferee was picked. "
                    + "The transferor is an individual; the step that creates the transfer must run first in this section.");
        }

        switch (iToken)
        {
            case "{transferor.login}":   return iCurrentPair.agent;
            case "{transferor.herd}":    return iCurrentPair.transferor.herdNumber;
            case "{transferor.name}":    return iCurrentPair.transferor.name;
            case "{transferor.address}": return iCurrentPair.transferor.address;
            case "{transferee.herd}":    return iCurrentPair.transferee.herdNumber;
            case "{transferee.name}":    return iCurrentPair.transferee.name;
            case "{transferee.address}": return iCurrentPair.transferee.address;
            case "{agent}":              return iCurrentPair.agent;
            case "{transferor.agent}":   return iCurrentPair.agent;
            case "{transferee.agent}":   return iCurrentPair.transfereeAgent;
            case "{transferee.login}":   return iCurrentPair.transfereeAgent;
            default:
                throw new IllegalArgumentException(LOG_PREFIX + "Unknown token " + pValue.trim()
                        + ". Use {transferor.herd}, {transferor.name}, {transferee.herd}, {transferee.name}, "
                        + "{transferor.address}, {transferee.address}, {agent}, {transferor.agent}, {transferor.login}, "
                        + "{transferee.agent}, {transferee.login} or {auto.agent}.");
        }
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : isAutoAgentToken / resolveAgent / rankedAgents
    // Description   : {auto.agent} = the agent with the most usable herds, other than the logged-in agent and the
    //                 current transferor agent; {auto.agent.N} = the N-th best. The pick is made once per scenario and
    //                 kept, so the transfereeAgent row, the re-login step and the acceptance steps all get the same
    //                 agent. Plain logins are returned unchanged, so every pair method can call resolveAgent safely.
    //
    //                 Ranking, first that answers:
    //                   1. Test Data Vault - ENTS_AGENT pools by AVAILABLE rows (what can actually be used today)
    //                   2. vault.meta top.agents - stored by TC_00_DATA from the "ENTS Top agents" query
    //                   3. live query "ENTS Top agents" (cached for the run)
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 01-10-2026
    // ***************************************************************************************************************************************************************************************
    public static boolean isAutoAgentToken(String pValue)
    {
        return pValue != null && pValue.trim().toLowerCase(Locale.ROOT).startsWith("{auto.agent");
    }

    public static synchronized String resolveAgent(String pValue)
    {
        if (!isAutoAgentToken(pValue)) return pValue == null ? "" : pValue.trim();

        String iToken = pValue.trim().toLowerCase(Locale.ROOT);
        int    iIndex = 1;
        if (iToken.startsWith("{auto.agent.") && iToken.endsWith("}"))
        {
            try { iIndex = Math.max(1, Integer.parseInt(iToken.substring("{auto.agent.".length(), iToken.length() - 1).trim())); }
            catch (NumberFormatException e)
            {
                throw new IllegalArgumentException(LOG_PREFIX + "Unknown token " + pValue.trim() + ". Use {auto.agent} or {auto.agent.2}, {auto.agent.3}, ...");
            }
        }
        if (AUTO_AGENTS.containsKey(iIndex)) return AUTO_AGENTS.get(iIndex);

        // Never the agent who is logged in or who owns the transferor herd - a transfer needs two different agents
        Set<String> iExclude = new HashSet<>();
        if (!iLoggedInUser.isEmpty()) iExclude.add(iLoggedInUser.toLowerCase(Locale.ROOT));
        if (iCurrentPair != null && iCurrentPair.agent != null) iExclude.add(iCurrentPair.agent.toLowerCase(Locale.ROOT));

        int iRank = 0;
        for (String iAgent : rankedAgents())
        {
            if (iExclude.contains(iAgent.toLowerCase(Locale.ROOT)) || TestDataVault.isLoginExpired(iAgent)) continue;
            iRank++;
            if (iRank == iIndex)
            {
                AUTO_AGENTS.put(iIndex, iAgent);
                CommonFunctions.log.info(LOG_PREFIX + pValue.trim() + " -> " + iAgent
                        + (iExclude.isEmpty() ? "" : " (skipped " + iExclude + ")") + " - kept for the rest of the scenario.");
                return iAgent;
            }
        }
        throw new IllegalStateException(LOG_PREFIX + "No agent with usable herds found for " + pValue.trim()
                + " (excluded " + iExclude + "). Run TC_00_DATA, or check the \"ENTS Top agents\" query.");
    }

    public static synchronized List<String> rankedAgents()
    {
        // 1. the vault: what is really available right now
        if (TestDataVault.isEnabled())
        {
            List<Map.Entry<String, Integer>> iPools = new ArrayList<>();
            for (Map.Entry<String, Integer> iEntry : TestDataVault.availableCounts().entrySet())
            {
                if (iEntry.getKey().startsWith(TestDataVault.POOL_ENTS_AGENT + "/") && iEntry.getValue() > 0) iPools.add(iEntry);
            }
            if (!iPools.isEmpty())
            {
                iPools.sort((a, b) -> b.getValue() - a.getValue() != 0 ? b.getValue() - a.getValue() : a.getKey().compareTo(b.getKey()));
                List<String> iRanked = new ArrayList<>();
                for (Map.Entry<String, Integer> iEntry : iPools) iRanked.add(iEntry.getKey().substring(TestDataVault.POOL_ENTS_AGENT.length() + 1));
                CommonFunctions.log.info(LOG_PREFIX + "Agent ranking from the vault: " + iPools);
                return iRanked;
            }
            // 2. the ranking TC_00_DATA stored
            List<String> iStored = TestDataVault.topAgents();
            if (!iStored.isEmpty())
            {
                CommonFunctions.log.info(LOG_PREFIX + "Agent ranking from vault.meta: " + iStored);
                return iStored;
            }
        }
        // 3. live
        if (RANKED_AGENTS == null)
        {
            RANKED_AGENTS = topAgentsLive(ConfigManager.getInt("data.auto.agents.rank", 10));
            CommonFunctions.log.info(LOG_PREFIX + "Agent ranking from the Top agents query: " + RANKED_AGENTS);
        }
        return RANKED_AGENTS;
    }

    // Runs "ENTS Top agents" and returns the logins, most herds first (shared with DataHarvester)
    public static List<String> topAgentsLive(int pHowMany)
    {
        String iYear = ConfigManager.getOrDefault("ents.scheme.year", "").trim();
        String iType = ConfigManager.getOrDefault("ents.cust.type", "").trim();
        String iTwo  = ConfigManager.getBool("ents.name.two.words", true) ? "Y" : "";
        String iLike = ConfigManager.getOrDefault("data.auto.agents.like", "ag%").trim();
        List<String> iRanked = new ArrayList<>();
        for (Map<String, Object> iRow : DBRouter.query("ENTS", "ENTS Top agents", String.valueOf(pHowMany), iYear, iType, iTwo, iLike))
        {
            String iLogin = text(iRow, "AGENT_LOGIN");
            if (!iLogin.isEmpty()) iRanked.add(iLogin);
        }
        return iRanked;
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : resolveTable
    // Description   : Returns a copy of a DataTable map with every token replaced (keys and order kept)
    // Parameters    : pTable (Map) - the DataTable as a key/value map
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 22-09-2026
    // ***************************************************************************************************************************************************************************************
    public static Map<String, String> resolveTable(Map<String, String> pTable)
    {
        Map<String, String> iResolved = new LinkedHashMap<>();
        for (Map.Entry<String, String> iEntry : pTable.entrySet())
        {
            iResolved.put(iEntry.getKey(), resolve(iEntry.getValue()));
        }
        return iResolved;
    }

    // =================================================================================================
    // PAIR SELECTION
    // =================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Function Name : nextSameAgentPair
    // Description   : Picks two different, unused herds of the same agent (transferor + transferee), records them in
    //                 the used-herds file, logs them and makes them the current pair.
    // Parameters    : pAgent   (String) - agent login, e.g. "aga6077"
    //                 pPurpose (String) - written to the used-herds file, e.g. the transfer type
    // Returns       : TransferPair
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 22-09-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized TransferPair nextSameAgentPair(String pAgent, String pPurpose)
    {
        if (pAgent == null || pAgent.isBlank())
        {
            throw new IllegalStateException(LOG_PREFIX + "No agent is logged in, so there is no agent to take herds from. "
                    + "The ENTS login step must run before the transfer is created.");
        }

        String     iAgent     = pAgent.trim();
        List<Herd> iPool      = agentPool(iAgent);
        Set<String> iUsed     = usedHerds();
        List<Herd> iAvailable = new ArrayList<>();

        for (Herd iHerd : iPool)
        {
            if (!iUsed.contains(iHerd.herdNumber)) iAvailable.add(iHerd);
        }

        if (iAvailable.size() < 2)
        {
            throw new IllegalStateException(LOG_PREFIX + "Agent Login query for " + iAgent + " has " + iAvailable.size()
                    + " unused herd(s) left out of " + iPool.size() + ", and a transfer needs 2. "
                    + "Clear or trim " + usedFile() + ", raise ents.pool.size, or use another agent.");
        }

        Collections.shuffle(iAvailable, new Random(System.nanoTime()));
        Herd iTransferor = iAvailable.get(0);
        Herd iTransferee = iAvailable.get(1);

        markUsed("transferor", iTransferor.herdNumber, iAgent, pPurpose);
        markUsed("transferee", iTransferee.herdNumber, iAgent, pPurpose);

        iCurrentPair = new TransferPair(iAgent, iTransferor, iTransferee);

        CommonFunctions.log.info(LOG_PREFIX + "Picked for [" + pPurpose + "] | Agent=" + iAgent
                + " | Transferor=" + iTransferor + " | Transferee=" + iTransferee
                + " | " + (iAvailable.size() - 2) + " unused herd(s) left in the pool");

        return iCurrentPair;
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : nextNoEntitlementPair
    // Description   : Negative-case version of nextSameAgentPair (TC_02_ENTS Section 2). Both herds belong to the same
    //                 agent and are picked at random:
    //                   transferor - an unused herd of the agent with NO entitlements in the scheme year
    //                                (query "ENTS Agent herds without entitlements")
    //                   transferee - an unused herd from the agent's usual Agent Login pool
    //                 Both are recorded in the used-herds file and become the current pair, so {transferor.herd},
    //                 {transferee.herd} and {transferee.name} work as usual.
    // Parameters    : pAgent   (String) - agent login, e.g. "aga6077"
    //                 pPurpose (String) - written to the used-herds file, e.g. the transfer type
    // Returns       : TransferPair
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 23-09-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized TransferPair nextNoEntitlementPair(String pAgent, String pPurpose)
    {
        if (pAgent == null || pAgent.isBlank())
        {
            throw new IllegalStateException(LOG_PREFIX + "No agent is logged in, so there is no agent to take herds from. "
                    + "The ENTS login step must run before the transfer search.");
        }

        String      iAgent = pAgent.trim();
        Set<String> iUsed  = usedHerds();

        List<Herd> iNoEnts    = noEntitlementPool(iAgent);
        List<Herd> iAvailable = new ArrayList<>();
        for (Herd iHerd : iNoEnts)
        {
            if (!iUsed.contains(iHerd.herdNumber)) iAvailable.add(iHerd);
        }

        if (iAvailable.isEmpty())
        {
            throw new IllegalStateException(LOG_PREFIX + "\"ENTS Agent herds without entitlements\" for " + iAgent
                    + " has no unused herd left out of " + iNoEnts.size() + ". "
                    + "Clear or trim " + usedFile() + ", raise ents.pool.size, or use another agent.");
        }

        Collections.shuffle(iAvailable, new Random(System.nanoTime()));
        Herd iTransferor = iAvailable.get(0);

        Set<String> iUsedPlus = new HashSet<>(iUsed);
        iUsedPlus.add(iTransferor.herdNumber);
        Herd iTransferee = pickUnused(iAgent, iUsedPlus, "transferee");

        markUsed("transferor-no-ents", iTransferor.herdNumber, iAgent, pPurpose);
        markUsed("transferee",         iTransferee.herdNumber, iAgent, pPurpose);

        iCurrentPair = new TransferPair(iAgent, iTransferor, iTransferee);

        CommonFunctions.log.info(LOG_PREFIX + "Picked for [" + pPurpose + "] (no entitlements) | Agent=" + iAgent
                + " | Transferor=" + iTransferor + " | Transferee=" + iTransferee
                + " | " + (iAvailable.size() - 1) + " unused no-entitlement herd(s) left");

        return iCurrentPair;
    }


    // ***************************************************************************************************************************************************************************************
    // Function Name : nextCrossAgentPair
    // Description   : Cross-agent version of nextSameAgentPair (TC_04_ENTS). The two herds come from two agents:
    //                   transferor - an unused herd from the Agent Login pool of pTransferorAgent (the logged-in agent)
    //                   transferee - an unused herd from the Agent Login pool of pTransfereeAgent
    //                 Both pools are fetched once per run and cached. Both herds are recorded in the used-herds file
    //                 (each with its own agent) and become the current pair. {transferee.agent} returns pTransfereeAgent,
    //                 so the login-swap step always logs in as the agent the transferee herd was taken from.
    //                 When both logins are the same, this is a same-agent pick (nextSameAgentPair).
    // Parameters    : pTransferorAgent (String) - logged-in agent, e.g. "aga6060"
    //                 pTransfereeAgent (String) - agent of the transferee, e.g. "aga6325"
    //                 pPurpose         (String) - written to the used-herds file, e.g. the transfer type
    // Returns       : TransferPair
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 29-09-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized TransferPair nextCrossAgentPair(String pTransferorAgent, String pTransfereeAgent, String pPurpose)
    {
        if (pTransferorAgent == null || pTransferorAgent.isBlank())
        {
            throw new IllegalStateException(LOG_PREFIX + "No agent is logged in, so there is no agent to take the transferor herd from. "
                    + "The ENTS login step must run before the transfer is created.");
        }
        if (pTransfereeAgent == null || pTransfereeAgent.isBlank())
        {
            throw new IllegalArgumentException(LOG_PREFIX + "The transfereeAgent row is empty - give the transferee agent login.");
        }

        String iOrAgent = pTransferorAgent.trim();
        String iEeAgent = resolveAgent(pTransfereeAgent);   // {auto.agent} -> the agent with the most herds
        if (iOrAgent.equalsIgnoreCase(iEeAgent))
        {
            return nextSameAgentPair(iOrAgent, pPurpose);
        }

        Set<String> iUsed       = usedHerds();
        Herd        iTransferor = pickUnused(iOrAgent, iUsed, "transferor");

        Set<String> iUsedPlus = new HashSet<>(iUsed);
        iUsedPlus.add(iTransferor.herdNumber);
        Herd iTransferee = pickUnused(iEeAgent, iUsedPlus, "transferee");

        markUsed("transferor", iTransferor.herdNumber, iOrAgent, pPurpose);
        markUsed("transferee", iTransferee.herdNumber, iEeAgent, pPurpose);

        iCurrentPair = new TransferPair(iOrAgent, iTransferor, iTransferee, iEeAgent);

        CommonFunctions.log.info(LOG_PREFIX + "Picked for [" + pPurpose + "] (cross-agent) | Transferor agent=" + iOrAgent
                + " | Transferor=" + iTransferor + " | Transferee agent=" + iEeAgent + " | Transferee=" + iTransferee);

        return iCurrentPair;
    }


    // ***************************************************************************************************************************************************************************************
    // Function Name : nextAgentToIndividualPair
    // Description   : Agent-to-individual version of nextSameAgentPair (TC_05_ENTS / TC_06_ENTS):
    //                   transferor - an unused herd from the Agent Login pool of pAgent (the logged-in agent)
    //                   transferee - an unused herd from the Individual Login query, i.e. a herd whose holder logs in
    //                                with their own online login (no agent needed to accept)
    //                 Both are recorded in the used-herds file (the transferee with the individual's login) and become
    //                 the current pair. {transferee.login} returns the individual's login for the login-swap step.
    // Parameters    : pAgent   (String) - logged-in agent, e.g. "agr9197"
    //                 pPurpose (String) - written to the used-herds file, e.g. the transfer type
    // Returns       : TransferPair
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 30-09-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized TransferPair nextAgentToIndividualPair(String pAgent, String pPurpose)
    {
        if (pAgent == null || pAgent.isBlank())
        {
            throw new IllegalStateException(LOG_PREFIX + "No agent is logged in, so there is no agent to take the transferor herd from. "
                    + "The ENTS login step must run before the transfer is created.");
        }

        String      iAgent      = pAgent.trim();
        Set<String> iUsed       = usedHerds();
        Herd        iTransferor = pickUnused(iAgent, iUsed, "transferor");

        Set<String> iUsedPlus = new HashSet<>(iUsed);
        iUsedPlus.add(iTransferor.herdNumber);

        Herd   iTransferee = pickUnusedIndividual(iUsedPlus, "transferee");
        String iLogin      = INDIVIDUAL_LOGINS.get(iTransferee.herdNumber);

        markUsed("transferor",            iTransferor.herdNumber, iAgent, pPurpose);
        markUsed("transferee-individual", iTransferee.herdNumber, iLogin, pPurpose);

        iCurrentPair = new TransferPair(iAgent, iTransferor, iTransferee, iLogin);

        CommonFunctions.log.info(LOG_PREFIX + "Picked for [" + pPurpose + "] (agent to individual) | Agent=" + iAgent
                + " | Transferor=" + iTransferor + " | Transferee=" + iTransferee + " | Individual login=" + iLogin);

        return iCurrentPair;
    }


    // ***************************************************************************************************************************************************************************************
    // Function Name : nextIndividualTransfereeForFixedTransferor
    // Description   : Keeps a transferor herd typed in the feature file (TC_12_ENTS: the ETF partner's own herd C2057024)
    //                 and picks only the transferee: an unused herd from the Individual Login query, whose own login
    //                 then accepts ({transferee.login}). The transferor is NOT written to the used-herds file, because
    //                 it is meant to be reused. Same idea as nextTransfereeForFixedTransferor, with an individual
    //                 transferee instead of an agent's client herd.
    // Parameters    : pTransferorHerd (String) - pinned transferor herd | pPurpose (String) - e.g. the transfer type
    // Returns       : TransferPair
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 02-10-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized TransferPair nextIndividualTransfereeForFixedTransferor(String pTransferorHerd, String pPurpose)
    {
        if (pTransferorHerd == null || pTransferorHerd.isBlank())
        {
            throw new IllegalArgumentException(LOG_PREFIX + "The transferorHerd cell is empty - give a herd number or {transferor.herd}.");
        }

        Set<String> iUsedPlus = new HashSet<>(usedHerds());
        iUsedPlus.add(pTransferorHerd.trim());

        Herd   iTransferor = new Herd(pTransferorHerd.trim(), "", "");
        Herd   iTransferee = pickUnusedIndividual(iUsedPlus, "transferee");
        String iLogin      = INDIVIDUAL_LOGINS.get(iTransferee.herdNumber);
        markUsed("transferee-individual", iTransferee.herdNumber, iLogin, pPurpose);

        iCurrentPair = new TransferPair(iLoggedInUser, iTransferor, iTransferee, iLogin);

        CommonFunctions.log.info(LOG_PREFIX + "Picked for [" + pPurpose + "] (pinned transferor, individual transferee) | Transferor="
                + pTransferorHerd.trim() + " (" + iLoggedInUser + ") | Transferee=" + iTransferee + " | Individual login=" + iLogin);
        return iCurrentPair;
    }


    // ***************************************************************************************************************************************************************************************
    // Function Name : nextIndividualTransferor
    // Description   : First half of an individual-as-transferor pair (TC_08 / TC_09 / TC_10_ENTS). Picks an unused herd
    //                 from the Individual Login query and makes it the current pair WITHOUT a transferee:
    //                   agent = the individual's own login (so {transferor.login} and {agent} return it)
    //                   transferor = that herd, transferee = null
    //                 The create step completes the pair with completePairWithAgentTransferee or
    //                 completePairWithIndividualTransferee. Recorded in the used-herds file straight away.
    // Parameters    : pPurpose (String) - written to the used-herds file, e.g. "individual transferor"
    // Returns       : TransferPair (transferee null)
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 30-09-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized TransferPair nextIndividualTransferor(String pPurpose)
    {
        Herd   iTransferor = pickUnusedIndividual(usedHerds(), "transferor");
        String iLogin      = INDIVIDUAL_LOGINS.get(iTransferor.herdNumber);

        markUsed("transferor-individual", iTransferor.herdNumber, iLogin, pPurpose);

        iCurrentPair = new TransferPair(iLogin, iTransferor, null, iLogin);

        CommonFunctions.log.info(LOG_PREFIX + "Picked individual transferor for [" + pPurpose + "] | Herd=" + iTransferor
                + " | Login=" + iLogin + " (transferee picked by the create step)");
        return iCurrentPair;
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : completePairWithAgentTransferee
    // Description   : Second half of an individual-as-transferor pair (TC_08_ENTS / TC_10_ENTS): the transferee is an
    //                 unused herd from the Agent Login pool of pAgent, and {transferee.agent} / {transferee.login}
    //                 return pAgent for the login-swap step.
    // Parameters    : pAgent (String) - agent (or ETF partner) login that manages the transferee, e.g. "aga6325"
    //                 pPurpose (String) - written to the used-herds file, e.g. the transfer type
    // Returns       : TransferPair
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 30-09-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized TransferPair completePairWithAgentTransferee(String pAgent, String pPurpose)
    {
        requireHalfPair("completePairWithAgentTransferee");
        if (pAgent == null || pAgent.isBlank())
        {
            throw new IllegalArgumentException(LOG_PREFIX + "The transfereeAgent row is empty - give the login of the agent who manages the transferee.");
        }

        String      iAgent    = resolveAgent(pAgent);   // {auto.agent} -> the agent with the most herds
        Set<String> iUsedPlus = new HashSet<>(usedHerds());
        iUsedPlus.add(iCurrentPair.transferor.herdNumber);

        Herd iTransferee = pickUnused(iAgent, iUsedPlus, "transferee");
        markUsed("transferee", iTransferee.herdNumber, iAgent, pPurpose);

        iCurrentPair = new TransferPair(iCurrentPair.agent, iCurrentPair.transferor, iTransferee, iAgent);

        CommonFunctions.log.info(LOG_PREFIX + "Pair completed for [" + pPurpose + "] (individual to agent) | Transferor="
                + iCurrentPair.transferor + " (" + iCurrentPair.agent + ") | Transferee agent=" + iAgent + " | Transferee=" + iTransferee);
        return iCurrentPair;
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : completePairWithIndividualTransferee
    // Description   : Second half of an individual-as-transferor pair (TC_09_ENTS): the transferee is another unused herd
    //                 from the Individual Login query, and {transferee.login} returns that individual's login.
    // Parameters    : pPurpose (String) - written to the used-herds file, e.g. the transfer type
    // Returns       : TransferPair
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 30-09-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized TransferPair completePairWithIndividualTransferee(String pPurpose)
    {
        requireHalfPair("completePairWithIndividualTransferee");

        Set<String> iUsedPlus = new HashSet<>(usedHerds());
        iUsedPlus.add(iCurrentPair.transferor.herdNumber);

        Herd   iTransferee = pickUnusedIndividual(iUsedPlus, "transferee");
        String iLogin      = INDIVIDUAL_LOGINS.get(iTransferee.herdNumber);
        markUsed("transferee-individual", iTransferee.herdNumber, iLogin, pPurpose);

        iCurrentPair = new TransferPair(iCurrentPair.agent, iCurrentPair.transferor, iTransferee, iLogin);

        CommonFunctions.log.info(LOG_PREFIX + "Pair completed for [" + pPurpose + "] (individual to individual) | Transferor="
                + iCurrentPair.transferor + " (" + iCurrentPair.agent + ") | Transferee=" + iTransferee + " (" + iLogin + ")");
        return iCurrentPair;
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : nextTransfereeForFixedTransferor
    // Description   : Keeps a transferor herd typed in the feature file (TC_11_ENTS: the ETF partner's own herd) and picks
    //                 only the transferee, an unused herd from the Agent Login pool of pTransfereeAgent. The transferor
    //                 is NOT written to the used-herds file, because it is meant to be reused.
    // Parameters    : pTransferorHerd  (String) - pinned transferor herd, e.g. "C2057024"
    //                 pTransfereeAgent (String) - agent who manages the transferee, e.g. "aga6581"
    //                 pPurpose         (String) - written to the used-herds file, e.g. the transfer type
    // Returns       : TransferPair
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 30-09-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized TransferPair nextTransfereeForFixedTransferor(String pTransferorHerd, String pTransfereeAgent, String pPurpose)
    {
        if (pTransfereeAgent == null || pTransfereeAgent.isBlank())
        {
            throw new IllegalArgumentException(LOG_PREFIX + "The transfereeAgent row is empty - give the login of the agent who manages the transferee.");
        }

        String      iAgent    = resolveAgent(pTransfereeAgent);   // {auto.agent} -> the agent with the most herds
        Set<String> iUsedPlus = new HashSet<>(usedHerds());
        iUsedPlus.add(pTransferorHerd.trim());

        Herd iTransferor = new Herd(pTransferorHerd.trim(), "", "");
        Herd iTransferee = pickUnused(iAgent, iUsedPlus, "transferee");
        markUsed("transferee", iTransferee.herdNumber, iAgent, pPurpose);

        iCurrentPair = new TransferPair(iLoggedInUser, iTransferor, iTransferee, iAgent);

        CommonFunctions.log.info(LOG_PREFIX + "Picked for [" + pPurpose + "] (pinned transferor) | Transferor=" + pTransferorHerd.trim()
                + " (" + iLoggedInUser + ") | Transferee agent=" + iAgent + " | Transferee=" + iTransferee);
        return iCurrentPair;
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : isIndividualLogin
    // Description   : True when the login was handed out by the Individual Login query in this run
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 30-09-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized boolean isIndividualLogin(String pLogin)
    {
        return pLogin != null && INDIVIDUAL_LOGINS.containsValue(pLogin.trim());
    }

    // The current pair must be a first half (individual transferor, no transferee yet)
    private static void requireHalfPair(String pCaller)
    {
        if (iCurrentPair == null || iCurrentPair.transferee != null)
        {
            throw new IllegalStateException(LOG_PREFIX + pCaller + " needs an individual transferor picked first. "
                    + "The login step must use {transferor.login} so nextIndividualTransferor runs before the transfer is created.");
        }
    }

    // One random herd of the Individual Login pool that is not in pExclude
    private static Herd pickUnusedIndividual(Set<String> pExclude, String pRole)
    {
        List<Herd> iPool      = individualPool();
        List<Herd> iAvailable = new ArrayList<>();
        for (Herd iHerd : iPool)
        {
            if (!pExclude.contains(iHerd.herdNumber)) iAvailable.add(iHerd);
        }
        if (iAvailable.isEmpty())
        {
            throw new IllegalStateException(LOG_PREFIX + "Individual Login query has no unused herd left out of " + iPool.size()
                    + ", and one is needed as the " + pRole + ". Clear or trim " + usedFile()
                    + ", or raise ents.individual.pool.size.");
        }
        Collections.shuffle(iAvailable, new Random(System.nanoTime()));
        return iAvailable.get(0);
    }


    // ***************************************************************************************************************************************************************************************
    // Function Name : pickUnused
    // Description   : One random herd of an agent that is not in pExclude. Throws with a clear message when the pool
    //                 has no unused herd left.
    // Parameters    : pAgent (String) - agent login | pExclude (Set) - herds already used | pRole (String) - for the message
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 22-09-2026
    // ***************************************************************************************************************************************************************************************
    private static Herd pickUnused(String pAgent, Set<String> pExclude, String pRole)
    {
        List<Herd> iPool      = agentPool(pAgent);
        List<Herd> iAvailable = new ArrayList<>();
        for (Herd iHerd : iPool)
        {
            if (!pExclude.contains(iHerd.herdNumber)) iAvailable.add(iHerd);
        }

        if (iAvailable.isEmpty())
        {
            throw new IllegalStateException(LOG_PREFIX + "Agent Login query for " + pAgent + " has no unused herd left out of "
                    + iPool.size() + ", and one is needed as the " + pRole + ". "
                    + "Clear or trim " + usedFile() + ", raise ents.pool.size, or use another agent.");
        }

        Collections.shuffle(iAvailable, new Random(System.nanoTime()));
        return iAvailable.get(0);
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : usePortalName
    // Description   : Replaces the name of a herd of the current pair with the name shown in the portal.
    //                 The transferee search only matches the exact portal name, and the DB name can differ from it
    //                 (e.g. "Martin Starr" in the DB, "Martin Starr Jnr" in the portal). After this call,
    //                 {transferor.name} / {transferee.name} return the portal name.
    // Parameters    : pHerd (String) - herd number of the current pair | pPortalName (String) - name from the Name column
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 22-09-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized void usePortalName(String pHerd, String pPortalName)
    {
        if (iCurrentPair == null || pHerd == null || pPortalName == null || pPortalName.isBlank()) return;

        String iName = pPortalName.trim().replaceAll("\\s+", " ");
        Herd   iOr   = iCurrentPair.transferor;
        Herd   iEe   = iCurrentPair.transferee;

        if (iOr.herdNumber.equalsIgnoreCase(pHerd.trim()) && !iName.equals(iOr.name))
        {
            CommonFunctions.log.info(LOG_PREFIX + "Transferor " + iOr.herdNumber + " name: DB='" + iOr.name + "' portal='" + iName + "' - using the portal name");
            iOr = new Herd(iOr.herdNumber, iName, iOr.address);
        }
        else if (iEe != null && iEe.herdNumber.equalsIgnoreCase(pHerd.trim()) && !iName.equals(iEe.name))
        {
            CommonFunctions.log.info(LOG_PREFIX + "Transferee " + iEe.herdNumber + " name: DB='" + iEe.name + "' portal='" + iName + "' - using the portal name");
            iEe = new Herd(iEe.herdNumber, iName, iEe.address);
        }
        else
        {
            return;
        }
        iCurrentPair = new TransferPair(iCurrentPair.agent, iOr, iEe, iCurrentPair.transfereeAgent);
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : agentPool
    // Description   : Rows of the Agent Login query for one agent, fetched once per run and cached
    // Parameters    : pAgent (String) - agent login
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 22-09-2026
    // ***************************************************************************************************************************************************************************************
    private static List<Herd> agentPool(String pAgent)
    {
        String     iKey    = pAgent.toLowerCase(Locale.ROOT);
        List<Herd> iCached = AGENT_POOLS.get(iKey);
        if (iCached != null) return iCached;

        List<Herd> iFromVault = vaultPool(TestDataVault.POOL_ENTS_AGENT, pAgent, "Agent Login");
        if (iFromVault == null) iFromVault = vaultPool(TestDataVault.POOL_ENTS_ETF, pAgent, "ETF partner");
        if (iFromVault != null)
        {
            AGENT_POOLS.put(iKey, iFromVault);
            return iFromVault;
        }

        int    iLimit = ConfigManager.getInt("ents.pool.size", 200);
        String iYear  = ConfigManager.getOrDefault("ents.scheme.year", "").trim();
        String iType  = ConfigManager.getOrDefault("ents.cust.type", "").trim();
        String iTwo   = ConfigManager.getBool("ents.name.two.words", true) ? "Y" : "";
        long   iStart = System.currentTimeMillis();

        CommonFunctions.log.info(LOG_PREFIX + "Running Agent Login query for " + pAgent + " (up to " + iLimit + " rows"
                + (iYear.isEmpty() ? ", all scheme years" : ", scheme year " + iYear)
                + (iType.isEmpty() ? ", all customer types" : ", cust_type " + iType)
                + (iTwo.isEmpty() ? "" : ", two-word names only") + ")...");
        DBRouter.runDB("ENTS", "ENTS Agent Login herds", pAgent, String.valueOf(iLimit), iYear, iType, iTwo);

        List<Herd> iPool = new ArrayList<>();
        for (Map<String, Object> iRow : DBRouter.getRows())
        {
            String iHerd = text(iRow, "HERD_NUMBER");
            if (!iHerd.isEmpty())
            {
                iPool.add(new Herd(iHerd, text(iRow, "HERD_NAME"), text(iRow, "ADDRESSLINE1")));
            }
        }

        CommonFunctions.log.info(LOG_PREFIX + "Agent Login query for " + pAgent + " returned " + iPool.size()
                + " herd(s) in " + (System.currentTimeMillis() - iStart) / 1000 + " s");

        String iVaultPool = TestDataVault.POOL_ENTS_AGENT;
        if (iPool.isEmpty())
        {
            // ETF partners (agr15512, agr15678) are not in herd_agt - their herds come via tden_herd_etf_link
            CommonFunctions.log.info(LOG_PREFIX + pAgent + " is not in herd_agt - running the ETF partner query...");
            DBRouter.runDB("ENTS", "ENTS ETF partner herds", pAgent, String.valueOf(iLimit), iYear, iTwo);
            for (Map<String, Object> iRow : DBRouter.getRows())
            {
                String iHerd = text(iRow, "HERD_NUMBER");
                if (!iHerd.isEmpty()) iPool.add(new Herd(iHerd, text(iRow, "HERD_NAME"), text(iRow, "ADDRESSLINE1")));
            }
            iVaultPool = TestDataVault.POOL_ENTS_ETF;
            CommonFunctions.log.info(LOG_PREFIX + "ETF partner query for " + pAgent + " returned " + iPool.size() + " herd(s)");
        }

        if (iPool.isEmpty())
        {
            throw new IllegalStateException(LOG_PREFIX + "Neither the Agent Login query nor the ETF partner query returned herds for "
                    + pAgent + ". Check the login, or run the queries in SQL Developer on CENTEST_ENTS_DATA.");
        }

        AGENT_POOLS.put(iKey, iPool);
        storeInVault(iVaultPool, pAgent, iPool, pAgent);
        return iPool;
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : noEntitlementPool
    // Description   : Herds of one agent with NO entitlements in the scheme year, fetched once per run and cached.
    //                 Scheme year = ents.scheme.year, or the current year when that is blank (the query needs a year).
    //                 No two-word name filter: the transferor name is never typed.
    // Parameters    : pAgent (String) - agent login
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 23-09-2026
    // ***************************************************************************************************************************************************************************************
    private static List<Herd> noEntitlementPool(String pAgent)
    {
        String     iKey    = pAgent.toLowerCase(Locale.ROOT);
        List<Herd> iCached = NO_ENTS_POOLS.get(iKey);
        if (iCached != null) return iCached;

        List<Herd> iFromVault = vaultPool(TestDataVault.POOL_ENTS_NO_ENTS, pAgent, "Agent herds without entitlements");
        if (iFromVault != null)
        {
            NO_ENTS_POOLS.put(iKey, iFromVault);
            return iFromVault;
        }

        int    iLimit = ConfigManager.getInt("ents.pool.size", 200);
        String iYear  = ConfigManager.getOrDefault("ents.scheme.year", "").trim();
        if (iYear.isEmpty()) iYear = String.valueOf(LocalDate.now().getYear());
        String iType  = ConfigManager.getOrDefault("ents.cust.type", "").trim();
        long   iStart = System.currentTimeMillis();

        CommonFunctions.log.info(LOG_PREFIX + "Running \"ENTS Agent herds without entitlements\" for " + pAgent
                + " (up to " + iLimit + " rows, scheme year " + iYear
                + (iType.isEmpty() ? ", all customer types" : ", cust_type " + iType) + ")...");
        DBRouter.runDB("ENTS", "ENTS Agent herds without entitlements", pAgent, String.valueOf(iLimit), iYear, iType);

        List<Herd> iPool = new ArrayList<>();
        for (Map<String, Object> iRow : DBRouter.getRows())
        {
            String iHerd = text(iRow, "HERD_NUMBER");
            if (!iHerd.isEmpty())
            {
                iPool.add(new Herd(iHerd, text(iRow, "HERD_NAME"), text(iRow, "ADDRESSLINE1")));
            }
        }

        CommonFunctions.log.info(LOG_PREFIX + "\"ENTS Agent herds without entitlements\" for " + pAgent + " returned "
                + iPool.size() + " herd(s) in " + (System.currentTimeMillis() - iStart) / 1000 + " s");

        if (iPool.isEmpty())
        {
            throw new IllegalStateException(LOG_PREFIX + "No herd without entitlements found for " + pAgent
                    + " in scheme year " + iYear + ". Check ents.scheme.year, or run the query in SQL Developer on CENTEST_ENTS_DATA.");
        }

        NO_ENTS_POOLS.put(iKey, iPool);
        storeInVault(TestDataVault.POOL_ENTS_NO_ENTS, pAgent, iPool, pAgent);
        return iPool;
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : individualPool
    // Description   : Rows of the Individual Login query, fetched once per run and cached. Same two-word name and
    //                 customer type settings as the Agent Login query (ents.name.two.words, ents.cust.type), because
    //                 the individual is typed into the same transferee search. Rows without a login are dropped.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 30-09-2026
    // ***************************************************************************************************************************************************************************************
    private static List<Herd> individualPool()
    {
        if (INDIVIDUAL_POOL != null) return INDIVIDUAL_POOL;

        List<Herd> iFromVault = vaultPool(TestDataVault.POOL_ENTS_INDIVIDUAL, "", "Individual Login");
        if (iFromVault != null)
        {
            for (TestDataVault.Row iRow : TestDataVault.available(TestDataVault.POOL_ENTS_INDIVIDUAL, ""))
            {
                INDIVIDUAL_LOGINS.putIfAbsent(iRow.herd, iRow.login);
            }
            INDIVIDUAL_POOL = iFromVault;
            return iFromVault;
        }

        int    iLimit = ConfigManager.getInt("ents.individual.pool.size", ConfigManager.getInt("ents.pool.size", 200));
        String iType  = ConfigManager.getOrDefault("ents.cust.type", "").trim();
        String iTwo   = ConfigManager.getBool("ents.name.two.words", true) ? "Y" : "";
        long   iStart = System.currentTimeMillis();

        CommonFunctions.log.info(LOG_PREFIX + "Running Individual Login query (up to " + iLimit + " rows"
                + (iType.isEmpty() ? ", all customer types" : ", cust_type " + iType)
                + (iTwo.isEmpty() ? "" : ", two-word names only") + ")...");
        DBRouter.runDB("ENTS", "ENTS Individual Login herds", String.valueOf(iLimit), iTwo, iType);

        List<Herd> iPool = new ArrayList<>();
        for (Map<String, Object> iRow : DBRouter.getRows())
        {
            String iHerd  = text(iRow, "HERD_NUMBER");
            String iLogin = text(iRow, "LOGIN_ID");
            if (!iHerd.isEmpty() && !iLogin.isEmpty() && !INDIVIDUAL_LOGINS.containsKey(iHerd))
            {
                iPool.add(new Herd(iHerd, text(iRow, "NAME"), text(iRow, "ADDRESS")));
                INDIVIDUAL_LOGINS.put(iHerd, iLogin);
            }
        }

        CommonFunctions.log.info(LOG_PREFIX + "Individual Login query returned " + iPool.size() + " herd(s) in "
                + (System.currentTimeMillis() - iStart) / 1000 + " s");

        if (iPool.isEmpty())
        {
            throw new IllegalStateException(LOG_PREFIX + "Individual Login query returned no herds. "
                    + "Run it in SQL Developer on CENTEST_ENTS_DATA, or check ents.cust.type / ents.name.two.words.");
        }

        INDIVIDUAL_POOL = iPool;
        storeInVault(TestDataVault.POOL_ENTS_INDIVIDUAL, "", iPool, null);
        return iPool;
    }

    private static String text(Map<String, Object> pRow, String pColumn)
    {
        return Objects.toString(pRow.get(pColumn), "").trim();
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : markNotFound
    // Description   : Records that a picked herd could not be found on screen (for example not in the agent's
    //                 Transfer Out list). The herd is already in the used-herds file, so it is never picked again;
    //                 this extra line only explains why, for whoever reads the file.
    // Parameters    : pHerd   (String) - herd number
    //                 pReason (String) - short reason, e.g. "not in Transfer Out list"
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 22-09-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized void markNotFound(String pHerd, String pReason)
    {
        String iAgent = iCurrentPair == null ? iLoggedInUser : iCurrentPair.agent;
        markUsed("not-found", pHerd, iAgent, pReason);
        CommonFunctions.log.warning(LOG_PREFIX + "Herd " + pHerd + " skipped: " + pReason);

        if (TestDataVault.isEnabled())
        {
            TestDataVault.markBad(pHerd, pReason);
            countBadAndRefill(iAgent);
        }
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : markCurrentPairUsed
    // Description   : The transfer of the current pair went through: both herds become USED in the vault. Called by
    //                 TC_01_ENTS "the transfer should be submitted successfully". Nothing happens without a pair.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 01-10-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized void markCurrentPairUsed()
    {
        markCurrentPairUsed(true);
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : markCurrentPairUsed(boolean)
    // Description   : The section is finished. pConfirmed = the portal showed the submitted message.
    //                 Reuse mode (data.reuse.herds=true, 01-10-2026): a confirmed transfer only moved 0.01 entitlements,
    //                 so both herds go back to AVAILABLE in the vault and can be picked again, even later in this run.
    //                 Two exceptions stay USED until the next weekly refill, because reusing them would break a test:
    //                   - the transferee of a Lease: it now holds leased entitlements, and as a transferor it would hit
    //                     "Leased entitlements can only be transferred by Change of Registration ..."
    //                   - both herds of an unconfirmed transfer: it may still be pending, and a second transfer on the
    //                     same herd could be blocked or accept the wrong transfer
    // Parameters    : pConfirmed (boolean)
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 01-10-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized void markCurrentPairUsed(boolean pConfirmed)
    {
        if (iCurrentPair == null) return;
        boolean iReuse = TestDataVault.isReuseOn();
        boolean iLease = iLastPurpose.toLowerCase(Locale.ROOT).contains("lease");
        String  iOr    = iCurrentPair.transferor.herdNumber;
        String  iEe    = iCurrentPair.transferee == null ? null : iCurrentPair.transferee.herdNumber;

        if (TestDataVault.isEnabled())
        {
            if (!pConfirmed && iReuse)
            {
                TestDataVault.markUsedFinal(iOr, "transfer not confirmed - may still be pending");
                if (iEe != null) TestDataVault.markUsedFinal(iEe, "transfer not confirmed - may still be pending");
            }
            else
            {
                TestDataVault.markUsed(iOr);
                if (iEe != null)
                {
                    if (iReuse && iLease) TestDataVault.markUsedFinal(iEe, "lease transferee - holds leased entitlements now");
                    else                  TestDataVault.markUsed(iEe);
                }
            }
        }

        if (iReuse && pConfirmed)
        {
            COMPLETED_THIS_RUN.add(iOr);
            if (iEe != null && !iLease) COMPLETED_THIS_RUN.add(iEe);
            CommonFunctions.log.info(LOG_PREFIX + "Reuse mode: " + iOr + (iEe != null && !iLease ? " and " + iEe : "")
                    + " can be picked again" + (iLease && iEe != null ? " (" + iEe + " kept out: lease transferee)" : "") + ".");
        }
        BAD_IN_A_ROW.clear();
    }

    // =================================================================================================
    // TEST DATA VAULT BRIDGE
    // =================================================================================================

    // Herds marked BAD in a row per agent (reset by a success). Three in a row = the vault pool is stale -> refetch.
    private static final Map<String, Integer> BAD_IN_A_ROW = new HashMap<>();

    // ***************************************************************************************************************************************************************************************
    // Function Name : vaultPool
    // Description   : The AVAILABLE rows of a vault pool as Herd objects, or null when the vault is off or has nothing
    //                 for this pool (the caller then runs the live query).
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 01-10-2026
    // ***************************************************************************************************************************************************************************************
    private static List<Herd> vaultPool(String pPool, String pKey, String pLabel)
    {
        if (!TestDataVault.isEnabled() || !TestDataVault.hasPool(pPool, pKey)) return null;

        List<TestDataVault.Row> iRows = TestDataVault.available(pPool, pKey);
        if (iRows.isEmpty())
        {
            CommonFunctions.log.warning(LOG_PREFIX + "Vault pool " + pPool + "/" + pKey + " has no available row left - running the "
                    + pLabel + " query instead (run TC_00_DATA to refill the vault).");
            return null;
        }

        List<Herd> iPool = new ArrayList<>();
        for (TestDataVault.Row iRow : iRows) iPool.add(new Herd(iRow.herd, iRow.name, iRow.address));
        CommonFunctions.log.info(LOG_PREFIX + pLabel + " pool" + (pKey.isEmpty() ? "" : " for " + pKey) + " taken from the vault: "
                + iPool.size() + " available herd(s), no query run.");
        return iPool;
    }

    // Rows of a live query are stored in the vault too, so the next run finds them there
    private static void storeInVault(String pPool, String pKey, List<Herd> pHerds, String pLogin)
    {
        if (!TestDataVault.isEnabled()) return;
        try
        {
            List<TestDataVault.Row> iRows = new ArrayList<>();
            for (Herd iHerd : pHerds)
            {
                String iLogin = pLogin != null ? pLogin : INDIVIDUAL_LOGINS.getOrDefault(iHerd.herdNumber, "");
                iRows.add(new TestDataVault.Row(pPool, pKey, iHerd.herdNumber, iHerd.name, iHerd.address, iLogin));
            }
            TestDataVault.putPool(pPool, pKey, iRows);
        }
        catch (Exception e)
        {
            CommonFunctions.log.warning(LOG_PREFIX + "Could not store the " + pPool + " rows in the vault: " + e.getMessage());
        }
    }

    // Three BAD herds in a row for one agent: drop the cached pool so the next pick runs the live query and refills the vault
    private static void countBadAndRefill(String pAgent)
    {
        String iKey   = pAgent == null ? "" : pAgent.toLowerCase(Locale.ROOT);
        int    iCount = BAD_IN_A_ROW.merge(iKey, 1, Integer::sum);
        int    iLimit = ConfigManager.getInt("data.bad.in.a.row", 3);
        if (iCount >= iLimit)
        {
            CommonFunctions.log.warning(LOG_PREFIX + iCount + " bad herd(s) in a row for " + pAgent
                    + " - the vault pool looks stale, the next pick runs the live query and refills it.");
            AGENT_POOLS.remove(iKey);
            NO_ENTS_POOLS.remove(iKey);
            INDIVIDUAL_POOL = null;
            for (String iPoolName : new String[]{ TestDataVault.POOL_ENTS_AGENT, TestDataVault.POOL_ENTS_ETF })
            {
                for (TestDataVault.Row iRow : TestDataVault.available(iPoolName, pAgent))
                {
                    TestDataVault.markBad(iRow.herd, "pool refetched after " + iCount + " bad herds in a row");
                }
            }
            BAD_IN_A_ROW.put(iKey, 0);
        }
    }

    // =================================================================================================
    // USED-HERDS FILE
    // =================================================================================================

    private static Path usedFile()
    {
        return Paths.get(ConfigManager.getOrDefault("ents.used.herds.file", "runtime-data/ents_used_herds.csv"));
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : usedHerds
    // Description   : Herds that must not be picked: those handed out in this run, plus (when ents.skip.used.herds=true)
    //                 every herd listed in the used-herds file from earlier runs.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 22-09-2026
    // ***************************************************************************************************************************************************************************************
    private static Set<String> usedHerds()
    {
        Set<String> iUsed = new HashSet<>(USED_THIS_RUN);

        // Reuse mode: only herds still in flight are skipped (handed out, transfer not confirmed yet). The used-herds
        // file is still written as a log, but not read.
        if (TestDataVault.isReuseOn())
        {
            iUsed.removeAll(COMPLETED_THIS_RUN);
            return iUsed;
        }

        if (!ConfigManager.getBool("ents.skip.used.herds", true)) return iUsed;

        Path iFile = usedFile();
        if (!Files.exists(iFile)) return iUsed;

        try
        {
            for (String iLine : Files.readAllLines(iFile, StandardCharsets.UTF_8))
            {
                String[] iCells = iLine.split(",", -1);
                if (iCells.length >= 4 && !iCells[3].isBlank() && !"herd".equalsIgnoreCase(iCells[3].trim()))
                {
                    iUsed.add(iCells[3].trim());
                }
            }
        }
        catch (IOException e)
        {
            CommonFunctions.log.warning(LOG_PREFIX + "Could not read " + iFile + " (" + e.getMessage()
                    + ") - only herds used in this run are skipped.");
        }
        return iUsed;
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : markUsed
    // Description   : Adds one line to the used-herds file. A write failure is logged, never fatal.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 22-09-2026
    // ***************************************************************************************************************************************************************************************
    private static void markUsed(String pRole, String pHerd, String pLogin, String pPurpose)
    {
        USED_THIS_RUN.add(pHerd);
        COMPLETED_THIS_RUN.remove(pHerd);   // handed out again - in flight until its transfer is confirmed
        if (pPurpose != null) iLastPurpose = pPurpose;

        // Vault: a herd handed out is RESERVED until markCurrentPairUsed (USED) or markNotFound (BAD)
        if (TestDataVault.isEnabled() && !"not-found".equals(pRole))
        {
            try { TestDataVault.reserveHerd(pHerd, System.getProperty("testcase", ""), pRole + " " + (pPurpose == null ? "" : pPurpose)); }
            catch (Exception e) { CommonFunctions.log.warning(LOG_PREFIX + "Vault reserve failed for " + pHerd + ": " + e.getMessage()); }
        }

        Path iFile = usedFile();
        try
        {
            if (iFile.getParent() != null) Files.createDirectories(iFile.getParent());
            if (!Files.exists(iFile))
            {
                Files.write(iFile, (CSV_HEADER + System.lineSeparator()).getBytes(StandardCharsets.UTF_8));
            }

            String iLine = String.join(",",
                    LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")),
                    csv(System.getProperty("testcase", "")),
                    csv(pRole),
                    csv(pHerd),
                    csv(pLogin),
                    csv(pPurpose)) + System.lineSeparator();

            Files.write(iFile, iLine.getBytes(StandardCharsets.UTF_8), StandardOpenOption.APPEND);
        }
        catch (IOException e)
        {
            CommonFunctions.log.warning(LOG_PREFIX + "Could not record " + pHerd + " in " + iFile + " (" + e.getMessage() + ")");
        }
    }

    // Commas would break the simple CSV format - replace them
    private static String csv(String pValue)
    {
        return pValue == null ? "" : pValue.replace(',', ' ').replace('\n', ' ').replace('\r', ' ').trim();
    }
}