package com.stepdefinitions;


import com.base.ConfigReader;
import com.base.DriverManager;
import com.pages.BPSApplicationsPage;
import com.pages.ClientApplicationPage;
import com.pages.LoginPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import java.util.Properties;

public class ClientApplicationSteps {

    LoginPage loginPage;
    //BPSdashboardPage bpsdashboardPage;
    BPSApplicationsPage bpsapplicationsPage;
    ClientApplicationPage clientapplicationPage;
    WebDriver driver;
    Properties prop;
    ConfigReader configReader;
    DriverManager driverManager;

    public ClientApplicationSteps(DriverManager driverManager){
        try {
            this.driverManager=driverManager;
            driver=driverManager.getDriverInstance();
            loginPage = new LoginPage(driver);
            bpsapplicationsPage = new BPSApplicationsPage(driver);
            clientapplicationPage = new ClientApplicationPage(driver);
            configReader = new ConfigReader();
            prop = configReader.init_prop();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }



    @And("Agent is on Client Application Page")
    public void ClientApplicationPage() {
        String title = driver.getTitle();
        System.out.println("title of Client Application" + title);
    }

    @When("Click on Applications NavLink Dropdown")
    public void AgentClickOnApplicationsNavlinkTab() throws InterruptedException {
        clientapplicationPage.AgentClickOnApplicationsNavLink();
        Thread.sleep(2000);
    }

    @When("Click on Farm Details NavLink Dropdown")
    public void AgentClickOnFarmDetailsNavlinkTab() throws InterruptedException {
        clientapplicationPage.AgentClickOnFarmDetailsNavLink();
        Thread.sleep(2000);
    }

    @When("Click on Correspondence NavLink Dropdown")
    public void AgentClickOnCorrespondenceNavlinkTab() throws InterruptedException {
        clientapplicationPage.AgentClickOnCorrespondenceNavLink();
        Thread.sleep(2000);
    }

    @Then("Check Visibility of Start 2022 BPS Amendment")
    public void AgentCheckVisibilityOfStartAmendment() throws InterruptedException {
        if(clientapplicationPage.VisibilityOfAgentStartAmendment()==false) {
            Assert.assertFalse(clientapplicationPage.VisibilityOfAgentStartAmendment(),"Start 2022 BPS Amendment option is present");
            System.out.println("Start 2022 BPS Amendment option is present");
        }
        else {
            Assert.assertTrue(clientapplicationPage.VisibilityOfAgentStartAmendment(),"Start 2022 BPS Amendment option is not present");
            System.out.println("Start 2022 BPS Amendment option is not present");
        }
    }

//    @Then("Check Visibility of Start 2022 BPS Application")
//    public void AgentCheckVisibilityOfStartApplication() throws InterruptedException {
//        Assert.assertTrue(clientapplicationPage.VisibilityOfAgentStartApplication());
//    }


    @And("Check Visibility of Transfer of Entitlements Applications")
    public void AgentCheckVisibilityOfTransferOfEntitlements() throws InterruptedException {
        if(clientapplicationPage.VisibilityOfAgentTransferOfEntitlementsApplications()==false) {
            Assert.assertFalse(clientapplicationPage.VisibilityOfAgentTransferOfEntitlementsApplications(),"Transfer of Entitlements Applications option is present");
            System.out.println("Transfer of Entitlements Applications option is present");
        }
        else {
            Assert.assertTrue(clientapplicationPage.VisibilityOfAgentTransferOfEntitlementsApplications(),"Transfer of Entitlements Applications option is not present");
            System.out.println("Transfer of Entitlements Applications option is not present");
        }
    }

    @And("Check Visibility of National Reserve and Young Farmer Scheme Application")
    public void AgentCheckVisibilityOfYoungFarmerScheme() throws InterruptedException {
        if(clientapplicationPage.VisibilityOfAgentNationalReserveAndYoungFarmerSchemeApplciation()==false) {
            Assert.assertFalse(clientapplicationPage.VisibilityOfAgentNationalReserveAndYoungFarmerSchemeApplciation(),"National Reserve and Young Farmer Scheme Application option is present");
            System.out.println("National Reserve and Young Farmer Scheme Application option is present");
        }
        else {
            Assert.assertTrue(clientapplicationPage.VisibilityOfAgentNationalReserveAndYoungFarmerSchemeApplciation(),"National Reserve and Young Farmer Scheme Application option is not present");
            System.out.println("National Reserve and Young Farmer Scheme Application option is not present");
        }
    }




    @Then("Check Visibility of Personal Details")
    public void AgentCheckVisibilityOfPersonalDetails() throws InterruptedException {
        if(clientapplicationPage.VisibilityOfPersonalDetails()==false) {
            Assert.assertFalse(clientapplicationPage.VisibilityOfPersonalDetails(),"Personal Details option is present");
            System.out.println("Personal Details option is present");
        }
        else {
            Assert.assertTrue(clientapplicationPage.VisibilityOfPersonalDetails(),"Personal Details option is not present");
            System.out.println("Personal Details option is not present");
        }
    }

    @And("Check Visibility of Entitlements Position 2022")
    public void AgentCheckVisibilityOfEntitlementsPosition2022() throws InterruptedException {
        System.out.println(clientapplicationPage.VisibilityOfEntitlementPosition2022());
        if(clientapplicationPage.VisibilityOfEntitlementPosition2022()==false) {
            Assert.assertFalse(clientapplicationPage.VisibilityOfEntitlementPosition2022(),"Entitlements Position 2022 option is present");
            System.out.println("Entitlements Position 2022 option is present");
        }
        else {
            Assert.assertTrue(clientapplicationPage.VisibilityOfEntitlementPosition2022(),"Entitlements Position 2022 option is not present");
            System.out.println("Entitlements Position 2022 option is not present");
        }
    }

    @And("Check Visibility of Entitlements Position 2021")
    public void AgentCheckVisibilityOfEntitlementsPosition2021() throws InterruptedException {
        if(clientapplicationPage.VisibilityOfEntitlementPosition2021()==false) {
            Assert.assertFalse(clientapplicationPage.VisibilityOfEntitlementPosition2021(),"Entitlements Position 2021 option is present");
            System.out.println("Entitlements Position 2021 option is present");
        }
        else {
            Assert.assertTrue(clientapplicationPage.VisibilityOfEntitlementPosition2021(),"Entitlements Position 2021 option is not present");
            System.out.println("Entitlements Position 2021 option is not present");
        }
    }

    @And("Check Visibility of Entitlements Position 2020")
    public void AgentCheckVisibilityOfEntitlementsPosition2020() throws InterruptedException {
        if(clientapplicationPage.VisibilityOfEntitlementPosition2020()==false) {
            Assert.assertFalse(clientapplicationPage.VisibilityOfEntitlementPosition2020(),"Entitlements Position 2020 option is present");
            System.out.println("Entitlements Position 2020 option is present");
        }
        else {
            Assert.assertTrue(clientapplicationPage.VisibilityOfEntitlementPosition2020(),"Entitlements Position 2020 option is not present");
            System.out.println("Entitlements Position 2020 option is not present");
        }
    }

    @And("Check Visibility of Entitlements Position 2015-2019")
    public void AgentCheckVisibilityOfEntitlementsPosition2015To2019() throws InterruptedException {
        if(clientapplicationPage.VisibilityOfEntitlementPosition2015To2019()==false) {
            Assert.assertFalse(clientapplicationPage.VisibilityOfEntitlementPosition2015To2019(),"Entitlements Position 2015-2019 option is present");
            System.out.println("Entitlements Position 2015-2019 option is present");
        }
        else {
            Assert.assertTrue(clientapplicationPage.VisibilityOfEntitlementPosition2015To2019(),"Entitlements Position 2015-2019 option is not present");
            System.out.println("Entitlements Position 2015-2019 option is not present");
        }
    }

    @And("Check Visibility of Usage Position")
    public void AgentCheckVisibilityOfUsagePosition() throws InterruptedException {
        if(clientapplicationPage.VisibilityOfUsagePosition()==false) {
            Assert.assertFalse(clientapplicationPage.VisibilityOfUsagePosition(),"Usage Position option is present");
            System.out.println("Usage Position option is present");
        }
        else {
            Assert.assertTrue(clientapplicationPage.VisibilityOfUsagePosition(),"Usage Position option is not present");
            System.out.println("Usage Position option is not present");
        }
    }

    @And("Check Visibility of Parcel Search")
    public void AgentCheckVisibilityOfParcelSearch() throws InterruptedException {
        if(clientapplicationPage.VisibilityOfParcelSearch()==false) {
            Assert.assertFalse(clientapplicationPage.VisibilityOfParcelSearch(),"Parcel Search option is present");
            System.out.println("Parcel Search option is present");
        }
        else {
            Assert.assertTrue(clientapplicationPage.VisibilityOfParcelSearch(),"Parcel Search option is not present");
            System.out.println("Parcel Search option is not present");
        }
    }

    @And("Check Visibility of View Nitrates")
    public void AgentCheckVisibilityOfViewNitrates() throws InterruptedException {
        if(clientapplicationPage.VisibilityOfViewNitrates()==false) {
            Assert.assertFalse(clientapplicationPage.VisibilityOfViewNitrates(),"View Nitrates option is present");
            System.out.println("View Nitrates option is present");
        }
        else {
            Assert.assertTrue(clientapplicationPage.VisibilityOfViewNitrates(),"View Nitrates option is not present");
            System.out.println("View Nitrates option is not present");
        }
    }

    @And("Check Visibility of Applications and Payments Summary")
    public void AgentCheckVisibilityOfApplicationsAndPaymentsSummary() throws InterruptedException {
        if(clientapplicationPage.VisibilityOfApplicationsAndPaymentsSummary()==false) {
            Assert.assertFalse(clientapplicationPage.VisibilityOfApplicationsAndPaymentsSummary(),"Applications and Payments Summary option is present");
            System.out.println("Applications and Payments Summary option is present");
        }
        else {
            Assert.assertTrue(clientapplicationPage.VisibilityOfApplicationsAndPaymentsSummary(),"Applications and Payments Summary option is not present");
            System.out.println("Applications and Payments Summary option is not present");
        }
    }




    @Then("Click on Personal Details Option")
    public void AgentClickOnPersonalDetails() throws InterruptedException {
        clientapplicationPage.AgentClickOnPersonalDetails();
    }

    @And("Click on Entitlements Position 2015-2019 Option")
    public void AgentClickOnEntitlementsPosition2015To2019() throws InterruptedException {
        clientapplicationPage.AgentClickOnEntitlementPosition2015To2019();
    }

    @And("Click on View Nitrates Option")
    public void AgentClickOnViewNitrates() throws InterruptedException {
        clientapplicationPage.AgentClickOnViewNitrates();
    }


    @Then("Click on Parcel Search Option")
    public void AgentClickOnParcelSearch() throws InterruptedException {
        clientapplicationPage.AgentClickOnParcelSearch();
    }

    @And("Agent Enters the Parcel Number {string}")
    public void AgentEnterClientFullName(String arg0) {
        clientapplicationPage.AgentEnterParcelNumber(arg0);
    }

    @Then("Click on Parcel Page Search Button")
    public void AgentClickOnParcelSearchButton() throws InterruptedException {
        clientapplicationPage.AgentClickOnParcelSearchButton();
    }

    @And("Click on the Applications and Payments Summary Page Land Details Tab")
    public void AgentClickOnApplicationAndPaymentsSummaryLandDetailsTab() throws InterruptedException {
        clientapplicationPage.AgentClickOnLandDetailsTab();
    }

    @And("Click on the View Map Button")
    public void AgentClickOnViewMapButton() throws InterruptedException {
        clientapplicationPage.AgentClickOnViewMapButton();
    }

    @Then("Click on My Correspondence")
    public void AgentClickOnMyCorrespondence() throws InterruptedException {
        clientapplicationPage.AgentClickOnMyCorrespondence();
    }


    @Then("Check Visibility of My Correspondence")
    public void AgentCheckVisibilityOfMyCorrespondence() throws InterruptedException {
        Assert.assertTrue(clientapplicationPage.VisibilityOfMyCorrespondence());
    }

    @And("Check Visibility of Upload Document")
    public void AgentCheckVisibilityOfUploadDocument() throws InterruptedException {
        Assert.assertTrue(clientapplicationPage.VisibilityOfUploadDocument());
    }

    @And("Check Visibility of Print Cover Letter")
    public void AgentCheckVisibilityOfPrintCoverLetter() throws InterruptedException {
//        Assert.assertTrue(clientapplicationPage.VisibilityOfPrintCoverLetter());
        if(clientapplicationPage.VisibilityOfPrintCoverLetter()==false) {
            Assert.assertFalse(clientapplicationPage.VisibilityOfPrintCoverLetter(),"Print Cover Letter option is present");
            System.out.println("Print Cover Letter option is present");
        }
        else {
            Assert.assertTrue(clientapplicationPage.VisibilityOfPrintCoverLetter(),"Print Cover Letter option is not present");
            System.out.println("Print Cover Letter option is not present");
        }
    }




    @And("Select Correspondence Year {int}")
    public void StaffSelectCorrespondenceSchemeYear(int arg0) {
        clientapplicationPage.AgentSelectCorrespondenceSchemeYear(arg0);
    }

    @And("Click on Get Correspondence Button")
    public void AgentClickOnGetCorrespondence() throws InterruptedException {
        clientapplicationPage.AgentClickOnGetCorrespondenceButton();
    }

    @And("Click on View Correspondence Button")
    public void AgentClickOnViewCorrespondence() throws InterruptedException {
        clientapplicationPage.AgentClickOnViewCorrespondenceButton();
    }

    @Then("Click on Upload Document")
    public void AgentClickOnUploadDocument() throws InterruptedException {
        clientapplicationPage.AgentClickOnUploadDocument();
    }

    @Then("Click on Print Cover Letter")
    public void AgentClickOnPrintCoverLetter() throws InterruptedException {
        clientapplicationPage.AgentClickOnPrintCoverLetter();
    }

//    @And("Agent Navigates to Outstanding Applications Tab")
//    public void AgentClickOnOutstandingApplicationsTab() throws InterruptedException {
//        bpsapplicationsPage.AgentClickOnOutstandingApplicationsTab();
//        Thread.sleep(2000);
//    }
//
//    @And("Agent Navigates to Draft Applications Tab")
//    public void AgentClickOnDraftApplicationsTab() throws InterruptedException {
//        bpsapplicationsPage.AgentClickOnDraftApplicationsTab();
//        Thread.sleep(2000);
//    }
//
//    @And("Agent Navigates to Paid Clients Tab")
//    public void AgentClickOnPaidClientsTab() throws InterruptedException {
//        bpsapplicationsPage.AgentClickOnPaidClientsTab();
//        Thread.sleep(2000);
//    }
//
//    @Then("Check if Print Preview Button is Visible")
//    public void AgentCheckPrintPreviewVisibility() throws InterruptedException {
//        bpsapplicationsPage.VisibilityOfPrintPreviewButton();
//    }
//
//    @Then("Agent Clicks on Print Preview Button")
//    public void AgentClicksOnPrintPreviewButton() throws InterruptedException {
//        bpsapplicationsPage.AgentClickOnPrintPreviewButton();
//    }
//
//    @And("Check if Download Button is Visible")
//    public void AgentCheckDownloadButtonVisibility() throws InterruptedException {
//        bpsapplicationsPage.VisibilityOfDownloadButton();
//        Assert.assertTrue(bpsapplicationsPage.VisibilityOfDownloadButton());
//    }
//
//    @Then("Agent Clicks on Download Button")
//    public void AgentClicksOnDownloadButton() throws InterruptedException {
//        bpsapplicationsPage.AgentClickOnDownloadButton();
//        Thread.sleep(5000);
//    }
//
//    @Then("Agent Clicks on Client Radio Button")
//    public void AgentClicksOnClientRadioButton() throws InterruptedException {
//        bpsapplicationsPage.AgentClickOnBPSApplicationsClientRadioButton();
//    }
//
//    @Then("Agent Clicks on View Button")
//    public void AgentClicksOnViewButton() throws InterruptedException {
//        bpsapplicationsPage.AgentClickOnBPSApplicationsViewButton();
//    }
//
//    @And("Check if No Clients are Displayed")
//    public void AgentCheckClientListVisibility() throws InterruptedException {
//        bpsapplicationsPage.CheckIfNoCLientsDisplayed();
//    }
//
//

}
