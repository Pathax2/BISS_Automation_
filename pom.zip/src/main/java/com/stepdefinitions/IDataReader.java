package com.stepdefinitions;

import java.util.List;
import java.util.Map;

public interface IDataReader {

    /**
     * To get all the rows from the excel
     * @return
     */
    public List<String> getAllRows();


    public List<String> getAllRowsSecondColumn();

    public List<String> getAllRowsFirstColumn();


    /**
     * To get a single row from the excel
     * @return
     */
    public Map<String, String> getASingleRow();
}
