// ===================================================================================================================================
// File          : SvgCharts.java
// Package       : reporting
// Description   : Small chart drawing helpers for the dashboard report. Each method returns plain inline SVG text -
//                 no JavaScript library, no CDN, so the report opens offline, from Jenkins and inside a PDF.
//
//                 Colours are CSS classes (s1..s5 series, sg grey, sc critical, q1..q6 sequential blue), defined
//                 twice in DashboardReport: once for the light theme and once for the dark theme. Switching the
//                 theme therefore recolours every chart without redrawing it.
//
//                 Mark rules (same as the mockups): thin bars, 4 px rounded data end, square end on the axis, a 2 px
//                 gap between stacked segments, values written next to bars, legends whenever there is more than
//                 one series.
//
// Author        : Aniket Pathare | aniket.pathare@government.ie
// Date Created  : 13-10-2026
// ===================================================================================================================================

package reporting;

import java.util.List;

final class SvgCharts
{
    private SvgCharts() { }

    // One labelled value
    static final class Bar
    {
        final String label;
        final double value;
        final String display;
        final String title;

        Bar(String pLabel, double pValue, String pDisplay, String pTitle)
        {
            label   = pLabel;
            value   = pValue;
            display = pDisplay;
            title   = pTitle;
        }
    }

    // One row of a stacked bar
    static final class Stack
    {
        final String   label;
        final double[] values;
        final String   total;

        Stack(String pLabel, double[] pValues, String pTotal)
        {
            label  = pLabel;
            values = pValues;
            total  = pTotal;
        }
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : hbars
    // Description   : Horizontal bar chart, one series. Bars start at the axis (square end) and have a 4 px rounded end.
    // Parameters    : pBars      - rows (label, value, text written after the bar, hover title)
    //                 pClass     - colour class, e.g. "s1"
    //                 pLabelW    - width kept for the labels on the left
    //                 pWidth     - total drawing width
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 13-10-2026
    // ***************************************************************************************************************************************************************************************
    static String hbars(List<Bar> pBars, String pClass, int pLabelW, int pWidth)
    {
        if (pBars.isEmpty()) return empty("Nothing recorded in this run");
        int    iBarH  = 16, iGap = 12;
        double iMax   = 0;
        for (Bar b : pBars) iMax = Math.max(iMax, b.value);
        if (iMax <= 0) iMax = 1;
        // room on the right for the longest value text (about 6.5 px per character at 12 px)
        int    iRight = 70;
        for (Bar b : pBars) iRight = Math.max(iRight, (int) (b.display.length() * 6.5) + 12);
        int    iPlotW = pWidth - pLabelW - iRight;
        int    iH     = pBars.size() * (iBarH + iGap) + 6;

        StringBuilder s = open(pWidth, iH);
        s.append(line(pLabelW, 0, pLabelW, iH - 4, "axis"));
        for (int i = 0; i < pBars.size(); i++)
        {
            Bar    b = pBars.get(i);
            double y = i * (iBarH + iGap) + 4;
            double w = iPlotW * b.value / iMax;
            s.append("<g><title>").append(esc(b.title)).append("</title>");
            s.append(text(pLabelW - 8, y + iBarH - 3, "end", "lab", fit(b.label, labelChars(b.label, pLabelW))));
            if (w > 0) s.append(roundRight(pLabelW, y, w, iBarH, 4, pClass));
            s.append(text(pLabelW + w + 6, y + iBarH - 3, "start", "val", esc(b.display)));
            s.append("</g>");
        }
        return s.append("</svg>").toString();
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : stackedHbars
    // Description   : Horizontal stacked bars (e.g. setup / scenarios / teardown per test case) with a legend.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 13-10-2026
    // ***************************************************************************************************************************************************************************************
    static String stackedHbars(List<Stack> pRows, String[] pNames, String[] pClasses, int pLabelW, int pWidth)
    {
        if (pRows.isEmpty()) return empty("Nothing recorded in this run");
        int    iBarH = 18, iGap = 14;
        double iMax  = 0;
        for (Stack r : pRows) { double t = 0; for (double v : r.values) t += v; iMax = Math.max(iMax, t); }
        if (iMax <= 0) iMax = 1;
        int iPlotW = pWidth - pLabelW - 80;
        int iH     = pRows.size() * (iBarH + iGap) + 6;

        StringBuilder s = new StringBuilder(legend(pNames, pClasses));
        s.append(open(pWidth, iH));
        s.append(line(pLabelW, 0, pLabelW, iH - 4, "axis"));
        for (int i = 0; i < pRows.size(); i++)
        {
            Stack  r = pRows.get(i);
            double y = i * (iBarH + iGap) + 4;
            double x = pLabelW;
            int    iLast = -1;
            for (int k = 0; k < r.values.length; k++) if (r.values[k] > 0) iLast = k;

            StringBuilder iTitle = new StringBuilder(r.label);
            for (int k = 0; k < r.values.length; k++) iTitle.append(" | ").append(pNames[k]).append(": ").append(Math.round(r.values[k]));
            s.append("<g><title>").append(esc(iTitle.toString())).append("</title>");
            s.append(text(pLabelW - 8, y + iBarH - 4, "end", "lab", fit(r.label, pLabelW / 7)));
            for (int k = 0; k < r.values.length; k++)
            {
                double w = iPlotW * r.values[k] / iMax;
                if (w <= 0) continue;
                double sw = Math.max(w - 2, 1);
                if (k == iLast) s.append(roundRight(x, y, sw, iBarH, 4, pClasses[k]));
                else            s.append(rect(x, y, sw, iBarH, pClasses[k]));
                x += w;
            }
            s.append(text(x + 6, y + iBarH - 4, "start", "val", esc(r.total)));
            s.append("</g>");
        }
        return s.append("</svg>").toString();
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : stackedColumns
    // Description   : Vertical stacked columns (e.g. failure causes per test case) with a legend and totals on top.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 13-10-2026
    // ***************************************************************************************************************************************************************************************
    static String stackedColumns(String[] pLabels, int[][] pSeries, String[] pNames, String[] pClasses, int pWidth, int pHeight)
    {
        if (pLabels.length == 0) return empty("No failures in this run");
        int left = 34, bottom = 30, top = 16;
        int pw = pWidth - left - 10, ph = pHeight - top - bottom;
        int[] totals = new int[pLabels.length];
        int   mx     = 1;
        for (int i = 0; i < pLabels.length; i++)
        {
            for (int[] ser : pSeries) totals[i] += ser[i];
            mx = Math.max(mx, totals[i]);
        }
        double bw = (double) pw / pLabels.length;

        StringBuilder s = new StringBuilder(legend(pNames, pClasses));
        s.append(open(pWidth, pHeight));
        for (int t : new int[]{0, (mx + 1) / 2, mx})
        {
            double y = top + ph - (double) ph * t / mx;
            s.append(line(left, y, left + pw, y, "grid"));
            s.append(text(left - 6, y + 4, "end", "tick", String.valueOf(t)));
        }
        for (int i = 0; i < pLabels.length; i++)
        {
            double x = left + i * bw + Math.min(10, bw * 0.15);
            double w = bw - 2 * Math.min(10, bw * 0.15);
            double y = top + ph;
            int iLast = -1;
            for (int k = 0; k < pSeries.length; k++) if (pSeries[k][i] > 0) iLast = k;
            StringBuilder iTitle = new StringBuilder(pLabels[i]);
            for (int k = 0; k < pSeries.length; k++) if (pSeries[k][i] > 0) iTitle.append(" | ").append(pNames[k]).append(": ").append(pSeries[k][i]);
            s.append("<g><title>").append(esc(iTitle.toString())).append("</title>");
            for (int k = 0; k < pSeries.length; k++)
            {
                int v = pSeries[k][i];
                if (v <= 0) continue;
                double h  = (double) ph * v / mx;
                double hh = Math.max(h - 2, 1);
                if (k == iLast) s.append(roundTop(x, y - hh, w, hh, 4, pClasses[k]));
                else            s.append(rect(x, y - hh, w, hh, pClasses[k]));
                y -= h;
            }
            if (totals[i] > 0) s.append(text(x + w / 2, y - 5, "middle", "val", String.valueOf(totals[i])));
            s.append(text(x + w / 2, pHeight - 10, "middle", "tick", fit(pLabels[i], (int) Math.max(4, bw / 6.5))));
            s.append("</g>");
        }
        return s.append("</svg>").toString();
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : flowMap
    // Description   : "Who transferred to whom": senders on the left, receivers on the right, a ribbon per pair whose
    //                 thickness is the number of transfers. Up to 4 senders get a series colour, the rest are grouped
    //                 grey as "Other".
    // Parameters    : pFrom / pTo / pCount - one entry per (sender, receiver) pair
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 13-10-2026
    // ***************************************************************************************************************************************************************************************
    static String flowMap(List<String> pFrom, List<String> pTo, List<Integer> pCount, int pWidth)
    {
        if (pFrom.isEmpty()) return empty("No transfer was submitted in this run");

        java.util.LinkedHashMap<String, Integer> iLeft  = new java.util.LinkedHashMap<>();
        java.util.LinkedHashMap<String, Integer> iRight = new java.util.LinkedHashMap<>();
        int iTotal = 0;
        for (int i = 0; i < pFrom.size(); i++)
        {
            iLeft.merge(pFrom.get(i), pCount.get(i), Integer::sum);
            iRight.merge(pTo.get(i), pCount.get(i), Integer::sum);
            iTotal += pCount.get(i);
        }
        String[] iClasses = {"s1", "s2", "s3", "s4"};
        java.util.Map<String, String> iColour = new java.util.HashMap<>();
        int k = 0;
        for (String n : iLeft.keySet()) iColour.put(n, k < 4 ? iClasses[k++] : "sg");

        int    iGapN  = 8, lx = Math.max(130, pWidth / 4), rx = pWidth - Math.max(150, pWidth / 4), nw = 12;
        int    iRows  = Math.max(iLeft.size(), iRight.size());
        int    iH     = Math.max(160, Math.min(360, 60 + iTotal * 6 + iRows * 18));
        double scale  = (double) (iH - 40 - iGapN * Math.max(iLeft.size(), iRight.size())) / Math.max(1, iTotal);

        java.util.Map<String, double[]> lpos = new java.util.HashMap<>();
        java.util.Map<String, double[]> rpos = new java.util.HashMap<>();
        double y = 4;
        for (java.util.Map.Entry<String, Integer> e : iLeft.entrySet())  { lpos.put(e.getKey(), new double[]{y, y}); y += e.getValue() * scale + iGapN; }
        y = 4;
        for (java.util.Map.Entry<String, Integer> e : iRight.entrySet()) { rpos.put(e.getKey(), new double[]{y, y}); y += e.getValue() * scale + iGapN; }

        StringBuilder s = open(pWidth, iH);
        double mx = (lx + nw + rx) / 2.0;
        for (int i = 0; i < pFrom.size(); i++)
        {
            double h  = pCount.get(i) * scale;
            double[] a = lpos.get(pFrom.get(i));
            double[] b = rpos.get(pTo.get(i));
            double y0 = a[1], y1 = b[1];
            a[1] += h; b[1] += h;
            s.append("<path class=\"ribbon ").append(iColour.get(pFrom.get(i))).append("\" d=\"M").append(f(lx + nw)).append(',').append(f(y0))
             .append(" C").append(f(mx)).append(',').append(f(y0)).append(' ').append(f(mx)).append(',').append(f(y1)).append(' ').append(f(rx)).append(',').append(f(y1))
             .append(" V").append(f(y1 + h)).append(" C").append(f(mx)).append(',').append(f(y1 + h)).append(' ').append(f(mx)).append(',').append(f(y0 + h))
             .append(' ').append(f(lx + nw)).append(',').append(f(y0 + h)).append(" Z\"><title>")
             .append(esc(pFrom.get(i) + " -> " + pTo.get(i) + ": " + pCount.get(i) + " transfer(s)")).append("</title></path>");
        }
        for (java.util.Map.Entry<String, Integer> e : iLeft.entrySet())
        {
            double[] p = lpos.get(e.getKey());
            double h = e.getValue() * scale;
            s.append("<rect x=\"").append(lx).append("\" y=\"").append(f(p[0])).append("\" width=\"").append(nw).append("\" height=\"").append(f(Math.max(h, 2)))
             .append("\" rx=\"3\" class=\"").append(iColour.get(e.getKey())).append("\"/>");
            s.append(text(lx - 8, p[0] + h / 2 - 2, "end", "lab", fit(e.getKey(), 22)));
            s.append(text(lx - 8, p[0] + h / 2 + 12, "end", "tick", e.getValue() + " sent"));
        }
        for (java.util.Map.Entry<String, Integer> e : iRight.entrySet())
        {
            double[] p = rpos.get(e.getKey());
            double h = e.getValue() * scale;
            s.append("<rect x=\"").append(rx).append("\" y=\"").append(f(p[0])).append("\" width=\"").append(nw).append("\" height=\"").append(f(Math.max(h, 2)))
             .append("\" rx=\"3\" class=\"node\"/>");
            s.append(text(rx + nw + 8, p[0] + h / 2 - 2, "start", "lab", fit(e.getKey(), 22)));
            s.append(text(rx + nw + 8, p[0] + h / 2 + 12, "start", "tick", e.getValue() + " received"));
        }
        s.append(text(lx + nw / 2.0, iH - 4, "middle", "axisTitle", "CREATED BY"));
        s.append(text(rx + nw / 2.0, iH - 4, "middle", "axisTitle", "ACCEPTED BY"));
        return s.append("</svg>").toString();
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : heatMatrix
    // Description   : Grid of counts (rows x columns) in one blue ramp - darker = more. Empty cells show a dot.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 13-10-2026
    // ***************************************************************************************************************************************************************************************
    static String heatMatrix(List<String> pRows, List<String> pCols, int[][] pValues, String pColTitle)
    {
        if (pRows.isEmpty() || pCols.isEmpty()) return empty("No transfer was submitted in this run");
        int cell = 64, lw = 140, top = 50;
        int mx = 1;
        for (int[] r : pValues) for (int v : r) mx = Math.max(mx, v);
        int w = lw + cell * pCols.size() + 10, h = top + cell * pRows.size() + 10;

        StringBuilder s = open(w, h);
        s.append(text(lw + cell * pCols.size() / 2.0, 12, "middle", "axisTitle", pColTitle));
        for (int j = 0; j < pCols.size(); j++) s.append(text(lw + j * cell + cell / 2.0, top - 10, "middle", "lab", fit(pCols.get(j), 9)));
        for (int i = 0; i < pRows.size(); i++)
        {
            s.append(text(lw - 10, top + i * cell + cell / 2.0 + 4, "end", "lab", fit(pRows.get(i), 18)));
            for (int j = 0; j < pCols.size(); j++)
            {
                int v = pValues[i][j];
                double x = lw + j * cell, y = top + i * cell;
                s.append("<g><title>").append(esc(pRows.get(i) + " -> " + pCols.get(j) + ": " + v)).append("</title>");
                if (v == 0)
                {
                    s.append("<rect x=\"").append(f(x + 1)).append("\" y=\"").append(f(y + 1)).append("\" width=\"").append(cell - 2).append("\" height=\"").append(cell - 2)
                     .append("\" rx=\"4\" class=\"cell0\"/>");
                    s.append(text(x + cell / 2.0, y + cell / 2.0 + 4, "middle", "tick", "&#183;"));
                }
                else
                {
                    int q = Math.max(1, Math.min(6, (int) Math.round(6.0 * v / mx)));
                    s.append("<rect x=\"").append(f(x + 1)).append("\" y=\"").append(f(y + 1)).append("\" width=\"").append(cell - 2).append("\" height=\"").append(cell - 2)
                     .append("\" rx=\"4\" class=\"q").append(q).append("\"/>");
                    s.append(text(x + cell / 2.0, y + cell / 2.0 + 5, "middle", q >= 4 ? "cellTxtOn" : "cellTxt", String.valueOf(v)));
                }
                s.append("</g>");
            }
        }
        return s.append("</svg>").toString();
    }

    // Sequential legend for heatMatrix
    static String rampLegend(int pMax)
    {
        StringBuilder s = new StringBuilder("<div class=\"legend\"><span>1</span><span class=\"ramp\">");
        for (int q = 1; q <= 6; q++) s.append("<i class=\"q").append(q).append("\"></i>");
        return s.append("</span><span>").append(pMax).append("</span></div>").toString();
    }

    // Thin inline bar for table cells (0..100)
    static String meter(double pPercent, String pClass)
    {
        double w = Math.max(0, Math.min(100, pPercent)) * 0.9;
        return "<svg class=\"meter\" width=\"94\" height=\"12\" viewBox=\"0 0 94 12\"><rect x=\"0\" y=\"5\" width=\"90\" height=\"2\" class=\"grid\"/>"
                + (w > 0 ? roundRight(0, 1, Math.max(w, 2), 10, 3, pClass) : "") + "</svg>";
    }


    // ===============================================================================================================================
    //  PRIMITIVES
    // ===============================================================================================================================

    static String legend(String[] pNames, String[] pClasses)
    {
        if (pNames.length < 2) return "";
        StringBuilder s = new StringBuilder("<div class=\"legend\">");
        for (int i = 0; i < pNames.length; i++)
        {
            s.append("<span><i class=\"").append(pClasses[i]).append("\"></i>").append(esc(pNames[i])).append("</span>");
        }
        return s.append("</div>").toString();
    }

    private static StringBuilder open(int pW, int pH)
    {
        return new StringBuilder("<svg class=\"chart\" viewBox=\"0 0 ").append(pW).append(' ').append(pH)
                .append("\" width=\"").append(pW).append("\" height=\"").append(pH).append("\" role=\"img\">");
    }

    private static String empty(String pText)
    {
        return "<p class=\"empty\">" + esc(pText) + "</p>";
    }

    private static String roundRight(double x, double y, double w, double h, double r, String pClass)
    {
        r = Math.min(r, Math.min(w / 2, h / 2));
        return "<path class=\"" + pClass + "\" d=\"M" + f(x) + "," + f(y) + " H" + f(x + w - r) + " Q" + f(x + w) + "," + f(y) + " " + f(x + w) + "," + f(y + r)
                + " V" + f(y + h - r) + " Q" + f(x + w) + "," + f(y + h) + " " + f(x + w - r) + "," + f(y + h) + " H" + f(x) + " Z\"/>";
    }

    private static String roundTop(double x, double y, double w, double h, double r, String pClass)
    {
        r = Math.min(r, Math.min(w / 2, h));
        return "<path class=\"" + pClass + "\" d=\"M" + f(x) + "," + f(y + h) + " V" + f(y + r) + " Q" + f(x) + "," + f(y) + " " + f(x + r) + "," + f(y)
                + " H" + f(x + w - r) + " Q" + f(x + w) + "," + f(y) + " " + f(x + w) + "," + f(y + r) + " V" + f(y + h) + " Z\"/>";
    }

    private static String rect(double x, double y, double w, double h, String pClass)
    {
        return "<rect class=\"" + pClass + "\" x=\"" + f(x) + "\" y=\"" + f(y) + "\" width=\"" + f(w) + "\" height=\"" + f(h) + "\"/>";
    }

    private static String line(double x1, double y1, double x2, double y2, String pClass)
    {
        return "<line class=\"" + pClass + "\" x1=\"" + f(x1) + "\" y1=\"" + f(y1) + "\" x2=\"" + f(x2) + "\" y2=\"" + f(y2) + "\"/>";
    }

    private static String text(double x, double y, String pAnchor, String pClass, String pText)
    {
        return "<text x=\"" + f(x) + "\" y=\"" + f(y) + "\" text-anchor=\"" + pAnchor + "\" class=\"" + pClass + "\">" + pText + "</text>";
    }

    // Escaped label, cut to pMax characters (the full text stays in the hover title)
    // How many characters fit in pWidth px: upper-case text is wider (about 8 px) than mixed case (about 6.5 px)
    private static int labelChars(String pText, int pWidth)
    {
        String t = pText == null ? "" : pText;
        int upper = 0;
        for (char c : t.toCharArray()) if (Character.isUpperCase(c) || Character.isDigit(c)) upper++;
        double px = t.isEmpty() || upper < t.length() / 2 ? 6.8 : 8.2;
        return (int) ((pWidth - 10) / px);
    }

    private static String fit(String pText, int pMax)
    {
        String t = pText == null ? "" : pText;
        if (t.length() > pMax && pMax > 3) t = t.substring(0, pMax - 1) + "…";
        return esc(t);
    }

    private static String f(double v)
    {
        return String.format(java.util.Locale.ROOT, "%.1f", v);
    }

    static String esc(String pText)
    {
        if (pText == null) return "";
        return pText.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
}
