// ===================================================================================================================================
// File          : TC_11_ENTS.java
// Package       : stepdefinitions.ENTS
// Description   : ETF Partner-as-TRANSFEROR with MANUAL entitlements (TC_11_ENTS).
//
//                 Steps in this file (3):
//                   1. the ETF partner logs in as transferor {string}                        (Background + each section)
//                   2. the ETF partner creates a transfer with manual entitlements (DataTable)
//                   3. the ETF partner logs back in as transferor                            (not used by a feature today)
//
//                 KEY DIFFERENCE from the standard transfer: the entitlement is typed in by hand
//                 (Add Manual Entitlement -> Entitlement Type -> amount -> Net UV) instead of picking a row, and the
//                 transferee search also takes an address.
//
//                 Playwright edition (30-09-2026, from the Selenium file):
//                   - Same step texts, same ObjectRepository keys, same flow.
//                   - The copied Keycloak login block and the local isVisible are replaced by EntsSession.loginAs; an
//                     expired account fails the step with the login in the message.
//                   - Step 2 opens the transferor herd with EntsSession.openTransferOutHerd (waits for the row of THAT
//                     herd, skips rows marked expired) instead of clicking the first View link after Search.
//                   - Step 2 checks the four manual-entitlement Object Repository keys BEFORE the first click and names
//                     every missing one. They are not in the Playwright repository yet (30-09-2026) - see the
//                     ObjectRepository paste block that came with this file.
//                   - Lease year: kept as in Selenium - the lease year is picked whenever the Lease Year dropdown appears
//                     (the Selenium code ignored the leaseYear row). leaseYear=Yes now also waits for it.
//                   - Step 3 logs out first when a session is still open; the Selenium version typed into a login page
//                     that was not on screen, and used iExitBISSLink / iLogoutBtn, which are not in the repository.
//                   - Thread.sleep calls removed; the waits come from iAction and EntsSession.
//
//                 Runtime data (utilities.EntsTestData): a "transfereeAgent | aga6581" row picks the transferee from that
//                 agent's Agent Login pool, and {transferee.herd} / {transferee.name} / {transferee.address} fill the
//                 search. The transferor is picked from the logged-in partner's pool when transferorHerd is
//                 {transferor.herd}, or kept as typed when it is a herd number (EntsTestData.nextTransfereeForFixedTransferor)
//                 - the Selenium version used the partner's own herd C2057024 for every section.
//                 02-10-2026: a "transfereeType | Individual" row (TC_12_ENTS, ETF partner to individual) takes the
//                 transferee from the Individual Login query instead; {transferee.login} is then that individual's own
//                 login. Used by TC_11, TC_12 and TC_20.
//
// Author        : Aniket Pathare | aniket.pathare@government.ie
// Date Created  : 31-03-2026 | Updated: 02-10-2026 (individual transferee, TC_12_ENTS)
// ===================================================================================================================================

package stepdefinitions.ENTS;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;
import utilities.EntsTestData;
import utilities.ObjReader;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import static commonFunctions.CommonFunctions.iAction;
import static stepdefinitions.ENTS.EntsSession.PROBE_SECONDS;
import static stepdefinitions.ENTS.EntsSession.isVisible;
import static stepdefinitions.ENTS.EntsSession.pause;

public class TC_11_ENTS
{
    private static final Logger log = Logger.getLogger(TC_11_ENTS.class.getName());

    // The ETF partner of the last "logs in as transferor" step - used by "logs back in as transferor"
    private static String iPartnerUsername = "";

    // Object Repository keys the manual-entitlement flow needs on top of the standard transfer keys
    private static final String[] MANUAL_ENTITLEMENT_KEYS = {
            "iTransfereeAddressField", "iTransferAddManualEntitlementBtn",
            "iTransferEntitlementTypeDropdown", "iTransferNetUVField" };


    // ===================================================================================================================================
    //  ETF PARTNER LOGIN
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the ETF partner logs in as transferor {string}
    // Description   : Keycloak login as the ETF partner (username, password TD:Password, PIN or OTP, TOTP, T&C).
    //                 When a session is still open (no username box on screen) loginAs opens the base URL first.
    // Parameters    : pPartnerUsername (String) - ETF partner login, e.g. "agr15512"
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 30-09-2026 (Playwright, shared login)
    // ***************************************************************************************************************************************************************************************
    @Given("the ETF partner logs in as transferor {string}")
    public void theETFPartnerLogsInAsTransferor(String pPartnerUsername)
    {
        String iUsername = EntsTestData.resolve(pPartnerUsername);
        log.info("[STEP] Given the ETF partner logs in as transferor: " + iUsername);

        iPartnerUsername = iUsername;
        EntsSession.loginAs(iUsername, "[LOGIN-ETF-TRANSFEROR]");
    }


    // ===================================================================================================================================
    //  ETF PARTNER CREATES THE TRANSFER (manual entitlements)
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the ETF partner creates a transfer with manual entitlements (DataTable)
    // Description   : 1. Searches the transferor herd and opens its first not-expired row
    //                 2. Create Transfer Application
    //                 3. Searches the transferee by herd, name and (optional) address; selects the open row on a multi-match
    //                 4. Picks the transfer type, Next
    //                 5. Add Manual Entitlement: entitlement type, amount, Net UV, lease year when shown, Add, Next
    //                 6. Types the notes
    //
    //                 DataTable keys:
    //                   transferorHerd    (String) - ETF partner's herd, e.g. "C2057024", or {transferor.herd}
    //                   transfereeHerd    (String) - transferee herd number, or {transferee.herd}
    //                   transfereeName    (String) - transferee name as shown in the portal, or {transferee.name}
    //                   transfereeAddress (String) - OPTIONAL. First address line, or {transferee.address}
    //                   transfereeAgent   (String) - OPTIONAL. Agent who manages the transferee (needed with tokens)
    //                   transfereeType    (String) - OPTIONAL. "Individual" = the transferee is an individual with their
    //                                                own login (TC_12_ENTS); then no transfereeAgent row is needed
    //                   transferType      (String) - transfer type text, e.g. "Gift of Entitlements"
    //                   entitlements      (String) - amount, e.g. "0.01"
    //                   entitlementType   (String) - OPTIONAL, default "BISS"
    //                   netUV             (String) - OPTIONAL, default "1"
    //                   leaseYear         (String) - OPTIONAL. "Yes" for a Lease
    //                   notes             (String) - notes for the transfer summary
    //
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 02-10-2026 (individual transferee, TC_12_ENTS)
    // ***************************************************************************************************************************************************************************************
    @When("the ETF partner creates a transfer with manual entitlements")
    public void theETFPartnerCreatesATransferWithManualEntitlements(DataTable pDataTable)
    {
        log.info("[STEP] When the ETF partner creates a transfer with manual entitlements");

        requireRepositoryKeys();

        Map<String, String> iRaw = pDataTable.asMap(String.class, String.class);

        // Runtime pair: transferor from the partner's pool, or pinned; transferee from the named agent's pool, or
        // (TC_12_ENTS, "transfereeType | Individual") an individual with their own login
        if (EntsTestData.tableHasToken(iRaw))
        {
            String  iPurpose         = iRaw.getOrDefault("transferType", "").trim();
            String  iTransfereeAgent = iRaw.getOrDefault("transfereeAgent", "").trim();
            String  iTransferorCell  = iRaw.getOrDefault("transferorHerd", "").trim();
            boolean iToIndividual    = "Individual".equalsIgnoreCase(iRaw.getOrDefault("transfereeType", "").trim());

            if (iToIndividual)
            {
                if (EntsTestData.hasToken(iTransferorCell)) EntsTestData.nextAgentToIndividualPair(EntsTestData.loggedInUser(), iPurpose);
                else                                         EntsTestData.nextIndividualTransfereeForFixedTransferor(iTransferorCell, iPurpose);
            }
            else if (EntsTestData.hasToken(iTransferorCell))
            {
                EntsTestData.nextCrossAgentPair(EntsTestData.loggedInUser(), iTransfereeAgent, iPurpose);
            }
            else
            {
                EntsTestData.nextTransfereeForFixedTransferor(iTransferorCell, iTransfereeAgent, iPurpose);
            }
        }

        Map<String, String> iData = EntsTestData.resolveTable(iRaw);

        String  iTransferorHerd = iData.get("transferorHerd").trim();
        String  iTransfereeHerd = iData.get("transfereeHerd").trim();
        String  iTransfereeName = iData.get("transfereeName").trim();
        String  iTransferType   = iData.get("transferType").trim();
        String  iEntitlements   = iData.get("entitlements").trim();
        String  iEntType        = iData.getOrDefault("entitlementType", "BISS").trim();
        String  iNetUV          = iData.getOrDefault("netUV", "1").trim();
        String  iNotes          = iData.get("notes").trim();
        String  iAddress        = iData.getOrDefault("transfereeAddress", "").trim();
        boolean iHasLeaseYear   = "Yes".equalsIgnoreCase(iData.getOrDefault("leaseYear", "").trim());

        // -- 1. Transferor herd: wait for ITS row, skip expired rows, click View ---------------------------------------
        EntsSession.openTransferOutHerd(iTransferorHerd);
        log.info("Transferor herd opened: " + iTransferorHerd);

        // -- 2. Create Transfer Application ---------------------------------------------------------------------------
        iAction("CLICK", "XPATH", ObjReader.getLocator("iCreateTransferBtn"), null);

        // -- 3. Transferee search (the address field is unique to ETF transfers) ---------------------------------------
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iTransferTypeSearchBtn"), null);
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iTransfereeHerdField"), iTransfereeHerd);
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iTransfereeNameField"), iTransfereeName);
        if (!iAddress.isEmpty())
        {
            iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iTransfereeAddressField"), iAddress);
        }
        iAction("CLICK", "XPATH", ObjReader.getLocator("iTransferDialogSearchBtn"), null);
        log.info("Transferee searched: " + iTransfereeName + " (" + iTransfereeHerd + ")"
                + (iAddress.isEmpty() ? "" : " | address: " + iAddress));
        EntsSession.selectOpenTransfereeMatch(iTransfereeHerd);

        // -- 4. Transfer type, Next (same helper as TC_01_ENTS) -------------------------------------------------------
        TC_01_ENTS.selectTransferType(iTransferType);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iTransferNextBtn"), null);

        // -- 5. MANUAL entitlement --------------------------------------------------------------------------------------
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iTransferAddManualEntitlementBtn"), null);
        iAction("LIST",    "XPATH", ObjReader.getLocator("iTransferEntitlementTypeDropdown"), iEntType);
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iTransferEntitlementAmountField"), iEntitlements);
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iTransferNetUVField"), iNetUV);

        // Selenium picked the lease year whenever the dropdown appeared (3 s check) - kept; leaseYear=Yes waits for it
        String iLeaseDropdown = ObjReader.getLocator("iTransferLeaseYearDropdown");
        if (iHasLeaseYear || isVisible(iLeaseDropdown, PROBE_SECONDS))
        {
            iAction("CLICK", "XPATH", iLeaseDropdown, null);
            iAction("CLICK", "XPATH", ObjReader.getLocator("iTransferLeaseYearFirstOption"), null);
            log.info("Lease year selected.");
        }

        iAction("CLICK", "XPATH", ObjReader.getLocator("iTransferDialogAddBtn"), null);
        pause(1500);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iTransferNextBtn"), null);

        // -- 6. Notes ---------------------------------------------------------------------------------------------------
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iTransferNotesField"), iNotes);

        log.info("ETF manual transfer created | Type=" + iTransferType + " | Transferor=" + iTransferorHerd
                + " -> Transferee=" + iTransfereeHerd + " | Entitlements=" + iEntitlements + " " + iEntType + " | NetUV=" + iNetUV);
    }


    // ***************************************************************************************************************************************************************************************
    // Step          : the ETF partner logs back in as transferor
    // Description   : Logs in again as the ETF partner of the last "logs in as transferor" step. Logs out first when a
    //                 session is still open (the Keycloak username box is not on screen). The BISS URL opens BISS
    //                 directly, so no application search is needed after the login.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 30-09-2026 (Playwright, shared login)
    // ***************************************************************************************************************************************************************************************
    @When("the ETF partner logs back in as transferor")
    public void theETFPartnerLogsBackInAsTransferor()
    {
        log.info("[STEP] When the ETF partner logs back in as transferor: " + iPartnerUsername);

        if (iPartnerUsername.isBlank())
        {
            throw new IllegalStateException("[LOGIN-ETF-TRANSFEROR] No ETF partner is known yet - the step "
                    + "'the ETF partner logs in as transferor' must run earlier in the scenario.");
        }

        if (!isVisible(ObjReader.getLocator("iUsernametxtbox"), PROBE_SECONDS))
        {
            EntsSession.logout();
        }

        EntsSession.loginAs(iPartnerUsername, "[LOGIN-ETF-TRANSFEROR]");
    }


    // ===================================================================================================================================
    //  HELPERS
    // ===================================================================================================================================

    // Fails BEFORE the first click when a manual-entitlement key is missing from the Object Repository, naming all of them
    private static void requireRepositoryKeys()
    {
        List<String> iMissing = new ArrayList<>();
        for (String iKey : MANUAL_ENTITLEMENT_KEYS)
        {
            if (!ObjReader.containsKey(iKey)) iMissing.add(iKey);
        }
        if (!iMissing.isEmpty())
        {
            throw new IllegalStateException("[OR] 'the ETF partner creates a transfer with manual entitlements' needs these Object "
                    + "Repository keys, which are not in ObjectRepository.properties: " + String.join(", ", iMissing)
                    + ". Add them (see the TC_11_ENTS notes) before running this test case.");
        }
    }
}