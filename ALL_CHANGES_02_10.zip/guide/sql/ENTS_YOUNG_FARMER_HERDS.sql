-- ENTS Young Farmer herds - herds managed by an agent that have NO NR/CISYF application yet (iap_group_code = 4)
-- Source: Simon's "for Young Farmer" query (shared 02-10-2026). Run on CENTEST_ENTS_DATA.
--
-- This is the version the framework runs (DBRouter case "ENTS YOUNG FARMER HERDS"). Three changes from the original:
--   1. LOGIN_ID comes from a CURRENT agent link (end date 31-DEC-9999) instead of the last 7 characters after the
--      last 'aga' in herd_agt - that could be an ended link, and a login of another length was cut.
--   2. NOT IN became NOT EXISTS - one NULL iap_from_herd in tden_inet_application makes NOT IN return nothing.
--   3. Random order and a row limit. Simon's fixed herd list is the commented-out line.
--
-- Expected: D1461126, D195C519 and W1750439 appear when the herd list line is enabled and they still have no application.

SELECT herd_id, login_id FROM (
  SELECT herd_id, login_id FROM (
    SELECT DISTINCT ve.herd_id herd_id,
           LOWER(REGEXP_SUBSTR(UPPER(ve.herd_agt), '31-DEC-9999 (AGA[^, ]*)', 1, 1, NULL, 1)) login_id
    FROM vwco_ents_herd_abls_rpt ve
    WHERE ve.herd_agt IS NOT NULL
    AND   UPPER(ve.herd_agt) LIKE '%31-DEC-9999 AGA%'
    AND   NOT EXISTS (SELECT 1 FROM tden_inet_application a
                      WHERE a.iap_from_herd  = ve.herd_id
                      AND   a.iap_group_code = 4)
    -- AND   ve.herd_id IN ('D1461126','D195C519','W1750439')
  )
  WHERE login_id IS NOT NULL
  ORDER BY DBMS_RANDOM.VALUE
)
WHERE ROWNUM <= 200;


-- Simon's original, for comparison (remove the herd_id line to see other cases):
--
-- SELECT ve.herd_id Herd_ID,
-- SUBSTR(ve.herd_agt, INSTR(ve.herd_agt, 'aga', -1, 1), 7) Login_ID
-- FROM vwco_ents_herd_abls_rpt ve
-- WHERE 1=1
-- AND ve.herd_agt IS NOT NULL
-- AND UPPER(ve.herd_agt) LIKE '%AGA%'
-- AND ve.herd_id NOT IN (
--    SELECT iap_from_herd
--    FROM tden_inet_application
--    WHERE iap_group_code = 4)
-- AND herd_id in ('D1461126','D195C519','W1750439');
