// ===================================================================================================================================
// File          : PdfExporter.java
// Package       : reporting
// Description   : Saves a finished HTML report as a PDF with the Playwright browser the framework already uses - no new
//                 library and no internet access. The page is opened from disk in a headless browser, switched to the
//                 light theme, every collapsed section is opened, and Chromium prints it (A4 landscape, every tab on
//                 its own page - the print styles of ReportAssets).
//
//                 Uses browser.channel like PlaywrightFactory (e.g. "chrome" = the installed Chrome, no download).
//                 PDF printing only works in Chromium-based browsers; with browser.channel=msedge it uses Edge.
//                 A failure is logged and never fails the run - the HTML report is already written.
//
//                 Settings: report.pdf.scale (default 0.72) - shrink so the 1680 px wide page fits A4 landscape.
//
// Author        : Aniket Pathare | aniket.pathare@government.ie
// Date Created  : 13-10-2026
// ===================================================================================================================================

package reporting;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.options.Margin;
import utilities.ConfigManager;

import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

final class PdfExporter
{
    private static final Logger log = Logger.getLogger(PdfExporter.class.getName());

    private PdfExporter() { }

    // ***************************************************************************************************************************************************************************************
    // Function Name : export
    // Description   : Opens pHtml in a headless browser and saves it as pPdf.
    // Parameters    : pHtml (Path) - finished HTML report | pPdf (Path) - PDF to write
    // Returns       : boolean - true when the PDF was written
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 13-10-2026
    // ***************************************************************************************************************************************************************************************
    static boolean export(Path pHtml, Path pPdf)
    {
        long   iStart   = System.currentTimeMillis();
        String iChannel = ConfigManager.getOrDefault("browser.channel", "").trim();

        // Same rule as PlaywrightFactory: an installed browser channel means Playwright must not try to download one
        Map<String, String> iEnv = new HashMap<>(System.getenv());
        if (!iChannel.isEmpty() || ConfigManager.getBool("playwright.skip.browser.download", false))
        {
            iEnv.put("PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD", "1");
        }

        try (Playwright iPlaywright = Playwright.create(new Playwright.CreateOptions().setEnv(iEnv)))
        {
            BrowserType.LaunchOptions iLaunch = new BrowserType.LaunchOptions().setHeadless(true);
            if (!iChannel.isEmpty()) iLaunch.setChannel(iChannel);

            try (Browser iBrowser = iPlaywright.chromium().launch(iLaunch))
            {
                Page iPage = iBrowser.newPage(new Browser.NewPageOptions().setViewportSize(1680, 1200));
                iPage.navigate(pHtml.toAbsolutePath().toUri().toString());
                iPage.evaluate("() => { document.documentElement.setAttribute('data-theme', 'light');"
                        + " document.querySelectorAll('details').forEach(d => d.open = true); }");

                double iScale = Math.max(0.3, Math.min(1.0, Double.parseDouble(ConfigManager.getOrDefault("report.pdf.scale", "0.72"))));
                iPage.pdf(new Page.PdfOptions()
                        .setPath(pPdf)
                        .setFormat("A4")
                        .setLandscape(true)
                        .setPrintBackground(true)
                        .setScale(iScale)
                        .setMargin(new Margin().setTop("10mm").setBottom("10mm").setLeft("8mm").setRight("8mm")));
            }
            log.info("[PdfExporter] PDF written : " + pPdf + " (" + (System.currentTimeMillis() - iStart) + " ms)");
            return true;
        }
        catch (Exception e)
        {
            log.warning("[PdfExporter] PDF not written for " + pHtml.getFileName() + " : " + e.getMessage()
                    + " | The HTML report is fine. PDF printing needs a Chromium-based browser: set browser.channel=chrome"
                    + " (installed Chrome) or report.pdf.enabled=false to skip it.");
            return false;
        }
    }
}
