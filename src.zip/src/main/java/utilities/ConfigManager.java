// ===================================================================================================================================
// File          : ConfigManager.java
// Package       : utilities
// Description   : Centralised configuration manager for the BISS automation framework.
//                 Loads a base application.properties file and overlays an environment-specific
//                 profile file (application-dev.properties, application-docker.properties, etc.).
//
// Profile resolution order (highest wins):
//   1. JVM -D system properties                 (-Dexplicit.wait.seconds=40)
//   2. OS environment variables with BISS_ prefix (BISS_EXPLICIT_WAIT_SECONDS=40)   <- NEW for Docker
//   3. application-<env>.properties
//   4. application.properties (base defaults)
//
// Environment variable naming rule : prefix BISS_, upper-case, dots and dashes become underscores
//   explicit.wait.seconds  ->  BISS_EXPLICIT_WAIT_SECONDS
//   app.url                ->  BISS_APP_URL
//
// Active profile : -Denv=<profile>  or  BISS_ENV=<profile>  (default "dev")
// Config folder  : -Dconfig.path=<folder> or BISS_CONFIG_PATH (default src/test/resources/config/)
//
// Author        : Aniket Pathare | aniket.pathare@goverment.ie
// Date Created  : 10-03-2026
// Updated       : 15-09-2026 - Environment variable layer and configurable folder for container execution
// ===================================================================================================================================

package utilities;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Locale;
import java.util.Properties;
import java.util.logging.Logger;

public class ConfigManager
{
    private static final Logger log = Logger.getLogger(ConfigManager.class.getName());

    private static final String iEnvPrefix = "BISS_";

    private static final String iConfigBasePath = resolveBootstrapValue("config.path", "src/test/resources/config/");
    private static final String iBaseFileName   = "application.properties";

    private static final Properties iProperties = new Properties();

    private static final String iActiveProfile = resolveBootstrapValue("env", "dev").trim().toLowerCase(Locale.ROOT);

    static
    {
        loadBaseProperties();
        loadProfileProperties();
        log.info("[ConfigManager] Loaded | Profile='" + iActiveProfile + "' | Folder='" + iConfigBasePath
                + "' | Total keys=" + iProperties.size());
    }

    private ConfigManager() {}

    // ***************************************************************************************************************************************************************************************
    // Function Name : toEnvName
    // Description   : Converts a property key into its BISS_ environment variable name.
    // Parameters    : pKey (String) - property key e.g. explicit.wait.seconds
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Created  : 15-09-2026
    // ***************************************************************************************************************************************************************************************
    public static String toEnvName(String pKey)
    {
        return iEnvPrefix + pKey.trim().toUpperCase(Locale.ROOT).replace('.', '_').replace('-', '_');
    }

    private static String resolveBootstrapValue(String pKey, String pDefault)
    {
        String iValue = System.getProperty(pKey);
        if (iValue != null && !iValue.trim().isEmpty()) { return iValue.trim(); }

        iValue = System.getenv(toEnvName(pKey));
        if (iValue != null && !iValue.trim().isEmpty()) { return iValue.trim(); }

        return pDefault;
    }

    private static void loadBaseProperties()
    {
        String iPath = iConfigBasePath + iBaseFileName;

        try (InputStream iStream = new FileInputStream(iPath))
        {
            iProperties.load(iStream);
            log.info("[ConfigManager] Base config loaded from : " + iPath);
        }
        catch (Exception iException)
        {
            throw new RuntimeException("[ConfigManager] Failed to load base config from : '"
                    + iPath + "' | Reason : " + iException.getMessage(), iException);
        }
    }

    private static void loadProfileProperties()
    {
        String iPath = iConfigBasePath + "application-" + iActiveProfile + ".properties";

        try (InputStream iStream = new FileInputStream(iPath))
        {
            Properties iProfileProps = new Properties();
            iProfileProps.load(iStream);
            iProperties.putAll(iProfileProps);
            log.info("[ConfigManager] Profile config loaded from : " + iPath + " | Keys overridden=" + iProfileProps.size());
        }
        catch (Exception iException)
        {
            log.warning("[ConfigManager] Profile config not found for env='" + iActiveProfile
                    + "'. Using base defaults only. Path attempted: " + iPath);
        }
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : get
    // Description   : Returns a String config value. -D system property wins, then BISS_ environment variable,
    //                 then the profile file, then the base file.
    // Parameters    : pKey (String) - property key
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Created  : 10-03-2026 | Updated: 15-09-2026 (environment variable layer)
    // ***************************************************************************************************************************************************************************************
    public static String get(String pKey)
    {
        if (pKey == null || pKey.trim().isEmpty())
        {
            throw new RuntimeException("[ConfigManager] Key cannot be null or blank.");
        }

        String iJvmValue = System.getProperty(pKey.trim());
        if (iJvmValue != null && !iJvmValue.trim().isEmpty())
        {
            return iJvmValue.trim();
        }

        String iEnvValue = System.getenv(toEnvName(pKey));
        if (iEnvValue != null && !iEnvValue.trim().isEmpty())
        {
            return iEnvValue.trim();
        }

        String iValue = iProperties.getProperty(pKey.trim());

        if (iValue == null || iValue.trim().isEmpty())
        {
            throw new RuntimeException("[ConfigManager] Key not found in config : '" + pKey
                    + "' | Active profile : '" + iActiveProfile + "'");
        }

        return iValue.trim();
    }

    public static String getOrDefault(String pKey, String pDefault)
    {
        try
        {
            return get(pKey);
        }
        catch (Exception iException)
        {
            return pDefault;
        }
    }

    public static int getInt(String pKey, int pDefault)
    {
        try
        {
            return Integer.parseInt(get(pKey));
        }
        catch (Exception iException)
        {
            return pDefault;
        }
    }

    public static boolean getBool(String pKey, boolean pDefault)
    {
        try
        {
            return Boolean.parseBoolean(get(pKey));
        }
        catch (Exception iException)
        {
            return pDefault;
        }
    }

    public static long getLong(String pKey, long pDefault)
    {
        try
        {
            return Long.parseLong(get(pKey));
        }
        catch (Exception iException)
        {
            return pDefault;
        }
    }

    public static String getActiveProfile()
    {
        return iActiveProfile;
    }

    public static void printAll()
    {
        log.info("[ConfigManager] ===== Active Configuration (Profile: " + iActiveProfile + ") =====");
        iProperties.stringPropertyNames().stream().sorted().forEach(iKey ->
        {
            String iLower = iKey.toLowerCase(Locale.ROOT);
            String iValue = iLower.contains("password") || iLower.contains("secret") || iLower.contains("token")
                    ? "****MASKED****"
                    : getOrDefault(iKey, "");

            log.info("[ConfigManager]   " + iKey + " = " + iValue);
        });
    }
}
