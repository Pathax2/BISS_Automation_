package com.stepdefinitions;


import com.base.ConfigReader;
import com.base.DriverManager;
import com.pages.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.codehaus.plexus.util.cli.Arg;
import org.openqa.selenium.WebDriver;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

public class MyClientsSteps {

    LoginPage loginPage;
    //BPSdashboardPage bpsdashboardPage;
    MyClientsPage myclientsPage;
    WebDriver driver;
    Properties prop;
    ConfigReader configReader;
    DriverManager driverManager;
    DatabaseQueriesPage databaseQueriesPage;
    MyClientsPage myClientsPage;
    ApplicationPortalPage applicationPortalPage;

    public MyClientsSteps(DriverManager driverManager){
        try {
//            driver = driverManager.getDriver();
            this.driverManager=driverManager;
            driver=driverManager.getDriverInstance();
            loginPage = new LoginPage(driver);
            //bpsdashboardPage = new BPSdashboardPage(driver);
            myclientsPage = new MyClientsPage(driver);
            configReader = new ConfigReader();
            prop = configReader.init_prop();
            databaseQueriesPage = new DatabaseQueriesPage(driver);
            applicationPortalPage = new ApplicationPortalPage(driver);
            myClientsPage = new MyClientsPage(driver);
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    // region BPS Code

    @And("Agent is on My Clients Page")
    public void StaffParcelSearchPage() {
        String title = driver.getTitle();
        System.out.println("title of My Clients Page" + title);
    }

    @And("Agent Selects a Client by Clicking on Checkbox")
    public void AgentClickOnClientRadioButton() {
        myclientsPage.AgentClickOnClientRadioButton();
    }

    @Then("Click on the Client View Button")
    public void AgentClickOnClientViewButton() throws InterruptedException {
        myclientsPage.AgentClickOnViewButton();
        Thread.sleep(2000);
    }


    @Then("Visibility of Applications NavLink Dropdown")
    public void AgentVisibilityApplicationsNavLink() throws InterruptedException {
        myclientsPage.AgentVisibilityApplicationsNavLink();
        Thread.sleep(2000);
    }
    @And("Visibility of Farm Details NavLink Dropdown")
    public void AgentVisibilityFarmDetailsNavLink() throws InterruptedException {
        myclientsPage.AgentVisibilityFarmDetailsNavLink();
        Thread.sleep(2000);
    }
    @And("Visibility of Correspondence NavLink Dropdown")
    public void AgentVisibilityCorrespondenceNavLink() throws InterruptedException {
        myclientsPage.AgentVisibilityCorrespondenceNavLink();
        Thread.sleep(2000);
    }

    @And("Click on Application and Payments Summary")
    public void AgentClickOnApplicationPaymentsAndSummary() throws InterruptedException {
        myclientsPage.AgentClickOnApplicationsAndPaymentsSummary();
        Thread.sleep(2000);
    }

    @And("Agent selects Application And Payments Summary Scheme Year {int} from the dropdown")
    public void StaffSelectApplicationAndPaymentsSummarySchemeYear(int arg0) {
        myclientsPage.AgentSelectApplicationsAndSummarySchemeYear(arg0);
    }

    @And("Click on Application and Payments Summary View button")
    public void AgentClickOnApplicationPaymentsAndSummaryViewButton() throws InterruptedException {
        myclientsPage.AgentClickOnApplicationsAndPaymentsSummaryViewButton();
        Thread.sleep(2000);
    }

    @Then("Change the number of rows Displayed in the page to {string}")
    public void AgentChangeNumberOfRowsDisplayedOnPage(String Arg0) throws InterruptedException {
        myclientsPage.ChangeNumberOfRowsDisplayedInPage(Arg0);
        Thread.sleep(5000);
    }

    @And("Move To {string}")
    public void MoveToNextPage(String Arg0) {
        myclientsPage.AgentClickOnPaginationAndNewsNavigationButtons(Arg0);
    }

    // endregion

    // region BISS Code

    @And("Agent Click on the Farmer with Herd Number {string}")
    public void AgentExpandHerd(String Arg0) throws InterruptedException {
        myclientsPage.AgentExpandClientRow(Arg0);
        Thread.sleep(5000);
    }

    @Then("Agent Search for Herd Number {string}")
    public void AgentSearchForHerdNumber(String Arg0) throws InterruptedException {
        myclientsPage.AgentSearchForHerd(Arg0);
        Thread.sleep(3000);
    }

    @And("Agent Click on the {string} Quick Filter")
    public void AgentClickOnTheQuickFilter(String Filter) throws InterruptedException {
        myclientsPage.AgentSelectQuickFilters(Filter);
        Thread.sleep(4000);
    }

    @Then("Agent Click on First Herd in Not Started Section")
    public void AgentClickOnFirstHerdInNotStartedSection() {
        myclientsPage.AgentClickOnFirstClientInList();
    }

     @And("Agent Click on the Row with the Client {string}")
    public void AgentClickOnClientRow(String Arg0) {
        myclientsPage.AgentExpandClientRow(Arg0);
     }

     @Then("Agent Click on the View Dashboard Button")
    public void AgentClickOnViewDashboardButton() throws IOException, InterruptedException {
        myclientsPage.AgentClickOnViewDashboard();
     }

     @And("Agent switch to {string} Tab in My Clients Page")
     public void AgentSwitchTabs(String Arg0) throws InterruptedException {
        myclientsPage.AgentSwitchMyClientsTabs(Arg0);
        Thread.sleep(3000);
     }
    //@Then("Agent Navigate to Client Dashboard")

    @When("Agent expand Upload Documents Accordion")
    public void AgentExpandAccordion() {
        myclientsPage.AgentClickOnUploadDocAccordion();
    }

    @Then("Agent Select from {string} dropdown the doctype {string} to Upload")
    public void AgentSelectDocTypeToUpload(String DropdownName, String DocType) {
        myclientsPage.AgentSelectDocumentTypeInDropdown(DropdownName,DocType);
    }

    @And("Upload Document in Correspondence")
    public void AgentUploadDocument() throws InterruptedException {
        myclientsPage.UploadDocument();
        Thread.sleep(10000);
    }

    @And("Get {int} Herds from DataBase")
    public void getHerdsFromDataBase(int herdNumbers) {
        String herds = "./src/main/resources/TestData/Herd With No NRCISYF Submission.xls";
        databaseQueriesPage.runQueryForHerds(herdNumbers, herds);
    }

    @And("Collect All Herds of that agent which are not submitted save it to excel file")
    public void getHerdsFromFrontend() throws InterruptedException, IOException {
        applicationPortalPage.collectAllHerdsOfThatAgentWhichAreNotSubmitted();
    }


    @And("Get Agent from Database with {int} herds and put in the {string} field in login page")
    public void getAgentsFromDataBase(int value, String FieldName) throws SQLException, IOException, InterruptedException {
        String HerdWithNoSubmission = "./src/main/resources/TestData/Herd With No NRCISYF Submission.xls";
        myClientsPage.agentNewUsername(FieldName,HerdWithNoSubmission, value);
//        int counterOfAgents = 3;
//        try {
//            myClientsPage.checkExpiredAgent();
//             while(myClientsPage.checkExpiredAgent()==1 && counterOfAgents<=value){
//                 counterOfAgents++;
//                 driver.navigate().back();
//                 myClientsPage.agentUsername(FieldName, databaseQueriesPage.runQueryForAgents(databaseQueriesPage.getHerdNumberFromSpecifiedFile(counterOfAgents, HerdWithNoSubmission),temp));
//                }
//        } catch (Exception e) {
//            myClientsPage.agentUsername(FieldName, databaseQueriesPage.runQueryForAgents(databaseQueriesPage.getHerdNumberFromSpecifiedFile(counterOfAgents, HerdWithNoSubmission),temp));
//        }
//        String agents = "./src/main/resources/TestData/Agent of Herd With No NRCISYF Submission.xls";
//        myClientsPage.agentUsername(FieldName, databaseQueriesPage.getAgentNumberFromSpecifiedFile(agent,agentWithNoSubmission));

    }

    @And("Get {int} Agent for Herd from DataBase and put in the {string} field in login page")
    public void getAgentForHerdFromDataBaseAndPutInTheFieldInLoginPage(int value, String fieldName) throws IOException, SQLException, InterruptedException {
        String HerdWithNoSubmission = "./src/main/resources/TestData/Herd With No NRCISYF Submission.xls";
        int temp = 0;
        myClientsPage.agentUsername(fieldName, databaseQueriesPage.runQueryForAgents(databaseQueriesPage.getHerdNumberFromSpecifiedFile(value, HerdWithNoSubmission),temp));

    }

    @And("Check if Agent is Active in {int} herds in the {string} field")
    public void checkIfAgentIsActive(int value, String fieldName) {
        String HerdWithNoSubmission = "./src/main/resources/TestData/Herd With No NRCISYF Submission.xls";
        int counterOfAgents = 3;
        int temp = 0;
        try {
            myClientsPage.checkExpiredAgent();
            while(myClientsPage.checkExpiredAgent()==1 && counterOfAgents<=value){
                counterOfAgents++;
                driver.navigate().back();
                myClientsPage.agentUsername(fieldName, databaseQueriesPage.runQueryForAgents(databaseQueriesPage.getHerdNumberFromSpecifiedFile(counterOfAgents, HerdWithNoSubmission),temp));
            }
        } catch (Exception e) {
//            actions.sendKeys(FieldLocator, databaseQueriesPage.runQueryForAgents(databaseQueriesPage.getHerdNumberFromSpecifiedFile(counterOfAgents, HerdWithNoSubmission),temp));
//            System.out.println(databaseQueriesPage.getHerdNumberFromSpecifiedFile(counterOfAgents, HerdWithNoSubmission));
//            String herdID = databaseQueriesPage.getHerdNumberFromSpecifiedFile(counterOfAgents, HerdWithNoSubmission);
//          //  myClientsPage.agentUsername(FieldName, databaseQueriesPage.runQueryForAgents(databaseQueriesPage.getHerdNumberFromSpecifiedFile(counterOfAgents, HerdWithNoSubmission),temp));
        }
    }

    // endregion
}
