Feature: BISS Individual completes an end-to-end farmer application journey

  # --------------------------------------------------------------------------------------------------------------------
  # Purpose:
  #   Single end-to-end regression journey covering the major business flow in the BISS Application Portal,
  #   run by an INDIVIDUAL (the herd owner logs in as themselves). Same flow and step definitions as TC_03.
  #
  # Individual test data (Hooks, test case ID contains "_IND" - no hard-coded herd):
  #   Herd  : DATA "List of not started individual herds with CISYF flag"  (Not Started 'RI', CISYF flag, herd.year)
  #   Login : INET "Get Individual Login for herd"                         (role 100 herd -> role 115 login)
  #
  # Differences from TC_03 (agent):
  #   - No Home / My Clients navigation (an individual has no client list)
  #   - The individual opens their own Farmer Dashboard instead of searching the herd in My Clients
  #
  # Journey covered:
  #   - Login and portal navigation
  #   - Farmer dashboard access
  #   - Side navigation tab validation
  #   - Start application
  #   - Active Farmer step
  #   - Scheme Selection step
  #   - Land Details validations:
  #       * invalid parcel
  #       * archived parcel
  #       * add parcel
  #       * add plot
  #       * add parcel from map
  #       * edit/delete/undo parcel
  #       * delete plot
  #       * mandatory information completion
  #   - GAEC 7 handling
  #   - ACRES warnings flow
  #   - Eco selections
  #   - Review and Submit
  #   - Correspondence document upload
  #
  # Notes:
  #   1. This feature is intentionally designed as one controlled business journey.
  #   2. Test data such as herd rows, parcel IDs, plot references, and eco values should come from your framework.
  #   3. Step wording is kept consistent so step definitions can be designed cleanly in the new framework.
  # --------------------------------------------------------------------------------------------------------------------

  Background:
    Given the individual user is on the login page
    When the individual logs into the application with valid credentials and OTP
    And the individual opens the "Basic Income Support for Sustainability" application
    Then the individual should land on the BISS Home page

  @regression @e2e @biss @individual
  Scenario: AT-E2E-IND-01 - Individual completes the end-to-end BISS farmer application flow

    # -----------------------------------------
    # Farmer dashboard (own herd - no My Clients search)
    # -----------------------------------------
    When the individual opens their farmer dashboard
    Then the individual farmer dashboard should be displayed

    # -----------------------------------------
    # Side navigation validation
    # -----------------------------------------
    When the individual navigates through the farmer side navigation tabs
      | Applications / Payments           |
      | Farm Details                      |
      | Entitlements / Usage              |
      | Transfers                         |
      | NR-CISYF                          |
      | My Correspondence                 |
      | Home                              |
    Then each requested side navigation tab should open successfully

    # -----------------------------------------
    # Application start
    # -----------------------------------------
    When the individual deletes any existing draft if present
    And the individual starts a new BISS application
    Then the Active Farmer step should be displayed

    # -----------------------------------------
    # Active Farmer step
    # -----------------------------------------
    When the individual selects "Making Hay/Silage/Haylage" in the Active Farmer step
    And the individual proceeds to the next application step
    Then the Scheme Selection step should be displayed

    # -----------------------------------------
    # Scheme Selection step
    # -----------------------------------------
    When the individual selects the "Organics" scheme
    And the individual proceeds to the next application step
    And the individual accepts the scheme selection acknowledgement if displayed
    Then the Land Details step should be displayed

    # -----------------------------------------
    # Land Details - invalid parcel validation
    # -----------------------------------------
    When the individual attempts to add parcel "Invalid789"
    Then the invalid parcel warning message should be displayed
    And the add parcel dialog should remain available for correction or cancellation

    # -----------------------------------------
    # Land Details - archived parcel validation
    # -----------------------------------------
    When the individual attempts to add archived parcel "H19112055"
    Then the archived parcel warning should be displayed if applicable

    # -----------------------------------------
    # Land Details - add valid parcel
    # -----------------------------------------
    When the individual adds parcel "A1190600016" with claimed area "7"
    And the individual sets parcel ownership status to "Owned"
    And the individual sets parcel use to "Apples"
    And the individual sets parcel organic status to "Conventional"
    Then the parcel should be added successfully to Land Details

    # -----------------------------------------
    # Land Details - claimed parcel validation
    # -----------------------------------------
    When the individual attempts to add parcel "A1190600016" again
    Then the already claimed parcel warning should be displayed if applicable

    # -----------------------------------------
    # Land Details - add plot
    # -----------------------------------------
    When the individual adds a plot with the following details
      | county            | Donegal            |
      | townland          | Aghadachor - E22301 |
      | plotReference     | T12345679          |
      | ownershipStatus   | Owned              |
      | organicStatus     | Conventional       |
      | claimedArea       | 15                 |
      | plotUse           | Blackcurrants      |
      | mapChangeOption   | Submit Paper Map By Post |
    Then the plot should be added successfully to Land Details

    # -----------------------------------------
    # Land Details - add parcel from GIS map
    # -----------------------------------------
    When the individual adds a parcel from the GIS map with the following details
      | county            | Clare              |
      | townland          | Addergoole - C11501 |
      | claimedArea       | 4                  |
      | ownershipStatus   | Owned              |
      | parcelUse         | Beetroot               |
      | organicStatus     | Conventional       |
    Then the GIS-selected parcel should be added successfully

    # -----------------------------------------
    # Land Details - add parcel to edit/delete
    # -----------------------------------------
    When the individual adds parcel "J1650300004" with claimed area "3"
    And the individual sets parcel ownership status to "Owned"
    And the individual sets parcel use to "Clover"
    And the individual sets parcel organic status to "Conventional"
    Then parcel "J1650300004" should be available in Land Details

    # -----------------------------------------
    # Land Details - edit parcel using side drawer
    # -----------------------------------------
    When the individual opens parcel "J1650300004" in the side drawer
    And the individual raises an EH change request with reason "Test Reason"
    And the individual changes parcel use to "Coriander"
    And the individual saves the parcel changes
    Then the parcel update should be saved successfully

    # -----------------------------------------
    # Land Details - delete and undo parcel
    # -----------------------------------------
    When the individual deletes parcel "J1650300004"
    Then parcel "J1650300004" should be marked for deletion
    When the individual undoes deletion for parcel "J1650300004"
    Then parcel "J1650300004" should be restored in Land Details

    # -----------------------------------------
    # Land Details - add plot to delete later
    # -----------------------------------------
    When the individual adds a plot with the following details
      | county            | Donegal              |
      | townland          | Aghadowey - E18601   |
      | plotReference     | T87654322            |
      | ownershipStatus   | Owned                |
      | organicStatus     | Conventional         |
      | claimedArea       | 10                   |
      | plotUse           | Apples               |
      | mapChangeOption   | Submit Paper Map By Post |
    Then plot "T87654322" should be available in Land Details

    # -----------------------------------------
    # Land Details - delete plot
    # -----------------------------------------
    When the individual deletes parcel or plot "T87654322"
    And the individual confirms the deletion
    #Then plot "T87654321" should be marked for deletion

    # -----------------------------------------
    # Land Details - complete mandatory information
    # -----------------------------------------
    When the individual completes all mandatory information in Land Details
    And the individual proceeds to the next application step
    Then the next application step should open successfully

    #----------------------------------------------------------
    # ISLAND PAGE
    #-------------------------------------------------------------
    And the individual reaches on Island Stepper

    # -----------------------------------------
    # GAEC 7 step
    # -----------------------------------------
    When the individual opens the "GAEC 7" step
    And the individual proceeds from GAEC 7
    And the individual handles any GAEC 7 continue action if present
    Then the application should move beyond the GAEC 7 step

    # -----------------------------------------
    # ACRES step
    # -----------------------------------------
    And the individual handles the ACRES step if present
    #Below Steps explain what is happening
    #When the agent opens the "ACRES" step
    #And the agent selects "Yes, rescore" on panel 1
    #And the agent continues panel 1
    #Then the ACRES step should be completed successfully

    # -----------------------------------------
    # Eco step
    # -----------------------------------------
    When the individual opens the "Eco" step
    And the individual selects eco AP options "" and ""
    Then the Eco step should be completed successfully

    # -----------------------------------------
    # Eco opt-out validation
    # -----------------------------------------
    #When the agent returns to the "Scheme Selection" step
    #And the agent opens the "Eco" scheme card
    #And the agent proceeds to the next application step
    #And the agent accepts the acknowledgement if displayed
    #Then the application should continue successfully after eco validation

    # -----------------------------------------
    # Review and Submit
    # -----------------------------------------
    When the individual opens the "Review & Submit" step
    And the individual completes all review page next actions
    And the individual accepts the Terms and Conditions
    And the individual submits the application
    And the individual confirms the application submission
    Then the application should be submitted successfully

    # -----------------------------------------
    # Correspondence and upload document
    # -----------------------------------------
    When the individual navigates through the farmer side navigation tabs
      | My Correspondence                 |
    Then each requested side navigation tab should open successfully
    Then the individual clicks on the " Upload a document" stepper button
      #When Individual expand Upload Documents Accordion
    And the individual selects "Commonage Evidence" from the Document type dropdown
    And the individual uploads a document in Correspondence
    Then the document should be uploaded successfully in Correspondence