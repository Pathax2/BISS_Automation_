Feature: TC_05_ENTS - Transfer Application E2E Regression Pack (Agent to Individual)

  # --------------------------------------------------------------------------------------------------------------------
  # Purpose:
  #   Single end-to-end regression journey covering Transfer of Entitlements flows where the Transferor is an Agent
  #   (agr9197) and the Transferee is an Individual user who logs in with their own login.
  #
  #   Difference from TC_03_ENTS / TC_04_ENTS (agent to agent):
  #     - the transferee logs in with an individual login, not an agent login
  #     - a personal details dialog can be shown after the individual logs in (closed when shown)
  #     - the individual opens "Transfers" from the farmer side navigation (no My Clients tab switch)
  #     - the individual sees the transfer on their own Transfers page (no herd search)
  #
  #   Transfer types covered:
  #     Section 1 : Change of Registration (205)  - Selenium: C1120016 to Y104069X (Daniel Mulvany / PAUDYFROG)
  #     Section 2 : Inheritance            (201)  - Selenium: C1120016 to Y104069X (Daniel Mulvany / PAUDYFROG)
  #     Section 3 : Gift                   (202)  - Selenium: C1120016 to Y1041344 (Felim Sullivan / TERENCE1)
  #     Section 4 : Lease                  (211)  - Selenium: C1120016 to Y1041344 (Felim Sullivan / TERENCE1) + lease year
  #
  # Migrated from: TC_05_ENTS.feature (legacy 4 separate scenarios)
  #   TC_17 -> Section 1     TC_18 -> Section 2     TC_19 -> Section 3     TC_20 -> Section 4
  #
  # Runtime data (Playwright, 30-09-2026):
  #   No herd, name or individual login is typed in this file. The "transfereeType | Individual" row makes the create
  #   step pick the pair with EntsTestData.nextAgentToIndividualPair:
  #     transferor herd           - an unused herd from the Agent Login pool of the logged-in agent (agr9197)
  #     transferee herd/name/login - an unused herd from the Individual Login query (holder has their own online login)
  #   Both are written to runtime-data/ents_used_herds.csv and never reused.
  #     {transferor.herd}  {transferee.herd}  {transferee.name}  {transferee.login}
  #   The individual login step uses {transferee.login}, so it always logs in as the owner of the transferee herd.
  #   Put a herd number, name or login back in any cell to pin it for debugging (the Selenium values are in the
  #   comments of each section).
  #
  #   The transferee herd is not a client of the agent, so the create step checks only the transferor in the
  #   Transfer Out list. The individual sees the transfer on their own Transfers page (no herd search).
  #
  # Step reuse:
  #   Background login / navigation / side navigation -> stepdefinitions.TC_03
  #   Login as a named user                           -> stepdefinitions.ENTS.TC_08_ENTS
  #   Tab switching                                   -> stepdefinitions.TC_06
  #   Create / upload / send / key / submit           -> stepdefinitions.ENTS.TC_01_ENTS
  #   Transferor re-login between sections            -> stepdefinitions.ENTS.TC_03_ENTS
  #   Individual logout + login, individual acceptance -> stepdefinitions.ENTS.TC_05_ENTS
  #
  #   "the transfer should be submitted successfully" logs out, so each next section starts with
  #   "the agent logs out and re-log in as the transferee agent" (the variant WITHOUT a logout, TC_03_ENTS) to log
  #   back in as the transferor agent, exactly as in the Selenium file.
  #
  # Author : Aniket Pathare | aniket.pathare@government.ie
  # Created: 31-03-2026 | Updated: 30-09-2026 (Playwright + runtime ENTS data, individual transferees)
  # --------------------------------------------------------------------------------------------------------------------

  Background:
    Given the agent user is on the login page
    When the individual logs in as transferor "agr9197"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page

  @regression @transfers @agent-to-individual @e2e
  Scenario: AT-ENTS-TRANSFERS-E2E-05 - Agent completes all Agent-to-Individual transfer types

    # ===========================================
    # SECTION 1 : Change of Registration (205)
    # Covers: TC_17
    # Transferee: an individual with their own login (Individual Login query)
    # ===========================================

    # --- Transferor (Agent) ---
    When the agent creates a transfer application with the following details
      | transferorHerd | {transferor.herd}              |
      | transfereeHerd | {transferee.herd}              |
      | transfereeName | {transferee.name}              |
      | transfereeType | Individual                     |
      | transferType   | Change of Registration Details |
      | entitlements   | 0.01                           |
      | notes          | Test Notes                     |
    And the agent uploads the transferor signature document
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Individual - own login) ---
    When the agent logs out and re-logs in as the individual transferee "{transferee.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 2 : Inheritance (201)
    # Covers: TC_18
    # Transferee: an individual with their own login (Individual Login query)
    # ===========================================

    # --- Transferor (Agent) ---
    When the agent logs out and re-log in as the transferee agent "agr9197"
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent creates a transfer application with the following details
      | transferorHerd | {transferor.herd}           |
      | transfereeHerd | {transferee.herd}           |
      | transfereeName | {transferee.name}           |
      | transfereeType | Individual                  |
      | transferType   | Inheritance of Entitlements |
      | entitlements   | 0.01                        |
      | notes          | Test Notes                  |
    And the agent uploads the transferor signature document
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Individual - own login) ---
    When the agent logs out and re-logs in as the individual transferee "{transferee.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 3 : Gift of Entitlements (202)
    # Covers: TC_19
    # Transferee: an individual with their own login (Individual Login query)
    # ===========================================

    # --- Transferor (Agent) ---
    When the agent logs out and re-log in as the transferee agent "agr9197"
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent creates a transfer application with the following details
      | transferorHerd | {transferor.herd}    |
      | transfereeHerd | {transferee.herd}    |
      | transfereeName | {transferee.name}    |
      | transfereeType | Individual           |
      | transferType   | Gift of Entitlements |
      | entitlements   | 0.01                 |
      | notes          | Test Notes           |
    And the agent uploads the transferor signature document
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Individual - own login) ---
    When the agent logs out and re-logs in as the individual transferee "{transferee.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 4 : Lease of Entitlements (211)
    # Covers: TC_20
    # Transferee: an individual with their own login (Individual Login query)
    # NOTE: Lease includes lease year selection
    # ===========================================

    # --- Transferor (Agent) ---
    When the agent logs out and re-log in as the transferee agent "agr9197"
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent creates a transfer application with the following details
      | transferorHerd | {transferor.herd}     |
      | transfereeHerd | {transferee.herd}     |
      | transfereeName | {transferee.name}     |
      | transfereeType | Individual            |
      | transferType   | Lease of Entitlements |
      | entitlements   | 0.01                  |
      | leaseYear      | Yes                   |
      | notes          | Test Notes            |
    And the agent uploads the transferor signature document
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Individual - own login) ---
    When the agent logs out and re-logs in as the individual transferee "{transferee.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully