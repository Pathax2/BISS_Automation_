package com.utility;


import io.cucumber.java.Scenario;
import io.restassured.RestAssured;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Collection;
import static io.restassured.RestAssured.given;
import static io.restassured.specification.ProxySpecification.host;


public class JiraXrayClient {
    public static final String EXECUTION_STATUS_PASS = "PASSED";
    public static final String EXECUTION_STATUS_FAIL = "FAILED";
    public static final String EXECUTION_STATUS_WIP = "EXECUTING";
    public static final String EXECUTION_STATUS_UNEXECUTED = "-1";
    public static final String EXECUTION_STATUS_BLOCKED = "BLOCKED";
    public static void reportToJira(String arg0, Scenario scenario, String executionComment, String cyclename) throws Exception {
        String tagPrefix = arg0;
        if (!tagPrefix.isEmpty()) {
            String testId = extractJiraIssueId(scenario, tagPrefix);
            System.out.println(testId);
            String baseURL = "https://xray.cloud.getxray.app";
            // Step 1: Set Base URI
            RestAssured.baseURI = baseURL;
//            try {
//                // Step 2: Set Proxy using IP and Port
//                RestAssured.proxy = host("10.2.68.69").withPort(8080);
//            }
//            catch (Exception e)
//            {
//                System.out.println(e.getMessage());
//            }
            String clientId = "B1E1D4C4882B45D6A1B1B6F3BBEA4620";
            String clientSecret = "b646d709b2eaacc837f868dc2227c827ff1fbe85115676b51fb1253b9afbf553";
            String authPayload = String.format(
                    "{ \"client_id\": \"%s\", \"client_secret\": \"%s\" }",
                    clientId, clientSecret);
            String token = given()
                    .header("Content-Type", "application/json")
                    .body(authPayload)
                    .when()
                    .post("/api/v2/authenticate")
                    .then()
                    .extract()
                    .asString()
                    .replace("\"", "");
//             System.out.println("Bearer Token: " + token);
            // Step 4: Get Test Case Details using the Bearer Token
            String testKey = testId; // Replace with your actual test key
            String executionKey = cyclename;
            String statusToZephyr = convertScenarioStatusToZephyrStatus(scenario);
            System.out.println(statusToZephyr);
            // Build the JSON object
            JSONObject testCase = new JSONObject();
            testCase.put("testKey", testKey);
            testCase.put("status", statusToZephyr);
            JSONArray tests = new JSONArray();
            tests.put(testCase);
            JSONObject body = new JSONObject();
            body.put("testExecutionKey", executionKey);
            body.put("tests", tests);
            System.out.println(body);
            // Send the request
            RestAssured.baseURI = baseURL;
            String validatethebody = given()
                    .header("Content-Type", "application/json")
                    .header("Authorization", "Bearer " + token)
                    .body(body.toString())
                    .when()
                    .post("/api/v2/import/execution")
                    .then()
                    .extract()
                    .asString()
                    .replace("\"", "");
            System.out.println(validatethebody.trim());
        }
        else
        {
            System.out.println("the tag prefix is missing");
        }
        RestAssured.reset();
    }
    private static String convertScenarioStatusToZephyrStatus(Scenario scenario) {
        String scenarioStatus = scenario.getStatus().toString();
        System.out.println("Scenario Status: " + scenario.getStatus());
        String statusToZephyr = null;
        switch (scenarioStatus) {
            case "passed":
            case "PASSED":
                statusToZephyr = EXECUTION_STATUS_PASS;
                break;
            case "failed":
            case "FAILED":
                statusToZephyr = EXECUTION_STATUS_FAIL;
                break;
            case "pending":
            case "PENDING":
            case "skipped":
            case "SKIPPED":
                statusToZephyr = EXECUTION_STATUS_BLOCKED;
                break;
            default:
                statusToZephyr = EXECUTION_STATUS_UNEXECUTED;
        }
        return statusToZephyr;
    }
    private static String extractJiraIssueId(Scenario scenario, String tagPrefix) {
        Collection<String> sourceTagNames = scenario.getSourceTagNames();
        sourceTagNames.forEach(tag -> System.out.println("scenario has tag: " + tag));
        String tagContainsPrefix = sourceTagNames.stream().filter(tag -> tag.contains(tagPrefix))
                .findFirst().orElse("");
        String testId = StringUtils.substringAfter(tagContainsPrefix, "=");
        System.out.println("Test ID: " + testId);
        TestDataHolder.addRecord(TestDataHolder.ZEPHYR_TEST_ID, testId, true, true);
        return testId;
    }
}

