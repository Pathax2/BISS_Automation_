Feature: TC_09_ENTS - Transfer Application E2E Regression Pack (Individual to Individual)

  # --------------------------------------------------------------------------------------------------------------------
  # Purpose:
  #   Single end-to-end regression journey covering Transfer of Entitlements flows where both the Transferor and the
  #   Transferee are Individuals with their own logins. Neither side searches a herd: each opens "Transfers" from the
  #   farmer side navigation and works on their own Transfers page.
  #
  #   Transfer types covered:
  #     Section 1 : Lease                  (211)  - Selenium: SOUTHVIEW1    to T1060418 (Patrick Hoban) / 3970723H  + lease year
  #     Section 2 : Sale                   (212)  - Selenium: RENATENOHL@.. to M2081822 (Mary Ann Ryan & P J Quinn) / 4589015L
  #     Section 3 : Gift                   (202)  - Selenium: 3029508B      to O119072X (Louise Cunningham) / JOHNBALLYORAN
  #     Section 4 : Division               (204)  - Selenium: H2200068      to R126120X (Margt Reid) / 6838713O
  #     Section 5 : Merger                 (203)  - Selenium: EILEEN.KEENAN to D2560055 (Gerard Hazelwood & Timothy O'Sullivan) / TIMOTHY.MURPHY
  #     Section 6 : Change of Registration (205)  - Selenium: KARENKELLYWH  to X1370418 (John Burke) / KADAGH.GEOGHEGAN
  #     Section 7 : Change of Legal Entity (206)  - Selenium: BRENDANCLARKE to N1211270 (Michael Kelleher Jnr) / JOHNSHERIDAN89
  #     Section 8 : Inheritance            (201)  - Selenium: BRENDANCLARKE to N1211270 (Michael Kelleher Jnr) / JOHNSHERIDAN89
  #
  # Migrated from: TC_09_ENTS.feature (legacy 8 separate scenarios)
  #
  # Runtime data (Playwright, 30-09-2026):
  #   The login step runs before the create step, so the pair is built in two halves (EntsTestData):
  #     "the individual logs in as transferor {transferor.login}" picks an unused herd from the Individual Login query
  #       (holder has their own online login) and logs its owner in
  #     the create step then picks the transferee: another unused herd from the Individual Login query
  #       ("transfereeType | Individual", completePairWithIndividualTransferee)
  #     {transferor.login}  {transferee.herd}  {transferee.name}  {transferee.login}
  #   Every pick is written to runtime-data/ents_used_herds.csv and never reused. Put a herd number, name or login back
  #   in any cell to pin it for debugging (the Selenium values are in the comments of each section).
  #
  # Step reuse:
  #   Background login / navigation / side navigation -> stepdefinitions.TC_03
  #   Individual login + create                       -> stepdefinitions.ENTS.TC_08_ENTS
  #   Send / key / submit                             -> stepdefinitions.ENTS.TC_01_ENTS
  #   Individual logout + login, individual acceptance -> stepdefinitions.ENTS.TC_05_ENTS
  #
  # Author : Aniket Pathare | aniket.pathare@government.ie
  # Created: 31-03-2026 | Updated: 30-09-2026 (Playwright + runtime ENTS data)
  # --------------------------------------------------------------------------------------------------------------------

  Background:
    Given the agent user is on the login page
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |

  @regression @transfers @individual-to-individual @e2e
  Scenario: AT-ENTS-TRANSFERS-E2E-09 - Individual completes all transfer types to Individual

    # ===========================================
    # SECTION 1 : Lease of Entitlements (211)
    # Selenium: SOUTHVIEW1 to T1060418 (Patrick Hoban), accepted by 3970723H
    # NOTE: Lease includes lease year selection
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual creates a transfer application with the following details
      | transfereeHerd | {transferee.herd}     |
      | transfereeName | {transferee.name}     |
      | transfereeType | Individual            |
      | transferType   | Lease of Entitlements |
      | entitlements   | 0.01                  |
      | leaseYear      | Yes                   |
      | notes          | Test Notes            |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Individual - own login) ---
    When the agent logs out and re-logs in as the individual transferee "{transferee.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 2 : Sale of Entitlements (212)
    # Selenium: RENATENOHL to M2081822 (Mary Ann Ryan & P J Quinn), accepted by 4589015L
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual creates a transfer application with the following details
      | transfereeHerd | {transferee.herd}    |
      | transfereeName | {transferee.name}    |
      | transfereeType | Individual           |
      | transferType   | Sale of Entitlements |
      | entitlements   | 0.01                 |
      | notes          | Test Notes           |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Individual - own login) ---
    When the agent logs out and re-logs in as the individual transferee "{transferee.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 3 : Gift of Entitlements (202)
    # Selenium: 3029508B to O119072X (Louise Cunningham), accepted by JOHNBALLYORAN
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual creates a transfer application with the following details
      | transfereeHerd | {transferee.herd}    |
      | transfereeName | {transferee.name}    |
      | transfereeType | Individual           |
      | transferType   | Gift of Entitlements |
      | entitlements   | 0.01                 |
      | notes          | Test Notes           |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Individual - own login) ---
    When the agent logs out and re-logs in as the individual transferee "{transferee.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 4 : Division of Entitlements (204)
    # Selenium: H2200068 to R126120X (Margt Reid), accepted by 6838713O
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual creates a transfer application with the following details
      | transfereeHerd | {transferee.herd}                   |
      | transfereeName | {transferee.name}                   |
      | transfereeType | Individual                          |
      | transferType   | Division of Entitlements (Scission) |
      | entitlements   | 0.01                                |
      | notes          | Test Notes                          |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Individual - own login) ---
    When the agent logs out and re-logs in as the individual transferee "{transferee.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 5 : Merger of Entitlements (203)
    # Selenium: EILEEN.KEENAN to D2560055 (Gerard Hazelwood & Timothy O'Sullivan), accepted by TIMOTHY.MURPHY
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual creates a transfer application with the following details
      | transfereeHerd | {transferee.herd}                                                       |
      | transfereeName | {transferee.name}                                                       |
      | transfereeType | Individual                                                              |
      | transferType   | Merger of 2 or more holdings (forming an unregistered Farm Partnership) |
      | entitlements   | 0.01                                                                    |
      | notes          | Test Notes                                                              |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Individual - own login) ---
    When the agent logs out and re-logs in as the individual transferee "{transferee.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 6 : Change of Registration (205)
    # Selenium: KARENKELLYWH to X1370418 (John Burke), accepted by KADAGH.GEOGHEGAN
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual creates a transfer application with the following details
      | transfereeHerd | {transferee.herd}              |
      | transfereeName | {transferee.name}              |
      | transfereeType | Individual                     |
      | transferType   | Change of Registration Details |
      | entitlements   | 0.01                           |
      | notes          | Test Notes                     |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Individual - own login) ---
    When the agent logs out and re-logs in as the individual transferee "{transferee.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 7 : Change of Legal Entity (206)
    # Selenium: BRENDANCLARKE to N1211270 (Michael Kelleher Jnr), accepted by JOHNSHERIDAN89
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual creates a transfer application with the following details
      | transfereeHerd | {transferee.herd}      |
      | transfereeName | {transferee.name}      |
      | transfereeType | Individual             |
      | transferType   | Change of Legal Entity |
      | entitlements   | 0.01                   |
      | notes          | Test Notes             |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Individual - own login) ---
    When the agent logs out and re-logs in as the individual transferee "{transferee.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully

    # ===========================================
    # SECTION 8 : Inheritance (201)
    # Selenium: BRENDANCLARKE to N1211270 (Michael Kelleher Jnr), accepted by JOHNSHERIDAN89
    # ===========================================

    # --- Transferor (Individual - own login) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual creates a transfer application with the following details
      | transfereeHerd | {transferee.herd}           |
      | transfereeName | {transferee.name}           |
      | transfereeType | Individual                  |
      | transferType   | Inheritance of Entitlements |
      | entitlements   | 0.01                        |
      | notes          | Test Notes                  |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Individual - own login) ---
    When the agent logs out and re-logs in as the individual transferee "{transferee.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers |
    And the individual completes the transferee acceptance flow
      | transfereeHerd | {transferee.herd} |
      | notes          | Approved Test     |
    Then the transfer should be submitted successfully