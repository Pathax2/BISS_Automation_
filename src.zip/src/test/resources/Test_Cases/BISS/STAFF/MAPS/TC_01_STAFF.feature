# ====================================================================================================================================
# CATEGORY : MAPS
# ====================================================================================================================================
# Covers all Map Printing regression packs for the BISS internal (staff) portal:
#   TC_01 - Map generation by herd number search
#   TC_02 - Map generation by parcel number search, incl. every required-field validation
#   TC_03 - Generated map metadata and pagination
#   TC_04 - Partnership herd maps and download
#   TC_05 - Maps surfaced on the Correspondence screen
#   TC_10 - Map download from the generated maps table
#   TC_11 - Parcel search format tolerance
#
# DATA
#   Herds, parcels and references are resolved from the DB at runtime by the @staffdata hook
#   via DBRouter. Features never name a herd index - "the next submitted herd" pops the next
#   unused value from the resolved list, so sections stay independent and re-runnable.
#   Staff accounts (agr11612 / agr2332 / agr4442 / agr5033) are hardcoded permission
#   fixtures, not test data - each carries a specific role the test depends on.
#
# STEP DEFINITIONS : MapPrintingSteps.java (stepdefinitions.STAFF)
# LOCATORS         : ObjectRepository.properties - Section: Map Printing
# Author           : Aniket Pathare | aniket.pathare@government.ie
# Created          : 15-07-2026
# ====================================================================================================================================

# ====================================================================================================================================
# TC_01_STAFF.feature
# ====================================================================================================================================
@maps @regression @staff
Feature: TC_01_STAFF - Map Printing by Herd Number

  # Migrated from legacy "Regression Suite for Map Printing with Herd" (AT-TC-01, 02, 04).
  # Legacy AT-TC-03 was commented out as a depleted case and is not carried forward.
  #
  # BUSINESS FLOW
  #   An internal map printing user searches a herd on the Map Printing screen, chooses the
  #   parcels and map layout to render, and requests generation. The screen must also refuse
  #   a search with no herd number.
  #
  # WHAT THIS VALIDATES
  #   1. A map can be generated for a single selected parcel of a herd.
  #   2. Searching with an empty herd field raises the mandatory-field error.
  #   3. A map can be generated across all parcels of a herd.


  Background:
    Given the staff user is logged in to the BISS internal portal as "agr11612"
    And the staff user is on the Map Printing screen

  @e2e @map-generation
  Scenario: Staff generates herd maps for single and all parcel selections

    # SECTION 1 - AT-TC-01 (BISSAGL-14969)
    # Validates: a map is accepted for generation when one parcel of a submitted herd is
    # selected against a Full Colour Ortho A4 layout with the legend enabled.
    When the staff user searches Map Printing for the next submitted herd for scheme year "2025"
    And the staff user requests a map with the following settings
      | parcels | single              |
      | mapType | Full Color Ortho A4 |
      | legend  | yes                 |
    Then the map generation request should be accepted

    # SECTION 2 - AT-TC-02 (BISSAGL-14968)
    # Validates: the herd number is mandatory - searching with an empty field is rejected.
    When the staff user searches Map Printing with no herd number
    Then the staff user should see the validation error "Herd number required."

    # SECTION 3 - AT-TC-04 (BISSAGL-14966)
    # Validates: generation is accepted when every parcel on the herd is selected, proving
    # the multi-parcel path as well as the single-parcel path in Section 1.
    When the staff user searches Map Printing for the next submitted herd for scheme year "2023"
    And the staff user requests a map with the following settings
      | parcels | all                 |
      | mapType | Full Color Ortho A4 |
      | legend  | yes                 |
    Then the map generation request should be accepted








