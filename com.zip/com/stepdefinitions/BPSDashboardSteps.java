package com.stepdefinitions;


import com.base.ConfigReader;
import com.base.DriverManager;
import com.pages.BPSdashboardPage;
import com.pages.DatabaseQueriesPage;
import com.pages.LoginPage;
import com.pages.MyClientsPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
//import sun.tools.jconsole.Tab;

import java.awt.*;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

public class BPSDashboardSteps {

    LoginPage loginPage;
    BPSdashboardPage bpsdashboardPage;
    MyClientsPage parcelsearchPage;
    DatabaseQueriesPage databaseQueriesPage;
    WebDriver driver;
    Properties prop;
    ConfigReader configReader;
    DriverManager driverManager;
    public BPSDashboardSteps(DriverManager driverManager){
        try {
            this.driverManager=driverManager;
            driver=driverManager.getDriverInstance();
            loginPage = new LoginPage(driver);
            bpsdashboardPage = new BPSdashboardPage(driver);
            parcelsearchPage = new MyClientsPage(driver);
            databaseQueriesPage = new DatabaseQueriesPage(driver);
            configReader = new ConfigReader();
            prop = configReader.init_prop();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    // region BPS Steps Code
    @Then("Agent Check for News Section Visibility")
    public void AgentCheckVisibilityOfNewsSection() throws InterruptedException {
        Assert.assertTrue(bpsdashboardPage.AgentCheckNewsSection());
    }

    @And("Navigate to News Page")
    public void AgentNavigateToNewsPage() {
        bpsdashboardPage.AgentClickOnViewInNewsSection();
    }

    @Then("Staff is on Agent News Page")
    public void AgentNewsPage() {
        String title = driver.getTitle();
        System.out.println("title of Agent News Page" + title);
    }

    @And("Agent enters the Herd Number as {string}")
    public void AgentEnterHerd(String Arg0) {
        bpsdashboardPage.AgentEnterHerd(Arg0);
    }

    @Then("Agent clicks on the Search Herd Button")
    public void AgentClickOnSearchHerd() {
        bpsdashboardPage.AgentClickOnSearchHerdButton();
    }

    @And("Agent clicks on the Searched Herd View Button")
    public void AgentClickOnSearchedHerdViewButton() {
        bpsdashboardPage.AgentClickOnSearchedHerdViewButton();
    }

    @And("Agent Click on the Help Link")
    public void AgentClickOnHelpLink() throws InterruptedException {
        bpsdashboardPage.AgentClickOnHelpLink();
        Thread.sleep(2000);
        // Current WindowHandle
        String winHandlePresent = driver.getWindowHandle();
        for(String winHandle : driver.getWindowHandles()) {
//            String LinkText = driver.switchTo().window(winHandle).findElement(By.id("I_11")).getText();
//            System.out.println(LinkText);
            driver.switchTo().window(winHandle);
        }
    }

    @Then("Verify Agent is in Help Window and title has 2022")
    public void AgentHelpPage() {
        String title = driver.getTitle();
        System.out.println("title of Help Page is : " + title);
        Assert.assertEquals(title,"Bps Direct Payments 2022 Help");
    }

    @And("Agent Navigate to Filing Your BPS Application Online")
    public void NavigateToFilingYourBPSApplicationOnline() throws InterruptedException {
        bpsdashboardPage.AgentNavigateToFilingBPSApplicationOnline();
    }

    @And("Verify that Partnership Information has the year 2022")
    public void AgentCheckIfThereIs2022inPartnershipText() {
        Assert.assertTrue(bpsdashboardPage.AgentCheckPartnerShipInformationContains());
    }

    @And("Verify that ANC para has been updated to the year 2022")
    public void AgentCheckIfThereIs2022inANCText() {
        Assert.assertTrue(bpsdashboardPage.AgentCheckANCContains2022());
    }

    @And("Verify that YFS para years have been updated")
    public void AgentCheckIfThereIsUpdateInYFSContent() {
        Assert.assertTrue(bpsdashboardPage.AgentCheckYFS1stParaContains2021());
        Assert.assertTrue(bpsdashboardPage.AgentCheckYFS2ndParaContains2022());
    }

    @And("Verify that GLAS para years have been updated To 2022")
    public void AgentCheckIfThereIsUpdateInGLASContent() {
        Assert.assertTrue(bpsdashboardPage.AgentCheckGLAS2ndParaContains2022());
        Assert.assertTrue(bpsdashboardPage.AgentCheckGLAS3rdParaContains2022());
    }

    @And("Agent Navigate to Submitting a No Change Case")
    public void NavigateToSubmittingANoChangeCase() throws InterruptedException {
        bpsdashboardPage.AgentNavigateToSubmittingANoChangeCase();
    }

    @And("Verify that Navigate to Submitting a No Change Case To 2022")
    public void AgentCheckIfThereIsUpdateInSubmittingNoChangeCaseContent() {
        Assert.assertTrue(bpsdashboardPage.AgentCheckSubmittingANoChangeCaseContentUpdateTo2022());
    }

    @And("Agent Navigate to Land Parcel Details")
    public void NavigateToLandParcelDetails() throws InterruptedException {
        bpsdashboardPage.AgentNavigateToLandParcelDetails();
    }

    @And ("Check if Pop Up Section present in Land Parcel Details")
    public void AgentCheckPopUpSectionInLandParcelDetails() {
        bpsdashboardPage.AgentCheckPopUpSection();
    }

    @And("Agent Navigate to Add Plot")
    public void NavigateToAddPlot() throws InterruptedException {
        bpsdashboardPage.AgentNavigateToAddPlot();
    }

    @And ("Check if Add Plot Content Year Updated to 2022")
    public void AgentCheckYearUpdateInAddPlot() {
        bpsdashboardPage.AgentCheckAddPlotSectionYearUpdate();
    }

    @And("Agent Navigate to Island Details")
    public void NavigateToIslandDetails() throws InterruptedException {
        bpsdashboardPage.AgentNavigateToIslandDetails();
    }

    @And ("Check if Island Details Content Year Updated to 2022")
    public void AgentCheckYearUpdateInIslandDetails() {
        bpsdashboardPage.AgentCheckIslandDetailsSectionYearUpdate();
    }

    @And("Agent Navigate to Organic Land Details")
    public void NavigateToOrganicLandDetails() throws InterruptedException {
        bpsdashboardPage.AgentNavigateToOrganicLandDetails();
    }

    @And ("Check if Organic Land Details Content Year Updated to 2022")
    public void AgentCheckYearUpdateInOrganicLandDetails() {
        bpsdashboardPage.AgentCheckOrganicLandDetailsSectionYearUpdate();
    }

    @And("Agent Navigate to Greening")
    public void NavigateToGreening() throws InterruptedException {
        bpsdashboardPage.AgentNavigateToGreening();
    }

    @And ("Check if Provisional Status Update Content Year in Greening Tab Updated to 2022")
    public void AgentCheckYearUpdateInProvisionalStatusUpdate() {
        bpsdashboardPage.AgentCheckProvisionalStatusTableContains2022();
    }

    @And("Agent Navigate to SIM")
    public void NavigateToSIM() throws InterruptedException {
        bpsdashboardPage.AgentNavigateToSIM();
    }

    @And("Agent Check SIM Section Text")
    public void AgentCheckSIMSectionText() {
        Assert.assertEquals(bpsdashboardPage.AgentCheckSIMSectionText(),"A pop-up with the following SIM warning:");
    }

    @And("Agent Navigate to Application Summary")
    public void NavigateToApplicationSummary() throws InterruptedException {
        bpsdashboardPage.AgentNavigateToApplicationSummary();
    }

    @And ("Check if Application Summary Content Year Updated to 2022")
    public void AgentCheckYearUpdateInApplicationSummary() {
        bpsdashboardPage.AgentCheckApplicationSummarySectionYearUpdate();
    }

    // endregion

    @When("Agent Click on My Clients")
    public void AgentClickOnMyClients() {
        loginPage.AgentClickOnMyClients();
    }

    // region BISS Code

    @When("Agent Click on the {string} hyperlink in the Quick Links Section")
    public void AgentClickOnQuickLinksInDashboard(String Arg0) throws InterruptedException {
        bpsdashboardPage.AgentClickOnQuickLinksViewClientsLink(Arg0);
        Thread.sleep(2000);
    }

    @And("Agent Click on View Clients Button in BISS Applications Section")
    public void AgentClickOnViewAllClientsButtonInApplicationsSection() {
        bpsdashboardPage.AgentClickOnTotalClientsButton();
    }

    @Then("Agent Click On Read More Button in News Section")
    public void AgentClickOnReadMoreButton() {
        bpsdashboardPage.AgentClickOnReadMoreNewsButton();
    }

    // endregion


    // region Get Data from File Implementation

    // Get Herd Number from Database Store in File and enter value from particular row in the field
    @Then("Staff Enter Value as Herd Number with Payments from row {int} in the {string} field")
    public void StaffEnterHerdWithPaymentsFromParticularRowInFileInField(int Value, String FieldName) throws InterruptedException, IOException {
        // FilePaths
        String HerdWithPayments = "./src/main/resources/TestData/Herd With Payments.xls";
        bpsdashboardPage.StaffEnterValueInTextBox(FieldName, databaseQueriesPage.GetHerdNumberFromSpecifiedFile(Value,HerdWithPayments));
    }

    @Then("Staff Enter Value as Herd Number with Submission from row {int} in the {string} field")
    public void StaffEnterHerdWithSubmissionsFromParticularRowInFileInField(int Value, String FieldName) throws InterruptedException, IOException {
        // FilePaths
        String HerdWithSubmissions = "./src/main/resources/TestData/Herd With Submissions.xls";
        bpsdashboardPage.StaffEnterValueInTextBox(FieldName, databaseQueriesPage.GetHerdNumberFromSpecifiedFile(Value,HerdWithSubmissions));
    }

    @Then("Staff Enter Value as Herd Number with Submission and Penalty from row {int} in the {string} field")
    public void StaffEnterHerdWithSubmissionsAndPenaltyFromParticularRowInFileInField(int Value, String FieldName) throws InterruptedException, IOException {
        // FilePaths
        String HerdWithSubmissionsAndPenalty = "./src/main/resources/TestData/Herd With Submissions and Penalty.xls";
        bpsdashboardPage.StaffEnterValueInTextBox(FieldName, databaseQueriesPage.GetHerdNumberFromSpecifiedFile(Value,HerdWithSubmissionsAndPenalty));
    }

    @Then("Staff Enter Value as LPIS Parcel Number from row {int} in the {string} field")
    public void StaffEnterLPISParcelsFromParticularRowInFileInField(int Value, String FieldName) throws InterruptedException, IOException {
        // FilePaths
        String LPISParcels = "./src/main/resources/TestData/LPIS Parcels.xls";
        bpsdashboardPage.StaffEnterValueInTextBox(FieldName, databaseQueriesPage.GetHerdNumberFromSpecifiedFile(Value,LPISParcels));
    }

    @Then("Staff Enter Value as Reference Number from row {int} in the {string} field")
    public void StaffEnterReferenceNumberFromParticularRowInFileInField(int Value, String FieldName) throws InterruptedException, IOException {
        // FilePaths
        String ReferenceNumbers = "./src/main/resources/TestData/Reference Number with 2023 Applications.xls";
        bpsdashboardPage.StaffEnterValueInTextBox(FieldName, databaseQueriesPage.GetHerdNumberFromSpecifiedFile(Value,ReferenceNumbers));
    }

    @Then("Staff Enter Value as Herd Number with Submission and SIM opted in from row {int} in the {string} field")
    public void StaffEnterHerdWithSubmissionsAndSimOptedInFromParticularRowInFileInField(int Value, String FieldName) throws InterruptedException, IOException {
        // FilePaths
        String HerdWithPaymentsAndSimOptedIn = "./src/main/resources/TestData/Herd With Submissions and SIM Opted In.xls";
        bpsdashboardPage.StaffEnterValueInTextBox(FieldName, databaseQueriesPage.GetHerdNumberFromSpecifiedFile(Value,HerdWithPaymentsAndSimOptedIn));
    }

    @Then("Staff Enter Value as Herd Number with Submission and no Amendment from row {int} in the {string} field")
    public void StaffEnterHerdWithSubmissionsAndNoAmendFromParticularRowInFileInField(int Value, String FieldName) throws InterruptedException, IOException {
        // FilePaths
        String HerdWithPaymentsAndNoAmend = "./src/main/resources/TestData/Herd With Submissions and No Amend.xls";
        bpsdashboardPage.StaffEnterValueInTextBox(FieldName, databaseQueriesPage.GetHerdNumberFromSpecifiedFile(Value,HerdWithPaymentsAndNoAmend));
    }

    @Then("Staff Enter Value as Herd Number with Admin Check Not Started from row {int} in the {string} field")
    public void StaffEnterHerdWithAdminCheckNotStartedFromParticularRowInFileInField(int Value, String FieldName) throws InterruptedException, IOException {
        // FilePaths
        String HerdWithSubmissionsAndAdminCheckNotStarted = "./src/main/resources/TestData/Herd With Submissions and No Admin Check.xls";
        bpsdashboardPage.StaffEnterValueInTextBox(FieldName, databaseQueriesPage.GetHerdNumberFromSpecifiedFile(Value,HerdWithSubmissionsAndAdminCheckNotStarted));
    }

    @Then("Staff Enter Value as Herd Number with Query Letter Not Started from row {int} in the {string} field")
    public void StaffEnterHerdWithQueryLetterNotStartedFromParticularRowInFileInField(int Value, String FieldName) throws InterruptedException, IOException {
        // FilePaths
        String HerdWithSubmissionsAndQueryLetterNotStarted = "./src/main/resources/TestData/Herd With Submissions and No Query Letter.xls";
        bpsdashboardPage.StaffEnterValueInTextBox(FieldName, databaseQueriesPage.GetHerdNumberFromSpecifiedFile(Value,HerdWithSubmissionsAndQueryLetterNotStarted));
    }

    // endregion

    // region Staff BISS Code
    @When("Staff Click on {string} Quick Link in Navbar")
    public void StaffClickOnQuickLink(String QuickLink) throws InterruptedException {
        bpsdashboardPage.StaffClickOnQuickLinks(QuickLink);
        Thread.sleep(5000);
    }


    @When("Staff Click on {string} Link in Navbar")
    public void StaffClickOnSideNavLink(String MenuItem) throws InterruptedException {
        bpsdashboardPage.StaffClickOnSideNavQuickLink(MenuItem);
        Thread.sleep(5000);
    }

    @When("Check if Admin Inspection is Completed after clicking On the {string} table {string} link number {int}")
    public void staffChecksIfAdminInspectionIsCompletedError(String table, String viewOrAmend, int num) throws InterruptedException {
        bpsdashboardPage.staffChecksIfAdminInspectionIsCompletedError(table, viewOrAmend, num);
    }

    @Then("Staff click on Coordination or Coordination Amendment Link in Navbar")
    public void staffClickOnCoordinationOrCoordinationAmendmentLinkInNavbar() throws InterruptedException {
        bpsdashboardPage.staffClickOnCoordinationOrCoordinationAmendmentLinkInNavbar();
        Thread.sleep(5000);
    }

    @Then("Staff CLick on Parcel No Header in AMS Screen")
    public void StaffClickParcelNoHeader() throws InterruptedException {
        Thread.sleep(2000);
        bpsdashboardPage.StaffClickOnParcelNoHeader();
    }

    @And("Staff Check if element {string} is present")
    public void StaffCheckElementPresent(String Element) throws InterruptedException{
        Assert.assertFalse(bpsdashboardPage.StaffCheckIfElementPresent(Element));
    }


    @And("Staff Check if dropdown {string} is present")
    public void StaffCheckDropdownPresent(String Element) throws InterruptedException{
        Thread.sleep(3000);
        Assert.assertFalse(bpsdashboardPage.StaffCheckIfDropdownPresent(Element));
    }

    @Then("Staff Check {string} Link not Present in Navbar")
    public void StaffCheckNavLinkNotPresent(String MenuItem) throws InterruptedException {
        Assert.assertTrue(bpsdashboardPage.StaffCheckIfSideNavLinkIsNotPresent(MenuItem));
        Thread.sleep(2000);
    }

    @Then("Staff Check {string} Link Present in Navbar")
    public void StaffCheckNavLinkPresent(String MenuItem) throws InterruptedException {
        Assert.assertFalse(bpsdashboardPage.StaffCheckIfSideNavLinkIsNotPresent(MenuItem));
        Thread.sleep(2000);
    }

    @Then("Staff Click on {string} Tab in Application Search Page")
    public void StaffSwitchTabInApplicationSearch(String Tab) throws InterruptedException {
        bpsdashboardPage.StaffSwitchDashboardTabs(Tab);
        Thread.sleep(3000);
    }

    @Then("Staff Click on {string} Tab in Herd Dashboard Page")
    // Tabs : Application Summary, Active Farmer Status, Land Details, GAEC 8, Digitisation Tasks
    public void StaffSwitchTabInHerdDashboard(String Tab) throws InterruptedException {
        bpsdashboardPage.StaffSwitchDashboardTabs(Tab);
        Thread.sleep(3000);
    }

    @Then("Staff Click on {string} Tab in Pattern Matching Page")
    public void StaffSwitchTabInPatternMatching(String Tab) throws InterruptedException {
        bpsdashboardPage.StaffSwitchDashboardTabs(Tab);
        Thread.sleep(3000);
    }

    @When("Staff Click on {string} Link")
    public void StaffClickCheckPaymentLink(String Link) throws InterruptedException {
        bpsdashboardPage.StaffClickOnLinkInList(Link);
        Thread.sleep(5000);
    }

    @When("Staff Click On First View Link In List")
    public void StaffClickOnFirstViewLink() {
        bpsdashboardPage.StaffClickOnViewLinkInList();
    }

    @And("Staff Enter {string} value as {string}")
    public void StaffEnterInputValue(String Field , String Value) {
        bpsdashboardPage.StaffEnterValue(Field, Value);
    }

    @Then("Staff Select {string} dropdown value as {string}")
    public void StaffSelectDropdownValue(String Dropdown, String Value) throws InterruptedException {
        bpsdashboardPage.StaffChangeDropdownValue(Dropdown,Value);
        Thread.sleep(2000);
    }

    @Then("Staff Change the {string} no formcontrolname dropdown value as {string}")
    public void StaffSelectNoFormcontolNameDropdownValue(String Dropdown, String Value) throws InterruptedException {
        bpsdashboardPage.StaffChangeDropdownValue(Dropdown,Value);
        Thread.sleep(2000);
    }

    @Then("Staff Change the {string} query letter dropdown value as {string}")
    public void StaffSelectQueryLetterDropdownValue(String Dropdown, String Value) throws InterruptedException {
        bpsdashboardPage.StaffChangeQueryLetterDropdownValue(Dropdown,Value);
        Thread.sleep(2000);
    }

    @And("Staff Change the {string} Multi Option Dropdown Value")
    public void StaffSelectMultiOptionDropdownValue(String Dropdown) throws InterruptedException {
        bpsdashboardPage.StaffChangeValueForMultiOptionDropdown(Dropdown);
    }

    @And("Staff Open and Close the {string} Multi Option Dropdown Value")
    public void StaffOpenAndCloseMultiOptionDropdownValue(String Dropdown) throws InterruptedException {
        bpsdashboardPage.StaffOpenAndCloseMultiSelectDropdown(Dropdown);
    }

    @And("Staff Select All the {string} Multi Option Dropdown Values")
    public void StaffSelectAllMultiOptionDropdownValues(String Dropdown) throws InterruptedException {
        bpsdashboardPage.StaffSelectAllOptionsForMultiOptionDropdown(Dropdown);
        Thread.sleep(5000);
    }

    @Then("Staff Click on the {string} button")
    public void StaffClickOnButton(String Button) throws InterruptedException {
        Thread.sleep(2000);
        bpsdashboardPage.StaffClickOnButton(Button);
        Thread.sleep(4000);
    }

    @And("Staff Click on {string} Scheme Selection Card")
    public void StaffClickOnSchemeSelectionCard(String Scheme) {
        bpsdashboardPage.StaffClickOnSchemeSelectionCard(Scheme);
    }

    @Then("Staff Check if {string} Scheme Selected")
    public void StaffCheckIfSchemeSelected(String Scheme) throws InterruptedException {
        Thread.sleep(2000);
        bpsdashboardPage.StaffCheckIfSchemeCardSelected(Scheme);
    }

    @And("Staff Check if card has title as {string} and {string} is the abbreviation")
    public void StaffCheckTitleandAbbreviation(String Title, String Abbreviation) {
        bpsdashboardPage.StaffCheckCardTitleAndAbbreviation(Title, Abbreviation);
    }

//    @Then("Staff Click on the {string} green border button")
//    public void StaffClickOnGreenBorderButton(String Button) throws InterruptedException {
//        Thread.sleep(2000);
//        bpsdashboardPage.StaffClickOnGreenBorderButton(Button);
//        Thread.sleep(2000);
//    }

    @Then("Staff check TickMark for {string} Scheme")
    public void StaffCheckTickMark(String Scheme) throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertFalse(bpsdashboardPage.StaffCheckAppliedTickMarkForScheme(Scheme));
        System.out.println("The tick mark is present for "+Scheme+" scheme selected : " + !bpsdashboardPage.StaffCheckAppliedTickMarkForScheme(Scheme));
    }

    @Then("Staff check no TickMark for {string} Scheme")
    public void StaffCheckNoTickMark(String Scheme) throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(bpsdashboardPage.StaffCheckAppliedTickMarkForScheme(Scheme));
        System.out.println("The tick mark is present for "+Scheme+" scheme selected : " + !bpsdashboardPage.StaffCheckAppliedTickMarkForScheme(Scheme));
    }

    @When("Staff use the {string} Quick Filter")
    // Locators Arg "QA_VIEW_ALL" , "QA_VIEW_ALL", "QA_ONE_DUE" , "QA_ONE_PASSED" , "QA_ONE_FAILED" , "QA_TWO_DUE" , "QA_TWO_PASSED" , "QA_TWO_FAILED"
    public void StaffUseQuickFilters(String Filter) {
        bpsdashboardPage.StaffSelectQuickFilters(Filter);
    }

    @Then("Staff select {string} value as {string}")
    // Dropdowns : Arg sapRunFileId, paymentQaType , county
    public void StaffSelectPQADropdownValue (String Dropdown, String Value) {
        bpsdashboardPage.StaffSelectDropdownValue(Dropdown, Value);
    }

    @Then("Staff Type Rejection Reason as {string}")
    public void StaffTypeRejectReason(String Reason){
        bpsdashboardPage.StaffTypeRejectionReason(Reason);
    }

    @Then("Staff Type Text as {string} in {string} Query Letters TextArea")
    public void StaffTypeQueryLetterComments(String Comment, String Box){
        bpsdashboardPage.StaffTypeQueryLetterComments(Box,Comment);
    }

    @When("Staff Click On the {string} Panel in Errors Screen")
    public void StaffClickOnPanelInErrorScreen(String PanelName) throws InterruptedException {
        bpsdashboardPage.StaffClickOnErrorsPanel(PanelName);
    }

    @Then("Staff Get Parcel Numbers")
    public void StaffGetParcelNumbers() throws InterruptedException {
        bpsdashboardPage.StaffGetErrorParcelNumber();
        Thread.sleep(3000);
    }

    @And("Staff Select {string} as the Reason for Reduction in Admin Inspection Page")
    public void StaffSelectReductionReason(String Reason) throws InterruptedException {
        bpsdashboardPage.StaffSelectReasonforReduction(Reason);
    }

    @Then("Staff zoom out of screen thrice")
    public void StaffZoomOutOfScreen() throws InterruptedException, AWTException {
        bpsdashboardPage.StaffReduceResolutionOfScreen();
        Thread.sleep(10000);
    }

    @Then("Staff zoom out of screen {string} times")
    public void StaffZoomOutOfScreenNumberofTimes(String times) throws InterruptedException, AWTException {
        bpsdashboardPage.StaffReduceResolutionOfScreenNumberOfTimes(times);
    }

    @And("Click on Dialog Box {string} Button")
    public void StaffClickOnDialogBoxButton(String ButtonName) {
        bpsdashboardPage.AgentClickOnButtonInDialog(ButtonName);
    }

    @And("Staff switch to the {string} tab")
    public void StaffSwitchTab(String TabName) throws InterruptedException {
        bpsdashboardPage.StaffClickOnTabInDashboard(TabName);
        Thread.sleep(6000);
    }

    @And("Staff switch to the {string} tab in Correspondence Header")
    public void StaffSwitchTabInCorrespondanceHeader(String TabName) throws InterruptedException {
        bpsdashboardPage.StaffClickOnTabInCorrespondanceHeader(TabName);
        Thread.sleep(6000);
    }

    @Then("Staff Check {string} Tab Visibility")
    public void StaffCheckTabvisibility(String TabName) {
        Assert.assertTrue(bpsdashboardPage.StaffCheckTabInDashboard(TabName));
    }

    @And("Staff Select {string} as Map Printing Type")
    public void StaffSelectMapPrintingType(String Type) {
        bpsdashboardPage.StaffSelectMapPrintingType(Type);
    }

    @And("Staff Select {string} as Search By Type")
    public void StaffSelectSearchByType(String Type) {
        bpsdashboardPage.StaffSelectTheSearchByType(Type);
    }

    @Then("Staff Enter Value as {string} in the {string} field")
    public void StaffEnterValueInField(String Value, String FieldName) throws InterruptedException {
        bpsdashboardPage.StaffEnterValueInTextBox(FieldName,Value);
    }

    @Then("Agent Search for Herd Number Field and Enter Herd as {string}")
    public void AgentSearchForHerdNumber(String Arg0) throws InterruptedException {
        Thread.sleep(4000);
        bpsdashboardPage.AgentSearchForHerdField(Arg0);
        Thread.sleep(3000);
    }

    // region Scheme Selection
    @Then("Staff Get Title of Scheme Selection Card {string} and check if it is {string}")
    public void StaffCheckTitleOfSchemeCards(String CardNumber, String CardName) {
        Assert.assertEquals(bpsdashboardPage.StaffGetSchemeSelectionCardTitle(CardNumber),CardName);
    }

    @And("Staff Get Acronym Full Form of Scheme Selection Card {string} and check if it is {string}")
    public void StaffCheckContentOfSchemeCards(String CardNumber, String CardName) {
        Assert.assertEquals(bpsdashboardPage.StaffGetSchemeSelectionCardAcronymExpansion(CardNumber),CardName);
    }

    @Then("Staff Click on the {string} Scheme Card View Details Link")
    public void StaffClickOnViewDetailsLinkOnSchemeCard(String Scheme) {
        bpsdashboardPage.StaffClickOnViewDetailsLinkForSchemeCard(Scheme);
    }

    @And("Staff get {string} View Details Dialog Content")
    public void StaffGetAllViewDetailsDialogContent(String Scheme) {
        bpsdashboardPage.StaffGetViewDetailsDialogContent(Scheme);
    }

    @Then("Staff check if toggle present for {string} scheme")
    public void StaffCheckIfTogglePresentForScheme(String Scheme) {
        bpsdashboardPage.StaffCheckSwitchToggleForSchemeCards(Scheme);
    }

    @And("Staff Check if {string} scheme is selected or not selected")
    public void StaffCheckIfSchemeSelectedAndOptedIn(String Scheme) {
        bpsdashboardPage.StaffCheckIfSchemeSelected(Scheme);
    }

    @And("Staff Capture Screenshot of Scenario")
    public void StafffCaptureScreenshotOfScenario() {
//        bpsdashboardPage.StaffCaptureScreenshotOfScenario();
    }
    // endregion

    // region DB Stepdef

    // Get Herd Number from Database and enter in the field
    @Then("Staff Enter Value as Herd Number {int} in the {string} field")
    public void StaffEnterHerdFromDBInField(int Value, String FieldName) throws InterruptedException, IOException {
        bpsdashboardPage.StaffEnterValueInTextBox(FieldName, databaseQueriesPage.GetHerdNumberFromFile(Value));
    }

    // Get Parcel Number from Database and enter in the field
    @Then("Staff Enter Value as Parcel Number {int} in the {string} field")
    public void StaffEnterParcelFromDBInField(int Value, String FieldName) throws InterruptedException, IOException {
        bpsdashboardPage.StaffEnterValueInTextBox(FieldName, databaseQueriesPage.GetHerdNumberFromFile(Value));
    }
    
    // endregion


    @Then("Staff check if Generate Map Setting Section visible")
    public void StaffCheckGenerateMapSectionVisbility() {
        bpsdashboardPage.StaffCheckIfGenerateMapSettingsPresent();
    }

    @And("Staff Click On Legend Indicator CheckBox")
    public void StaffClickOnLegendIndicatorCheckBox() throws InterruptedException {
        bpsdashboardPage.StaffClickOnPrintLegendCheckBox();
    }

    @Then("Staff Check {string} Error Message")
    public void StaffCheckErrorMessage(String Error) throws InterruptedException {
        Assert.assertTrue(bpsdashboardPage.StaffCheckHerdRequiredError(Error));
        System.out.println(bpsdashboardPage.StaffCheckHerdRequiredError(Error));
        Thread.sleep(3000);
    }

    @Then("Staff Check {string} Error Message without span")
    public void StaffCheckErrorMessageWithoutSpan(String Error) throws InterruptedException {
        Assert.assertTrue(bpsdashboardPage.StaffCheckErrorWithNoSpan(Error));
        System.out.println(bpsdashboardPage.StaffCheckErrorWithNoSpan(Error));
        Thread.sleep(3000);
    }

    @And("Staff Check No Results Warning Message")
    public void StaffCheckNoResultsWarning() {
        Assert.assertTrue(bpsdashboardPage.StaffCheckNoParcelsWarning());
    }

    @And("Staff check if {string} of herd is {string}")
    public void StaffCheckNameAndAddressOfHerd(String Detail, String NameOrAddress) {
        Assert.assertEquals(bpsdashboardPage.StaffCheckHerdDetails(Detail), NameOrAddress);
    }

    @And("Staff print {string} of the herd")
    public void StaffCheckNameAndAddressOfHerd(String Detail) {
        System.out.println(bpsdashboardPage.StaffCheckHerdDetails(Detail));
    }

    @And("Staff Check the {string} of Generated Map")
    public void StaffCheckDetailsOfGeneratedMap(String Detail) throws InterruptedException {
        System.out.println(Detail+" : "+bpsdashboardPage.StaffCheckGeneratedMapDetails(Detail));
        //Thread.sleep(4000);
    }

    @Then("Staff Click On {string} Pagination Button")
    public void StaffClickOnPaginationButton(String ButtonName) throws InterruptedException {
        bpsdashboardPage.StaffClickOnPaginationButtons(ButtonName);
        Thread.sleep(2000);
    }

    @Then("Staff Click On First Ready to Download Link")
    public void StaffclickOnDownloadLink() throws InterruptedException {
        bpsdashboardPage.StaffClickOnReadytoDownload();
        Thread.sleep(4000);
    }

    @And("Staff Check the final status of Generated Map")
    public void StaffCheckStatusOfHerd() throws InterruptedException {
        Thread.sleep(10000);
        System.out.println("Final Status : "+bpsdashboardPage.StaffCheckReadyToDownloadStatus());
    }

    @And("Staff Scroll to Documents Section")
    public void StaffScrollToDocSection() throws InterruptedException {
        bpsdashboardPage.StaffScrollToDocumentSection();
        Thread.sleep(5000);
    }

    @Then("Staff Click on Agent Row in SSO Admin Search")
    public void StaffClickOnAgentRow() throws InterruptedException {
        bpsdashboardPage.StaffClickOnRowInSSOAdminPage();
        Thread.sleep(2000);
    }

    @And("Staff Switch To {string} Tab for user")
    public void StaffSwitchTabForUser(String TabName) {
        bpsdashboardPage.SwitchTabsForUser(TabName);
    }

    @And("Staff Switch To {string} Authorisation Tab")
    public void StaffSwitchAuthorisationTab(String TabName) throws InterruptedException {
        bpsdashboardPage.SwitchAuthorisationTabs(TabName);
        Thread.sleep(2000);
    }

    @Then("Staff Select {string} as Application value")
    public void StaffSelectApplicationValue(String Value) throws InterruptedException {
        bpsdashboardPage.StaffSelectApplication(Value);
        Thread.sleep(4000);
    }

    @When("Staff Filter {string} User Role")
    public void StaffFilterUserRole(String Role) throws InterruptedException {
        bpsdashboardPage.StaffFilterUserRole(Role);
        Thread.sleep(2000);
    }

    @Then("Staff Select {string} User Role")
    public void StaffSelectUserrole(String Role) throws InterruptedException {
        bpsdashboardPage.StaffSelectUserRole(Role);
        Thread.sleep(2000);
    }

    @And("Staff Select alll Roles on {string} side box")
    public void StaffSelectAllRoles(String Side) {
        bpsdashboardPage.StaffSelectAllRoles(Side);
    }

    @And("Staff click on {string} SSO Button")
    public void StaffClickOnMoveButton(String MoveButton) throws InterruptedException {
        bpsdashboardPage.StaffMoveRolesBetweenAvailableAndAssigned(MoveButton);
        Thread.sleep(5000);
    }

    @Then("Staff Click On {string} Link")
    public void StaffClickOnExitapplicationLink(String Link) throws InterruptedException {
        bpsdashboardPage.StaffClickOnExitApplicationLink(Link);
        Thread.sleep(2000);
    }

    @Then("Staff Click On SignOut Button")
    public void StaffClickOnSignOutLink() {
        bpsdashboardPage.StaffClickOnSignOutButton();
    }

    @Then("Staff Check Admin Inspection Status")
    public void StaffCheckAdminInspectionStatus() {
        Assert.assertEquals(bpsdashboardPage.StaffCheckInspectionApplicationStatus(),"Completed");
        System.out.println("Inspection Status : " + bpsdashboardPage.StaffCheckInspectionApplicationStatus());
    }

    @Then("Staff Click on {string} SIM parcel to open side drawer")
    public void StaffClickOnSIMParcelToOpenSideDrawer(String Parcel) {
        bpsdashboardPage.StafClickSIMParcelToOpenSideDrawer(Parcel);
    }

    @When("Staff Enter value as {string} in the {string} SIM side drawer field")
    public void StaffEnterValueInSimEditDrawerField(String Value, String Field) {
          bpsdashboardPage.StaffEnterValueInSIMEditDrawerField(Value, Field);
    }

    @Then("Staff Check Value of the Original Application Total")
    public void  StaffCheckOriginalApplicationTotalValue() {
        bpsdashboardPage.StaffCheckOriginalApplicationTotal();
    }

    @Then("Staff Click On the {string} Checkbox in the SIM Parcel Edit Drawer")
    public void StaffClickOnSIMEditDrawerCheckBox(String Checkbox) throws InterruptedException {
        bpsdashboardPage.AgentClickOnSIMEditDrawerCheckBox(Checkbox);
    }

    @And("Staff Toggle Sim option")
    public void StaffToggleSIMOption() throws InterruptedException {
        Thread.sleep(5000);
        bpsdashboardPage.StaffToggleSIMOption();
    }

    @Then("Staff Enter Sim Notes as {string}")
    public void StaffEnterSimNotes(String Note) {
        bpsdashboardPage.StaffChangeSimNotesBeforeSubmitting(Note);
    }

    @And("Staff Check History Tab for Activity")
    public void StaffCheckHistoryTabActivity() throws InterruptedException {
        System.out.println(bpsdashboardPage.StaffCheckEntryInHistoryTab());
        Thread.sleep(8000);
    }

    @And("Staff verify Admin Check Entry is {string} in History Screen")
    public void StaffCheckAdminCheckEntryInHistoryTab(String Message) {
        Assert.assertEquals(bpsdashboardPage.StaffCheckAdminCheckEntry(Message),Message);
    }

    @Then("Staff Select {string} option as Admin Check Result")
    public void StaffSelectAdminResult(String Result) {
        bpsdashboardPage.StaffSelectAdminCheckResultRadio(Result);
    }

    @Then("Staff Check SIM Tick on BISS Application Summary Screen")
    public void StaffCheckSIMTickVisibility() {
        if (bpsdashboardPage.StaffCheckSIMtick()) {
            System.out.println("SIM Tick not present");
        }
        else {
            System.out.println("SIM Tick present");
        }
    }

    @And("Staff Check SIM Calculated Payable Area")
    public void StaffCheckCalculatedPayableArea() {
        bpsdashboardPage.StaffCheckCalculatedPayableArea();
    }

    // region Active Farmer Section Steps
    @And("Staff Select {string} as Admin Check Result")
    public void StaffSelectAdminCheckResult(String Result) throws InterruptedException {
        Thread.sleep(3000);
        bpsdashboardPage.StaffSelectAdminCheckResult(Result);
    }

    @Then("Staff Enter {string} as Admin Notes")
    public void StaffEnterAdminNotes(String Note) {
        bpsdashboardPage.StaffEnterTextInAdminNotes(Note);
    }



    // endregion

    // endregion
}
