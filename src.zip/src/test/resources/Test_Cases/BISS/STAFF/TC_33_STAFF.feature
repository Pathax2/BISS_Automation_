Feature: TC_S33 - Regression Pack for Prevent SIM Indicator when Crop is Not SIM

  # ──────────────────────────────────────────────────────────────────────────
  # Purpose:
  #   Validates that the SIM indicator cannot be selected when the crop is not SIM,
  #   and verifies Eco scheme toggle behaviour for the same herds. Covers:
  #     - TC01: Open BISS Amendments for L1161200 (2023) and verify Eco card is accessible
  #     - TC02: Toggle Eco for L1161200 (2023) then A1140364 (2024) — submit both
  #
  # Common Background:
  #   Staff login as agr4442 → open BISS application.
  #
  # DB Data:
  #   No DB pool step required. Fixed herds L1161200 and A1140364 have known states.
  #
  # Notes:
  #   1. TC01 (from the first legacy Prevent SIM file, BISSAGL-14676) navigates
  #      to BISS Amendments for L1161200 and opens the Eco card only — no submission.
  #   2. TC02 (BISSAGL-14675) performs the full Eco toggle and submit cycle.
  #   3. The SIM indicator prevention behaviour is implicitly covered by the
  #      Eco scheme toggle — if SIM indicator could be toggled for a non-SIM crop
  #      it would surface during the amendment flow.
  #
  # Author  : Aniket Pathare | aniket.pathare@government.ie
  # Created : 2026-05-14
  # ──────────────────────────────────────────────────────────────────────────

  Background:
    Given the staff user is on the staff login page
    When the staff user logs in with username "agr4442"
    And the staff user selects the data protection checkbox and clicks login
    And the staff user opens the "Basic Income Support for Sustainability" application

  @tmsLink=BISSAGL-14676 @tmsLink=BISSAGL-14675 @regression
  Scenario: TC_S33 - Prevent SIM Indicator when Crop Not SIM end-to-end regression

    # ── TC01: Navigate to BISS Amendments for L1161200 (2023) — Eco card accessible
    When the staff user searches for herd "L1161200" for scheme year "2023" and opens the BISS Amendments
    Then the Eco Scheme Selection Card should be visible and accessible

    # ── TC02: Toggle Eco for L1161200 (2023) and A1140364 (2024) — submit both ─
    When the staff user toggles the Eco scheme card and submits the amendment for herd "L1161200"
    Then the scheme panel summary should reflect the updated Eco state
    When the staff user searches for herd "A1140364" for scheme year "2024" and opens the BISS Amendments
    And the staff user toggles the Eco scheme card and submits the amendment
    Then the scheme panel summary should reflect the updated Eco state for herd "A1140364"
