//package com.stepdefinitions;
//
//import com.base.ConfigReader;
//import com.base.DriverManager;
////import com.base.ExcelReader;
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
//import org.openqa.selenium.WebDriver;
//
//import java.io.IOException;
//import java.util.List;
//import java.util.Map;
//import java.util.Properties;
//
//public class ContactUs
//{
//    Properties prop;
//    WebDriver driver;
//    ConfigReader configReader;
//
//    public ContactUs(DriverManager driverManager){
//        try {
//            driver = driverManager.getDriver();
//            configReader = new ConfigReader();
//            prop = configReader.init_prop();
//        }
//        catch (Exception e){
//            e.printStackTrace();
//        }
//    }
//
//    @Given("user navigates to contact us page")
//    public void user_navigates_to_contact_us_page()    {
//
////    driver.get("http://automationpractice.com/index.php?controller=contact");
//    }
//
//        @When("user fills the form from given sheetname {string} and rownumber {int}")
//        public void user_fills_the_form_from_given_sheetname_and_rownumber(String sheetName, Integer rowNumber) throws InvalidFormatException, IOException, InterruptedException
//        {
//            configReader = new ConfigReader();
//            prop = configReader.init_prop();
//            ExcelReader reader = new ExcelReader();
//            List<Map<String,String>> testData =
//                    reader.getData(prop.getProperty("excelpath"), sheetName);
//
//            String email = testData.get(rowNumber).get("email");
//            String orderRef = testData.get(rowNumber).get("reference");
//            String messageText = testData.get(rowNumber).get("messageText");
//
//            System.out.println(email + orderRef + messageText);
//
////    contactUsPage.fillContactUsForm(email, orderRef, messageText);
//        }
//
//        @When("user clicks on send button")
//        public void user_clicks_on_send_button()
//        {
////    contactUsPage.clickSend();
//        }
//
//        @Then("it shows a successful message {string}")
//        public void it_shows_a_successful_message(String expSuccessMessage)
//        {
//
//
//        }
//
//    }
