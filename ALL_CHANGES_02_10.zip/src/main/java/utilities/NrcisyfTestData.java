// ===================================================================================================================================
// File          : NrcisyfTestData.java
// Package       : utilities
// Description   : Runtime herd + agent for the NR/CISYF (Young Farmer) test cases: TC_13, TC_15, TC_16, TC_21 to TC_25_ENTS.
//
//                 Every NR/CISYF submission needs a herd that has NO NR/CISYF application yet, plus the agent who
//                 manages it. After a submission the herd shows "View Application" instead of Apply / Edit, so the next
//                 section needs another herd. This class hands those herds out, in this order:
//
//                   1. Test Data Vault pool ENTS_YOUNG_FARMER (filled by TC_00_DATA) - no query at all.
//                      A herd of the agent who is already logged in is preferred, so the test can carry on without a
//                      logout and login.
//                   2. Live query "ENTS Young Farmer herds" (Simon's Young Farmer query, ENTS database) - run once per
//                      run, the rows are kept in memory and stored in the vault for the next run.
//                   3. Nothing found: null. The callers (Hooks @tc13, TC_13_ENTS recovery) then use their old
//                      BISS_DATA + BISS_INET lookup, unchanged from Selenium.
//                 nrcisyf.herd.source=legacy skips 1 and 2 (the Selenium behaviour).
//
//                 Status of a herd in the vault (pool ENTS_YOUNG_FARMER is never reused, see data.reuse.pools):
//                   picked                   -> RESERVED
//                   submitted                -> USED   (markSubmitted)
//                   saved as draft           -> USED   (markSavedDraft - it now has an application)
//                   already had View Application when opened -> BAD (markAlreadySubmitted)
//                   not in the agent's NR/CISYF list -> BAD (markNotListed)
//                   picked but not touched, test case passed -> AVAILABLE again (releaseUntouched, from Hooks)
//                 A herd submitted in THIS run is remembered (lastSubmitted), so the post-submission section of TC_13
//                 opens that herd instead of querying for a submitted one.
//
//                 No browser code here - the step definitions do the clicking.
//
// Author        : Aniket Pathare | aniket.pathare@government.ie
// Date Created  : 02-10-2026
// ===================================================================================================================================

package utilities;

import commonFunctions.CommonFunctions;
import database.DBRouter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public final class NrcisyfTestData
{
    private static final String LOG = "[NRCISYF-DATA] ";

    // Herds handed out in this run (any source) - never handed out twice
    private static final Set<String> TAKEN_THIS_RUN     = new HashSet<>();
    // Herds submitted in this run - their "View Application" is expected, not a data problem
    private static final Set<String> SUBMITTED_THIS_RUN = new HashSet<>();
    // Herds saved as draft or marked bad in this run - never released back to AVAILABLE
    private static final Set<String> DONE_THIS_RUN      = new HashSet<>();
    // Rows of the live query, kept for the run: {herd, login}
    private static       List<String[]> LIVE_ROWS = null;
    // Last herd + agent submitted in this run
    private static       String[] LAST_SUBMITTED = null;

    private NrcisyfTestData() { }


    // ***************************************************************************************************************************************************************************************
    // Function Name : isEnabled
    // Description   : False when nrcisyf.herd.source=legacy - the callers then use their Selenium lookup only.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 02-10-2026
    // ***************************************************************************************************************************************************************************************
    public static boolean isEnabled()
    {
        return !"legacy".equalsIgnoreCase(ConfigManager.getOrDefault("nrcisyf.herd.source", "youngfarmer").trim());
    }


    // ***************************************************************************************************************************************************************************************
    // Function Name : nextHerd
    // Description   : Next herd with no NR/CISYF application and its agent: vault first, then the live query.
    // Parameters    : pPreferLogin    (String) - agent already logged in; one of their herds is taken when there is one
    //                 pExcludeHerds   (Set)    - e.g. Hooks.BLACKLISTED_HERDS (may be null)
    //                 pExpiredLogins  (Set)    - e.g. Hooks.EXPIRED_AGENTS (may be null)
    //                 pPurpose        (String) - for the vault and the log, e.g. "@tc13 hook"
    // Returns       : String[] {herd, agent login}, or null when neither source has one (caller falls back to legacy)
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 02-10-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized String[] nextHerd(String pPreferLogin, Set<String> pExcludeHerds, Set<String> pExpiredLogins, String pPurpose)
    {
        if (!isEnabled()) return null;

        String iPrefer   = pPreferLogin == null ? "" : pPreferLogin.trim();
        String iTestCase = System.getProperty("testcase", "");

        // -- 1. Vault ---------------------------------------------------------------------------------------------------
        if (TestDataVault.isEnabled())
        {
            try
            {
                List<TestDataVault.Row> iRows = new ArrayList<>();
                for (TestDataVault.Row iRow : TestDataVault.available(TestDataVault.POOL_ENTS_YOUNG_FARMER, ""))
                {
                    if (usable(iRow.herd, iRow.login, pExcludeHerds, pExpiredLogins)) iRows.add(iRow);
                }
                if (!iRows.isEmpty())
                {
                    TestDataVault.Row iPick = preferLogin(iRows, iPrefer);
                    TestDataVault.reserveHerd(iPick.herd, iTestCase, "NR/CISYF " + n(pPurpose));
                    TAKEN_THIS_RUN.add(iPick.herd);
                    CommonFunctions.log.info(LOG + "From vault: herd=" + iPick.herd + " | agent=" + iPick.login
                            + (iPick.login.equalsIgnoreCase(iPrefer) ? " (same agent - no re-login needed)" : "")
                            + " | " + (iRows.size() - 1) + " available left [" + n(pPurpose) + "]");
                    return new String[]{ iPick.herd, iPick.login };
                }
                if (TestDataVault.hasPool(TestDataVault.POOL_ENTS_YOUNG_FARMER, ""))
                {
                    CommonFunctions.log.warning(LOG + "Vault pool ENTS_YOUNG_FARMER has no usable row left - running the Young Farmer query "
                            + "(run TC_00_DATA to refill the vault).");
                }
            }
            catch (Exception e)
            {
                CommonFunctions.log.warning(LOG + "Vault lookup failed (" + e.getMessage() + ") - running the Young Farmer query.");
            }
        }

        // -- 2. Live query (once per run) --------------------------------------------------------------------------------
        try
        {
            if (LIVE_ROWS == null) LIVE_ROWS = runQuery(ConfigManager.getInt("nrcisyf.pool.size", 200));

            List<String[]> iCandidates = new ArrayList<>();
            for (String[] iRow : LIVE_ROWS)
            {
                if (usable(iRow[0], iRow[1], pExcludeHerds, pExpiredLogins)) iCandidates.add(iRow);
            }
            if (iCandidates.isEmpty())
            {
                CommonFunctions.log.warning(LOG + "Young Farmer query has no usable herd left out of " + LIVE_ROWS.size()
                        + " - falling back to the BISS_DATA lookup.");
                return null;
            }

            Collections.shuffle(iCandidates, new Random(System.nanoTime()));
            String[] iPick = iCandidates.get(0);
            for (String[] iRow : iCandidates)
            {
                if (!iPrefer.isEmpty() && iRow[1].equalsIgnoreCase(iPrefer)) { iPick = iRow; break; }
            }
            TAKEN_THIS_RUN.add(iPick[0]);
            if (TestDataVault.isEnabled())
            {
                try { TestDataVault.reserveHerd(iPick[0], iTestCase, "NR/CISYF " + n(pPurpose)); }
                catch (Exception iIgnored) { }
            }
            CommonFunctions.log.info(LOG + "From the Young Farmer query: herd=" + iPick[0] + " | agent=" + iPick[1]
                    + " | " + (iCandidates.size() - 1) + " usable left [" + n(pPurpose) + "]");
            return iPick;
        }
        catch (Exception e)
        {
            CommonFunctions.log.warning(LOG + "Young Farmer query failed (" + e.getMessage() + ") - falling back to the BISS_DATA lookup.");
            return null;
        }
    }


    // ***************************************************************************************************************************************************************************************
    // Function Name : runQuery
    // Description   : Runs "ENTS Young Farmer herds" and returns {herd, login} rows. When the vault is on, the rows are
    //                 also stored as pool ENTS_YOUNG_FARMER so the next run finds them there.
    //                 nrcisyf.herds (comma separated, optional) limits the query to those herds - Simon's test list.
    // Parameters    : pLimit (int) - rows to fetch
    // Returns       : List of String[] {herd, login}
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 02-10-2026
    // ***************************************************************************************************************************************************************************************
    public static List<String[]> runQuery(int pLimit)
    {
        String iHerdList = ConfigManager.getOrDefault("nrcisyf.herds", "").trim();
        long   iStart    = System.currentTimeMillis();

        List<String[]>          iRows      = new ArrayList<>();
        List<TestDataVault.Row> iVaultRows = new ArrayList<>();
        for (Map<String, Object> iRow : DBRouter.query("ENTS", "ENTS Young Farmer herds", String.valueOf(pLimit), iHerdList))
        {
            String iHerd  = TestDataVault.text(iRow, "HERD_ID");
            String iLogin = TestDataVault.text(iRow, "LOGIN_ID").toLowerCase(Locale.ROOT);
            if (iHerd.isEmpty() || iLogin.isEmpty()) continue;
            iRows.add(new String[]{ iHerd, iLogin });
            iVaultRows.add(new TestDataVault.Row(TestDataVault.POOL_ENTS_YOUNG_FARMER, "", iHerd, "", "", iLogin));
        }

        CommonFunctions.log.info(LOG + "Young Farmer query: " + iRows.size() + " herd(s) in "
                + (System.currentTimeMillis() - iStart) / 1000 + " s" + (iHerdList.isEmpty() ? "" : " (limited to nrcisyf.herds)"));

        if (TestDataVault.isEnabled() && !iVaultRows.isEmpty())
        {
            try { TestDataVault.putPool(TestDataVault.POOL_ENTS_YOUNG_FARMER, "", iVaultRows); }
            catch (Exception e) { CommonFunctions.log.warning(LOG + "Could not store the rows in the vault: " + e.getMessage()); }
        }
        return iRows;
    }


    // ***************************************************************************************************************************************************************************************
    // Function Name : markSubmitted / markSavedDraft / markAlreadySubmitted / wasSubmittedThisRun / lastSubmitted
    // Description   : Vault status after the NR/CISYF flow, and the memory of the last submission.
    //                 markAlreadySubmitted ignores herds submitted in this run - their View Application is expected.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 02-10-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized void markSubmitted(String pHerd, String pLogin)
    {
        if (pHerd == null || pHerd.isBlank()) return;
        SUBMITTED_THIS_RUN.add(pHerd.trim());
        LAST_SUBMITTED = new String[]{ pHerd.trim(), pLogin == null ? "" : pLogin.trim() };
        vault(() -> TestDataVault.markUsedFinal(pHerd.trim(), "NR/CISYF application submitted"));
        CommonFunctions.log.info(LOG + "Submitted: herd=" + pHerd.trim() + " | agent=" + LAST_SUBMITTED[1]);
    }

    public static synchronized void markSavedDraft(String pHerd)
    {
        if (pHerd == null || pHerd.isBlank()) return;
        DONE_THIS_RUN.add(pHerd.trim());
        vault(() -> TestDataVault.markUsedFinal(pHerd.trim(), "NR/CISYF application saved as draft"));
    }

    public static synchronized void markAlreadySubmitted(String pHerd)
    {
        if (pHerd == null || pHerd.isBlank() || SUBMITTED_THIS_RUN.contains(pHerd.trim())) return;
        DONE_THIS_RUN.add(pHerd.trim());
        vault(() -> TestDataVault.markBad(pHerd.trim(), "already had an NR/CISYF application (View Application) when opened"));
    }

    // The agent's NR/CISYF list does not show the herd (search found no row) - the next herd is taken instead
    public static synchronized void markNotListed(String pHerd, String pLogin)
    {
        if (pHerd == null || pHerd.isBlank()) return;
        DONE_THIS_RUN.add(pHerd.trim());
        vault(() -> TestDataVault.markBad(pHerd.trim(), "not in the NR/CISYF list of " + n(pLogin)));
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : releaseUntouched
    // Description   : Called by Hooks after a test case that PASSED: herds handed out in this run that were never
    //                 submitted, saved or marked bad go back to AVAILABLE (e.g. the TC_16_ENTS herd, which only shows
    //                 the Entitlements / Usage page). After a failed test case they stay RESERVED - the run may have
    //                 left a half-filled application on them.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 02-10-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized void releaseUntouched()
    {
        List<String> iReleased = new ArrayList<>();
        for (String iHerd : new ArrayList<>(TAKEN_THIS_RUN))
        {
            if (SUBMITTED_THIS_RUN.contains(iHerd) || DONE_THIS_RUN.contains(iHerd)) continue;
            vault(() -> TestDataVault.release(iHerd));
            TAKEN_THIS_RUN.remove(iHerd);
            iReleased.add(iHerd);
        }
        if (!iReleased.isEmpty()) CommonFunctions.log.info(LOG + "Not used, back to AVAILABLE: " + iReleased);
    }

    public static synchronized boolean wasSubmittedThisRun(String pHerd)
    {
        return pHerd != null && SUBMITTED_THIS_RUN.contains(pHerd.trim());
    }

    public static synchronized String[] lastSubmitted()
    {
        return LAST_SUBMITTED == null ? null : LAST_SUBMITTED.clone();
    }


    // ===================================================================================================================================
    //  HELPERS
    // ===================================================================================================================================

    private static boolean usable(String pHerd, String pLogin, Set<String> pExcludeHerds, Set<String> pExpiredLogins)
    {
        if (pHerd == null || pHerd.isBlank() || pLogin == null || pLogin.isBlank()) return false;
        if (TAKEN_THIS_RUN.contains(pHerd)) return false;
        if (pExcludeHerds != null && pExcludeHerds.contains(pHerd)) return false;
        if (pExpiredLogins != null)
        {
            for (String iExpired : pExpiredLogins) if (iExpired != null && iExpired.trim().equalsIgnoreCase(pLogin.trim())) return false;
        }
        return !TestDataVault.isEnabled() || !TestDataVault.isLoginExpired(pLogin);
    }

    // A row of the preferred agent when there is one, otherwise a random row
    private static TestDataVault.Row preferLogin(List<TestDataVault.Row> pRows, String pPrefer)
    {
        List<TestDataVault.Row> iSame = new ArrayList<>();
        if (!pPrefer.isEmpty())
        {
            for (TestDataVault.Row iRow : pRows) if (iRow.login.equalsIgnoreCase(pPrefer)) iSame.add(iRow);
        }
        List<TestDataVault.Row> iFrom = iSame.isEmpty() ? new ArrayList<>(pRows) : iSame;
        Collections.shuffle(iFrom, new Random(System.nanoTime()));
        return iFrom.get(0);
    }

    // Vault writes are best effort - a vault problem never fails a test step
    private static void vault(Runnable pAction)
    {
        if (!TestDataVault.isEnabled()) return;
        try { pAction.run(); }
        catch (Exception e) { CommonFunctions.log.warning(LOG + "Vault update failed: " + e.getMessage()); }
    }

    private static String n(String pValue)
    {
        return pValue == null ? "" : pValue.trim();
    }
}
