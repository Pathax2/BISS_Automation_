// =====================================================================================================================================
// File          : StaffSteps.java
// Package       : stepdefinitions.BISS.STAFF
// Purpose       : Single consolidated step definition library for every BISS internal (staff) portal feature:
//                 MAPS, SIM, CORRESPONDENCE, PAYMENTS, SCHEME, ACTIVE FARMER, AMS and OPENSHIFT.
//                 Features: src/test/resources/Test_Cases/BISS/STAFF/...
//
// Common Background : All staff features log in through the internal portal (CENTEST or OpenShift), open the
//                     BISS application, and then work from the Home screen or a named tab. The login and
//                     application-open steps are shared by every feature in this library.
//
// DB Data       : Herds, parcels and reference numbers come from the Oracle DB through utilities.StaffTestData.
//                 Feature files never name a row index - they ask for "the next submitted herd" and this class
//                 takes the next unused value of the relevant pool. That keeps sections independent and the
//                 features free of Excel-era row references.
//
// Notes         : - Declarative step wording. A single business step (e.g. "requests a map with the following
//                   settings") performs the whole UI interaction sequence internally, so the feature files
//                   describe intent and this class owns the mechanics.
//                 - Staff usernames stay hardcoded in the features: they are permission fixtures, not test
//                   data. Each carries a specific role the scenario depends on.
//                 - Passwords resolve from TestData.xlsx via the "TD:Password" mechanism.
//
// PLAYWRIGHT MIGRATION (05-10-2026) - same step texts, same Object Repository keys, same click order:
//   Selenium                                                     Playwright
//   Hooks.STAFF_* lists filled by the @staffdata hook        ->  StaffTestData.pool(kind, schemeYear), loaded the first
//                                                                time a step asks (see StaffTestData for tags and sizes)
//   getDriver().findElements(By).isEmpty()/isDisplayed()     ->  UiHelpers.isVisible(locator, seconds) - first match,
//                                                                never throws
//   findElement(By).getText() / getAttribute("textContent")  ->  Locator.innerText() / Locator.textContent()
//   getDriver().navigate().to(Hooks.iUrl)                    ->  UiHelpers.navigateTo(staff login address, see below)
//   switchTo().activeElement().sendKeys(Keys.TAB)            ->  UiHelpers.pressKey("Tab")
//   Thread.sleep(ms)                                         ->  pause(ms) (page.waitForTimeout - same duration)
//   WebDriverWait numberOfWindowsToBe + window handles       ->  BrowserContext.waitForPage + Page.close
//   iAction("CHECKBOX", ..., null)                           ->  Playwright CHECKBOX needs CHECK / UNCHECK, so:
//                                                                  toggles (SIM indicator, Force Majeure) -> CLICK
//                                                                  Eh change request (must end ticked)    -> CHECK
//
// Other changes (each marked "Change from Selenium" at the place it happens):
//   - The login steps open the staff login page when it is not already on screen: staff.url, or a StaffURL column
//     in the Config sheet, otherwise Hooks.iUrl as in Selenium.
//   - Map generation polling (500 x 5 s in Selenium) reads staff.map.poll.attempts / staff.map.poll.seconds,
//     with the same defaults. A missing first row is logged and polled again instead of failing at once.
//   - Absence checks ("should not have access", "no late penalty") look for PROBE_SECONDS before deciding the
//     element is absent, instead of a single immediate findElements.
//   - The [STEP] log lines show the values used instead of the {string} placeholders.
//
// Author        : Aniket Pathare | aniket.pathare@government.ie
// Date Created  : 15-07-2026 | Updated: 05-10-2026 (Playwright)
// =====================================================================================================================================

package stepdefinitions.BISS.STAFF;

import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.TimeoutError;
import commonFunctions.CommonFunctions;
import commonFunctions.PlaywrightFactory;
import commonFunctions.UiHelpers;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import stepdefinitions.Hooks;
import utilities.ConfigManager;
import utilities.ExcelUtilities;
import utilities.ObjReader;
import utilities.StaffTestData;
import utilities.StaffTestData.Pool;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import static commonFunctions.CommonFunctions.iAction;

public class StaffSteps
{
    // TC_03-style logger - every step opens with a [STEP] line so staff runs are traceable in the console/report.
    private static final Logger log = Logger.getLogger(StaffSteps.class.getName());

    // How long an "is it there?" check waits before deciding the element is absent
    private static final int PROBE_SECONDS = ConfigManager.getInt("probe.timeout.seconds", 3);

    // Config sheet columns tried for the staff login address when staff.url is not set (same names as TC_15_ENTS)
    private static final String[] STAFF_URL_COLUMNS = { "StaffURL", "Staff URL", "Staff_URL", "StaffUrl" };

    // =================================================================================================================================
    // SECTION 1 : Runtime data pools and cursors
    // =================================================================================================================================
    // StaffTestData holds the pools. Each cursor tracks how far through its pool the scenario has walked, so
    // "the next submitted herd" hands back a different herd each time it is called within one scenario.
    // Cucumber creates a new StaffSteps for every scenario, so every scenario starts at the first row (as in Selenium).

    private int iSubmittedHerdCursor  = 0;
    private int iPenaltyHerdCursor    = 0;
    private int iNoAmendHerdCursor    = 0;
    private int iAdminCheckHerdCursor = 0;
    private int iQueryLetterCursor    = 0;
    private int iSimOptedHerdCursor   = 0;
    private int iParcelCursor         = 0;
    private int iReferenceCursor      = 0;

    // Holds the value most recently taken from a pool, so a step can re-use the SAME herd rather than advance
    // to the next one. Needed where legacy deliberately re-visits one herd across several scheme years.
    private String iCurrentHerd = null;

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Hook          : readPoolSizeTags
    // Description   : Passes the scenario tags (feature tags included) to StaffTestData, so the Selenium size tags
    //                 such as @parcels:10 or @herds:10:submitted still decide how many rows a pool loads.
    //                 Only reads tags - no database access, no browser - so it costs nothing on other scenarios.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 05-10-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Before
    public void readPoolSizeTags(Scenario pScenario)
    {
        StaffTestData.applyTags(pScenario.getSourceTagNames());
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : iNextFromPool
    // Description   : Returns the next unused value from a runtime pool. Fails loudly rather than wrapping around -
    //                 a scenario asking for more herds than the query returned is a data problem that must surface,
    //                 not be silently masked by re-using row 1. The caller advances its cursor.
    // Parameters    : pPool      (List<String>) - the resolved pool from StaffTestData
    //                 pCursor    (int)          - current position
    //                 pPoolName  (String)       - for the error message
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026 | Updated: 05-10-2026 (Playwright - pools from StaffTestData)
    // ---------------------------------------------------------------------------------------------------------------------------------
    private String iNextFromPool(List<String> pPool, int pCursor, String pPoolName)
    {
        if (pPool == null || pPool.isEmpty())
        {
            throw new IllegalStateException("Runtime pool '" + pPoolName + "' is empty. Check that the corresponding DBRouter "
                    + "query returns rows for this scheme year on the DATA database.");
        }

        if (pCursor >= pPool.size())
        {
            throw new IllegalStateException("Scenario requested more values from pool '" + pPoolName + "' than the query returned ("
                    + pPool.size() + "). Increase staff.pool.size or add a size tag to the feature, e.g. @herds:10:submitted.");
        }

        log.info("[STAFF-DATA] " + pPoolName + " row " + (pCursor + 1) + "/" + pPool.size() + " : " + pPool.get(pCursor));
        // Dashboard ledger (14-10-2026): staff values are picked here, so this is where they are recorded
        reporting.ExecutionMetrics.herdPicked("staff " + pPoolName, pPool.get(pCursor), "", "Internal portal - " + pPoolName);
        return pPool.get(pCursor);
    }

    // Next submitted herd for a scheme year (the pool most steps use)
    private String iNextSubmittedHerd(String pSchemeYear)
    {
        String iHerd = iNextFromPool(StaffTestData.pool(Pool.SUBMITTED, pSchemeYear), iSubmittedHerdCursor, Pool.SUBMITTED.description());
        iSubmittedHerdCursor++;
        return iHerd;
    }

    // =================================================================================================================================
    // SECTION 2 : Login and portal entry - shared by every staff feature
    // =================================================================================================================================

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserIsLoggedInToTheBissInternalPortal
    // Description   : Logs into the CENTEST internal portal and opens the BISS application. Combines what legacy
    //                 spread across four steps (open page, enter username, enter password, click login, open app).
    // Parameters    : pUsername (String) - staff account, a permission fixture from the feature file
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026 | Updated: 05-10-2026 (Playwright)
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Given("the staff user is logged in to the BISS internal portal as {string}")
    public void theStaffUserIsLoggedInToTheBissInternalPortal(String pUsername)
    {
        log.info("[STEP] the staff user is logged in to the BISS internal portal as " + pUsername);
        iOpenStaffLoginPageIfNeeded();
        iPerformStaffLogin(pUsername);

        // Click into the search bar first to make sure it has focus before we start typing
        iAction("CLICK", "XPATH", ObjReader.getLocator("iAuthorizedApplicationSearchBar"), "");

        // Type the full application name into the search bar so it filters the results list
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iAuthorizedApplicationSearchBar"), "Basic Income Support for Sustainability");

        // The result is showing - click the BISS application link to enter the portal
        iAction("CLICK", "XPATH", ObjReader.getLocator("iBissApplicationLink"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserIsLoggedInToTheOpenShiftBissPortal
    // Description   : As above but against the OpenShift deployment. The URL is selected by the run configuration;
    //                 the login mechanics are identical, which is the point of the OpenShift packs - they prove the
    //                 same flows behave the same way on the other deployment.
    // Parameters    : pUsername (String) - staff account
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026 | Updated: 05-10-2026 (Playwright)
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Given("the staff user is logged in to the OpenShift BISS portal as {string}")
    public void theStaffUserIsLoggedInToTheOpenShiftBissPortal(String pUsername)
    {
        log.info("[STEP] the staff user is logged in to the OpenShift BISS portal as " + pUsername);
        iOpenStaffLoginPageIfNeeded();
        iPerformStaffLogin(pUsername);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iBissApplicationLink"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserReLogsInToTheBissInternalPortal
    // Description   : Switches to a different staff account mid-scenario. Used where a section needs a role the
    //                 Background user does not hold - e.g. Map Printing is invisible to non-internal users, so
    //                 TC_02 switches to agr5033 to prove exactly that.
    // Parameters    : pUsername (String) - the account to switch to
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026 | Updated: 05-10-2026 (Playwright)
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user re-logs in to the BISS internal portal as {string}")
    public void theStaffUserReLogsInToTheBissInternalPortal(String pUsername)
    {
        log.info("[STEP] the staff user re-logs in to the BISS internal portal as " + pUsername);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iAccountExit"), null);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iExitLink2"), null);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iLogoutbtn"), null);
        UiHelpers.navigateTo(iStaffLoginUrl());
        iPerformStaffLogin(pUsername);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iBissApplicationLink"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserReLogsInToTheOpenShiftBissPortal
    // Description   : Role switch on the OpenShift deployment.
    // Parameters    : pUsername (String) - the account to switch to
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026 | Updated: 05-10-2026 (Playwright)
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user re-logs in to the OpenShift BISS portal as {string}")
    public void theStaffUserReLogsInToTheOpenShiftBissPortal(String pUsername)
    {
        log.info("[STEP] the staff user re-logs in to the OpenShift BISS portal as " + pUsername);
        UiHelpers.navigateTo(iStaffLoginUrl());
        iPerformStaffLogin(pUsername);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iBissApplicationLink"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : iPerformStaffLogin
    // Description   : Shared login mechanics. Password resolves from TestData.xlsx via the TD: mechanism rather
    //                 than sitting in the feature file or this class.
    // Parameters    : pUsername (String) - staff account
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    private void iPerformStaffLogin(String pUsername)
    {
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iUsernametxtbox"), pUsername);
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iPasswordtxtbox"), "TD:Password");

        // Data protection checkbox
        iAction("CLICK", "XPATH", ObjReader.getLocator("iStaffDataProtectionCheckbox"), null);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iLoginbtn"), null);
        log.info("[STAFF-LOGIN] Login submitted for " + pUsername);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : iOpenStaffLoginPageIfNeeded
    // Description   : Change from Selenium: Selenium relied on Hooks having opened the staff login page. Here the
    //                 page is opened when the username box is not on screen within PROBE_SECONDS, so a staff test
    //                 case also works when the run's Config URL is the agent portal.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 05-10-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    private void iOpenStaffLoginPageIfNeeded()
    {
        if (UiHelpers.isVisible(UiHelpers.byXpath(ObjReader.getLocator("iUsernametxtbox")), PROBE_SECONDS))
        {
            return;
        }
        String iUrl = iStaffLoginUrl();
        log.info("[STAFF-LOGIN] Login form not on screen - opening " + iUrl);
        UiHelpers.navigateTo(iUrl);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : iStaffLoginUrl
    // Description   : Address of the staff login page, in this order:
    //                   1. staff.url (ConfigManager: -Dstaff.url=..., application-<env>.properties)
    //                   2. Config sheet of TestData.xlsx, row of the current environment, first non-empty column of
    //                      StaffURL / Staff URL / Staff_URL / StaffUrl
    //                   3. Hooks.iUrl - the Selenium behaviour (the run's Config URL is the staff portal)
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 05-10-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    private static String iStaffLoginUrl()
    {
        String iUrl = ConfigManager.getOrDefault("staff.url", "").trim();
        if (!iUrl.isEmpty()) return iUrl;

        String iEnvironment = Hooks.iEnvironment == null ? "" : Hooks.iEnvironment.trim();
        try
        {
            ExcelUtilities iExcel = new ExcelUtilities(
                    ConfigManager.getOrDefault("test.data.file.path", "src/test/resources/Test_Data/TestData.xlsx"));
            int iRow = iExcel.findRow("Config", "Env", iEnvironment);
            if (iRow != -1)
            {
                for (String iColumn : STAFF_URL_COLUMNS)
                {
                    try
                    {
                        String iValue = iExcel.getCellValue("Config", iRow, iColumn);
                        if (iValue != null && !iValue.trim().isEmpty()) return iValue.trim();
                    }
                    catch (Exception iNoColumn)
                    {
                        // column not in the sheet - try the next name
                    }
                }
            }
        }
        catch (Exception iExcelError)
        {
            log.warning("[STAFF-LOGIN] Could not read the Config sheet: " + iExcelError.getMessage());
        }
        return Hooks.iUrl;
    }

    // =================================================================================================================================
    // SECTION 3 : Screen and tab navigation
    // =================================================================================================================================

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserIsOnTheMapPrintingScreen
    // Description   : Opens the Map Printing tab.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the staff user is on the Map Printing screen")
    public void theStaffUserIsOnTheMapPrintingScreen()
    {
        log.info("[STEP] the staff user is on the Map Printing screen");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iMapPrintingTab"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserIsSearchingByParcel
    // Description   : Switches the Map Printing search type from Herd (default) to Parcel.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the staff user is searching by parcel")
    public void theStaffUserIsSearchingByParcel()
    {
        log.info("[STEP] the staff user is searching by parcel");
        iAction("LIST", "XPATH", ObjReader.getLocator("iMapPrintingTypeSelect"), "Parcel");
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserNavigatesTheDashboardSideMenu
    // Description   : Walks the dashboard side menu through each named area in the DataTable. Replaces the legacy
    //                 pattern of one "Click on X Link in Navbar" step per area.
    // Parameters    : pMenuItems (DataTable) - single column of side menu link names, in visit order
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user navigates the dashboard side menu")
    public void theStaffUserNavigatesTheDashboardSideMenu(DataTable pMenuItems)
    {
        log.info("[STEP] the staff user navigates the dashboard side menu");
        for (String iItem : pMenuItems.asList())
        {
            iAction("CLICK", "XPATH", ObjReader.getLocator("iNavbarLink").replace("{LINK}", iItem), null);
        }
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theFollowingApplicationTabsShouldBeAvailable
    // Description   : Opens each tab named in the DataTable and verifies it renders. Replaces seven consecutive
    //                 "Click on X Link in Navbar" steps in legacy TC_21 with one declarative assertion.
    // Parameters    : pTabs (DataTable) - single column of tab names
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the following application tabs should be available")
    public void theFollowingApplicationTabsShouldBeAvailable(DataTable pTabs)
    {
        log.info("[STEP] the following application tabs should be available");
        for (String iTab : pTabs.asList())
        {
            iAction("CLICK",         "XPATH", ObjReader.getLocator("iNavbarLink").replace("{LINK}", iTab), null);
            iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iNavbarLink").replace("{LINK}", iTab), null);
        }
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theDashboardShouldRemainAvailable
    // Description   : Confirms the dashboard is still rendered after navigation.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the dashboard should remain available")
    public void theDashboardShouldRemainAvailable()
    {
        log.info("[STEP] the dashboard should remain available");
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iHomeSearchButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserShouldNotHaveAccessToTheTab
    // Description   : Asserts a tab is NOT present - the role restriction check. iAction's waits are built to find
    //                 elements, not to prove absence, so the tab is probed directly.
    //                 Kept from Selenium: the check uses iMapPrintingTab whatever pTabName says (only Map Printing is
    //                 asserted this way in the features). Change from Selenium: the probe waits PROBE_SECONDS, so a
    //                 tab that renders a moment late is still caught.
    // Parameters    : pTabName (String) - the tab that must not appear
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026 | Updated: 05-10-2026 (Playwright)
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the staff user should not have access to the {string} tab")
    public void theStaffUserShouldNotHaveAccessToTheTab(String pTabName)
    {
        log.info("[STEP] the staff user should not have access to the " + pTabName + " tab");
        if (UiHelpers.isVisible(UiHelpers.byXpath(ObjReader.getLocator("iMapPrintingTab")), PROBE_SECONDS))
        {
            throw new AssertionError("Tab '" + pTabName + "' is visible to this user but should be restricted.");
        }
        log.info("[STAFF] Tab '" + pTabName + "' is not shown to this user, as expected.");
    }

    // =================================================================================================================================
    // SECTION 4 : Search steps - DB-resolved and literal
    // =================================================================================================================================
    // Two families of search step exist deliberately:
    //   "the next <kind> herd"   - takes from a runtime pool, used wherever any herd of that kind will do.
    //   "herd <literal>"         - a named fixture, used only where the herd must have a specific property that
    //                              no DB query expresses (partnership, known SIM tick state, etc). Each literal
    //                              is justified in the feature file's TEST DATA NOTE.

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSearchesMapPrintingForTheNextSubmittedHerd
    // Description   : Takes the next submitted herd and searches Map Printing for it.
    // Parameters    : pSchemeYear (String) - scheme year to search
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user searches Map Printing for the next submitted herd for scheme year {string}")
    public void theStaffUserSearchesMapPrintingForTheNextSubmittedHerd(String pSchemeYear)
    {
        log.info("[STEP] the staff user searches Map Printing for the next submitted herd for scheme year " + pSchemeYear);
        iCurrentHerd = iNextSubmittedHerd(pSchemeYear);
        iSearchMapPrintingByHerd(iCurrentHerd, pSchemeYear);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSearchesMapPrintingForHerd
    // Description   : Searches Map Printing for a named herd literal.
    // Parameters    : pHerdNumber (String) - the fixture herd
    //                 pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user searches Map Printing for herd {string} for scheme year {string}")
    public void theStaffUserSearchesMapPrintingForHerd(String pHerdNumber, String pSchemeYear)
    {
        log.info("[STEP] the staff user searches Map Printing for herd " + pHerdNumber + " for scheme year " + pSchemeYear);
        iCurrentHerd = pHerdNumber;
        iSearchMapPrintingByHerd(pHerdNumber, pSchemeYear);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSearchesMapPrintingForPartnershipHerd
    // Description   : Searches Map Printing for a partnership fixture herd. Reads identically to the plain herd
    //                 step but names the partnership explicitly, so the feature states why the literal exists.
    // Parameters    : pHerdNumber (String) - the partnership herd
    //                 pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user searches Map Printing for partnership herd {string} for scheme year {string}")
    public void theStaffUserSearchesMapPrintingForPartnershipHerd(String pHerdNumber, String pSchemeYear)
    {
        log.info("[STEP] the staff user searches Map Printing for partnership herd " + pHerdNumber + " for scheme year " + pSchemeYear);
        iCurrentHerd = pHerdNumber;
        iSearchMapPrintingByHerd(pHerdNumber, pSchemeYear);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSearchesMapPrintingForTheNextLpisParcel
    // Description   : Takes the next LPIS parcel and searches Map Printing for it.
    // Parameters    : pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user searches Map Printing for the next LPIS parcel for scheme year {string}")
    public void theStaffUserSearchesMapPrintingForTheNextLpisParcel(String pSchemeYear)
    {
        log.info("[STEP] the staff user searches Map Printing for the next LPIS parcel for scheme year " + pSchemeYear);
        String iParcel = iNextFromPool(StaffTestData.pool(Pool.PARCELS, null), iParcelCursor, Pool.PARCELS.description());
        iParcelCursor++;
        iSearchMapPrintingByParcel(iParcel, pSchemeYear);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSearchesMapPrintingForParcel
    // Description   : Searches Map Printing for a named parcel literal.
    // Parameters    : pParcelNumber (String) - the parcel
    //                 pSchemeYear   (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user searches Map Printing for parcel {string} for scheme year {string}")
    public void theStaffUserSearchesMapPrintingForParcel(String pParcelNumber, String pSchemeYear)
    {
        log.info("[STEP] the staff user searches Map Printing for parcel '" + pParcelNumber + "' for scheme year " + pSchemeYear);
        iSearchMapPrintingByParcel(pParcelNumber, pSchemeYear);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSearchesMapPrintingForPartnershipParcel
    // Description   : Searches Map Printing for a partnership parcel fixture.
    // Parameters    : pParcelNumber (String) - the partnership parcel
    //                 pSchemeYear   (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user searches Map Printing for partnership parcel {string} for scheme year {string}")
    public void theStaffUserSearchesMapPrintingForPartnershipParcel(String pParcelNumber, String pSchemeYear)
    {
        log.info("[STEP] the staff user searches Map Printing for partnership parcel " + pParcelNumber + " for scheme year " + pSchemeYear);
        iSearchMapPrintingByParcel(pParcelNumber, pSchemeYear);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSearchesMapPrintingForEachInvalidParcel
    // Description   : Searches a sequence of malformed parcel values in one step. Legacy repeated three near
    //                 identical search blocks; the DataTable makes the intent - "none of these should break the
    //                 screen" - readable at a glance.
    // Parameters    : pSchemeYear (String)    - scheme year
    //                 pParcels    (DataTable) - single column of invalid parcel values
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user searches Map Printing for each of the following invalid parcels for scheme year {string}")
    public void theStaffUserSearchesMapPrintingForEachInvalidParcel(String pSchemeYear, DataTable pParcels)
    {
        log.info("[STEP] the staff user searches Map Printing for each of the following invalid parcels for scheme year " + pSchemeYear);
        for (String iParcel : pParcels.asList())
        {
            iSearchMapPrintingByParcel(iParcel, pSchemeYear);
        }
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSearchesMapPrintingWithNoHerdNumber
    // Description   : Clicks Search with the herd field empty, to trigger the mandatory-field error.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user searches Map Printing with no herd number")
    public void theStaffUserSearchesMapPrintingWithNoHerdNumber()
    {
        log.info("[STEP] the staff user searches Map Printing with no herd number");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iMapPrintingClearhButton"), null);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iMapPrintingSearchButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSearchesMapPrintingWithNoParcelNumber
    // Description   : Clicks Search with the parcel field empty.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user searches Map Printing with no parcel number")
    public void theStaffUserSearchesMapPrintingWithNoParcelNumber()
    {
        log.info("[STEP] the staff user searches Map Printing with no parcel number");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iMapParcelSearchRadioButton"), null);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iMapPrintingSearchButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : iSearchMapPrintingByHerd
    // Description   : Shared Map Printing herd search mechanics.
    // Parameters    : pHerdNumber (String) - herd to search
    //                 pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    private void iSearchMapPrintingByHerd(String pHerdNumber, String pSchemeYear)
    {
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iMapPrintingHerdNumber"), pHerdNumber);
        iAction("LIST",    "XPATH", ObjReader.getLocator("iMapPrintingSchemeYear"), pSchemeYear);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iMapPrintingSearchButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : iSearchMapPrintingByParcel
    // Description   : Shared Map Printing parcel search mechanics.
    // Parameters    : pParcelNumber (String) - parcel to search
    //                 pSchemeYear   (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    private void iSearchMapPrintingByParcel(String pParcelNumber, String pSchemeYear)
    {
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iMapPrintingParcelNumber"), pParcelNumber);
        iAction("LIST",    "XPATH", ObjReader.getLocator("iMapPrintingSchemeYear"), pSchemeYear);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iMapPrintingSearchButton"), null);
    }

    // =================================================================================================================================
    // SECTION 5 : Map generation - the declarative core of the MAPS category
    // =================================================================================================================================

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserRequestsAMapWithTheFollowingSettings
    // Description   : Composes and submits a map generation request from a settings table. This is the step that
    //                 replaces the legacy sequence of dropdown clicks, checkbox clicks and a Generate click.
    //
    //                 Supported keys (all optional - only supply what the scenario needs):
    //                   parcels  - "single" selects one parcel, "all" selects every parcel
    //                   mapType  - map layout, e.g. "Full Color Ortho A4", "Custom Layer A4"
    //                   imagery  - imagery layer, custom layouts only
    //                   raster   - raster layer, custom layouts only
    //                   vector   - "default" picks the first available vector layer
    //                   legend   - "yes" ticks the legend indicator
    //
    //                 Generation is only submitted when a mapType is supplied. That is deliberate: the validation
    //                 scenarios build a PARTIAL request (e.g. parcels only, then dismiss the map type selector)
    //                 to prove the field is mandatory, and must not click Generate.
    // Parameters    : pSettings (DataTable) - key/value settings map
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026 | Updated: 05-10-2026 (Playwright)
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the staff user requests a map with the following settings")
    public void theStaffUserRequestsAMapWithTheFollowingSettings(DataTable pSettings)
    {
        log.info("[STEP] the staff user requests a map with the following settings");
        Map<String, String> iSettings = pSettings.asMap(String.class, String.class);

        String iParcels = trimOrNull(iSettings.get("parcels"));
        String iMapType = trimOrNull(iSettings.get("mapType"));
        String iImagery = trimOrNull(iSettings.get("imagery"));
        String iRaster  = trimOrNull(iSettings.get("raster"));
        String iVector  = trimOrNull(iSettings.get("vector"));
        String iLegend  = trimOrNull(iSettings.get("legend"));
        log.info("[MAPS] Settings: " + iSettings);

        if (iParcels != null)
        {
            iAction("CLICK", "XPATH", ObjReader.getLocator("iParcelSelect"), null);
            iAction("CLICK", "XPATH", ObjReader.getLocator("all".equalsIgnoreCase(iParcels) ? "iParcelSelectAllOption" : "iParcelSelectFirstOption"), null);
            iAction("CLICK", "XPATH", ObjReader.getLocator("iParcelSelect"), null);
        }

        if (iMapType != null)
        {
            iAction("LIST", "XPATH", ObjReader.getLocator("iMapTypeSelect"), iMapType);
        }

        if (iImagery != null)
        {
            iAction("LIST", "XPATH", ObjReader.getLocator("iImagerySelect"), iImagery);
        }

        if (iRaster != null)
        {
            iAction("LIST", "XPATH", ObjReader.getLocator("iRasterSelect"), iRaster);
        }

        if (iVector != null)
        {
            iAction("CLICK", "XPATH", ObjReader.getLocator("iVectorSelect"), null);
            iAction("CLICK", "XPATH", ObjReader.getLocator("iVectorSelectFirstOption"), null);
            // Selenium: switchTo().activeElement().sendKeys(Keys.TAB) - closes the multi-select panel
            UiHelpers.pressKey("Tab");
        }

        if ("yes".equalsIgnoreCase(iLegend))
        {
            iAction("CLICK", "XPATH", ObjReader.getLocator("iLegendIndicator"), null);
        }

        // Only submit when the request is complete. Validation scenarios stop short by design.
        if (iMapType != null)
        {
            try
            {
                if (UiHelpers.isVisible(UiHelpers.byXpath(ObjReader.getLocator("iGenerateMapButton")), PROBE_SECONDS))
                {
                    iAction("CLICK", "XPATH", ObjReader.getLocator("iGenerateMapButton"), null);
                    pause(4000);
                }
                else
                {
                    log.info("[STEP] Generate Map button not available.");
                }
            }
            catch (Exception e)
            {
                log.warning("[STEP] Generate Map click skipped: " + e.getMessage());
            }
        }
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserOpensAndDismissesTheSelectorWithoutChoosingAValue
    // Description   : Opens a multi-select and closes it without choosing anything, to trigger that field's
    //                 mandatory error. The selector key maps to a locator so one step covers parcel, map type,
    //                 imagery and vector. The second click lands on the open panel's trigger; when the panel
    //                 overlay intercepts it, CommonFunctions retries it as a JavaScript click.
    // Parameters    : pSelectorKey (String) - locator key, e.g. "parcelSelect"
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the staff user opens and dismisses the {string} selector without choosing a value")
    public void theStaffUserOpensAndDismissesTheSelectorWithoutChoosingAValue(String pSelectorKey)
    {
        log.info("[STEP] the staff user opens and dismisses the " + pSelectorKey + " selector without choosing a value");
        String iLocatorKey = "i" + pSelectorKey.substring(0, 1).toUpperCase() + pSelectorKey.substring(1);

        iAction("CLICK", "XPATH", ObjReader.getLocator(iLocatorKey), null);
        iAction("CLICK", "XPATH", ObjReader.getLocator(iLocatorKey), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theMapGenerationRequestShouldBeAccepted
    // Description   : Confirms the request was accepted - the first row of the generated maps table reaches
    //                 "Ready to download". Polls the first row: staff.map.poll.attempts (default 500, as Selenium)
    //                 times, staff.map.poll.seconds (default 5) apart.
    //                 Change from Selenium: a first row that is not there yet is logged and polled again (Selenium
    //                 failed at once with NoSuchElementException).
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026 | Updated: 05-10-2026 (Playwright)
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the map generation request should be accepted")
    public void theMapGenerationRequestShouldBeAccepted()
    {
        log.info("[STEP] the map generation request should be accepted");

        int     iAttempts        = ConfigManager.getInt("staff.map.poll.attempts", 500);
        int     iSeconds         = ConfigManager.getInt("staff.map.poll.seconds", 5);
        Locator iFirstRow        = UiHelpers.byXpath(ObjReader.getLocator("iGeneratedMapFirstRow")).first();
        boolean iReadyToDownload = false;

        for (int i = 1; i <= iAttempts; i++)
        {
            String iStatus = UiHelpers.isVisible(iFirstRow, iSeconds) ? iFirstRow.innerText().trim() : "(no first row yet)";
            log.info("Attempt " + i + " | First row status : " + iStatus);

            if (iStatus.contains("Ready to download"))
            {
                log.info("Ready to download found on first row.");
                iReadyToDownload = true;
                iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iGeneratedMapFirstRow"), null);
                break;
            }

            log.info("Waiting for map generation...");
            pause(iSeconds * 1000L);
        }

        if (!iReadyToDownload)
        {
            throw new RuntimeException("'Ready to download' was not displayed on the first row within the expected time ("
                    + iAttempts + " checks, " + iSeconds + " s apart).");
        }
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theGenerateMapSettingsShouldBeAvailable
    // Description   : Confirms the generate map settings panel rendered after a search - i.e. the search resolved
    //                 and the screen did not break.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the generate map settings should be available")
    public void theGenerateMapSettingsShouldBeAvailable()
    {
        log.info("[STEP] the generate map settings should be available");
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iGenerateMapSettingsSection"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserShouldSeeTheHerdIdentityDetails
    // Description   : Verifies each named identity field is present for the searched herd. Presence rather than
    //                 value: the herd is DB-resolved, so the feature cannot know the expected name or address.
    // Parameters    : pFields (DataTable) - single column of field names, e.g. name / address
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026 | Updated: 05-10-2026 (Playwright)
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the staff user should see the herd identity details")
    public void theStaffUserShouldSeeTheHerdIdentityDetails(DataTable pFields)
    {
        log.info("[STEP] the staff user should see the herd identity details");

        for (String iField : pFields.asList())
        {
            String iXpath = "//tbody[contains(@class,'mdc-data-table__content')]/tr[1]"
                    + "/td[contains(@class,'mat-column-" + iField.toLowerCase() + "')]";

            iAction("WAITVISIBLE", "XPATH", iXpath, null);
            String iValue = UiHelpers.byXpath(iXpath).first().innerText().trim();

            if (iValue.isEmpty())
            {
                throw new AssertionError("Expected value for field '" + iField + "' but none was displayed.");
            }
            iAction("VERIFYELEMENT", "XPATH", iXpath, null);
            log.info("Verified " + iField + " : " + iValue);
        }
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theGeneratedMapShouldBeRecordedWithTheFollowingDetails
    // Description   : Verifies the generated map row carries every named metadata field. Replaces four separate
    //                 "verifies the X of the generated map" steps with one assertion over a table.
    // Parameters    : pFields (DataTable) - single column: status / id / herdNumber / date / mapType / mapError
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026 | Updated: 05-10-2026 (Playwright)
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the generated map should be recorded with the following details")
    public void theGeneratedMapShouldBeRecordedWithTheFollowingDetails(DataTable pFields)
    {
        pause(2000);
        log.info("[STEP] the generated map should be recorded with the following details");

        Map<String, String> iColumnClassMap = new HashMap<>();
        iColumnClassMap.put("id",         "mat-column-id");
        iColumnClassMap.put("herdNumber", "mat-column-herdNumber");
        iColumnClassMap.put("date",       "mat-column-date");
        iColumnClassMap.put("mapType",    "mat-column-mapType");
        iColumnClassMap.put("mapError",   "mat-column-mapError");
        iColumnClassMap.put("status",     "mat-column-status");

        for (String iField : pFields.asList())
        {
            String iColumnClass = iColumnClassMap.get(iField);

            if (iColumnClass == null)
            {
                throw new IllegalArgumentException("Unsupported generated map field: " + iField);
            }

            String iXpath =
                    "//mat-card[.//mat-card-title[contains(normalize-space(),'Generated Maps')]]" +
                            "//tbody[contains(@class,'mdc-data-table__content')]" +
                            "/tr[1]/td[contains(@class,'" + iColumnClass + "')]";

            String iContent = UiHelpers.byXpath(iXpath).first().textContent();
            String iValue   = iContent == null ? "" : iContent.trim();

            if (iValue.isEmpty())
            {
                throw new AssertionError("Expected value for generated map field '" + iField + "' but none was displayed.");
            }

            iAction("VERIFYELEMENT", "XPATH", iXpath, null);
            log.info("Verified " + iField + " : " + iValue);
        }
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theGeneratedMapShouldReachItsFinalStatus
    // Description   : Waits for the request to settle at its terminal status rather than staying in progress.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the generated map should reach its final status")
    public void theGeneratedMapShouldReachItsFinalStatus()
    {
        log.info("[STEP] the generated map should reach its final status");
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iReadyToDownloadLink"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserShouldBeAbleToDownloadTheGeneratedMap
    // Description   : Confirms the completed map exposes a working download link and follows it. The map opens as a
    //                 PDF in a new tab: the tab is waited for (staff.map.tab.seconds, default 30 as in Selenium),
    //                 its address logged, then closed, and the test carries on in the main tab.
    //                 No new tab within the time: a warning, as in Selenium (the step does not fail).
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026 | Updated: 05-10-2026 (Playwright)
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the staff user should be able to download the generated map")
    public void theStaffUserShouldBeAbleToDownloadTheGeneratedMap()
    {
        log.info("[STEP] the staff user should be able to download the generated map");

        Page iMainPage = CommonFunctions.getPage();
        int  iSeconds  = ConfigManager.getInt("staff.map.tab.seconds", 30);

        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iReadyToDownloadLink"), null);

        Page iMapTab;
        try
        {
            iMapTab = CommonFunctions.getContext().waitForPage(
                    new BrowserContext.WaitForPageOptions().setTimeout(iSeconds * 1000d),
                    () -> iAction("CLICK", "XPATH", ObjReader.getLocator("iReadyToDownloadLink"), null));
        }
        catch (TimeoutError e)
        {
            log.warning("[STEP] No new tab opened for the generated map within " + iSeconds + "s.");
            PlaywrightFactory.switchToPage(iMainPage);
            return;
        }

        log.info("[STEP] Closing map PDF tab: " + iMapTab.url());
        iMapTab.close();
        PlaywrightFactory.switchToPage(iMainPage);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserPagesThroughTheGeneratedMapsTable
    // Description   : Walks the pagination controls named in the DataTable, in order.
    // Parameters    : pControls (DataTable) - single column, e.g. Next page / Previous page
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user pages through the generated maps table")
    public void theStaffUserPagesThroughTheGeneratedMapsTable(DataTable pControls)
    {
        log.info("[STEP] the staff user pages through the generated maps table");
        for (String iControl : pControls.asList())
        {
            iAction("CLICK", "XPATH", ObjReader.getLocator("iPaginationButton").replace("{LABEL}", iControl), null);
        }
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theGeneratedMapsTableShouldRemainDisplayed
    // Description   : Confirms the table survived pagination.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the generated maps table should remain displayed")
    public void theGeneratedMapsTableShouldRemainDisplayed()
    {
        log.info("[STEP] the generated maps table should remain displayed");
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iGeneratedMapTable"), null);
    }

    // =================================================================================================================================
    // SECTION 6 : Validation and error assertions
    // =================================================================================================================================

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserShouldSeeTheValidationError
    // Description   : Asserts a field-level validation error is shown with the expected text, then switches the Map
    //                 Printing search back to Herd (as in Selenium) so the next section starts from the default.
    // Parameters    : pExpectedError (String) - expected message
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the staff user should see the validation error {string}")
    public void theStaffUserShouldSeeTheValidationError(String pExpectedError)
    {
        log.info("[STEP] the staff user should see the validation error '" + pExpectedError + "'");
        iAction("VERIFYTEXT", "XPATH", ObjReader.getLocator("iValidationError").replace("{TEXT}", pExpectedError), pExpectedError);
        iAction("CLICK",      "XPATH", ObjReader.getLocator("iMapHerdSearchRadioButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserShouldSeeTheSearchError
    // Description   : Asserts a search-level error. Kept separate from the field validation step because the
    //                 legacy DOM renders these without the span wrapper the field errors use.
    // Parameters    : pExpectedError (String) - expected message
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the staff user should see the search error {string}")
    public void theStaffUserShouldSeeTheSearchError(String pExpectedError)
    {
        log.info("[STEP] the staff user should see the search error '" + pExpectedError + "'");
        iAction("VERIFYTEXT", "XPATH", ObjReader.getLocator("iSearchError").replace("{TEXT}", pExpectedError), pExpectedError);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserShouldSeeTheFollowingSearchErrors
    // Description   : Asserts several search errors appear together. The empty-search case must report BOTH the
    //                 herd and reference errors, not just the first - hence a table rather than one string.
    // Parameters    : pErrors (DataTable) - single column of expected messages
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the staff user should see the following search errors")
    public void theStaffUserShouldSeeTheFollowingSearchErrors(DataTable pErrors)
    {
        log.info("[STEP] the staff user should see the following search errors");
        for (String iError : pErrors.asList())
        {
            iAction("VERIFYTEXT", "XPATH", ObjReader.getLocator("iSearchError").replace("{TEXT}", iError), iError);
        }
    }

    // =================================================================================================================================
    // SECTION 7 : Application opening - Home screen search then View
    // =================================================================================================================================
    // These steps collapse the legacy pattern of "click Home" -> "enter herd" -> "select year" -> "click Search"
    // -> "click View link 1" into one business action, and never name a row index.

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserOpensTheApplicationForTheNextSubmittedHerd
    // Description   : Takes the next submitted herd, searches for it and opens its application.
    // Parameters    : pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user opens the application for the next submitted herd for scheme year {string}")
    public void theStaffUserOpensTheApplicationForTheNextSubmittedHerd(String pSchemeYear)
    {
        log.info("[STEP] the staff user opens the application for the next submitted herd for scheme year " + pSchemeYear);
        iCurrentHerd = iNextSubmittedHerd(pSchemeYear);
        iSearchHomeByHerd(iCurrentHerd, pSchemeYear);
        iOpenFirstApplication();
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserOpensTheApplicationForTheSameSubmittedHerd
    // Description   : Re-opens the herd already in play rather than advancing to the next. Needed where legacy
    //                 deliberately re-visits ONE herd across several scheme years - advancing there would
    //                 compare different holdings and prove nothing.
    // Parameters    : pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user opens the application for the same submitted herd for scheme year {string}")
    public void theStaffUserOpensTheApplicationForTheSameSubmittedHerd(String pSchemeYear)
    {
        log.info("[STEP] the staff user opens the application for the same submitted herd for scheme year " + pSchemeYear);
        if (iCurrentHerd == null)
        {
            iCurrentHerd = iNextSubmittedHerd(pSchemeYear);
        }

        iSearchHomeByHerd(iCurrentHerd, pSchemeYear);
        iOpenFirstApplication();
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserOpensTheApplicationForHerd
    // Description   : Opens the application for a named fixture herd.
    // Parameters    : pHerdNumber (String) - fixture herd
    //                 pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user opens the application for herd {string} for scheme year {string}")
    public void theStaffUserOpensTheApplicationForHerd(String pHerdNumber, String pSchemeYear)
    {
        log.info("[STEP] the staff user opens the application for herd " + pHerdNumber + " for scheme year " + pSchemeYear);
        iCurrentHerd = pHerdNumber;
        iSearchHomeByHerd(pHerdNumber, pSchemeYear);
        iOpenFirstApplication();
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserOpensTheApplicationForTheNextPenaltyHerd
    // Description   : Takes the next herd carrying an application penalty and opens it.
    // Parameters    : pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user opens the application for the next penalty herd for scheme year {string}")
    public void theStaffUserOpensTheApplicationForTheNextPenaltyHerd(String pSchemeYear)
    {
        log.info("[STEP] the staff user opens the application for the next penalty herd for scheme year " + pSchemeYear);
        iCurrentHerd = iNextFromPool(StaffTestData.pool(Pool.PENALTY, pSchemeYear), iPenaltyHerdCursor, Pool.PENALTY.description());
        iPenaltyHerdCursor++;
        iSearchHomeByHerd(iCurrentHerd, pSchemeYear);
        iOpenFirstApplication();
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserOpensTheApplicationForTheNextNoAmendmentHerd
    // Description   : Takes the next herd with no amendment raised and opens it.
    // Parameters    : pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user opens the application for the next no-amendment herd for scheme year {string}")
    public void theStaffUserOpensTheApplicationForTheNextNoAmendmentHerd(String pSchemeYear)
    {
        log.info("[STEP] the staff user opens the application for the next no-amendment herd for scheme year " + pSchemeYear);
        iCurrentHerd = iNextFromPool(StaffTestData.pool(Pool.NOAMEND, pSchemeYear), iNoAmendHerdCursor, Pool.NOAMEND.description());
        iNoAmendHerdCursor++;
        iSearchHomeByHerd(iCurrentHerd, pSchemeYear);
        iOpenFirstApplication();
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserOpensTheApplicationForTheNextAdminCheckHerd
    // Description   : Takes the next herd with no admin check started and opens it.
    // Parameters    : pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user opens the application for the next admin-check herd for scheme year {string}")
    public void theStaffUserOpensTheApplicationForTheNextAdminCheckHerd(String pSchemeYear)
    {
        log.info("[STEP] the staff user opens the application for the next admin-check herd for scheme year " + pSchemeYear);
        iCurrentHerd = iNextFromPool(StaffTestData.pool(Pool.ADMINCHECK, pSchemeYear), iAdminCheckHerdCursor, Pool.ADMINCHECK.description());
        iAdminCheckHerdCursor++;
        iSearchHomeByHerd(iCurrentHerd, pSchemeYear);
        iOpenFirstApplication();
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserOpensTheApplicationForTheNextQueryLetterHerd
    // Description   : Takes the next herd with no query letter submitted and opens it.
    // Parameters    : pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user opens the application for the next query-letter herd for scheme year {string}")
    public void theStaffUserOpensTheApplicationForTheNextQueryLetterHerd(String pSchemeYear)
    {
        log.info("[STEP] the staff user opens the application for the next query-letter herd for scheme year " + pSchemeYear);
        iCurrentHerd = iNextFromPool(StaffTestData.pool(Pool.QUERYLETTER, pSchemeYear), iQueryLetterCursor, Pool.QUERYLETTER.description());
        iQueryLetterCursor++;
        iSearchHomeByHerd(iCurrentHerd, pSchemeYear);
        iOpenFirstApplication();
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserOpensTheApplicationForTheNextSimOptedHerd
    // Description   : Takes the next SIM opted-in herd and opens it.
    // Parameters    : pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user opens the application for the next SIM-opted herd for scheme year {string}")
    public void theStaffUserOpensTheApplicationForTheNextSimOptedHerd(String pSchemeYear)
    {
        log.info("[STEP] the staff user opens the application for the next SIM-opted herd for scheme year " + pSchemeYear);
        iCurrentHerd = iNextSimOptedHerd(pSchemeYear);
        iSearchHomeByHerd(iCurrentHerd, pSchemeYear);
        iOpenFirstApplication();
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserOpensTheApplicationForTheNextReferenceNumber
    // Description   : Takes the next reference number, searches by reference rather than herd, and opens it.
    // Parameters    : pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user opens the application for the next reference number for scheme year {string}")
    public void theStaffUserOpensTheApplicationForTheNextReferenceNumber(String pSchemeYear)
    {
        log.info("[STEP] the staff user opens the application for the next reference number for scheme year " + pSchemeYear);
        iSearchHomeByReference(iNextReference(pSchemeYear), pSchemeYear);
        iOpenFirstApplication();
    }

    // Next SIM opted-in herd for a scheme year
    private String iNextSimOptedHerd(String pSchemeYear)
    {
        String iHerd = iNextFromPool(StaffTestData.pool(Pool.SIMOPTED, pSchemeYear), iSimOptedHerdCursor, Pool.SIMOPTED.description());
        iSimOptedHerdCursor++;
        return iHerd;
    }

    // Next reference number for a scheme year
    private String iNextReference(String pSchemeYear)
    {
        String iReference = iNextFromPool(StaffTestData.pool(Pool.REFERENCES, pSchemeYear), iReferenceCursor, Pool.REFERENCES.description());
        iReferenceCursor++;
        return iReference;
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : iSearchHomeByHerd
    // Description   : Shared Home screen herd search mechanics.
    // Parameters    : pHerdNumber (String) - herd
    //                 pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    private void iSearchHomeByHerd(String pHerdNumber, String pSchemeYear)
    {
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iNavbarLink").replace("{LINK}", "Home"), null);
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iHomeHerdNumber"), pHerdNumber);
        iAction("LIST",    "XPATH", ObjReader.getLocator("iHomeSchemeYear"), pSchemeYear);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iHomeSearchButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : iSearchHomeByReference
    // Description   : Shared Home screen reference number search mechanics.
    // Parameters    : pReference  (String) - reference number
    //                 pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    private void iSearchHomeByReference(String pReference, String pSchemeYear)
    {
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iNavbarLink").replace("{LINK}", "Home"), null);
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iHomeReferenceNumber"), pReference);
        iAction("LIST",    "XPATH", ObjReader.getLocator("iHomeSchemeYear"), pSchemeYear);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iHomeSearchButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : iOpenFirstApplication
    // Description   : Opens the first result via its View link.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    private void iOpenFirstApplication()
    {
        iAction("CLICK", "XPATH",
                ObjReader.getLocator("iSearchResultLink").replace("{LABEL}", "View").replace("{INDEX}", "1"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : iOpenFirstApplicationForAmend
    // Description   : Opens the first result via its Amend link.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    private void iOpenFirstApplicationForAmend()
    {
        iAction("CLICK", "XPATH",
                ObjReader.getLocator("iSearchResultLink").replace("{LABEL}", "Amend").replace("{INDEX}", "1"), null);
    }

    // =================================================================================================================================
    // SECTION 8 : Home screen search steps that do NOT open an application
    // =================================================================================================================================

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSearchesTheHomeScreenForTheNextSubmittedHerd
    // Description   : Searches the Home screen without opening the result. Used by the OpenShift smoke pack,
    //                 where legacy commented out all post-search navigation.
    // Parameters    : pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user searches the Home screen for the next submitted herd for scheme year {string}")
    public void theStaffUserSearchesTheHomeScreenForTheNextSubmittedHerd(String pSchemeYear)
    {
        log.info("[STEP] the staff user searches the Home screen for the next submitted herd for scheme year " + pSchemeYear);
        iCurrentHerd = iNextSubmittedHerd(pSchemeYear);
        iSearchHomeByHerd(iCurrentHerd, pSchemeYear);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSearchesTheHomeScreenForHerd
    // Description   : Searches the Home screen for a named herd without opening it - used by the invalid-herd
    //                 validation cases.
    // Parameters    : pHerdNumber (String) - herd or invalid value
    //                 pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user searches the Home screen for herd {string} for scheme year {string}")
    public void theStaffUserSearchesTheHomeScreenForHerd(String pHerdNumber, String pSchemeYear)
    {
        log.info("[STEP] the staff user searches the Home screen for herd '" + pHerdNumber + "' for scheme year " + pSchemeYear);
        iSearchHomeByHerd(pHerdNumber, pSchemeYear);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSearchesTheHomeScreenForTheNextReferenceNumber
    // Description   : Searches by reference number without opening the result.
    // Parameters    : pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user searches the Home screen for the next reference number for scheme year {string}")
    public void theStaffUserSearchesTheHomeScreenForTheNextReferenceNumber(String pSchemeYear)
    {
        log.info("[STEP] the staff user searches the Home screen for the next reference number for scheme year " + pSchemeYear);
        iSearchHomeByReference(iNextReference(pSchemeYear), pSchemeYear);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSearchesTheHomeScreenWithNoCriteria
    // Description   : Clicks Search with every field empty, to trigger all mandatory errors at once.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user searches the Home screen with no criteria")
    public void theStaffUserSearchesTheHomeScreenWithNoCriteria()
    {
        log.info("[STEP] the staff user searches the Home screen with no criteria");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iNavbarLink").replace("{LINK}", "Home"), null);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iHomeSearchButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSearchesTheHomeScreenForTheFollowingFarmers
    // Description   : Runs a farmer search per row. Legacy had one scenario per surname/county pair; the table
    //                 makes the set of cases visible in one place.
    // Parameters    : pFarmers (DataTable) - columns: surname, county
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user searches the Home screen for the following farmers")
    public void theStaffUserSearchesTheHomeScreenForTheFollowingFarmers(DataTable pFarmers)
    {
        log.info("[STEP] the staff user searches the Home screen for the following farmers");
        for (Map<String, String> iRow : pFarmers.asMaps(String.class, String.class))
        {
            iAction("CLICK",   "XPATH", ObjReader.getLocator("iNavbarLink").replace("{LINK}", "Home"), null);
            iAction("LIST",    "XPATH", ObjReader.getLocator("iSearchByTypeSelect"), "Farmer");
            iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iHomeSurname"), iRow.get("surname"));
            iAction("LIST",    "XPATH", ObjReader.getLocator("iHomeCounty"), iRow.get("county"));
            iAction("CLICK",   "XPATH", ObjReader.getLocator("iHomeSearchButton"), null);
        }
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theApplicationShouldBeOpenableFromTheSearchResults
    // Description   : Confirms a search result row opens into the application.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the application should be openable from the search results")
    public void theApplicationShouldBeOpenableFromTheSearchResults()
    {
        log.info("[STEP] the application should be openable from the search results");
        iOpenFirstApplication();
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iApplicationSummaryPanel"), null);
    }

    // =================================================================================================================================
    // SECTION 9 : Parcels, Reference No. and Online Response tabs
    // =================================================================================================================================

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSearchesTheParcelsScreenForTheNextLpisParcel
    // Description   : Opens the Parcels tab and searches the next LPIS parcel.
    // Parameters    : pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user searches the Parcels screen for the next LPIS parcel for scheme year {string}")
    public void theStaffUserSearchesTheParcelsScreenForTheNextLpisParcel(String pSchemeYear)
    {
        log.info("[STEP] the staff user searches the Parcels screen for the next LPIS parcel for scheme year " + pSchemeYear);
        String iParcel = iNextFromPool(StaffTestData.pool(Pool.PARCELS, null), iParcelCursor, Pool.PARCELS.description());
        iParcelCursor++;

        iAction("CLICK",   "XPATH", ObjReader.getLocator("iTab").replace("{TAB}", "Parcels"), null);
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iParcelsParcelNumber"), iParcel);
        iAction("LIST",    "XPATH", ObjReader.getLocator("iParcelsSchemeYear"), pSchemeYear);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iParcelsSearchButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSearchesTheParcelsScreenForInvalidParcel
    // Description   : Searches the Parcels tab with a malformed value.
    // Parameters    : pParcelNumber (String) - invalid value
    //                 pSchemeYear   (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user searches the Parcels screen for invalid parcel {string} for scheme year {string}")
    public void theStaffUserSearchesTheParcelsScreenForInvalidParcel(String pParcelNumber, String pSchemeYear)
    {
        log.info("[STEP] the staff user searches the Parcels screen for invalid parcel '" + pParcelNumber + "' for scheme year " + pSchemeYear);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iTab").replace("{TAB}", "Parcels"), null);
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iParcelsParcelNumber"), pParcelNumber);
        iAction("LIST",    "XPATH", ObjReader.getLocator("iParcelsSchemeYear"), pSchemeYear);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iParcelsSearchButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserClearsTheParcelSearch
    // Description   : Clicks Clear on the Parcels tab.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the staff user clears the parcel search")
    public void theStaffUserClearsTheParcelSearch()
    {
        log.info("[STEP] the staff user clears the parcel search");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iParcelsClearButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSearchesTheParcelsScreenWithNoParcelNumber
    // Description   : Clicks Search on the Parcels tab with the field empty.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the staff user searches the Parcels screen with no parcel number")
    public void theStaffUserSearchesTheParcelsScreenWithNoParcelNumber()
    {
        log.info("[STEP] the staff user searches the Parcels screen with no parcel number");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iParcelsSearchButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theFollowingParcelActionsShouldBeAvailable
    // Description   : Exercises each parcel action named in the table and confirms it opens. Dialog actions are
    //                 dismissed and the map action returns to Land Details, leaving the screen ready for the next.
    // Parameters    : pActions (DataTable) - single column of action button labels
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the following parcel actions should be available")
    public void theFollowingParcelActionsShouldBeAvailable(DataTable pActions)
    {
        log.info("[STEP] the following parcel actions should be available");
        for (String iActionName : pActions.asList())
        {
            iAction("CLICK", "XPATH", ObjReader.getLocator("iParcelActionButton").replace("{LABEL}", iActionName), null);

            switch (iActionName)
            {
                case "View Claimants":
                    iAction("CLICK", "XPATH", ObjReader.getLocator("iDialogButton").replace("{LABEL}", "Cancel"), null);
                    break;

                case "Parcel History":
                    iAction("CLICK", "XPATH", ObjReader.getLocator("iDialogButton").replace("{LABEL}", "Close"), null);
                    break;

                case "View Map":
                    iAction("CLICK", "XPATH", ObjReader.getLocator("iReturnToLandDetailsLink"), null);
                    break;

                default:
                    break;
            }
        }
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSearchesTheReferenceNoScreenForTheNextReferenceNumber
    // Description   : Opens the Reference No. tab and searches the next reference.
    // Parameters    : pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user searches the Reference No. screen for the next reference number for scheme year {string}")
    public void theStaffUserSearchesTheReferenceNoScreenForTheNextReferenceNumber(String pSchemeYear)
    {
        log.info("[STEP] the staff user searches the Reference No. screen for the next reference number for scheme year " + pSchemeYear);
        String iReference = iNextReference(pSchemeYear);

        iAction("CLICK",   "XPATH", ObjReader.getLocator("iTab").replace("{TAB}", "Reference No."), null);
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iReferenceNoField"), iReference);
        iAction("LIST",    "XPATH", ObjReader.getLocator("iReferenceNoSchemeYear"), pSchemeYear);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iReferenceNoSearchButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSearchesTheReferenceNoScreenForInvalidReference
    // Description   : Searches the Reference No. tab with a malformed value.
    // Parameters    : pReference (String) - invalid value
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user searches the Reference No. screen for invalid reference {string}")
    public void theStaffUserSearchesTheReferenceNoScreenForInvalidReference(String pReference)
    {
        log.info("[STEP] the staff user searches the Reference No. screen for invalid reference '" + pReference + "'");
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iTab").replace("{TAB}", "Reference No."), null);
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iReferenceNoField"), pReference);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iReferenceNoSearchButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSearchesTheOnlineResponseScreenForTheNextSubmittedHerd
    // Description   : Opens the Online Response tab and searches the next submitted herd, with a scheme year.
    // Parameters    : pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user searches the Online Response screen for the next submitted herd for scheme year {string}")
    public void theStaffUserSearchesTheOnlineResponseScreenForTheNextSubmittedHerd(String pSchemeYear)
    {
        log.info("[STEP] the staff user searches the Online Response screen for the next submitted herd for scheme year " + pSchemeYear);
        String iHerd = iNextSubmittedHerd(pSchemeYear);

        iAction("CLICK",   "XPATH", ObjReader.getLocator("iTab").replace("{TAB}", "Online Response"), null);
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iOnlineResponseHerdNumber"), iHerd);
        iAction("LIST",    "XPATH", ObjReader.getLocator("iOnlineResponseSchemeYear"), pSchemeYear);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iOnlineResponseSearchButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSearchesTheOnlineResponseScreenForTheNextSubmittedHerdNoYear
    // Description   : Online Response search by herd with no scheme year - legacy AT-TC-13 omits the year.
    //                 The herd still has to come from a pool: Selenium's hook filled one submitted pool, so this
    //                 reads the pool of staff.default.scheme.year (default 2025).
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026 | Updated: 05-10-2026 (Playwright)
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the staff user searches the Online Response screen for the next submitted herd")
    public void theStaffUserSearchesTheOnlineResponseScreenForTheNextSubmittedHerdNoYear()
    {
        log.info("[STEP] the staff user searches the Online Response screen for the next submitted herd");
        String iHerd = iNextSubmittedHerd(ConfigManager.getOrDefault("staff.default.scheme.year", "2025"));

        iAction("CLICK",   "XPATH", ObjReader.getLocator("iTab").replace("{TAB}", "Online Response"), null);
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iOnlineResponseHerdNumber"), iHerd);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iOnlineResponseSearchButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSearchesTheOnlineResponseScreenWithNoCriteria
    // Description   : Clicks Search on Online Response with no criteria entered.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user searches the Online Response screen with no criteria")
    public void theStaffUserSearchesTheOnlineResponseScreenWithNoCriteria()
    {
        log.info("[STEP] the staff user searches the Online Response screen with no criteria");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iTab").replace("{TAB}", "Online Response"), null);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iOnlineResponseSearchButton"), null);
    }

    // =================================================================================================================================
    // SECTION 10 : SIM
    // =================================================================================================================================

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserHasOpenedTheSimScreenForHerd
    // Description   : Opens a herd's application and navigates straight to its SIM screen.
    // Parameters    : pHerdNumber (String) - fixture herd
    //                 pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the staff user has opened the SIM screen for herd {string} for scheme year {string}")
    public void theStaffUserHasOpenedTheSimScreenForHerd(String pHerdNumber, String pSchemeYear)
    {
        log.info("[STEP] the staff user has opened the SIM screen for herd " + pHerdNumber + " for scheme year " + pSchemeYear);
        iCurrentHerd = pHerdNumber;
        iSearchHomeByHerd(pHerdNumber, pSchemeYear);
        iOpenFirstApplication();
        iAction("CLICK", "XPATH", ObjReader.getLocator("iNavbarLink").replace("{LINK}", "SIM"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserAmendsSimParcelWithTheFollowingValues
    // Description   : Opens a SIM parcel's side drawer, applies each field/value pair from the table, and saves.
    //                 One step replaces legacy's open-drawer, enter-value, click-save sequence.
    // Parameters    : pParcelNumber (String)    - the SIM parcel to amend
    //                 pValues       (DataTable) - field/value pairs, e.g. simFoundArea | 4
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user amends SIM parcel {string} with the following values")
    public void theStaffUserAmendsSimParcelWithTheFollowingValues(String pParcelNumber, DataTable pValues)
    {
        log.info("[STEP] the staff user amends SIM parcel " + pParcelNumber + " with the following values");
        Map<String, String> iValues = pValues.asMap(String.class, String.class);

        iAction("CLICK", "XPATH", ObjReader.getLocator("iSimParcelRow").replace("{PARCEL}", pParcelNumber), null);

        for (Map.Entry<String, String> iEntry : iValues.entrySet())
        {
            String iLocatorKey = "i" + iEntry.getKey().substring(0, 1).toUpperCase() + iEntry.getKey().substring(1);
            iAction("TEXTBOX", "XPATH", ObjReader.getLocator(iLocatorKey), iEntry.getValue());
        }

        iAction("CLICK", "XPATH", ObjReader.getLocator("iSaveChangesButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserTogglesTheSimIndicatorOnParcel
    // Description   : Opens a SIM parcel drawer, flips its SIM indicator and saves. This is a scheme eligibility
    //                 change rather than an area correction, hence its own step.
    //                 Selenium iAction("CHECKBOX", ..., null) flipped the box; Playwright CHECKBOX needs CHECK or
    //                 UNCHECK, so the flip is a CLICK.
    // Parameters    : pParcelNumber (String) - the parcel
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026 | Updated: 05-10-2026 (Playwright)
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user toggles the SIM indicator on parcel {string}")
    public void theStaffUserTogglesTheSimIndicatorOnParcel(String pParcelNumber)
    {
        log.info("[STEP] the staff user toggles the SIM indicator on parcel " + pParcelNumber);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iSimParcelRow").replace("{PARCEL}", pParcelNumber), null);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iSimIndicator"), null);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iSaveChangesButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSubmitsTheSimAmendmentsWithNote
    // Description   : Submits the accumulated SIM amendments with a note and finishes the dialog.
    // Parameters    : pNote (String) - submission note
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user submits the SIM amendments with note {string}")
    public void theStaffUserSubmitsTheSimAmendmentsWithNote(String pNote)
    {
        log.info("[STEP] the staff user submits the SIM amendments with note '" + pNote + "'");
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iSubmitButton"), null);
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iSimNotes"), pNote);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iFinishButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserRevertsTheSimAmendments
    // Description   : Reverts unsaved SIM amendments back to the last submitted state.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user reverts the SIM amendments")
    public void theStaffUserRevertsTheSimAmendments()
    {
        log.info("[STEP] the staff user reverts the SIM amendments");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iRevertButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserTogglesTheSimSchemeOption
    // Description   : Flips the SIM scheme opt-in toggle on the application.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the staff user toggles the SIM scheme option")
    public void theStaffUserTogglesTheSimSchemeOption()
    {
        log.info("[STEP] the staff user toggles the SIM scheme option");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iSimSchemeToggle"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserOptsOutOfSimWithNote
    // Description   : Opts the herd OUT of SIM and submits with a note. Named by intent rather than mechanics so
    //                 the feature reads as the business action, not a toggle click.
    // Parameters    : pNote (String) - submission note
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user opts out of SIM with note {string}")
    public void theStaffUserOptsOutOfSimWithNote(String pNote)
    {
        log.info("[STEP] the staff user opts out of SIM with note '" + pNote + "'");
        iToggleSimAndSubmit(pNote);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserOptsInToSimWithNote
    // Description   : Opts the herd IN to SIM and submits with a note.
    // Parameters    : pNote (String) - submission note
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user opts in to SIM with note {string}")
    public void theStaffUserOptsInToSimWithNote(String pNote)
    {
        log.info("[STEP] the staff user opts in to SIM with note '" + pNote + "'");
        iToggleSimAndSubmit(pNote);
    }

    // Opt-in and opt-out are the same clicks in Selenium: SIM screen, toggle, Submit, note, Finish
    private void iToggleSimAndSubmit(String pNote)
    {
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iNavbarLink").replace("{LINK}", "SIM"), null);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iSimSchemeToggle"), null);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iSubmitButton"), null);
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iSimNotes"), pNote);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iFinishButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theSimAmendmentShouldBeSaved
    // Description   : Confirms a SIM amendment saved without error.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the SIM amendment should be saved")
    public void theSimAmendmentShouldBeSaved()
    {
        log.info("[STEP] the SIM amendment should be saved");
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iSimParcelTable"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theOriginalApplicationTotalShouldBeDisplayed
    // Description   : Confirms the ORIGINAL submitted total is still shown after amendment - proving the amended
    //                 figure has not overwritten what the applicant originally claimed.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the original application total should be displayed")
    public void theOriginalApplicationTotalShouldBeDisplayed()
    {
        log.info("[STEP] the original application total should be displayed");
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iOriginalApplicationTotal"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theSimTickShouldBeShownOnTheBissApplicationSummary
    // Description   : Confirms the SIM tick renders on the BISS Application summary - the screen that must stay
    //                 in agreement with the SIM screen.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the SIM tick should be shown on the BISS Application summary")
    public void theSimTickShouldBeShownOnTheBissApplicationSummary()
    {
        log.info("[STEP] the SIM tick should be shown on the BISS Application summary");
        iAction("CLICK",         "XPATH", ObjReader.getLocator("iNavbarLink").replace("{LINK}", "BISS Application"), null);
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iBissApplicationSimTick"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theCalculatedPayableAreaShouldChangeWithTheSimOptInState
    // Description   : Confirms the calculated payable area is present after an opt-in change. Payment is based on
    //                 this figure, so it must move with the opt-in state.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the calculated payable area should change with the SIM opt-in state")
    public void theCalculatedPayableAreaShouldChangeWithTheSimOptInState()
    {
        log.info("[STEP] the calculated payable area should change with the SIM opt-in state");
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iSimCalculatedPayableArea"), null);
    }

    // =================================================================================================================================
    // SECTION 11 : History and audit
    // =================================================================================================================================

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theAmendmentShouldBeRecordedInTheApplicationHistory
    // Description   : Confirms the last action left an audit trail. Every amendment to a live scheme application
    //                 must be traceable, which is why this assertion follows each one.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the amendment should be recorded in the application history")
    public void theAmendmentShouldBeRecordedInTheApplicationHistory()
    {
        log.info("[STEP] the amendment should be recorded in the application history");
        iAction("CLICK",         "XPATH", ObjReader.getLocator("iNavbarLink").replace("{LINK}", "Notes/History"), null);
        iAction("CLICK",         "XPATH", ObjReader.getLocator("iTab").replace("{TAB}", "History"), null);
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iHistoryFirstRow"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theApplicationHistoryShouldRecord
    // Description   : Asserts a specific system note appears in the history, verbatim. Used where the note text
    //                 itself is the contract - e.g. the Active Farmer stop applied/lifted notes, whose exact
    //                 wording tells staff whether payment is blocked.
    // Parameters    : pExpectedNote (String) - the note text
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the application history should record {string}")
    public void theApplicationHistoryShouldRecord(String pExpectedNote)
    {
        log.info("[STEP] the application history should record '" + pExpectedNote + "'");
        iAction("CLICK",      "XPATH", ObjReader.getLocator("iNavbarLink").replace("{LINK}", "Notes/History"), null);
        iAction("CLICK",      "XPATH", ObjReader.getLocator("iTab").replace("{TAB}", "History"), null);
        iAction("VERIFYTEXT", "XPATH", ObjReader.getLocator("iHistoryEntry").replace("{TEXT}", pExpectedNote), pExpectedNote);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserOpensTheNotesAndHistoryScreen
    // Description   : Opens the next submitted herd's Notes and History screen.
    // Parameters    : pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user opens the Notes and History screen for the next submitted herd for scheme year {string}")
    public void theStaffUserOpensTheNotesAndHistoryScreen(String pSchemeYear)
    {
        log.info("[STEP] the staff user opens the Notes and History screen for the next submitted herd for scheme year " + pSchemeYear);
        iCurrentHerd = iNextSubmittedHerd(pSchemeYear);
        iSearchHomeByHerd(iCurrentHerd, pSchemeYear);
        iOpenFirstApplication();
        iAction("CLICK", "XPATH", ObjReader.getLocator("iNavbarLink").replace("{LINK}", "Notes/History"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserRaisesTheAddNoteDialog
    // Description   : Opens the Add Note dialog.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the staff user raises the add note dialog")
    public void theStaffUserRaisesTheAddNoteDialog()
    {
        log.info("[STEP] the staff user raises the add note dialog");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iAddNoteButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theApplicationHistoryShouldBeDisplayed
    // Description   : Confirms the history screen rendered.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the application history should be displayed")
    public void theApplicationHistoryShouldBeDisplayed()
    {
        log.info("[STEP] the application history should be displayed");
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iNotesHistoryPanel"), null);
    }

    // =================================================================================================================================
    // SECTION 12 : Scheme selection and amendments
    // =================================================================================================================================

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserAmendsTheApplicationForTheNextSubmittedHerd
    // Description   : Opens the next submitted herd's application in AMEND mode.
    // Parameters    : pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user amends the application for the next submitted herd for scheme year {string}")
    public void theStaffUserAmendsTheApplicationForTheNextSubmittedHerd(String pSchemeYear)
    {
        log.info("[STEP] the staff user amends the application for the next submitted herd for scheme year " + pSchemeYear);
        iCurrentHerd = iNextSubmittedHerd(pSchemeYear);
        iSearchHomeByHerd(iCurrentHerd, pSchemeYear);
        iOpenFirstApplicationForAmend();
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserAmendsTheApplicationForTheNextSimOptedHerd
    // Description   : Opens the next SIM opted-in herd in AMEND mode.
    // Parameters    : pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user amends the application for the next SIM-opted herd for scheme year {string}")
    public void theStaffUserAmendsTheApplicationForTheNextSimOptedHerd(String pSchemeYear)
    {
        log.info("[STEP] the staff user amends the application for the next SIM-opted herd for scheme year " + pSchemeYear);
        iCurrentHerd = iNextSimOptedHerd(pSchemeYear);
        iSearchHomeByHerd(iCurrentHerd, pSchemeYear);
        iOpenFirstApplicationForAmend();
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserAmendsTheApplicationForHerd
    // Description   : Opens a named fixture herd's application in AMEND mode.
    // Parameters    : pHerdNumber (String) - fixture herd
    //                 pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user amends the application for herd {string} for scheme year {string}")
    public void theStaffUserAmendsTheApplicationForHerd(String pHerdNumber, String pSchemeYear)
    {
        log.info("[STEP] the staff user amends the application for herd " + pHerdNumber + " for scheme year " + pSchemeYear);
        iCurrentHerd = pHerdNumber;
        iSearchHomeByHerd(pHerdNumber, pSchemeYear);
        iOpenFirstApplicationForAmend();
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserOpensInternalAmendmentsForHerd
    // Description   : Opens a herd's application and navigates to the BISS Amendments screen.
    // Parameters    : pHerdNumber (String) - fixture herd
    //                 pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user opens Internal Amendments for herd {string} for scheme year {string}")
    public void theStaffUserOpensInternalAmendmentsForHerd(String pHerdNumber, String pSchemeYear)
    {
        log.info("[STEP] the staff user opens Internal Amendments for herd " + pHerdNumber + " for scheme year " + pSchemeYear);
        iCurrentHerd = pHerdNumber;
        iSearchHomeByHerd(pHerdNumber, pSchemeYear);
        iOpenFirstApplication();
        iAction("CLICK", "XPATH", ObjReader.getLocator("iNavbarLink").replace("{LINK}", "BISS Amendments"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSelectsTheFollowingSchemes
    // Description   : Clicks each named scheme card. Replaces one step per scheme in legacy.
    // Parameters    : pSchemes (DataTable) - single column of scheme names
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the staff user selects the following schemes")
    public void theStaffUserSelectsTheFollowingSchemes(DataTable pSchemes)
    {
        log.info("[STEP] the staff user selects the following schemes");
        iClickSchemeCards(pSchemes.asList());
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserDeselectsTheFollowingSchemes
    // Description   : Deselects each named scheme card. Mechanically the same click as selection, but named
    //                 separately so the feature states the intent - fixture resets read as resets.
    // Parameters    : pSchemes (DataTable) - single column of scheme names
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the staff user deselects the following schemes")
    public void theStaffUserDeselectsTheFollowingSchemes(DataTable pSchemes)
    {
        log.info("[STEP] the staff user deselects the following schemes");
        iClickSchemeCards(pSchemes.asList());
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserGoesBackAndDeselectsTheFollowingSchemes
    // Description   : Uses Back to abandon a selection without submitting - the escape path that prevents an
    //                 accidental scheme change from reaching the applicant's record.
    // Parameters    : pSchemes (DataTable) - single column of scheme names
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the staff user goes back and deselects the following schemes")
    public void theStaffUserGoesBackAndDeselectsTheFollowingSchemes(DataTable pSchemes)
    {
        log.info("[STEP] the staff user goes back and deselects the following schemes");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iBackButton"), null);
        iClickSchemeCards(pSchemes.asList());
    }

    // One click per named scheme card (select and deselect are the same click)
    private void iClickSchemeCards(List<String> pSchemes)
    {
        for (String iScheme : pSchemes)
        {
            iAction("CLICK", "XPATH", ObjReader.getLocator("iSchemeCard").replace("{SCHEME}", iScheme), null);
        }
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserProceedsToTheNextStep
    // Description   : Advances the amendment stepper.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the staff user proceeds to the next step")
    public void theStaffUserProceedsToTheNextStep()
    {
        log.info("[STEP] the staff user proceeds to the next step");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iNextButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSubmitsTheAmendment
    // Description   : Advances the stepper and submits. Combines the Next + Submit Changes pair legacy always
    //                 performs together.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the staff user submits the amendment")
    public void theStaffUserSubmitsTheAmendment()
    {
        log.info("[STEP] the staff user submits the amendment");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iNextButton"), null);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iSubmitChangesButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSubmitsTheAmendmentAndConfirms
    // Description   : Submits an amendment and acknowledges the confirmation dialog.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the staff user submits the amendment and confirms")
    public void theStaffUserSubmitsTheAmendmentAndConfirms()
    {
        log.info("[STEP] the staff user submits the amendment and confirms");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iNextButton"), null);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iSubmitChangesButton"), null);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iDialogButton").replace("{LABEL}", "OK"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theSchemeCardsShouldBePresentedAsFollows
    // Description   : Verifies each scheme card carries the expected acronym and full title, optionally at a
    //                 given position. Replaces four separate verify steps per card in legacy.
    // Parameters    : pCards (DataTable) - columns: acronym, title; optional column: position
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the scheme cards should be presented as follows")
    public void theSchemeCardsShouldBePresentedAsFollows(DataTable pCards)
    {
        log.info("[STEP] the scheme cards should be presented as follows");
        for (Map<String, String> iRow : pCards.asMaps(String.class, String.class))
        {
            String iAcronym  = iRow.get("acronym");
            String iTitle    = iRow.get("title");
            String iPosition = iRow.get("position");

            if (iPosition != null)
            {
                iAction("VERIFYTEXT", "XPATH", ObjReader.getLocator("iSchemeCardByPosition").replace("{INDEX}", iPosition), iAcronym);
            }
            else
            {
                iAction("VERIFYTEXT", "XPATH", ObjReader.getLocator("iSchemeCardTitle").replace("{SCHEME}", iAcronym), iAcronym);
            }

            iAction("VERIFYTEXT", "XPATH", ObjReader.getLocator("iSchemeCardAcronym").replace("{SCHEME}", iAcronym), iTitle);
        }
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theFollowingSchemeDetailsDialogsShouldBeReadable
    // Description   : Opens each scheme's View Details dialog, reads it and closes it.
    // Parameters    : pDialogs (DataTable) - single column of scheme full titles
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the following scheme details dialogs should be readable")
    public void theFollowingSchemeDetailsDialogsShouldBeReadable(DataTable pDialogs)
    {
        log.info("[STEP] the following scheme details dialogs should be readable");
        for (String iDialog : pDialogs.asList())
        {
            iAction("CLICK",         "XPATH", ObjReader.getLocator("iSchemeViewDetailsLink").replace("{SCHEME}", iDialog), null);
            iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iSchemeDetailsDialog").replace("{TITLE}", iDialog), null);
            iAction("CLICK",         "XPATH", ObjReader.getLocator("iDialogButton").replace("{LABEL}", "Close"), null);
        }
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theFollowingSchemesShouldOfferASelectionToggle
    // Description   : Verifies each named scheme exposes a toggle.
    // Parameters    : pSchemes (DataTable) - single column of scheme names
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the following schemes should offer a selection toggle")
    public void theFollowingSchemesShouldOfferASelectionToggle(DataTable pSchemes)
    {
        log.info("[STEP] the following schemes should offer a selection toggle");
        for (String iScheme : pSchemes.asList())
        {
            iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iSchemeToggle").replace("{SCHEME}", iScheme), null);
        }
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theSelectionStateShouldBeReadableForTheFollowingSchemes
    // Description   : Verifies each named scheme reports a readable selection state. Presence rather than a
    //                 specific on/off value: the starting state varies by herd, and legacy printed rather than
    //                 asserted it. What matters is that the panel renders a state for every scheme.
    // Parameters    : pSchemes (DataTable) - single column of scheme names
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the selection state should be readable for the following schemes")
    public void theSelectionStateShouldBeReadableForTheFollowingSchemes(DataTable pSchemes)
    {
        log.info("[STEP] the selection state should be readable for the following schemes");
        for (String iScheme : pSchemes.asList())
        {
            iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iSchemeCard").replace("{SCHEME}", iScheme), null);
        }
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theSchemeShouldBeSelected
    // Description   : Asserts one named scheme is currently selected.
    // Parameters    : pScheme (String) - scheme name
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the {string} scheme is selected")
    public void theSchemeShouldBeSelected(String pScheme)
    {
        log.info("[STEP] the " + pScheme + " scheme is selected");
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iSchemeCardSelected").replace("{SCHEME}", pScheme), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theCardShouldHaveTitleWithAbbreviation
    // Description   : Verifies a card's title and abbreviation together.
    // Parameters    : pTitle        (String) - card title, e.g. MSSM
    //                 pAbbreviation (String) - full scheme name
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the card has title {string} with abbreviation {string}")
    public void theCardShouldHaveTitleWithAbbreviation(String pTitle, String pAbbreviation)
    {
        log.info("[STEP] the card has title " + pTitle + " with abbreviation " + pAbbreviation);
        iAction("VERIFYTEXT", "XPATH", ObjReader.getLocator("iSchemeCardTitle").replace("{SCHEME}", pTitle), pTitle);
        iAction("VERIFYTEXT", "XPATH", ObjReader.getLocator("iSchemeCardAcronym").replace("{SCHEME}", pTitle), pAbbreviation);
    }

    // =================================================================================================================================
    // SECTION 13 : Submission details and late penalties
    // =================================================================================================================================

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theSubmissionDetailsShouldShowLatePenaltiesAsFollows
    // Description   : Asserts each named scheme either DOES or DOES NOT carry a late penalty. This is the core of
    //                 the PAYMENTS category: BISS, CISYF and NR have separate deadlines, so a herd can be late for
    //                 one and on time for another. Flagging the wrong scheme means an applicant is docked money
    //                 they should keep - hence the positive AND negative checks in one table.
    //                 Change from Selenium: the error is looked for during PROBE_SECONDS (Selenium took one
    //                 immediate findElements snapshot).
    // Parameters    : pPenalties (DataTable) - columns: scheme, penalty (yes/no)
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026 | Updated: 05-10-2026 (Playwright)
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the submission details should show late penalties as follows")
    public void theSubmissionDetailsShouldShowLatePenaltiesAsFollows(DataTable pPenalties)
    {
        log.info("[STEP] the submission details should show late penalties as follows");
        for (Map<String, String> iRow : pPenalties.asMaps(String.class, String.class))
        {
            String  iScheme        = iRow.get("scheme");
            String  iExpectPenalty = iRow.get("penalty");
            String  iErrorLocator  = ObjReader.getLocator("iSubmissionDetailError").replace("{FIELD}", iScheme);
            boolean iHasPenalty    = UiHelpers.isVisible(UiHelpers.byXpath(iErrorLocator), PROBE_SECONDS);

            log.info("[PAYMENTS] " + iScheme + " late penalty shown=" + iHasPenalty + " | expected=" + iExpectPenalty);

            if ("yes".equalsIgnoreCase(iExpectPenalty) && !iHasPenalty)
            {
                throw new AssertionError("Expected a late penalty against '" + iScheme + "' but none is shown.");
            }

            if ("no".equalsIgnoreCase(iExpectPenalty) && iHasPenalty)
            {
                throw new AssertionError("A late penalty is shown against '" + iScheme + "' but none was expected. "
                        + "An applicant may be penalised for a scheme they submitted on time.");
            }
        }
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theSubmissionDetailsShouldRecordTheFollowingFields
    // Description   : Verifies each named Submission Details field is present. Legacy captured and PRINTED these
    //                 values without asserting them; presence is preserved as the check, since the herd is DB
    //                 resolved and the feature cannot know the expected value.
    // Parameters    : pFields (DataTable) - single column of field labels
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the submission details should record the following fields")
    public void theSubmissionDetailsShouldRecordTheFollowingFields(DataTable pFields)
    {
        log.info("[STEP] the submission details should record the following fields");
        for (String iField : pFields.asList())
        {
            iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iSubmissionDetailField").replace("{FIELD}", iField), null);
        }
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theSubmissionDetailsValueShouldBe
    // Description   : Asserts a Submission Details field holds an exact value - e.g. "Amendment" must read "None"
    //                 on an application never amended, rather than sitting empty.
    // Parameters    : pField         (String) - field label
    //                 pExpectedValue (String) - expected value
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the submission details {string} value should be {string}")
    public void theSubmissionDetailsValueShouldBe(String pField, String pExpectedValue)
    {
        log.info("[STEP] the submission details " + pField + " value should be " + pExpectedValue);
        iAction("VERIFYTEXT", "XPATH", ObjReader.getLocator("iSubmissionDetailValue").replace("{FIELD}", pField), pExpectedValue);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserAmendsTheApplicationBySelectingTheFollowingSchemes
    // Description   : Opens the amend path from an already-open application and selects schemes. Used where a
    //                 section is already inside an application and needs to amend it without re-searching.
    // Parameters    : pSchemes (DataTable) - single column of scheme names
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user amends the application by selecting the following schemes")
    public void theStaffUserAmendsTheApplicationBySelectingTheFollowingSchemes(DataTable pSchemes)
    {
        log.info("[STEP] the staff user amends the application by selecting the following schemes");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iNavbarLink").replace("{LINK}", "BISS Amendments"), null);
        iClickSchemeCards(pSchemes.asList());
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserRequestsAnEhChangeOnTheFirstPlot
    // Description   : Opens the first plot's side drawer, requests an Eh (eligible hectares) change with a reason,
    //                 saves and closes. An Eh change alters the area an applicant is paid on, so it carries a
    //                 mandatory reason.
    //                 Selenium iAction("CHECKBOX", ..., null); the request box must end up ticked, so CHECK is used
    //                 (it does not untick a box that is already ticked).
    // Parameters    : pReason (String) - the reason for the change
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026 | Updated: 05-10-2026 (Playwright)
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user requests an Eh change on the first plot with reason {string}")
    public void theStaffUserRequestsAnEhChangeOnTheFirstPlot(String pReason)
    {
        log.info("[STEP] the staff user requests an Eh change on the first plot with reason '" + pReason + "'");
        iAction("CLICK",    "XPATH", ObjReader.getLocator("iNextButton"), null);
        iAction("CLICK",    "XPATH", ObjReader.getLocator("iFirstPlotReference"), null);
        iAction("CHECKBOX", "XPATH", ObjReader.getLocator("iRequestEhChangeCheckbox"), "CHECK");
        iAction("TEXTBOX",  "XPATH", ObjReader.getLocator("iEhChangeReason"), pReason);
        iAction("CLICK",    "XPATH", ObjReader.getLocator("iStepperSaveChangesButton"), null);
        iAction("CLICK",    "XPATH", ObjReader.getLocator("iStepperCancelButton"), null);
    }

    // =================================================================================================================================
    // SECTION 14 : Active Farmer admin check and appeals
    // =================================================================================================================================

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserOpensTheActiveFarmerScreenForTheNextAdminCheckHerd
    // Description   : Takes the next admin-check herd, opens its application and navigates to Active Farmer.
    // Parameters    : pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user opens the Active Farmer screen for the next admin-check herd for scheme year {string}")
    public void theStaffUserOpensTheActiveFarmerScreenForTheNextAdminCheckHerd(String pSchemeYear)
    {
        log.info("[STEP] the staff user opens the Active Farmer screen for the next admin-check herd for scheme year " + pSchemeYear);
        iCurrentHerd = iNextFromPool(StaffTestData.pool(Pool.ADMINCHECK, pSchemeYear), iAdminCheckHerdCursor, Pool.ADMINCHECK.description());
        iAdminCheckHerdCursor++;
        iSearchHomeByHerd(iCurrentHerd, pSchemeYear);
        iOpenFirstApplication();
        iAction("CLICK", "XPATH", ObjReader.getLocator("iNavbarLink").replace("{LINK}", "Active Farmer"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserReturnsToTheActiveFarmerScreenForTheSameAdminCheckHerd
    // Description   : Re-opens the Active Farmer screen on the herd already in play WITHOUT advancing the cursor.
    //                 Legacy AT-TC-02 silently depended on the check started by AT-TC-01 still being in progress
    //                 on the same herd - an implicit cross-scenario dependency that breaks under reordering or
    //                 parallel execution. Chaining makes it explicit and safe.
    // Parameters    : pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user returns to the Active Farmer screen for the same admin-check herd for scheme year {string}")
    public void theStaffUserReturnsToTheActiveFarmerScreenForTheSameAdminCheckHerd(String pSchemeYear)
    {
        log.info("[STEP] the staff user returns to the Active Farmer screen for the same admin-check herd for scheme year " + pSchemeYear);
        if (iCurrentHerd == null)
        {
            throw new IllegalStateException("No herd is currently in play. This step re-opens the herd used by the previous section and "
                    + "cannot run first in a scenario.");
        }

        iSearchHomeByHerd(iCurrentHerd, pSchemeYear);
        iOpenFirstApplication();
        iAction("CLICK", "XPATH", ObjReader.getLocator("iNavbarLink").replace("{LINK}", "Active Farmer"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserStartsTheActiveFarmerAdminCheck
    // Description   : Starts the admin check and confirms the send dialog. Starting a check applies a STOP that
    //                 blocks payment until it is resolved.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the staff user starts the active farmer admin check")
    public void theStaffUserStartsTheActiveFarmerAdminCheck()
    {
        log.info("[STEP] the staff user starts the active farmer admin check");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iStartAdminCheckButton"), null);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iDialogButton").replace("{LABEL}", "Send"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserCompletesTheAdminCheckWithTheFollowingResult
    // Description   : Records an admin check outcome with its mandatory note. APPROVED lifts the payment stop;
    //                 REJECTED leaves it in place. The note text carries into the system note, which is why the
    //                 feature asserts it verbatim afterwards.
    // Parameters    : pResult (DataTable) - keys: result (APPROVED/REJECTED), notes
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the staff user completes the admin check with the following result")
    public void theStaffUserCompletesTheAdminCheckWithTheFollowingResult(DataTable pResult)
    {
        log.info("[STEP] the staff user completes the admin check with the following result");
        Map<String, String> iResult = pResult.asMap(String.class, String.class);

        iAction("LIST",    "XPATH", ObjReader.getLocator("iAdminCheckResultSelect"), iResult.get("result"));
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iAdminNotes"), iResult.get("notes"));
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iSaveChangesButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserRaisesAnAppealWithSupportingEvidence
    // Description   : Runs the full appeal path - start the appeal, confirm it, upload the farmer's evidence and
    //                 submit it for review. The file path comes from the TestData column AppealEvidencePath.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the staff user raises an appeal with supporting evidence")
    public void theStaffUserRaisesAnAppealWithSupportingEvidence()
    {
        log.info("[STEP] the staff user raises an appeal with supporting evidence");
        iAction("CLICK",      "XPATH", ObjReader.getLocator("iStartAppealProcessButton"), null);
        iAction("CLICK",      "XPATH", ObjReader.getLocator("iDialogButton").replace("{LABEL}", "Yes, Appeal"), null);
        iAction("CLICK",      "XPATH", ObjReader.getLocator("iUploadDocumentButton"), null);
        iAction("UPLOADFILE", "XPATH", ObjReader.getLocator("iDocumentUploadInput"), "TD:AppealEvidencePath");
        iAction("CLICK",      "XPATH", ObjReader.getLocator("iSubmitButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theActiveFarmerTabShouldBeAvailable
    // Description   : Opens the Active Farmer tab and confirms it renders.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the Active Farmer tab should be available")
    public void theActiveFarmerTabShouldBeAvailable()
    {
        log.info("[STEP] the Active Farmer tab should be available");
        iAction("CLICK",         "XPATH", ObjReader.getLocator("iTab").replace("{TAB}", "Active Farmer"), null);
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iActiveFarmerPanel"), null);
    }

    // =================================================================================================================================
    // SECTION 15 : Correspondence and query letters
    // =================================================================================================================================

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserStartsACoordinationAmendmentToHerd
    // Description   : Opens Coordination Amendments and starts a transfer to the nominated destination herd.
    // Parameters    : pNewHerdNumber (String) - destination herd
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the staff user starts a coordination amendment to herd {string}")
    public void theStaffUserStartsACoordinationAmendmentToHerd(String pNewHerdNumber)
    {
        log.info("[STEP] the staff user starts a coordination amendment to herd " + pNewHerdNumber);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iNavbarLink").replace("{LINK}", "Coordination Amendments"), null);
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iNewHerdNo"), pNewHerdNumber);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iStartButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserMovesAllParcelsToTheNewHerd
    // Description   : Moves the whole holding in one action, rather than parcel by parcel.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the staff user moves all parcels to the new herd")
    public void theStaffUserMovesAllParcelsToTheNewHerd()
    {
        log.info("[STEP] the staff user moves all parcels to the new herd");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iMoveAllToNewHerdButton"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theCoordinationAmendmentShouldBeSaved
    // Description   : Saves the transfer and confirms it persisted.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the coordination amendment should be saved")
    public void theCoordinationAmendmentShouldBeSaved()
    {
        log.info("[STEP] the coordination amendment should be saved");
        iAction("CLICK",         "XPATH", ObjReader.getLocator("iSaveButton"), null);
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iCoordinationAmendmentsPanel"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserDraftsAQueryLetterWithTheFollowingDetails
    // Description   : Drafts a query letter from a details table - selects the document type and enters the free
    //                 text that explains what is being asked of the applicant in this specific case.
    // Parameters    : pDetails (DataTable) - keys: docType, comment
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the staff user drafts a query letter with the following details")
    public void theStaffUserDraftsAQueryLetterWithTheFollowingDetails(DataTable pDetails)
    {
        log.info("[STEP] the staff user drafts a query letter with the following details");
        Map<String, String> iDetails = pDetails.asMap(String.class, String.class);

        iAction("CLICK",   "XPATH", ObjReader.getLocator("iNavbarLink").replace("{LINK}", "Correspondence"), null);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iTab").replace("{TAB}", " Query Letter"), null);
        iAction("LIST",    "XPATH", ObjReader.getLocator("iQueryLetterDocType"), iDetails.get("docType"));
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iQueryLetterComment"), iDetails.get("comment"));
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theQueryLetterPreviewShouldBeDisplayed
    // Description   : Previews the drafted letter and confirms it renders before it would be issued.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the query letter preview should be displayed")
    public void theQueryLetterPreviewShouldBeDisplayed()
    {
        log.info("[STEP] the query letter preview should be displayed");
        iAction("CLICK",         "XPATH", ObjReader.getLocator("iPreviewButton"), null);
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iQueryLetterPreviewPanel"), null);
    }

    // =================================================================================================================================
    // SECTION 16 : AMS
    // =================================================================================================================================

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserOpensTheAmsScreenForHerd
    // Description   : Opens a named herd's application and navigates to the AMS tab under Inspections.
    // Parameters    : pHerdNumber (String) - inspection fixture herd
    //                 pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user opens the AMS screen for herd {string} for scheme year {string}")
    public void theStaffUserOpensTheAmsScreenForHerd(String pHerdNumber, String pSchemeYear)
    {
        log.info("[STEP] the staff user opens the AMS screen for herd " + pHerdNumber + " for scheme year " + pSchemeYear);
        iCurrentHerd = pHerdNumber;
        iSearchHomeByHerd(pHerdNumber, pSchemeYear);
        iOpenFirstApplication();
        iAction("CLICK", "XPATH", ObjReader.getLocator("iNavbarLink").replace("{LINK}", "Inspections"), null);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iTab").replace("{TAB}", "AMS"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserOpensTheAmsScreenForTheNextSimOptedHerd
    // Description   : Takes the next SIM opted-in herd and opens its Inspections screen (no AMS tab click, as in
    //                 Selenium).
    // Parameters    : pSchemeYear (String) - scheme year
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user opens the AMS screen for the next SIM-opted herd for scheme year {string}")
    public void theStaffUserOpensTheAmsScreenForTheNextSimOptedHerd(String pSchemeYear)
    {
        log.info("[STEP] the staff user opens the AMS screen for the next SIM-opted herd for scheme year " + pSchemeYear);
        iCurrentHerd = iNextSimOptedHerd(pSchemeYear);
        iSearchHomeByHerd(iCurrentHerd, pSchemeYear);
        iOpenFirstApplication();
        iAction("CLICK", "XPATH", ObjReader.getLocator("iNavbarLink").replace("{LINK}", "Inspections"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserSortsTheAmsResultsByColumnInBothDirections
    // Description   : Clicks a column header twice to sort ascending then descending.
    // Parameters    : pColumn (String) - column header label
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the staff user sorts the AMS results by {string} in both directions")
    public void theStaffUserSortsTheAmsResultsByColumnInBothDirections(String pColumn)
    {
        log.info("[STEP] the staff user sorts the AMS results by " + pColumn + " in both directions");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iAmsColumnHeader").replace("{COLUMN}", pColumn), null);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iAmsColumnHeader").replace("{COLUMN}", pColumn), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theAmsResultsShouldBeDisplayed
    // Description   : Confirms the AMS results table rendered.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the AMS results should be displayed")
    public void theAmsResultsShouldBeDisplayed()
    {
        log.info("[STEP] the AMS results should be displayed");
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iAmsResultsTable"), null);
    }

    // =================================================================================================================================
    // SECTION 17 : Force Majeure and application dialogs
    // =================================================================================================================================
    // Selenium iAction("CHECKBOX", iForceMajeureInput, null) flipped the box. Playwright CHECKBOX needs CHECK or UNCHECK,
    // and these steps flip it (apply, then remove), so the flip is a CLICK.

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserCancelsAForceMajeureRequestAcrossTheFollowingYears
    // Description   : Opens the Force Majeure dialog and cancels it, for each scheme year in the table, on ONE
    //                 herd. Force Majeure rules differ by year, hence the sweep. Cancelling must leave the
    //                 application untouched - the escape path before a consequential change is committed.
    //                 No herd in play yet: the first submitted herd of the FIRST year in the table is used.
    // Parameters    : pYears (DataTable) - single column of scheme years
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026 | Updated: 05-10-2026 (Playwright)
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user cancels a Force Majeure request for the same submitted herd across the following years")
    public void theStaffUserCancelsAForceMajeureRequestAcrossTheFollowingYears(DataTable pYears)
    {
        log.info("[STEP] the staff user cancels a Force Majeure request for the same submitted herd across the following years");
        List<String> iYears = pYears.asList();

        if (iCurrentHerd == null && !iYears.isEmpty())
        {
            iCurrentHerd = iNextSubmittedHerd(iYears.get(0));
        }

        for (String iYear : iYears)
        {
            iSearchHomeByHerd(iCurrentHerd, iYear);
            iOpenFirstApplication();
            iAction("CLICK", "XPATH", ObjReader.getLocator("iForceMajeureInput"), null);
            iAction("CLICK", "XPATH", ObjReader.getLocator("iDialogButton").replace("{LABEL}", "Cancel"), null);
        }
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserAppliesAndRemovesForceMajeureAcrossTheFollowingYears
    // Description   : Applies Force Majeure with a note, then removes it with another, for each year in the table.
    //                 Each transition requires its own note because it changes how deadlines and penalties are
    //                 applied to the application.
    //                 No herd in play yet: the first submitted herd of the FIRST year in the table is used.
    // Parameters    : pRows (DataTable) - columns: year, applyNote, removeNote
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026 | Updated: 05-10-2026 (Playwright)
    // ---------------------------------------------------------------------------------------------------------------------------------
    @When("the staff user applies and removes Force Majeure for the same submitted herd across the following years")
    public void theStaffUserAppliesAndRemovesForceMajeureAcrossTheFollowingYears(DataTable pRows)
    {
        log.info("[STEP] the staff user applies and removes Force Majeure for the same submitted herd across the following years");
        List<Map<String, String>> iYearRows = pRows.asMaps(String.class, String.class);

        if (iCurrentHerd == null && !iYearRows.isEmpty())
        {
            iCurrentHerd = iNextSubmittedHerd(iYearRows.get(0).get("year"));
        }

        for (Map<String, String> iRow : iYearRows)
        {
            iSearchHomeByHerd(iCurrentHerd, iRow.get("year"));
            iOpenFirstApplication();

            iAction("CLICK",   "XPATH", ObjReader.getLocator("iForceMajeureInput"), null);
            iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iAddNoteText"), iRow.get("applyNote"));
            iAction("CLICK",   "XPATH", ObjReader.getLocator("iDialogButton").replace("{LABEL}", "Save"), null);

            iAction("CLICK",   "XPATH", ObjReader.getLocator("iForceMajeureInput"), null);
            iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iAddNoteText"), iRow.get("removeNote"));
            iAction("CLICK",   "XPATH", ObjReader.getLocator("iDialogButton").replace("{LABEL}", "Save"), null);
        }
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theForceMajeureStateShouldRemainUnchanged
    // Description   : Confirms the application summary is intact after the Force Majeure interactions.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the Force Majeure state should remain unchanged")
    public void theForceMajeureStateShouldRemainUnchanged()
    {
        log.info("[STEP] the Force Majeure state should remain unchanged");
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iApplicationSummaryPanel"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theForceMajeureStateShouldBeReadableFromTheFollowingTabs
    // Description   : Reads the Force Majeure state via each named tab. Legacy AT-TC-02 is titled "Force Majeure
    //                 Save" but its save steps are commented out - it only navigates and reads. Reproduced as
    //                 written; TC_23 Section 2 holds the working save coverage.
    // Parameters    : pTabs (DataTable) - single column of tab names
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the Force Majeure state should be readable from the following tabs")
    public void theForceMajeureStateShouldBeReadableFromTheFollowingTabs(DataTable pTabs)
    {
        log.info("[STEP] the Force Majeure state should be readable from the following tabs");
        for (String iTab : pTabs.asList())
        {
            iAction("CLICK", "XPATH", ObjReader.getLocator("iNavbarLink").replace("{LINK}", iTab), null);
        }

        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iForceMajeureInput"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theStaffUserOpensTheApplicationSummaryDetailsDialog
    // Description   : Opens the application summary View Details dialog.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @And("the staff user opens the application summary details dialog")
    public void theStaffUserOpensTheApplicationSummaryDetailsDialog()
    {
        log.info("[STEP] the staff user opens the application summary details dialog");
        iAction("CLICK", "XPATH",
                ObjReader.getLocator("iSearchResultLink").replace("{LABEL}", "View details").replace("{INDEX}", "2"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theDialogShouldCloseCleanly
    // Description   : Closes the dialog and confirms the underlying screen is still usable.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the dialog should close cleanly")
    public void theDialogShouldCloseCleanly()
    {
        log.info("[STEP] the dialog should close cleanly");
        iAction("CLICK",         "XPATH", ObjReader.getLocator("iDialogButton").replace("{LABEL}", "Close"), null);
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iApplicationSummaryPanel"), null);
    }

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : theInfoIconShouldExposeItsTooltip
    // Description   : Hovers an info icon and confirms its explanatory tooltip appears.
    // Parameters    : pFieldLabel (String) - the field the icon sits against
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026
    // ---------------------------------------------------------------------------------------------------------------------------------
    @Then("the {string} info icon should expose its tooltip")
    public void theInfoIconShouldExposeItsTooltip(String pFieldLabel)
    {
        log.info("[STEP] the " + pFieldLabel + " info icon should expose its tooltip");
        iAction("HOVER",         "XPATH", ObjReader.getLocator("iInfoIcon").replace("{FIELD}", pFieldLabel), null);
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iTooltip"), null);
    }

    // =================================================================================================================================
    // SECTION 18 : Small helpers
    // =================================================================================================================================

    // ---------------------------------------------------------------------------------------------------------------------------------
    // Function Name : closeSecondTab
    // Description   : Closes every tab other than the one the test works in and stays on that one. Not a step;
    //                 kept from Selenium (which closed window handle 1 and switched back to handle 0).
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 15-07-2026 | Updated: 05-10-2026 (Playwright)
    // ---------------------------------------------------------------------------------------------------------------------------------
    public void closeSecondTab()
    {
        Page iMainPage = CommonFunctions.getPage();
        for (Page iPage : CommonFunctions.getContext().pages())
        {
            if (iPage != iMainPage)
            {
                log.info("[STAFF] Closing extra tab: " + iPage.url());
                iPage.close();
            }
        }
        PlaywrightFactory.switchToPage(iMainPage);
    }

    // Replacement for Thread.sleep - keeps Playwright's event loop running while waiting
    private static void pause(long pMilliseconds)
    {
        CommonFunctions.getPage().waitForTimeout(pMilliseconds);
    }

    // Trimmed DataTable cell, or null when the key is missing / the cell is empty
    private static String trimOrNull(String pValue)
    {
        return pValue == null || pValue.trim().isEmpty() ? null : pValue.trim();
    }
}
