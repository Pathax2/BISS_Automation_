Feature: TC_20_ENTS - Transfer Application E2E (ETF Partner to Agent) and then submits appeals

  # Migrated from: TC_11_ENTS.feature (legacy 8 scenarios)
  # Transferor: ETF Partner (agr15512) | Transferee: a client herd of agent aga6581
  # KEY DIFFERENCE: Uses MANUAL entitlements (Add Manual + Type + Net UV) instead of standard Add
  # Also includes txeeAddress field in transferee search
  #
  # New steps: ETF partner creates transfer with manual entitlements
  # Reused: TC_07_ENTS (ETF login), TC_03_ENTS (agent transferee)
  #
  #
  # Runtime data (Playwright, 02-10-2026, same as TC_11_ENTS):
  #   The transferor stays the ETF partner's own herd C2057024 (pinned). The transferee comes from aga6581's Agent
  #   Login pool / vault pool ENTS_AGENT (transfereeAgent row, EntsTestData.nextTransfereeForFixedTransferor), filling
  #     {transferee.herd}  {transferee.name}  {transferee.address}  {transferee.agent}
  #   Selenium values are kept in the section comments. Put a herd, name or login back in a cell to pin it.
  #
  # Author: Aniket Pathare | Created: 31-03-2026

  Background:
    Given the ETF partner logs in as transferor "agr15512"
    And the agent opens the "Basic Income Support for Sustainability" application


  @regression @transfers @etf-to-agent @e2e
  Scenario: AT-ENTS-TRANSFERS-E2E-20 - ETF Partner completes all transfer types to Agent and then submits appeals

    #-------------------------------------------- SECTION 1 : CLE (206)----------------------------------------------------
    When the ETF partner creates a transfer with manual entitlements
      | transferorHerd   | C2057024           |
      | transfereeHerd   | {transferee.herd}  |
      | transfereeName   | {transferee.name}  |
      | transfereeAddress| {transferee.address}|
      | transfereeAgent  | aga6581            |
      | transferType     | Change of Legal Entity|
      | entitlements     | 0.01               |
      | entitlementType  | BISS               |
      | netUV            | 1                  |
      | notes            | Test Notes         |
    And the agent uploads the transferor signature document
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured


    When the agent logs in as transferee agent "{transferee.agent}"
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfers should be submitted successfully
    And Validate if Appeal can be made sucessfully


    #---------------------------------------------------- SECTION 2 : Change of Registration (205)----------------------------------------------------
    Given the ETF partner logs in as transferor "agr15512"
    And the agent opens the "Basic Income Support for Sustainability" application
    When the ETF partner creates a transfer with manual entitlements
      | transferorHerd   | C2057024           |
      | transfereeHerd   | {transferee.herd}  |
      | transfereeName   | {transferee.name}  |
      | transfereeAddress| {transferee.address}|
      | transfereeAgent  | aga6581            |
      | transferType     | Change of Registration Details|
      | entitlements     | 0.01               |
      | entitlementType  | BISS               |
      | netUV            | 1                  |
      | notes            | Test Notes         |
    And the agent uploads the transferor signature document
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured


    When the agent logs in as transferee agent "{transferee.agent}"
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfers should be submitted successfully
    And Validate if Appeal can be made sucessfully


    # ----------------------------------------------------SECTION 3 : Lease (211)----------------------------------------------------
    Given the ETF partner logs in as transferor "agr15512"
    And the agent opens the "Basic Income Support for Sustainability" application
    When the ETF partner creates a transfer with manual entitlements
      | transferorHerd   | C2057024           |
      | transfereeHerd   | {transferee.herd}  |
      | transfereeName   | {transferee.name}  |
      | transfereeAddress| {transferee.address}|
      | transfereeAgent  | aga6581            |
      | transferType     | Lease of Entitlements|
      | entitlements     | 0.01               |
      | entitlementType  | BISS               |
      | netUV            | 1                  |
      | leaseYear        | Yes                |
      | notes            | Test Notes         |
    And the agent uploads the transferor signature document
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured


    When the agent logs in as transferee agent "{transferee.agent}"
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfers should be submitted successfully
    And Validate if Appeal can be made sucessfully


    # ----------------------------------------------------SECTION 4 : Gift (202)----------------------------------------------------
    Given the ETF partner logs in as transferor "agr15512"
    And the agent opens the "Basic Income Support for Sustainability" application
    When the ETF partner creates a transfer with manual entitlements
      | transferorHerd   | C2057024           |
      | transfereeHerd   | {transferee.herd}  |
      | transfereeName   | {transferee.name}  |
      | transfereeAddress| {transferee.address}|
      | transfereeAgent  | aga6581            |
      | transferType     | Gift of Entitlements|
      | entitlements     | 0.01               |
      | entitlementType  | BISS               |
      | netUV            | 1                  |
      | notes            | Test Notes         |
    And the agent uploads the transferor signature document
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured


    When the agent logs in as transferee agent "{transferee.agent}"
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfers should be submitted successfully
    And Validate if Appeal can be made sucessfully


    #---------------------------------------------------- SECTION 5 : Merger (203)----------------------------------------------------
    Given the ETF partner logs in as transferor "agr15512"
    And the agent opens the "Basic Income Support for Sustainability" application
    When the ETF partner creates a transfer with manual entitlements
      | transferorHerd   | C2057024           |
      | transfereeHerd   | {transferee.herd}  |
      | transfereeName   | {transferee.name}   |
      | transfereeAddress| {transferee.address} |
      | transfereeAgent  | aga6581            |
      | transferType     | Merger of 2 or more holdings (forming an unregistered Farm Partnership)|
      | entitlements     | 0.01               |
      | entitlementType  | BISS               |
      | netUV            | 1                  |
      | notes            | Test Notes         |
    And the agent uploads the transferor signature document
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured


    When the agent logs in as transferee agent "{transferee.agent}"
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfers should be submitted successfully
    And Validate if Appeal can be made sucessfully

    #---------------------------------------------------- SECTION 6 : Division (204)----------------------------------------------------
    Given the ETF partner logs in as transferor "agr15512"
    And the agent opens the "Basic Income Support for Sustainability" application
    When the ETF partner creates a transfer with manual entitlements
      | transferorHerd   | C2057024           |
      | transfereeHerd   | {transferee.herd}  |
      | transfereeName   | {transferee.name}  |
      | transfereeAddress| {transferee.address}|
      | transfereeAgent  | aga6581            |
      | transferType     | Division of Entitlements (Scission)|
      | entitlements     | 0.01               |
      | entitlementType  | BISS               |
      | netUV            | 1                  |
      | notes            | Test Notes         |
    And the agent uploads the transferor signature document
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured


    When the agent logs in as transferee agent "{transferee.agent}"
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfers should be submitted successfully
    And Validate if Appeal can be made sucessfully


    # ----------------------------------------------------SECTION 7 : Inheritance (201)----------------------------------------------------
    Given the ETF partner logs in as transferor "agr15512"
    And the agent opens the "Basic Income Support for Sustainability" application
    When the ETF partner creates a transfer with manual entitlements
      | transferorHerd   | C2057024           |
      | transfereeHerd   | {transferee.herd}  |
      | transfereeName   | {transferee.name}  |
      | transfereeAddress| {transferee.address}|
      | transfereeAgent  | aga6581            |
      | transferType     | Inheritance of Entitlements|
      | entitlements     | 0.01               |
      | entitlementType  | BISS               |
      | netUV            | 1                  |
      | notes            | Test Notes         |
    And the agent uploads the transferor signature document
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured


    When the agent logs in as transferee agent "{transferee.agent}"
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfers should be submitted successfully
    And Validate if Appeal can be made sucessfully


    # ----------------------------------------------------SECTION 8 : Sale (212)----------------------------------------------------
    Given the ETF partner logs in as transferor "agr15512"
    And the agent opens the "Basic Income Support for Sustainability" application
    When the ETF partner creates a transfer with manual entitlements
      | transferorHerd   | C2057024           |
      | transfereeHerd   | {transferee.herd}  |
      | transfereeName   | {transferee.name}  |
      | transfereeAddress| {transferee.address}|
      | transfereeAgent  | aga6581            |
      | transferType     | Sale of Entitlements|
      | entitlements     | 0.01               |
      | entitlementType  | BISS               |
      | netUV            | 1                  |
      | notes            | Test Notes         |
    And the agent uploads the transferor signature document
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured


    When the agent logs in as transferee agent "{transferee.agent}"
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfers should be submitted successfully
    And Validate if Appeal can be made sucessfully
