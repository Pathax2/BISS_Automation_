// ===================================================================================================================================
// File          : TC_03_ENTS.java
// Package       : stepdefinitions.ENTS
// Description   : Step definitions for TC_03_ENTS - Transfer Application E2E (cross-agent steps).
//
//                 Only the steps that are unique to a cross-agent transfer live here. Every other step of the feature
//                 is defined elsewhere:
//                   login / portal navigation                       -> stepdefinitions.TC_03
//                   tab switching                                   -> stepdefinitions.TC_06
//                   login as a named user                           -> stepdefinitions.ENTS.TC_08_ENTS
//                   create / upload / send / key / submit           -> stepdefinitions.ENTS.TC_01_ENTS
//
//                 Steps in this file (4):
//                   1. the agent logs out and re-logs in as the transferee agent {string}
//                   2. the agent logs out and re-log in as the transferee agent {string}   (no logout - see below)
//                   3. the agent logs out and re-logs in as the transferor agent
//                   4. the agent completes the cross-agent transferee acceptance flow (DataTable)
//
//                 Steps 1 and 2 have almost the same text and were both in the Selenium file; step 2 never logged out,
//                 so it is kept as the "already logged out" variant. Both are here so either feature wording binds.
//
//                 Playwright edition (23-09-2026):
//                   - Same step texts, same ObjectRepository keys, same flow.
//                   - The copied login blocks (username, PIN loop, TOTP, T&C, Account Expired) are gone; the steps use
//                     the shared EntsSession.loginAs / EntsSession.logout.
//                   - Account Expired: Selenium called Hooks.markAgentExpired for the BISS runtime agent (a different
//                     user) and logged in again as the same expired ENTS user. EntsSession.loginAs now fails the step
//                     with the user name in the message.
//                   - Step 3 used iExitBISSLink / iLogoutBtn / iWelcomeLoginBtn, which are not in the Playwright
//                     ObjectRepository; it uses the same logout as every other ENTS step (iExitLink / iLogoutbtn).
//                     It remembers the agent who was logged in when step 1 or 2 ran, and falls back to the current
//                     pair's agent, TD:Username and Hooks.RUNTIME_USERNAME.
//                   - Step 4 searches the transferee herd with EntsSession.openTransferOutHerd, which waits for the row
//                     of THAT herd and skips rows marked expired. Selenium slept 2 s and clicked the first View link.
//                   - Step 4 checks that a transfer key was captured before typing it.
//                   - DataTable values and login names may be runtime tokens such as {transferee.herd}
//                     (utilities.EntsTestData).
//
// Author        : Aniket Pathare | aniket.pathare@government.ie
// Date Created  : 31-03-2026 | Updated: 23-09-2026 (Playwright + runtime ENTS data)
// ===================================================================================================================================

package stepdefinitions.ENTS;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;
import org.junit.jupiter.api.Assertions;
import stepdefinitions.Hooks;
import utilities.EntsTestData;
import utilities.ObjReader;

import java.util.Map;
import java.util.logging.Logger;

import static commonFunctions.CommonFunctions.iAction;

public class TC_03_ENTS
{
    private static final Logger log = Logger.getLogger(TC_03_ENTS.class.getName());

    // The agent who created the transfer. Remembered when the session switches to the transferee agent, so the
    // "re-logs in as the transferor agent" step can go back without the feature file naming the login again.
    private static String iTransferorAgent = "";


    // ===================================================================================================================================
    //  CROSS-AGENT SESSION MANAGEMENT - logout and re-login
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent logs out and re-logs in as the transferee agent {string}
    // Description   : Logs out of the transferor agent session and logs in as the transferee agent. The transferor
    //                 login is remembered for the "re-logs in as the transferor agent" step.
    // Parameters    : pUsername (String) - transferee agent login, e.g. "aga6325", or {transferee.agent}
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 23-09-2026 (Playwright, shared login)
    // ***************************************************************************************************************************************************************************************
    @When("the agent logs out and re-logs in as the transferee agent {string}")
    public void theAgentLogsOutAndReLogsInAsTheTransfereeAgent(String pUsername)
    {
        String iUsername = EntsTestData.resolve(pUsername);
        log.info("[STEP] When the agent logs out and re-logs in as the transferee agent: " + iUsername);

        rememberTransferorAgent();
        EntsSession.logout();
        EntsSession.loginAs(iUsername, "[LOGIN-TRANSFEREE-AGENT]");

        log.info("Logged in as the transferee agent: " + iUsername + " (transferor agent kept: " + iTransferorAgent + ")");
    }


    // ***************************************************************************************************************************************************************************************
    // Step          : the agent logs out and re-log in as the transferee agent {string}
    // Description   : Same as the step above but WITHOUT the logout - the Selenium version of this wording assumed the
    //                 session was already logged out. loginAs opens the base URL first when the username box is not
    //                 on screen. Kept so both feature wordings bind.
    // Parameters    : pUsername (String) - transferee agent login, or {transferee.agent}
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 23-09-2026 (Playwright, shared login)
    // ***************************************************************************************************************************************************************************************
    @When("the agent logs out and re-log in as the transferee agent {string}")
    public void theAgentLogsOutAndReLogInAsTheTransfereeAgent(String pUsername)
    {
        String iUsername = EntsTestData.resolve(pUsername);
        log.info("[STEP] When the agent re-logs in as the transferee agent (already logged out): " + iUsername);

        rememberTransferorAgent();
        EntsSession.loginAs(iUsername, "[LOGIN-TRANSFEREE-AGENT]");

        log.info("Logged in as the transferee agent: " + iUsername);
    }


    // ***************************************************************************************************************************************************************************************
    // Step          : the agent logs out and re-logs in as the transferor agent
    // Description   : Logs out of the transferee agent session, logs back in as the agent who created the transfer and
    //                 opens BISS -> Home -> My Clients -> Transfers, ready for the next section.
    //                 Login resolution order: the agent remembered when the session switched to the transferee agent,
    //                 the current pair's agent, the system property TD:Username, Hooks.RUNTIME_USERNAME.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 23-09-2026 (Playwright, shared login)
    // ***************************************************************************************************************************************************************************************
    @When("the agent logs out and re-logs in as the transferor agent")
    public void theAgentLogsOutAndReLogsInAsTheTransferorAgent()
    {
        log.info("[STEP] When the agent logs out and re-logs in as the transferor agent");

        String iUsername = transferorAgent();
        Assertions.assertFalse(iUsername.isEmpty(),
                "No transferor agent is known. The transfer must be created by an agent before switching back to it.");

        EntsSession.logout();
        EntsSession.loginAs(iUsername, "[LOGIN-TRANSFEROR-AGENT]");
        EntsSession.openBissMyClientsTransfers();

        log.info("Re-logged in as the transferor agent: " + iUsername);
    }


    // ===================================================================================================================================
    //  CROSS-AGENT TRANSFEREE ACCEPTANCE
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent completes the cross-agent transferee acceptance flow (DataTable)
    // Description   : 1. Searches the transferee herd and opens its first not-expired row
    //                 2. ETF button shown : ETF -> transfer key -> View Transfer Application
    //                    otherwise        : View Transfer Application (2) -> transfer key -> View Transfer Application
    //                 3. Enters notes, Submit Application to DAFM, accepts T&C, confirms
    //
    //                 DataTable keys:
    //                   transfereeHerd (String) - herd number, or {transferee.herd}
    //                   notes          (String) - transferee notes, e.g. "Approved Test"
    //
    //                 Depends on the key captured by TC_01_ENTS "the transfer key should be captured".
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 23-09-2026 (Playwright + runtime ENTS data)
    // ***************************************************************************************************************************************************************************************
    @And("the agent completes the cross-agent transferee acceptance flow")
    public void theAgentCompletesTheCrossAgentTransfereeAcceptanceFlow(DataTable pDataTable)
    {
        log.info("[STEP] And the agent completes the cross-agent transferee acceptance flow");

        Map<String, String> iData = EntsTestData.resolveTable(pDataTable.asMap(String.class, String.class));

        String iTransfereeHerd = iData.get("transfereeHerd").trim();
        String iNotes          = iData.get("notes").trim();
        String iTransferKey    = TC_01_ENTS.iCapturedTransferKey;

        Assertions.assertFalse(iTransferKey == null || iTransferKey.isEmpty(),
                "Transfer key must have been captured in the Transferor flow before the transferee can accept.");

        // Search the transferee herd in THIS agent's Transfer Out list and open its row
        EntsSession.openTransferOutHerd(iTransfereeHerd);
        log.info("Transferee herd opened: " + iTransfereeHerd);

        if (EntsSession.isVisible(ObjReader.getLocator("iETFBtn"), EntsSession.PROBE_SECONDS))
        {
            // Partner dashboard: ETF button, then the key
            iAction("CLICK", "XPATH", ObjReader.getLocator("iETFBtn"), null);
            log.info("ETF button clicked.");
        }
        else
        {
            // Standard dashboard: View Transfer Application, then the key
            iAction("WAITVISIBLE", "XPATH", ObjReader.getLocator("iTransferViewApplicationBtn2"), null);
            iAction("CLICK",       "XPATH", ObjReader.getLocator("iTransferViewApplicationBtn2"), null);
        }

        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iTransferKeyInputField"), iTransferKey);
        log.info("Transfer key entered: " + iTransferKey);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iTransferViewApplicationBtn"), null);

        // Notes, Submit Application to DAFM, T&C, confirm
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iTransferNotesField"), iNotes);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iTransferSubmitToDAFMBtn"), null);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iTransferTandCCheckbox"), null);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iTransferDialogSubmitBtn"), null);

        log.info("Cross-agent transferee acceptance completed for herd: " + iTransfereeHerd);
    }


    // ===================================================================================================================================
    //  HELPERS
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Function Name : rememberTransferorAgent
    // Description   : Stores the agent who is logged in right now, so the session can come back to it later
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 22-09-2026
    // ***************************************************************************************************************************************************************************************
    private static void rememberTransferorAgent()
    {
        String iCurrent = EntsTestData.loggedInUser();
        if (iCurrent != null && !iCurrent.isBlank())
        {
            iTransferorAgent = iCurrent.trim();
        }
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : transferorAgent
    // Description   : The agent who created the transfer: remembered login, else the current pair's agent, else the
    //                 system property TD:Username, else Hooks.RUNTIME_USERNAME. "" when none of them is set.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 22-09-2026
    // ***************************************************************************************************************************************************************************************
    private static String transferorAgent()
    {
        if (!iTransferorAgent.isBlank()) return iTransferorAgent;

        EntsTestData.TransferPair iPair = EntsTestData.currentPair();
        if (iPair != null && iPair.agent != null && !iPair.agent.isBlank()) return iPair.agent.trim();

        String iProperty = System.getProperty("TD:Username", "").trim();
        if (!iProperty.isEmpty()) return iProperty;

        return Hooks.RUNTIME_USERNAME == null ? "" : Hooks.RUNTIME_USERNAME.trim();
    }
}