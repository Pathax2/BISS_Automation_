# ====================================================================================================================================
# File          : TC_15_STAFF.feature
# Purpose       : AMS Internal Screen E2E Regression Pack
#                 Modernised from the legacy staff scenarios - single chained E2E Scenario with
#                 # SECTION markers mapping back to the original AT-TC ids.
# Data          : URL launched by Hooks (Config sheet, by environment). Password resolved from the
#                 TestData.xlsx Password column via the TD: mechanism. Herd/parcel/reference values
#                 supplied in-feature via DataTable (no row references).
# Step Defs     : StaffSteps.java (stepdefinitions.STAFF)
# Locators      : ObjectRepository.properties - Staff sections
# Author        : Aniket Pathare | aniket.pathare@government.ie
# Created       : 14-07-2026
# ====================================================================================================================================

Feature: TC_15_STAFF - AMS Internal Screen E2E Regression Pack

  Background:
    Given user on staff login page

  @regression @staff @ams @inspections @e2e
  Scenario: AT-STAFF-AMS-E2E-01 - Staff verifies the AMS internal read-only screen headers and partner tabs

    # SECTION 1 : Open AMS screen and verify client details + headers - AT-TC-02 (BISSAGL-14748)
    When Staff logs in with the Username "agr0191"
    And Staff opens the "Basic Income Support for Sustainability" application
    And Staff searches on the Home screen with the following details
      | field      | herdNumber |
      | herdValue  | IFP10100   |
      | schemeYear | 2024       |
    And Staff clicks the "View" link number 1 in the "application-search-table" table
    Then Staff clicks on "Inspections" Link in Navbar
    And Staff switches to the "AMS" tab
    Then Staff verifies "Partnership Farmer" client details on the AMS page
    And Staff verifies "Herd Number" client details on the AMS page
    When Staff switches to partner herd "I1330645" tab
    And Staff switches to partner herd "I1020085" tab
    Then Staff verifies the following header tabs are present on the AMS screen
      | header                    |
      | Townland                  |
      | Parcel no.                |
      | AMS status                |
      | Scheme                    |
      | AMS finding               |
      | AMS monitoring status     |
      | Claimed area (ha)         |
      | Updated claimed area (ha) |
      | Parcel use                |
      | Updated parcel use        |
      | Inspected crop found      |
    And Staff verifies pagination works on the AMS page
