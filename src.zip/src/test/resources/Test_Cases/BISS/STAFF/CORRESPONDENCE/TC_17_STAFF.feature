# ====================================================================================================================================
# File          : TC_17_STAFF.feature
# Purpose       : OpenShift Home Screen Search Validations E2E Regression Pack
#                 Modernised from the legacy staff scenarios - single chained E2E Scenario with
#                 # SECTION markers mapping back to the original AT-TC ids.
# Data          : URL launched by Hooks (Config sheet, by environment). Password resolved from the
#                 TestData.xlsx Password column via the TD: mechanism. Herd/parcel/reference values
#                 supplied in-feature via DataTable (no row references).
# Step Defs     : StaffSteps.java (stepdefinitions.STAFF)
# Locators      : ObjectRepository.properties - Staff sections
# Author        : Aniket Pathare | aniket.pathare@government.ie
# Created       : 14-07-2026
# ====================================================================================================================================

Feature: TC_17_STAFF - OpenShift Home Screen Search Validations E2E Regression Pack

  Background:
    Given user on OpenShift staff login page
    When Staff logs in with the Username "agr4442"
    And Staff opens the "Basic Income Support for Sustainability" application

  @regression @staff @openshift @validation @e2e
  Scenario: AT-STAFF-OS-HOME-E2E-01 - Staff validates herd, reference, parcel and farmer search error handling on OpenShift

    # SECTION 1 : Invalid herd search validation - AT-TC-02 (BISSAGL-18524)
    When Staff searches on the Home screen with the following details
      | field      | herdNumber |
      | herdValue  | ASUDASHADI |
      | schemeYear | 2024       |
    Then Staff should see the plain error message "The herd number you entered is invalid"

    # SECTION 2 : Empty search validations - AT-TC-03 (BISSAGL-18541)
    When Staff clicks the "Search" button
    Then Staff should see the plain error message "The herd number you entered is invalid"
    And Staff should see the plain error message "The reference number you entered is invalid"

    # SECTION 3 : Farmer search - AT-TC-05 (BISSAGL-18546)
    When Staff selects "Farmer" as Search By Type
    And Staff enters value "mc" in the "surname" field
    And Staff selects "county" dropdown value as "Donegal"
    And Staff clicks the "Search" button

    # SECTION 4 : Reference no. validation - AT-TC-11 (BISSAGL-18661)
    When Staff switches to the "Reference No." tab
    And Staff enters value "adssdasd" in the "referenceNumber" field
    And Staff clicks the "Search" button
    Then Staff should see the plain error message "Invalid reference no."