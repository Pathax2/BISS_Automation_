package com.pages;

import com.base.ActionClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import com.stepdefinitions.IDataReader;


import java.util.List;

import static org.openqa.selenium.support.locators.RelativeLocator.with;

public class LoginPage {
    WebDriver driver;
    ActionClass actions;
//    By AgentUserName = By.id("mat-input-sso-lib-username-field-0");
    By AgentUserName = By.id("username");
//    By StaffPassword = By.id("mat-input-sso-lib-password-field-0");
    By StaffPassword = By.id("password");
    By DataProtectionCheckBox = By.id("confirm_data_protection-input");
//    By.xpath("//span[contains(text(),'Confirm')]");
    By LogonButton = By.id("kc-login");
    By AgentLogonButton = By.id("login-form-submit-button");
    //login-form-submit-button
    //    By ApplicationList = By.xpath("//h2[@id=\"application-list-title\"]//following-sibling::table//td//a[text()='Export Certificate System']");
    By AuthorisedApplication = By.xpath("//a[text()='Basic Income Support for Sustainability']");
    By OpenShiftApplication = By.xpath("//a[text()='Basic Income Support for Sustainability (OSH)']");
    By SSOAdministrationApplication = By.xpath("//a[text()='SSO Administration']");
    //*[@id="application-list-menu"]/table/tbody/tr[6]
    By LogoutButton = By.id("app-menu-logout-button");


    // BISS Locators
    By NavbarMyClients = By.xpath("//a//descendant::span[contains(text(),'My Clients')]");
    By ChatPopUp = By.xpath("//div[@id='oclcw-chatButton']");


    public LoginPage(WebDriver driver) {
        this.driver = driver;
        actions = new ActionClass(driver);
    }

    public void launchAppURL() {
        // CENTEST Env
        driver.get("https://agfood.icentest.agriculture.gov.ie/sso-auth-ui-agent/#/login");
        // DEV Env
        //driver.get("https://agfood.idev.agriculture.gov.ie/sso-auth-ui-agent/#/login");
    }

    public void launchStaffAppURL() {
        // CENTEST Env
        driver.get("https://agapps.centest.agriculture.gov.ie/sso-auth-ui-staff/#/login");
    }

    public void launchOpenShiftStaffAppURL() {
        // CENTEST Env Openshift
        driver.get("https://biss-dept-ui-biss-sit.apps.services1.agriculture.gov.ie");
    }

    // region Login Implementation
    public void loginWithUserName(String agentusername) {
        actions.waitForVisibilityOfElement(AgentUserName, 30);
        actions.sendKeys(AgentUserName, agentusername);
    }

    public void userNameAgentField(String agentusername) {
        By AgentUserName = By.id("mat-input-sso-lib-username-field-0");
        actions.sendKeys(AgentUserName, agentusername);
    }

    // Try to use the herds from the Excel Spreadsheet
    public void GetAgentNumbersArray(IDataReader dataTable) throws InterruptedException {
        List<String> agents = dataTable.getAllRows();
        for (int i=0 ; i<agents.size() ;i++) {
            String currentherd = agents.get(i);
            String Split1 = currentherd.replaceAll("\\[","");
            String Split2 = Split1.replaceAll("]","");
            String Split3[] = Split2.split("\\.");
            String AgentNumber = Split3[0];
            loginWithUserName(AgentNumber);
//            enterPinCode("1");
//            loginWithpassword("@c3ntst678!!");
//            loginWithsubmit();
//            Thread.sleep(3000);
//            ClickOnBISSApplication();
        }
        //System.out.println(herdnumbers.size());
    }

    // Wait for Chat Window to appear
    public void waitForChatWindow() {
        actions.waitForVisibilityOfElement(ChatPopUp, 30);
    }

    // Agent Click On New Login Button
    public void AgentClickOnNewLoginButton(){
        actions.clickUsingJS(By.xpath("//button[contains(text(),'Login')]"));
        //driver.findElement(By.xpath("//button[contains(text(),'Login')]")).click();
    }

    By ContinueButton = By.id("kc-login");



    // All External Users Enter OTP to Login
    public void externalUserEnterOTP() {
        By OTPfield = By.xpath("//input[@class='form-control']");
        if(actions.isElementPresent(driver,OTPfield)){
            actions.sendKeys(OTPfield, "111111");
        }
        else{
            String otp = "1";
            int counter = 3;
            while (counter >= 1){
                try {
                    List<WebElement> element = driver.findElements(By.xpath("(//input[@class='form-control pin-input'])["+counter+"]"));
                    for(WebElement wb : element){
                        wb.sendKeys(otp);
                        counter--;
                    }
                    actions.waitforSeconds(1);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }}actions.waitforSeconds(2);
    }

    // New Code to enter Pin
    public void enterPinCode(String Arg0) {
        try {
            By pin1 = By.xpath("//input[@formcontrolname = 'pac1']//preceding::u[3]//following::mat-form-field[1]");
            By pin2 = By.xpath("//input[@formcontrolname = 'pac2']//preceding::u[2]//following::mat-form-field[2]");
            By pin3 = By.xpath("//input[@formcontrolname = 'pac3']//preceding::u[1]//following::mat-form-field[3]");
            By pin4 = By.xpath("//input[@formcontrolname = 'pac4']//preceding::u[2]//following::mat-form-field[4]");
            By pin5 = By.xpath("//input[@formcontrolname = 'pac5']//preceding::u[2]//following::mat-form-field[5]");
            By pin6 = By.xpath("//input[@formcontrolname = 'pac6']//preceding::u[2]//following::mat-form-field[6]");
            By pin7 = By.xpath("//input[@formcontrolname = 'pac7']//preceding::u[2]//following::mat-form-field[7]");

            if (driver.findElement(pin1).isDisplayed()) {
                By pin = By.xpath("//input[@formcontrolname = 'pac1']");
                By pinhdr = By.xpath("//input[@formcontrolname = 'pac1']//preceding::u[3]//following::mat-form-field[1]");
                actions.clickUsingJS(pinhdr);
                actions.sendKeys(pin, Arg0);
            } else {
//                System.out.println("pin1 doesnt exist");
            }

            if (driver.findElement(pin2).isDisplayed()) {
                By pin = By.xpath("//input[@formcontrolname = 'pac2']");
                By pinhdr = By.xpath("//input[@formcontrolname = 'pac2']//preceding::u[2]//following::mat-form-field[2]");
                actions.clickUsingJS(pinhdr);
                actions.sendKeys(pin, Arg0);
            } else {
//                System.out.println("pin2 doesnt exist");
            }

            if (driver.findElement(pin3).isDisplayed()) {
                By pin = By.xpath("//input[@formcontrolname = 'pac3']");
                By pinhdr = By.xpath("//input[@formcontrolname = 'pac3']//preceding::u[1]//following::mat-form-field[3]");
                actions.clickUsingJS(pinhdr);
                actions.sendKeys(pin, Arg0);
            } else {
//                System.out.println("pin3 doesnt exist");
            }

            if (driver.findElement(pin4).isDisplayed()) {
                By pin = By.xpath("//input[@formcontrolname = 'pac4']");
                By pinhdr = By.xpath("//input[@formcontrolname = 'pac4']//preceding::u[2]//following::mat-form-field[4]");
                actions.clickUsingJS(pinhdr);
                actions.sendKeys(pin, Arg0);
            } else {
//                System.out.println("pin4 doesnt exist");
            }

            if (driver.findElement(pin5).isDisplayed()) {
                By pin = By.xpath("//input[@formcontrolname = 'pac5']");
                By pinhdr = By.xpath("//input[@formcontrolname = 'pac5']//preceding::u[2]//following::mat-form-field[5]");
                actions.clickUsingJS(pinhdr);
                actions.sendKeys(pin, Arg0);
            } else {
//                System.out.println("pin5 doesnt exist");
            }

            if (driver.findElement(pin6).isDisplayed()) {
                By pin = By.xpath("//input[@formcontrolname = 'pac6']");
                By pinhdr = By.xpath("//input[@formcontrolname = 'pac6']//preceding::u[2]//following::mat-form-field[6]");
                actions.clickUsingJS(pinhdr);
                actions.sendKeys(pin, Arg0);
            } else {
//                System.out.println("pin6 doesnt exist");
            }

            if (driver.findElement(pin7).isDisplayed()) {
                By pin = By.xpath("//input[@formcontrolname = 'pac7']");
                By pinhdr = By.xpath("//input[@formcontrolname = 'pac7']//preceding::u[2]//following::mat-form-field[7]");
                actions.clickUsingJS(pinhdr);
                actions.sendKeys(pin, Arg0);
            } else {
//                System.out.println("pin7 doesnt exist");
            }
        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    public void loginWithpassword(String agentpassword){
        actions.waitForVisibilityOfElement(StaffPassword, 15);
        actions.sendKeys(StaffPassword, agentpassword);
    }


    public void passwordAgentField(String agentpassword){
        By AgentPassword = By.id("mat-input-sso-lib-password-field-0");
        actions.sendKeys(AgentPassword, agentpassword);
    }

    public void loginWithDataProtection() {
 //       actions.waitForVisibilityOfElement(DataProtectionCheckBox,50);
        actions.click(DataProtectionCheckBox);
    }

    public void loginWithsubmit() {
//        actions.waitForVisibilityOfElement(LogonButton,50);
        actions.clickUsingJS(LogonButton);
        //driver.findElement(LogonButton).click();
    }

    public void loginwithAgentSubmit() {
        actions.clickUsingJS(AgentLogonButton);
    }

    // Agent Enter OTP to login
    public void enterOTP(String otp) {
        int counter = 1;
        while (counter <= 7){
            try {
//                    WebElement element = driver.findElement(By.xpath("(//div[@class = 'pin_input_inner_container']/input)["+counter+"]"));
                WebElement element = driver.findElement(By.xpath("(//form[@id='kc-pin-login-form']/div/div/input)["+counter+"]"));
                if (element.isDisplayed() && element.isEnabled()){
                    element.sendKeys(otp);
                }else {
//                        System.out.println("Pin"+counter+" does not exist");
                    System.out.println("Pin"+counter+" disabled");
                }
                counter++;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }



    public void ClickOnBISSApplication() {
        //WebElement NextButton = driver.findElement(By.xpath("//button[contains(@class,'mat-paginator-navigation-next')]"));
        By NextButton = By.xpath("//button[@aria-label='Next page']");
        List<WebElement> BISSVisibility = driver.findElements(AuthorisedApplication);
        if (BISSVisibility.isEmpty()) {
            actions.clickUsingJS(NextButton);
//            actions.waitForVisibilityOfElement(AuthorisedApplication,50);
            actions.clickUsingJS(AuthorisedApplication);
        }
        else {
//            actions.waitForVisibilityOfElement(AuthorisedApplication,50);
            actions.clickUsingJS(AuthorisedApplication);
        }
    }

    public void ClickOnOpenShiftBISSApplication() {
        //WebElement NextButton = driver.findElement(By.xpath("//button[contains(@class,'mat-paginator-navigation-next')]"));
        By NextButton = By.xpath("//button[@aria-label='Next page']");
        List<WebElement> BISSVisibility = driver.findElements(OpenShiftApplication);
        if (BISSVisibility.isEmpty()) {
            actions.clickUsingJS(NextButton);
            actions.waitForVisibilityOfElement(OpenShiftApplication,50);
            actions.clickUsingJS(OpenShiftApplication);
        }
        else {
            actions.waitForVisibilityOfElement(OpenShiftApplication,50);
            actions.clickUsingJS(OpenShiftApplication);
        }
    }

    public void ClickOnSSOAdministrationLink() {
        //WebElement NextButton = driver.findElement(By.xpath("//button[contains(@class,'mat-paginator-navigation-next')]"));
        By NextButton = By.xpath("//button[contains(@class,'mat-paginator-navigation-next')]");
        List<WebElement> BISSVisibility = driver.findElements(SSOAdministrationApplication);
        if (BISSVisibility.isEmpty()) {
            actions.clickUsingJS(NextButton);
            actions.waitForVisibilityOfElement(SSOAdministrationApplication,50);
            actions.clickUsingJS(SSOAdministrationApplication);
        }
        else {
            actions.waitForVisibilityOfElement(SSOAdministrationApplication,50);
            actions.clickUsingJS(SSOAdministrationApplication);
        }
    }
    // endregion

    // Click on the My Clients Option in the Navbar
    public void AgentClickOnMyClients() {
        actions.waitForVisibilityOfElement(NavbarMyClients, 30);
        actions.clickUsingJS(NavbarMyClients);
    }

//    public void selectConfrimCheckBox() {
//        actions.waitForVisibilityOfElement(StaffDataProtectionCheckBox,15);
//        actions.click(StaffDataProtectionCheckBox);
//    }

    public void StaffLogout() {
        actions.waitForVisibilityOfElement(LogoutButton,15);
        actions.click(LogoutButton);
    }


    public void clickOnAuthorisedAppMenu(String arg0) {
        By menu=By.xpath("//a[normalize-space()='"+arg0+"']");
        actions.waitForVisibilityOfElement(menu,15);
        actions.click(menu);
    }

// region My Clients Page


    // endregion

}
