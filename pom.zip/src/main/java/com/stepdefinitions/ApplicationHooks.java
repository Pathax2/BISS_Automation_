package com.stepdefinitions;

import com.atlassian.jira.rest.client.api.domain.Issue;
import com.base.ConfigReader;
import com.base.DriverManager;
import com.utility.JiraXrayClient;
import com.utility.JiraZephyrClient;
import com.utility.TestDataHolder;
import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import io.qameta.allure.Allure;
import io.restassured.RestAssured;
import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.ByteArrayInputStream;
import java.util.Collection;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;


public class ApplicationHooks {

    WebDriver driver;
    Properties prop;
    ConfigReader configReader;
    DriverManager driverManager;

    public static final String EXECUTION_STATUS_PASS = "1";
    public static final String EXECUTION_STATUS_FAIL = "2";
    public static final String EXECUTION_STATUS_WIP = "3";
    public static final String EXECUTION_STATUS_UNEXECUTED = "-1";
    public static final String EXECUTION_STATUS_BLOCKED = "4";

    public ApplicationHooks(DriverManager driverManager){
        try {
            this.driverManager=driverManager;
            driver=driverManager.getDriverInstance();
            configReader = new ConfigReader();
            prop = configReader.init_prop();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    @After (order = 0)
    public void tearDownScenario(Scenario scenario) throws Exception {
        RestAssured.reset();    // Restassured is the class coming from the Restassured dependency (io.rest-assured)
        System.out.println("End of test scenario: " + scenario.getName());
//        reportToJira("tmslink",  scenario, "", prop.getProperty("TEST_CYCLE_NAME"));  //Below reportToJira method is used to convert the scenario status into zephyr status with the help of @After annotation
       JiraXrayClient.reportToJira("tmslink", scenario, "", "ENTSAGL-10576"); // Add Test Executioon ID Key
        System.out.println("End of test scenario: " + scenario.getName());
    }

    @After()
    public void tearDown(Scenario scenario) {
        if (scenario.isFailed()) {
            Allure.addAttachment("screenshot", new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
            byte[] img=(byte[]) ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
            scenario.attach(img,"image/jpeg",scenario.getName());
        }
        driverManager.closeBrowser();
    }

//    private void reportToJira(String arg0, Scenario scenario, String executionComment) throws Exception {
//        String tagPrefix = arg0 ; //the prefix value should be exact as mentioned in the feature file scenario
//        String testId = extractJiraIssueId(scenario, tagPrefix);
//        if (!com.google.common.base.Strings.isNullOrEmpty(testId)) {
//            try (JiraZephyrClient jiraClient = new JiraZephyrClient()) {
//                Issue testIssue = jiraClient.findIssue(testId); // using the JiraZephyrClient utility class reference variable finding the IssueID of the scenario
//                String projectId = testIssue.getProject().getId().toString(); //using the ISSUEID we get the projectID
//                String testcaseId = testIssue.getId().toString(); //To get the TestcaseID we can use the IssueId
//                //getExecutionCycleByProjectIdAndCycleNames is a method in the JiraZephyrClient utility class which will return the cycleID by specifying the ProjectID and Cyclename in the bracket
//
//                String cycleId = jiraClient.getExecutionCycleByProjectIdAndCycleNames(projectId,
//                        "TEST_CYCLE_NAME");
//
//
//                //To confirm if the status is mapped into the zephyr cycle name we have to generate the execution ID by calling
//                //The method createNewExecution from JiraZephyrClient class by using the cycleId, testcaseId, projectId
//
//                String executionId = jiraClient.createNewExecution(cycleId, testcaseId, projectId);
//                Collection<String> tagsCollection = scenario.getSourceTagNames();
//                Set<String> tags = new HashSet<>(tagsCollection);
//                tags.remove(tags.stream().filter(tag -> tag.contains(tagPrefix)).findFirst().get());
//
//                //With the help of the below method we can convert the scenario result into the zephyr status
//                String statusToZephyr = convertScenarioStatusToZephyrStatus(scenario);
//
//                //To Update the status executionID is been used which will be created after each scenario if passed or failed and zephyr status will be shown accordingly
//
//                jiraClient.updateExecutionStatus(executionId, statusToZephyr, executionComment);
//
//            }
//            RestAssured.reset();
//        }
//    }



//    private String convertScenarioStatusToZephyrStatus(Scenario scenario) {
//        String scenarioStatus = scenario.getStatus().toString();
//        System.out.println("Scenario Status: " + scenario.getStatus());
//        String statusToZephyr = null;
//        switch (scenarioStatus) {
//            case "passed":
//            case "PASSED":
//                statusToZephyr = "1"; //ID for pass status
//                break;
//            case "failed":
//            case "FAILED":
//                statusToZephyr = "2"; //Id for the Failed status
//
//
//                break;
//            case "pending":
//            case "PENDING":
//            case "skipped":
//            case "SKIPPED":
//                statusToZephyr = "4";  //ID when test got skipped
//                break;
//            default:
//                statusToZephyr = "-1"; //ID if the test has not executed
//        }
//        return statusToZephyr;
//    }

//    private String extractJiraIssueId(Scenario scenario, String tagPrefix) {
//        Collection<String> sourceTagNames = scenario.getSourceTagNames(); //Extract the tags from the scenario using the Scenario object
//        sourceTagNames.forEach(tag -> System.out.println("scenario has tag: " + tag));
//        String tagContainsPrefix = sourceTagNames.stream().filter(tag -> tag.contains(tagPrefix))
//                .findFirst().orElse("");
//        String testId = StringUtils.substringAfter(tagContainsPrefix, "="); //Extract the test label after ‘=’
//        System.out.println("Test ID: " + testId);
//        TestDataHolder.addRecord(TestDataHolder.ZEPHYR_TEST_ID, testId, true, true);
//        return testId;
//    }



    // New Code


    private void reportToJira(String arg0, Scenario scenario, String executionComment, String cyclename) throws Exception {
        String tagPrefix = arg0;
        String testId = extractJiraIssueId(scenario, tagPrefix);
        if (!com.google.common.base.Strings.isNullOrEmpty(testId)) {
            try (JiraZephyrClient jiraClient = new JiraZephyrClient()) {
                Issue testIssue = jiraClient.findIssue(testId);
                String projectId = testIssue.getProject().getId().toString();
                String testcaseId = testIssue.getId().toString();
                String cycleId = jiraClient.getExecutionCycleByProjectIdAndCycleNames(projectId,
                        cyclename);
                String executionId = jiraClient.createNewExecution(cycleId, testcaseId, projectId);
                Collection<String> tagsCollection = scenario.getSourceTagNames();
                Set<String> tags = new HashSet<>(tagsCollection);
                tags.remove(tags.stream().filter(tag -> tag.contains(tagPrefix)).findFirst().get());
                String statusToZephyr = convertScenarioStatusToZephyrStatus(scenario);
                jiraClient.updateExecutionStatus(executionId, statusToZephyr, executionComment);
            }
            RestAssured.reset();
        }
    }

    private String convertScenarioStatusToZephyrStatus(Scenario scenario) {
        String scenarioStatus = scenario.getStatus().toString();
        System.out.println("Scenario Status: " + scenario.getStatus());
        String statusToZephyr = null;
        switch (scenarioStatus) {
            case "passed":
            case "PASSED":
                statusToZephyr = EXECUTION_STATUS_PASS;
                break;
            case "failed":
            case "FAILED":
                statusToZephyr = EXECUTION_STATUS_FAIL;
                break;
            case "pending":
            case "PENDING":
            case "skipped":
            case "SKIPPED":
                statusToZephyr = EXECUTION_STATUS_BLOCKED;
                break;
            default:
                statusToZephyr = EXECUTION_STATUS_UNEXECUTED;
        }
        return statusToZephyr;
    }

    private String extractJiraIssueId(Scenario scenario, String tagPrefix) {
        Collection<String> sourceTagNames = scenario.getSourceTagNames();
        sourceTagNames.forEach(tag -> System.out.println("scenario has tag: " + tag));
        String tagContainsPrefix = sourceTagNames.stream().filter(tag -> tag.contains(tagPrefix))
                .findFirst().orElse("");
        String testId = StringUtils.substringAfter(tagContainsPrefix, "=");
        System.out.println("Test ID: " + testId);
        TestDataHolder.addRecord(TestDataHolder.ZEPHYR_TEST_ID, testId, true, true);
        return testId;
    }
}
