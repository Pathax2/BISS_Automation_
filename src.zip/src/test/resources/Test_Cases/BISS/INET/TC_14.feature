Feature: TC_18 - Preliminary Checks — Overclaim Checks E2E

  # Covers: Submit button, incomplete toast, navigate away modal, full submission,
  #         overclaim accept (standard/subdivided/commonage), overclaim reject,
  #         post-submission amendment claimed area, SfN recalculation, correspondence PDF
  #
  # DB queries: LIST OF HERDS WITH OVERCLAIMS CHECK, LIST OF HERDS WITH PRELIM CHECKS AND COMMONAGE
  # Author: Aniket Pathare | Created: 01-04-2026
  #
  Background:
    Given the agent user is on the login page
    When the agent logs into the application with valid credentials and OTP
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    And the agent navigates to the "Home" and "My Clients" Left Menu Link

  @regression @prelim-checks @overclaim @e2e
  Scenario: AT-TC-18-E2E - Overclaim Preliminary Checks end-to-end flow

    # ===========================================
    # SECTION 1 : Navigate to Prelim Checks
    # ===========================================
    When the agent loads a herd with overclaim checks from the database
    And the agent opens a farmer dashboard using herd data
    Then the farmer dashboard should be displayed
    When the agent navigates to the "Preliminary Checks" tab on the side navigation
    Then the Preliminary Checks screen should be displayed
    And the screen should show parcels with pending responses

    # ===========================================
    # SECTION 2 : Submit button visible when all responses provided
    # ===========================================
    When the agent provides responses for all parcels on the Prelim Checks screen
    Then the Submit button should be visible at the bottom of the page

    # ===========================================
    # SECTION 3 : Incomplete response — red toast
    # ===========================================
    When the agent clears one parcel response to make submission incomplete
    And the agent clicks the Submit button on the Prelim Checks screen
    Then a red toast message should appear on the top-right of the screen

    # ===========================================
    # SECTION 4 : Navigate away modal — Back / Leave
    # ===========================================
    When the agent provides responses for all parcels on the Prelim Checks screen
    And the agent clicks on a different tab without submitting
    Then a modal should appear with heading "Preliminary Checks not complete"
    And the modal should show "Leave page" as the primary button
    And the modal should show "Back" as the secondary button

    When the agent clicks the "Back" button on the navigate away modal
    Then the Preliminary Checks screen should still be displayed
    And the entered responses should be preserved

    When the agent clicks on a different tab without submitting
    And the agent clicks the "Leave page" button on the navigate away modal
    Then the agent should navigate away from the Prelim Checks screen
    When the agent navigates to the "Preliminary Checks" tab on the side navigation
    Then the screen should show parcels with pending responses

    # ===========================================
    # SECTION 5 : Accept overclaim — standard parcel
    # Claimed area = eligible hectare
    # ===========================================
    When the agent accepts the overclaim for a standard parcel
    And the agent provides responses for remaining parcels on the Prelim Checks screen
    And the agent clicks the Submit button on the Prelim Checks screen
    Then a confirmation modal should appear
    When the agent clicks "Confirm" on the submission modal
    Then a green toast message "Preliminary Checks Response submitted" should appear
    And the agent navigates to the "Correspondence" tab on the side navigation
    Then a new PDF should be visible in the correspondence list
    And the PDF should contain the year "2026" in its content or title

    # --- Post-submission: verify claimed area in amendment ---
    When the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent opens a farmer dashboard using herd data
    And the agent starts an amendment on the application
    Then the claimed area for the standard parcel should equal the eligible hectare
    And the SfN results should be recalculated if affected by claimed area

    # ===========================================
    # SECTION 6 : Accept overclaim — subdivided parcel
    # Claimed area = subdivided response value
    # ===========================================
    When the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent loads a herd with overclaim checks from the database
    And the agent opens a farmer dashboard using herd data
    And the agent navigates to the "Preliminary Checks" tab on the side navigation
    When the agent accepts the overclaim for a subdivided parcel
    And the agent provides responses for remaining parcels on the Prelim Checks screen
    And the agent clicks the Submit button on the Prelim Checks screen
    And the agent clicks "Confirm" on the submission modal
    Then the claimed area for the subdivided parcel should equal the subdivided response value
    And the SfN results should be recalculated if affected by claimed area

    # ===========================================
    # SECTION 7 : Accept overclaim — commonage parcel
    # Claimed area = EH of commonage fraction
    # ===========================================
    When the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent loads a herd with overclaim checks and commonage from the database
    And the agent opens a farmer dashboard using herd data
    And the agent navigates to the "Preliminary Checks" tab on the side navigation
    When the agent accepts the overclaim for a commonage parcel
    And the agent provides responses for remaining parcels on the Prelim Checks screen
    And the agent clicks the Submit button on the Prelim Checks screen
    And the agent clicks "Confirm" on the submission modal
    Then the claimed area for the commonage parcel should equal the EH of the commonage fraction
    And the SfN results should be recalculated if affected by claimed area

    # ===========================================
    # SECTION 8 : Reject overclaim — no change
    # ===========================================
    When the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent loads a herd with overclaim checks from the database
    And the agent opens a farmer dashboard using herd data
    And the agent navigates to the "Preliminary Checks" tab on the side navigation
    When the agent rejects the overclaim for a parcel
    And the agent provides responses for remaining parcels on the Prelim Checks screen
    And the agent clicks the Submit button on the Prelim Checks screen
    And the agent clicks "Confirm" on the submission modal
    Then the claimed area for the rejected parcel should remain unchanged