Feature: TC_S32 - Regression Pack for Select and Unselect ECO Scheme on Internal Amendments

  # ──────────────────────────────────────────────────────────────────────────
  # Purpose:
  #   Validates that toggling the Eco scheme during BISS Internal Amendments
  #   correctly reflects on the scheme panel summary for both 2023 and 2024 applications.
  #   Covers:
  #     - TC01: Toggle Eco for L1161200 (2023) then A1140364 (2024) — submit both
  #     - TC02: Repeat the same flow as a distinct regression defect path
  #
  # Common Background:
  #   Staff login as agr4442 → open BISS application.
  #
  # DB Data:
  #   No DB pool step required. Fixed herds L1161200 (2023) and A1140364 (2024) have
  #   known Eco scheme states required by this test.
  #
  # Notes:
  #   1. TC01 and TC02 are intentionally identical per the legacy design — each
  #      targets a distinct regression defect path (BISSAGL-14762 and BISSAGL-14763).
  #   2. The Eco toggle submit pattern verifies both the toggle action and the
  #      subsequent scheme panel summary state update.
  #
  # Author  : Aniket Pathare | aniket.pathare@government.ie
  # Created : 2026-05-14
  # ──────────────────────────────────────────────────────────────────────────

  Background:
    Given the staff user is on the staff login page
    When the staff user logs in with username "agr4442"
    And the staff user selects the data protection checkbox and clicks login
    And the staff user opens the "Basic Income Support for Sustainability" application

  @tmsLink=BISSAGL-14762 @tmsLink=BISSAGL-14763 @regression
  Scenario: TC_S32 - Select and Unselect ECO Scheme end-to-end regression

    # ── TC01: Toggle Eco for L1161200 (2023) then A1140364 (2024) ────────────
    When the staff user searches for herd "L1161200" for scheme year "2023" and opens the BISS Amendments
    And the staff user toggles the Eco scheme card and submits the amendment
    Then the scheme panel summary should reflect the updated Eco state for herd "L1161200"
    When the staff user searches for herd "A1140364" for scheme year "2024" and opens the BISS Amendments
    And the staff user toggles the Eco scheme card and submits the amendment
    Then the scheme panel summary should reflect the updated Eco state for herd "A1140364"

    # ── TC02: Repeat Eco toggle flow (regression defect path 2) ──────────────
    When the staff user searches for herd "L1161200" for scheme year "2023" and opens the BISS Amendments
    And the staff user toggles the Eco scheme card and submits the amendment
    Then the scheme panel summary should reflect the updated Eco state for herd "L1161200"
    When the staff user searches for herd "A1140364" for scheme year "2024" and opens the BISS Amendments
    And the staff user toggles the Eco scheme card and submits the amendment
    Then the scheme panel summary should reflect the updated Eco state for herd "A1140364"