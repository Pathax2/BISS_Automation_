package com.stepdefinitions;


import com.base.ConfigReader;
import com.base.DriverManager;
import com.pages.BPSdashboardPage;
import com.pages.LoginPage;
import com.pages.MyClientsNoHerdPage;
import com.pages.MyClientsPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.codehaus.plexus.util.cli.Arg;
import org.openqa.selenium.WebDriver;

import java.io.IOException;
import java.util.Properties;

public class MyClientsSteps {

    LoginPage loginPage;
    //BPSdashboardPage bpsdashboardPage;
    MyClientsPage myclientsPage;
    WebDriver driver;
    Properties prop;
    ConfigReader configReader;
    DriverManager driverManager;

    public MyClientsSteps(DriverManager driverManager){
        try {
//            driver = driverManager.getDriver();
            this.driverManager=driverManager;
            driver=driverManager.getDriverInstance();
            loginPage = new LoginPage(driver);
            //bpsdashboardPage = new BPSdashboardPage(driver);
            myclientsPage = new MyClientsPage(driver);
            configReader = new ConfigReader();
            prop = configReader.init_prop();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    // region BPS Code

    @And("Agent is on My Clients Page")
    public void StaffParcelSearchPage() {
        String title = driver.getTitle();
        System.out.println("title of My Clients Page" + title);
    }

    @And("Agent Selects a Client by Clicking on Checkbox")
    public void AgentClickOnClientRadioButton() {
        myclientsPage.AgentClickOnClientRadioButton();
    }

    @Then("Click on the Client View Button")
    public void AgentClickOnClientViewButton() throws InterruptedException {
        myclientsPage.AgentClickOnViewButton();
        Thread.sleep(2000);
    }


    @Then("Visibility of Applications NavLink Dropdown")
    public void AgentVisibilityApplicationsNavLink() throws InterruptedException {
        myclientsPage.AgentVisibilityApplicationsNavLink();
        Thread.sleep(2000);
    }
    @And("Visibility of Farm Details NavLink Dropdown")
    public void AgentVisibilityFarmDetailsNavLink() throws InterruptedException {
        myclientsPage.AgentVisibilityFarmDetailsNavLink();
        Thread.sleep(2000);
    }
    @And("Visibility of Correspondence NavLink Dropdown")
    public void AgentVisibilityCorrespondenceNavLink() throws InterruptedException {
        myclientsPage.AgentVisibilityCorrespondenceNavLink();
        Thread.sleep(2000);
    }

    @And("Click on Application and Payments Summary")
    public void AgentClickOnApplicationPaymentsAndSummary() throws InterruptedException {
        myclientsPage.AgentClickOnApplicationsAndPaymentsSummary();
        Thread.sleep(2000);
    }

    @And("Agent selects Application And Payments Summary Scheme Year {int} from the dropdown")
    public void StaffSelectApplicationAndPaymentsSummarySchemeYear(int arg0) {
        myclientsPage.AgentSelectApplicationsAndSummarySchemeYear(arg0);
    }

    @And("Click on Application and Payments Summary View button")
    public void AgentClickOnApplicationPaymentsAndSummaryViewButton() throws InterruptedException {
        myclientsPage.AgentClickOnApplicationsAndPaymentsSummaryViewButton();
        Thread.sleep(2000);
    }

    @Then("Change the number of rows Displayed in the page to {string}")
    public void AgentChangeNumberOfRowsDisplayedOnPage(String Arg0) throws InterruptedException {
        myclientsPage.ChangeNumberOfRowsDisplayedInPage(Arg0);
        Thread.sleep(5000);
    }

    @And("Staff Enter Value as {string} the Helpdesk {string} Field")
    public void StaffEnterValueInField(String Value, String Field) {
        myclientsPage.StaffEnterValueInField(Value, Field);
    }

    @And("Move To {string}")
    public void MoveToNextPage(String Arg0) {
        myclientsPage.AgentClickOnPaginationAndNewsNavigationButtons(Arg0);
    }

    // endregion

    // region BISS Code

    @And("Agent Click on the Farmer with Herd Number {string}")
    public void AgentExpandHerd(String Arg0) throws InterruptedException {
        myclientsPage.AgentExpandClientRow(Arg0);
        Thread.sleep(5000);
    }

    @Then("Agent Search for Herd Number {string}")
    public void AgentSearchForHerdNumber(String Arg0) throws InterruptedException {
        myclientsPage.AgentSearchForHerd(Arg0);
        Thread.sleep(3000);
    }

    @Then("Agent Search for Herd Number")
    public void agentSearchForHerdNumber() throws InterruptedException {
        myclientsPage.AgentSearchForHerd();
    }

    @Then("Agent Search Inactive Herd Number")
    public void agentSearchInactiveHerdNumber() {
        myclientsPage.agentSearchInactiveHerdNumber();
    }

    //Adding to update TC in 7801
    @Then("Staff Enter Value in the {string} field")
    public void StaffEnterInactiveFarmerValueInField(String FieldName) throws InterruptedException {
        myclientsPage.StaffEnterInactiveFarmerValueInField(FieldName);
    }

    @And("Agent Click on the {string} Quick Filter")
    public void AgentClickOnTheQuickFilter(String Filter) throws InterruptedException {
        myclientsPage.AgentSelectQuickFilters(Filter);
        Thread.sleep(4000);
    }

    @Then("Agent Click on First Herd in Not Started Section")
    public void AgentClickOnFirstHerdInNotStartedSection() {
        myclientsPage.AgentClickOnFirstClientInList();
    }

    //Added new method with no argument to get client from xpath directly
     @And("Agent Click on the Row with the Client")
    public void AgentClickOnClientRow() {
        String Arg0 = myclientsPage.agentSearchInactiveHerdNumber();
        myclientsPage.AgentExpandClientRow(Arg0);
     }

    @And("Agent Click on the Row with the Client {string}")
    public void AgentClickOnClientRow(String arg0) {
        //String Arg0 = myclientsPage.agentSearchInactiveHerdNumber();
        myclientsPage.AgentExpandClientRow(arg0);
    }


     @Then("Agent Click on the View Dashboard Button")
    public void AgentClickOnViewDashboardButton() throws IOException, InterruptedException {
        myclientsPage.AgentClickOnViewDashboard();
         Thread.sleep(2000);
     }

     @And("Agent switch to {string} Tab in My Clients Page")
     public void AgentSwitchTabs(String Arg0) throws InterruptedException {
        myclientsPage.AgentSwitchMyClientsTabs(Arg0);
        Thread.sleep(3000);
     }
    //@Then("Agent Navigate to Client Dashboard")

    @When("Agent expand Upload Documents Accordion")
    public void AgentExpandAccordion() {
        myclientsPage.AgentClickOnUploadDocAccordion();
    }

    @Then("Agent Select from {string} dropdown the doctype {string} to Upload")
    public void AgentSelectDocTypeToUpload(String DropdownName, String DocType) {
        myclientsPage.AgentSelectDocumentTypeInDropdown(DropdownName,DocType);
    }

    @And("Upload Document in Correspondence")
    public void AgentUploadDocument() throws InterruptedException {
        myclientsPage.UploadDocument();
        Thread.sleep(10000);
    }

    @And("Agent picks herd in list")
    public void agentPicksFirstHerdInList() throws InterruptedException {
        Thread.sleep(5000);
        myclientsPage.agentPicksFirstHerdInList();
    }

    @Then("Staff Enter same herd in the {string} field")
    public void StaffEnterSameValueInField(String FieldName) throws InterruptedException {
        myclientsPage.StaffEnterSameValueInField(FieldName);
    }




    // endregion
}
