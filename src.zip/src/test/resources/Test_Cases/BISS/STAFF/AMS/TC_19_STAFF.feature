Feature: TC_S19 - Regression Pack for Free Text Commonage Evidence Query Letter

  # ──────────────────────────────────────────────────────────────────────────
  # Purpose:
  #   Validates that a free text comment can be entered in the Commonage Evidence
  #   Query Letter on the Correspondence screen and the letter can be previewed.
  #   Covers:
  #     - TC01: Herd from the Query Letter Not Started pool (row 2)
  #     - TC02: Herd from the Admin Check Not Started pool (row 2)
  #
  # Common Background:
  #   Staff login as agr4442 → open BISS application.
  #   Two DB pools loaded in Background.
  #
  # DB Data:
  #   - 5 herds with Query Letter Not Started (TC01 uses row 2)
  #   - 5 herds with Admin Check Not Started (TC02 uses row 2)
  #   All herds resolved at runtime from Oracle DB. No hardcoded herd numbers.
  #
  # Notes:
  #   1. The docType dropdown uses a dedicated query letter step that handles
  #      the non-standard dropdown without a formcontrolname attribute.
  #   2. The comment textarea field name is "comment".
  #   3. Both TCs follow the same flow — the distinction is the DB pool used
  #      to source the herd, covering two different pre-conditions.
  #
  # Author  : Aniket Pathare | aniket.pathare@government.ie
  # Created : 2026-05-14
  # ──────────────────────────────────────────────────────────────────────────

  Background:
    Given the staff user is on the staff login page
    When the staff user logs in with username "agr4442"
    And the staff user selects the data protection checkbox and clicks login
    And the staff user opens the "Basic Income Support for Sustainability" application
    Then Get 5 Herds with Query Letter Not Started from DB
    And Get 5 Herds with Admin Check Not Started from DB

  @tmsLink=BISSAGL-14857 @tmsLink=BISSAGL-14856 @regression
  Scenario: TC_S19 - Free Text Commonage Evidence Query Letter end-to-end regression

    # ── TC01: Query Letter Not Started herd pool (row 2) ─────────────────────
    When the staff user searches for herd with query letter not started from row 2 for scheme year "2024" and views the application
    And the staff user navigates to "Correspondence" and switches to the Query Letter tab
    And the staff user selects "BISS Commonage Evidence Letter" from the document type dropdown
    And the staff user enters "Test Comment" in the comment field
    And the staff user clicks Preview
    Then the letter preview should be displayed successfully

    # ── TC02: Admin Check Not Started herd pool (row 2) ──────────────────────
    When the staff user searches for herd with admin check not started from row 2 for scheme year "2024" and views the application
    And the staff user navigates to "Correspondence" and switches to the Query Letter tab
    And the staff user selects "BISS Commonage Evidence Letter" from the document type dropdown
    And the staff user enters "Test Comment" in the comment field
    And the staff user clicks Preview
    Then the letter preview should be displayed successfully