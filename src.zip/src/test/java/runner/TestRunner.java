// ===================================================================================================================================
// File          : TestRunner.java
// Package       : runner
// Description   : Entry point for the BISS BDD Cucumber automation framework (Playwright edition).
//                 Reads ExecutionControl.xlsx, runs the selected test cases one by one through the Cucumber CLI,
//                 writes PASS/FAIL back and drives the reporting pipeline:
//                   ReportManager -> HtmlReportGenerator -> JUnitXmlGenerator
//
// Selection (NEW - container friendly):
//   -Dtestcase.ids=TC_01_Login,TC_04   or  BISS_TESTCASE_IDS=TC_01_Login,TC_04
//       Runs exactly these IDs, ignoring the Execution=Y flag. Lets CI shard one test case per container
//       without editing the Excel file inside the image.
//   (not set)
//       Original behaviour - every row with Execution=Y.
//
// Environment (NEW):
//   -Denvironment=SIT  or  BISS_ENVIRONMENT=SIT  overrides the Environment column for every selected row.
//
// Excel write-back:
//   -Dexecution.control.writeback=false  or  BISS_EXECUTION_CONTROL_WRITEBACK=false  skips the Status write
//   (useful when the xlsx is baked into a read-only image layer).
//
// Author        : Aniket Pathare | aniket.pathare@goverment.ie
// Date Created  : 10-03-2026
// Updated       : 29-03-2026 - Integrated CucumberStepListener + ReportManager.beginTestCase()
// Updated       : 15-09-2026 - testcase.ids / environment override / optional write-back for Docker execution
// Updated       : 16-09-2026 - Feature files found in any sub-folder depth, case-insensitive fallback (Selenium rule restored)
// Updated       : 18-09-2026 - Closes the shared browser after the last test case (browser.reuse)
// ===================================================================================================================================

package runner;

import io.cucumber.core.cli.Main;
import org.junit.jupiter.api.Test;
import reporting.HtmlReportGenerator;
import reporting.JUnitXmlGenerator;
import reporting.ReportManager;
import utilities.ConfigManager;
import utilities.ExcelUtilities;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TestRunner
{
    private static final Logger log = Logger.getLogger(TestRunner.class.getName());

    public static final String iExecutionControlFilePath  = ConfigManager.getOrDefault("execution.control.path",  "src/test/resources/Execution_Control_File/ExecutionControl.xlsx");
    public static final String iExecutionControlSheetName = ConfigManager.getOrDefault("execution.control.sheet", "Sheet1");
    public static final String iFeatureDirectoryPath      = ConfigManager.getOrDefault("feature.directory.path",  "src/test/resources/Test_Cases/");
    public static final String iStepDefinitionsGlue       = ConfigManager.getOrDefault("glue.package",            "stepdefinitions");

    private static final String iHtmlReportPath     = "target/cucumber-reports/";
    private static final String iJsonReportPath     = "target/cucumber-json/";
    private static final String iStepListenerPlugin = "reporting.CucumberStepListener";

    @Test
    public void executeSelectedTestCases()
    {
        runFrameworkExecution();
    }

    public static void main(String[] pArgs)
    {
        runFrameworkExecution();
    }

    private static Set<String> requestedTestCaseIds()
    {
        String iRaw = ConfigManager.getOrDefault("testcase.ids", "");
        return Arrays.stream(iRaw.split("[,;\\s]+"))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .map(s -> s.toUpperCase(Locale.ROOT))
                .collect(Collectors.toCollection(LinkedHashSet::new));
    }

    private static void runFrameworkExecution()
    {
        ExcelUtilities iExcel      = new ExcelUtilities(iExecutionControlFilePath);
        int            iRowCount   = iExcel.getRowCount(iExecutionControlSheetName);
        Set<String>    iRequested  = requestedTestCaseIds();
        Set<String>    iMatched    = new LinkedHashSet<>();
        String         iEnvOverride = ConfigManager.getOrDefault("environment", "");
        boolean        iWriteBack  = ConfigManager.getBool("execution.control.writeback", true);
        boolean        iAnyRun     = false;
        int            iPassCount  = 0;
        int            iFailCount  = 0;

        if (!iRequested.isEmpty())
        {
            log.info("[RUNNER] testcase.ids supplied - Execution flag ignored. Requested: " + iRequested);
        }

        String iSuiteBrowser = ConfigManager.getOrDefault("browser", "CHROME");
        ReportManager.startSuite(iEnvOverride, iSuiteBrowser);

        for (int iRowNumber = 1; iRowNumber <= iRowCount; iRowNumber++)
        {
            String iTestCaseID   = "";
            String iEnvironment  = "";
            String iBrowser      = "";
            String iDescription  = "";
            String iTags         = "";
            String iErrorMessage;
            String iScreenshot;
            long   iStartTime    = 0L;

            try
            {
                iTestCaseID = iExcel.getCellValue(iExecutionControlSheetName, iRowNumber, "TestCase_ID").trim();

                if (iRequested.isEmpty())
                {
                    String iExecFlag = iExcel.getCellValue(iExecutionControlSheetName, iRowNumber, "Execution").trim();
                    if (!iExecFlag.equalsIgnoreCase("Y"))
                    {
                        log.info("[RUNNER] Row " + iRowNumber + " skipped (Execution=" + iExecFlag + ")");
                        continue;
                    }
                }
                else if (!iRequested.contains(iTestCaseID.toUpperCase(Locale.ROOT)))
                {
                    continue;
                }

                iMatched.add(iTestCaseID.toUpperCase(Locale.ROOT));
                iAnyRun = true;

                iEnvironment = iEnvOverride.isEmpty()
                        ? iExcel.getCellValue(iExecutionControlSheetName, iRowNumber, "Environment").trim()
                        : iEnvOverride;
                iDescription = iExcel.getCellValue(iExecutionControlSheetName, iRowNumber, "Description").trim();

                if (iTestCaseID.isEmpty())
                {
                    throw new RuntimeException("TestCase_ID is blank at row " + iRowNumber);
                }

                if (iEnvironment.isEmpty())
                {
                    throw new RuntimeException("Environment is blank for TestCase_ID : " + iTestCaseID);
                }

                iBrowser = safeGetCell(iExcel, iExecutionControlSheetName, iRowNumber, "Browser", iSuiteBrowser);
                iTags    = safeGetCell(iExcel, iExecutionControlSheetName, iRowNumber, "Tags", "");

                // -Dbrowser.force=true makes -Dbrowser win over the Excel column (containers only ship Chromium/Firefox/WebKit)
                if (ConfigManager.getBool("browser.force", false))
                {
                    iBrowser = iSuiteBrowser;
                }

                String iFeaturePath = locateFeatureFile(iTestCaseID);

                System.setProperty("testcase",    iTestCaseID);
                System.setProperty("environment", iEnvironment);
                System.setProperty("browser",     iBrowser);

                printExecutionHeader(iTestCaseID, iEnvironment, iBrowser, iFeaturePath);
                new File(iHtmlReportPath).mkdirs();
                new File(iJsonReportPath).mkdirs();

                ReportManager.beginTestCase(iTestCaseID, iDescription, iTags);

                iStartTime = System.currentTimeMillis();

                byte iExitCode = Main.run(
                        new String[]{
                                iFeaturePath,
                                "--glue",   iStepDefinitionsGlue,
                                "--plugin", "pretty",
                                "--plugin", "summary",
                                "--plugin", iStepListenerPlugin,
                                "--plugin", "html:" + iHtmlReportPath + iTestCaseID + ".html",
                                "--plugin", "json:" + iJsonReportPath + iTestCaseID + ".json"
                        },
                        Thread.currentThread().getContextClassLoader()
                );

                long iDuration = System.currentTimeMillis() - iStartTime;

                if (iExitCode == 0)
                {
                    writeStatus(iExcel, iWriteBack, iRowNumber, "PASS");
                    log.info("[RUNNER] PASS : " + iTestCaseID + "  (" + formatDuration(iDuration) + ")");
                    iPassCount++;

                    ReportManager.recordResult(iTestCaseID, iDescription, "PASS",
                            iDuration, "", "", iTags, iEnvironment, iBrowser);
                }
                else
                {
                    iErrorMessage = System.getProperty("lastFailureReason." + iTestCaseID, "");
                    iScreenshot   = System.getProperty("lastScreenshotPath." + iTestCaseID, "");
                    String iTrace = System.getProperty("lastTracePath." + iTestCaseID, "");
                    if (!iTrace.isEmpty())
                    {
                        iErrorMessage = iErrorMessage + (iErrorMessage.isEmpty() ? "" : " | ") + "Trace: " + iTrace;
                    }

                    writeStatus(iExcel, iWriteBack, iRowNumber, "FAIL");
                    log.severe("[RUNNER] FAIL : " + iTestCaseID + "  (" + formatDuration(iDuration) + ")");
                    iFailCount++;

                    ReportManager.recordResult(iTestCaseID, iDescription, "FAIL",
                            iDuration, iErrorMessage, iScreenshot, iTags, iEnvironment, iBrowser);
                }
            }
            catch (Exception iException)
            {
                long iDuration = iStartTime > 0 ? System.currentTimeMillis() - iStartTime : 0L;

                try
                {
                    if (!iTestCaseID.isEmpty())
                    {
                        writeStatus(iExcel, iWriteBack, iRowNumber, "FAIL");
                    }
                }
                catch (Exception ignored) {}

                log.severe("[RUNNER] ERROR - Row=" + iRowNumber + "  TestCase_ID=" + iTestCaseID
                        + "\n           Reason: " + iException.getMessage());

                iFailCount++;

                ReportManager.recordResult(iTestCaseID, iDescription, "ERROR",
                        iDuration, iException.getMessage(), "", iTags, iEnvironment, iBrowser);
            }
        }

        // browser.reuse keeps one browser open across test cases - close it now that the last one has finished
        try   { commonFunctions.CommonFunctions.shutdownBrowser(); }
        catch (Exception e) { log.warning("[RUNNER] Browser shutdown failed : " + e.getMessage()); }

        ReportManager.endSuite();
        printExecutionSummary(iPassCount, iFailCount);

        try   { HtmlReportGenerator.generate(); }
        catch (Exception e) { log.severe("[RUNNER] HTML report failed : " + e.getMessage()); }

        try   { JUnitXmlGenerator.generate(); }
        catch (Exception e) { log.severe("[RUNNER] JUnit XML failed : " + e.getMessage()); }

        if (!iRequested.isEmpty())
        {
            Set<String> iMissing = new LinkedHashSet<>(iRequested);
            iMissing.removeAll(iMatched);
            if (!iMissing.isEmpty())
            {
                throw new RuntimeException("testcase.ids not found in ExecutionControl.xlsx: " + iMissing);
            }
        }

        if (!iAnyRun)
        {
            throw new RuntimeException("No test cases selected. Set Execution=Y in ExecutionControl.xlsx or pass -Dtestcase.ids=...");
        }

        if (iFailCount > 0)
        {
            throw new RuntimeException("Suite completed with " + iFailCount + " failure(s). "
                    + "Check Test_Report/html, Test_Report/docs and Test_Report/traces.");
        }
    }

    private static void writeStatus(ExcelUtilities pExcel, boolean pWriteBack, int pRow, String pStatus)
    {
        if (!pWriteBack) { return; }
        pExcel.setCellValue(iExecutionControlSheetName, pRow, "Status", pStatus);
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : locateFeatureFile
    // Description   : Finds <TestCase_ID>.feature anywhere under the feature folder (same rule as the Selenium TestRunner).
    //                   1. Test_Cases/<ID>.feature
    //                   2. Any sub-folder, any depth, exact file name (shallowest match wins)
    //                   3. Any sub-folder, any depth, ignoring upper/lower case (a warning is logged, because the
    //                      Linux Docker container is case-sensitive and would not find that file with a different case)
    //                 When nothing is found, the error lists the folder searched and how many feature files it holds.
    // Parameters    : pTestCaseID (String) - TestCase_ID from ExecutionControl.xlsx
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Created  : 10-03-2026 | Updated: 16-09-2026 (recursive, case-insensitive fallback, clearer error)
    // ***************************************************************************************************************************************************************************************
    private static String locateFeatureFile(String pTestCaseID)
    {
        final String iFeatureName = pTestCaseID + ".feature";
        File iRoot = new File(iFeatureDirectoryPath);

        File iDirect = new File(iRoot, iFeatureName);
        if (iDirect.isFile())
        {
            return iDirect.getPath();
        }

        if (!iRoot.isDirectory())
        {
            throw new RuntimeException("Feature folder does not exist : " + iRoot.getAbsolutePath()
                    + " | Copy the Test_Cases folder into src/test/resources/ or set -Dfeature.directory.path");
        }

        List<Path> iAllFeatures;
        try (Stream<Path> iWalk = Files.walk(iRoot.toPath()))
        {
            iAllFeatures = iWalk.filter(Files::isRegularFile)
                    .filter(iPath -> iPath.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".feature"))
                    .sorted(Comparator.comparingInt(Path::getNameCount).thenComparing(Path::toString))
                    .collect(Collectors.toList());
        }
        catch (Exception iException)
        {
            throw new RuntimeException("Failed searching for feature file " + iFeatureName + " under "
                    + iRoot.getAbsolutePath() + " : " + iException.getMessage(), iException);
        }

        for (Path iPath : iAllFeatures)
        {
            if (iPath.getFileName().toString().equals(iFeatureName))
            {
                return iPath.toString();
            }
        }

        for (Path iPath : iAllFeatures)
        {
            if (iPath.getFileName().toString().equalsIgnoreCase(iFeatureName))
            {
                log.warning("[RUNNER] Feature file name differs in case : expected '" + iFeatureName + "', found '"
                        + iPath.getFileName() + "'. This works on Windows but fails in the Linux Docker container - rename the file.");
                return iPath.toString();
            }
        }

        throw new RuntimeException("Feature file not found : " + iFeatureName + " | Searched " + iRoot.getAbsolutePath()
                + " and all sub-folders | Feature files found there : " + iAllFeatures.size()
                + " | TestCase_ID in ExecutionControl.xlsx must match the .feature file name");
    }

    private static String safeGetCell(ExcelUtilities pExcel, String pSheet, int pRow, String pColumnName, String pDefault)
    {
        try
        {
            String iValue = pExcel.getCellValue(pSheet, pRow, pColumnName).trim();
            return iValue.isEmpty() ? pDefault : iValue;
        }
        catch (Exception iException)
        {
            return pDefault;
        }
    }

    private static void printExecutionHeader(String pID, String pEnv, String pBrowser, String pPath)
    {
        System.out.println("\n==================================================================");
        System.out.println("  STARTING   : " + pID);
        System.out.println("  Environment: " + pEnv);
        System.out.println("  Browser    : " + pBrowser);
        System.out.println("  Feature    : " + pPath);
        System.out.println("==================================================================");
    }

    private static void printExecutionSummary(int pPass, int pFail)
    {
        System.out.println("\n==================================================================");
        System.out.println("  EXECUTION SUMMARY");
        System.out.println("  Total : " + (pPass + pFail));
        System.out.println("  PASS  : " + pPass);
        System.out.println("  FAIL  : " + pFail);
        System.out.println("  HTML  : Test_Report/html/");
        System.out.println("  XML   : target/surefire-reports/BISS_Execution_Results.xml");
        System.out.println("  TRACE : Test_Report/traces/ (failed test cases only)");
        System.out.println("==================================================================");
    }

    private static String formatDuration(long pMs)
    {
        long iSecs = (pMs / 1000) % 60;
        long iMins = pMs / (1000 * 60);
        return iMins > 0 ? iMins + "m " + iSecs + "s" : iSecs + "s";
    }
}
