package TestRunner;


import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.DataProvider;

@CucumberOptions(
        features = "@allure-results/rerun.txt",
        glue = {"com.stepdefinitions"}, dryRun = false, monochrome = true,
        plugin = { "pretty", "io.qameta.allure.cucumber6jvm.AllureCucumber6Jvm","json:target/cucumberDefault.json", "rerun:allure-results/rerun.txt" })
public class rerunfailed extends AbstractTestNGCucumberTests {
    @Override
    @DataProvider()
    public Object[][] scenarios() {
        return super.scenarios();
    }

    private String getprojectName;
    private String getBrowser;
    private String getVersion;
    private String getUser;
    private String getEnvironment;
    private String dateString;

}
