// ===================================================================================================================================
// File          : TC_02_ENTS.java
// Package       : stepdefinitions.ENTS
// Description   : Step definitions for TC_02_ENTS - Transfer Application negative case (herd without entitlements).
//
//                 Steps in this file (2):
//                   1. the agent initiates a transfer search for herd without entitlements (DataTable)
//                   2. the Add Entitlement button should not be present
//
//                 Every other step of TC_02_ENTS.feature is already defined:
//                   login / portal navigation                       -> stepdefinitions.TC_03
//                   tab switching                                   -> stepdefinitions.TC_06
//                   create / upload / send / key / submit / back    -> stepdefinitions.ENTS.TC_01_ENTS
//
//                 Playwright edition (22-09-2026):
//                   - Same step texts, same ObjectRepository keys, same flow.
//                   - The transferor herd is searched with EntsSession.openTransferOutHerd, which waits for the row of
//                     THAT herd and skips rows marked expired. Selenium clicked the first View link on the page, which
//                     could open an unrelated row before the search result arrived.
//                   - Runtime data (23-09-2026): when the DataTable has tokens, both herds are picked at random for
//                     the logged-in agent by EntsTestData.nextNoEntitlementPair:
//                       transferor - a herd of the agent with NO entitlements (query "ENTS Agent herds without entitlements")
//                       transferee - a herd from the agent's usual Agent Login pool
//                     Both are checked in the Transfer Out list first (blacklisted, missing, expired). A rejected herd is
//                     recorded in the used-herds file and a new pair is picked, up to ents.pair.retries (default 5).
//                     A plain herd number in a cell is used as it is (pinning for debugging).
//
// Author        : Aniket Pathare | aniket.pathare@government.ie
// Date Created  : 31-03-2026 | Updated: 23-09-2026 (Playwright + runtime herds for the negative case)
// ===================================================================================================================================

package stepdefinitions.ENTS;

import com.microsoft.playwright.Locator;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;
import org.junit.jupiter.api.Assertions;
import stepdefinitions.Hooks;
import utilities.ConfigManager;
import utilities.EntsTestData;
import utilities.ObjReader;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import static commonFunctions.CommonFunctions.iAction;
import static stepdefinitions.ENTS.EntsSession.pause;
import static stepdefinitions.ENTS.EntsSession.xp;

public class TC_02_ENTS
{
    private static final Logger log = Logger.getLogger(TC_02_ENTS.class.getName());


    // ===================================================================================================================================
    //  NEGATIVE CASE - HERD WITHOUT ENTITLEMENTS
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent initiates a transfer search for herd without entitlements (DataTable)
    // Description   : Runs the transferor flow up to the entitlement page and stops there. The next step asserts that
    //                 the Add button is absent.
    //                 This is TC_01_ENTS.theAgentCreatesATransferApplicationWithTheFollowingDetails() without step 5
    //                 (add entitlement), because the herd has none.
    //
    //                 DataTable keys:
    //                   transferorHerd (String) - {transferor.herd} (a random herd of the agent with no entitlements),
    //                                             or a herd number to pin it
    //                   transfereeHerd (String) - {transferee.herd}, or a herd number
    //                   transfereeName (String) - {transferee.name}, or the exact portal name
    //                   transferType   (String) - transfer type text, e.g. "Inheritance of Entitlements"
    //
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 23-09-2026 (Playwright + runtime herds)
    // ***************************************************************************************************************************************************************************************
    @When("the agent initiates a transfer search for herd without entitlements")
    public void theAgentInitiatesATransferSearchForHerdWithoutEntitlements(DataTable pDataTable)
    {
        log.info("[STEP] When the agent initiates a transfer search for herd without entitlements");

        Map<String, String> iRaw      = pDataTable.asMap(String.class, String.class);
        boolean             iRuntime  = EntsTestData.tableHasToken(iRaw);
        int                 iMaxTries = iRuntime ? Math.max(1, ConfigManager.getInt("ents.pair.retries", 5)) : 1;
        Map<String, String> iData     = null;

        // Pick a pair (runtime) and check both herds in the agent's Transfer Out list.
        // The transferee is checked first, so the last search on screen is the transferor.
        for (int iTry = 1; iTry <= iMaxTries; iTry++)
        {
            if (iRuntime)
            {
                EntsTestData.nextNoEntitlementPair(EntsTestData.loggedInUser(),
                        iRaw.getOrDefault("transferType", "").trim() + " (no entitlements)");
            }
            iData = EntsTestData.resolveTable(iRaw);

            String iRejectedHerd = iData.get("transfereeHerd").trim();
            String iReason       = herdProblem(iRejectedHerd, "transferee");
            if (iReason == null)
            {
                iRejectedHerd = iData.get("transferorHerd").trim();
                iReason       = herdProblem(iRejectedHerd, "transferor");
            }

            if (iReason == null)
            {
                // herdProblem may have swapped the DB name for the portal name - resolve the tokens again
                if (iRuntime) iData = EntsTestData.resolveTable(iRaw);
                break;
            }

            if (!iRuntime || iTry == iMaxTries)
            {
                throw new RuntimeException("[TRANSFER] Herd " + iRejectedHerd + " is " + iReason
                        + (iRuntime ? " (tried " + iMaxTries + " pairs - check the \"ENTS Agent herds without entitlements\" query / ents.scheme.year)" : ""));
            }
            EntsTestData.markNotFound(iRejectedHerd, iReason);
            log.warning("[TRANSFER] Try " + iTry + "/" + iMaxTries + ": " + iRejectedHerd + " " + iReason + " - picking another pair.");
        }

        String iTransferorHerd = iData.get("transferorHerd").trim();
        String iTransfereeHerd = iData.get("transfereeHerd").trim();
        String iTransfereeName = iData.get("transfereeName").trim();
        String iTransferType   = iData.get("transferType").trim();

        // Search the transferor herd and open its row (waits for that row, skips expired rows)
        EntsSession.openTransferOutHerd(iTransferorHerd);
        log.info("Transferor herd opened (no entitlements expected): " + iTransferorHerd);

        // Create Transfer Application
        iAction("CLICK", "XPATH", ObjReader.getLocator("iCreateTransferBtn"), null);

        // Search for the transferee
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iTransferTypeSearchBtn"), null);
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iTransfereeHerdField"), iTransfereeHerd);
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iTransfereeNameField"), iTransfereeName);
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iTransferDialogSearchBtn"), null);
        log.info("Transferee searched: " + iTransfereeName + " (" + iTransfereeHerd + ")");

        // Same herd returned twice ("2 matches found. Please select one:") - select the row with no End Date (24-09-2026)
        EntsSession.selectOpenTransfereeMatch(iTransfereeHerd);

        // Select the transfer type (same union XPath as TC_01_ENTS)
        pause(1000);
        iAction("CLICK", "XPATH",
                "//mat-radio-button[contains(.,'" + iTransferType + "')] | "
                        + "//tr[contains(.,'" + iTransferType + "')]//input | "
                        + "//*[@value='" + iTransferType + "']",
                null);
        pause(1000);

        // Next - lands on the entitlement page
        iAction("CLICK", "XPATH", ObjReader.getLocator("iTransferNextBtn"), null);

        log.info("Transfer setup complete - on the entitlement page. Expecting NO Add button for herd: " + iTransferorHerd);
    }


    // ***************************************************************************************************************************************************************************************
    // Function Name : herdProblem
    // Description   : Null when the herd can be used, otherwise the reason it cannot (same checks as TC_01_ENTS):
    //                   - "blacklisted"                              herd is in Hooks.BLACKLISTED_HERDS
    //                   - "not in the Transfer Out list of <agent>"  the search returns no row for this herd
    //                   - "expired (...)"                            every row of the herd has the Expired icon
    //                 For the transferee, the name of the not-expired row replaces the DB name (ents.name.from.portal),
    //                 because the transferee search needs the exact portal name.
    // Parameters    : pHerd (String) - herd number | pRole (String) - "transferor" or "transferee"
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 23-09-2026
    // ***************************************************************************************************************************************************************************************
    private static String herdProblem(String pHerd, String pRole)
    {
        if (Hooks.BLACKLISTED_HERDS.contains(pHerd))
        {
            return "blacklisted";
        }

        if (!EntsSession.searchTransferOut(pHerd))
        {
            return "not in the Transfer Out list of " + EntsTestData.loggedInUser();
        }

        if (EntsSession.activeTransferOutRows(pHerd) == 0)
        {
            return "expired (every Transfer Out row of this herd has the Expired icon)";
        }

        if ("transferee".equals(pRole) && ConfigManager.getBool("ents.name.from.portal", true))
        {
            String iPortalName = EntsSession.transferOutName(pHerd);
            log.info("[TRANSFER] transferee " + pHerd + " portal name (not-expired row)='" + iPortalName + "'");
            EntsTestData.usePortalName(pHerd, iPortalName);
        }
        return null;
    }


    // ***************************************************************************************************************************************************************************************
    // Step          : the Add Entitlement button should not be present
    // Description   : Asserts that no visible Add button is on the entitlement page and that the
    //                 "You currently have no entitlements to select" label is shown.
    //                 Change from Selenium: counts the VISIBLE Add buttons with Playwright locators instead of
    //                 findElements + isDisplayed, and gives the page a moment to render the empty state first.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @Then("the Add Entitlement button should not be present")
    public void theAddEntitlementButtonShouldNotBePresent()
    {
        log.info("[STEP] Then the Add Entitlement button should not be present");

        // Wait for the empty-state label rather than asserting on a page that is still rendering
        boolean iNoEntitlementLabel = EntsSession.isVisible(ObjReader.getLocator("iTransferNoEntitlementLabel"), 10);

        List<Locator> iAddButtons   = xp(ObjReader.getLocator("iTransferAddEntitlementBtns")).all();
        int           iVisibleCount = 0;
        for (Locator iBtn : iAddButtons)
        {
            if (iBtn.isVisible()) iVisibleCount++;
        }

        log.info("[TRANSFER] Visible Add button(s): " + iVisibleCount
                + " | 'no entitlements' label shown: " + iNoEntitlementLabel);

        Assertions.assertEquals(0, iVisibleCount,
                "Add Entitlement button should NOT be present for a herd without entitlements.");
        Assertions.assertTrue(iNoEntitlementLabel,
                "The 'You currently have no entitlements to select' label should be shown for a herd without entitlements.");

        log.info("Negative validation passed - Add Entitlement button is absent as expected.");
    }
}
