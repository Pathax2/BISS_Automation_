package com.stepdefinitions;


import com.base.ConfigReader;
import com.base.DriverManager;
import com.pages.BPSdashboardPage;
import com.pages.LoginPage;
import com.pages.MyClientsPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import java.util.List;
import java.util.Properties;

public class BPSDashboardSteps {

    LoginPage loginPage;
    BPSdashboardPage bpsdashboardPage;
    MyClientsPage parcelsearchPage;
    WebDriver driver;
    Properties prop;
    ConfigReader configReader;
    DriverManager driverManager;
    public BPSDashboardSteps(DriverManager driverManager){
        try {
            this.driverManager=driverManager;
            driver=driverManager.getDriverInstance();
            loginPage = new LoginPage(driver);
            bpsdashboardPage = new BPSdashboardPage(driver);
            parcelsearchPage = new MyClientsPage(driver);
            configReader = new ConfigReader();
            prop = configReader.init_prop();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    // region BPS Steps Code
    @Then("Agent Check for News Section Visibility")
    public void AgentCheckVisibilityOfNewsSection() throws InterruptedException {
        Assert.assertTrue(bpsdashboardPage.AgentCheckNewsSection());
    }

    @And("Navigate to News Page")
    public void AgentNavigateToNewsPage() {
        bpsdashboardPage.AgentClickOnViewInNewsSection();
    }

    @Then("Staff is on Agent News Page")
    public void AgentNewsPage() {
        String title = driver.getTitle();
        System.out.println("title of Agent News Page" + title);
    }

    @And("Agent enters the Herd Number as {string}")
    public void AgentEnterHerd(String Arg0) {
        bpsdashboardPage.AgentEnterHerd(Arg0);
    }

    @Then("Agent clicks on the Search Herd Button")
    public void AgentClickOnSearchHerd() {
        bpsdashboardPage.AgentClickOnSearchHerdButton();
    }

    @And("Agent clicks on the Searched Herd View Button")
    public void AgentClickOnSearchedHerdViewButton() {
        bpsdashboardPage.AgentClickOnSearchedHerdViewButton();
    }

    @And("Agent Click on the Help Link")
    public void AgentClickOnHelpLink() throws InterruptedException {
        bpsdashboardPage.AgentClickOnHelpLink();
        Thread.sleep(2000);
        // Current WindowHandle
        String winHandlePresent = driver.getWindowHandle();
        for(String winHandle : driver.getWindowHandles()) {
//            String LinkText = driver.switchTo().window(winHandle).findElement(By.id("I_11")).getText();
//            System.out.println(LinkText);
            driver.switchTo().window(winHandle);
        }
    }

    @Then("Verify Agent is in Help Window and title has 2022")
    public void AgentHelpPage() {
        String title = driver.getTitle();
        System.out.println("title of Help Page is : " + title);
        Assert.assertEquals(title,"Bps Direct Payments 2022 Help");
    }

    @And("Agent Navigate to Filing Your BPS Application Online")
    public void NavigateToFilingYourBPSApplicationOnline() throws InterruptedException {
        bpsdashboardPage.AgentNavigateToFilingBPSApplicationOnline();
    }

    @And("Verify that Partnership Information has the year 2022")
    public void AgentCheckIfThereIs2022inPartnershipText() {
        Assert.assertTrue(bpsdashboardPage.AgentCheckPartnerShipInformationContains());
    }

    @And("Verify that ANC para has been updated to the year 2022")
    public void AgentCheckIfThereIs2022inANCText() {
        Assert.assertTrue(bpsdashboardPage.AgentCheckANCContains2022());
    }

    @And("Verify that YFS para years have been updated")
    public void AgentCheckIfThereIsUpdateInYFSContent() {
        Assert.assertTrue(bpsdashboardPage.AgentCheckYFS1stParaContains2021());
        Assert.assertTrue(bpsdashboardPage.AgentCheckYFS2ndParaContains2022());
    }

    @And("Verify that GLAS para years have been updated To 2022")
    public void AgentCheckIfThereIsUpdateInGLASContent() {
        Assert.assertTrue(bpsdashboardPage.AgentCheckGLAS2ndParaContains2022());
        Assert.assertTrue(bpsdashboardPage.AgentCheckGLAS3rdParaContains2022());
    }

    @And("Agent Navigate to Submitting a No Change Case")
    public void NavigateToSubmittingANoChangeCase() throws InterruptedException {
        bpsdashboardPage.AgentNavigateToSubmittingANoChangeCase();
    }

    @And("Verify that Navigate to Submitting a No Change Case To 2022")
    public void AgentCheckIfThereIsUpdateInSubmittingNoChangeCaseContent() {
        Assert.assertTrue(bpsdashboardPage.AgentCheckSubmittingANoChangeCaseContentUpdateTo2022());
    }

    @And("Agent Navigate to Land Parcel Details")
    public void NavigateToLandParcelDetails() throws InterruptedException {
        bpsdashboardPage.AgentNavigateToLandParcelDetails();
    }

    @And ("Check if Pop Up Section present in Land Parcel Details")
    public void AgentCheckPopUpSectionInLandParcelDetails() {
        bpsdashboardPage.AgentCheckPopUpSection();
    }

    @And("Agent Navigate to Add Plot")
    public void NavigateToAddPlot() throws InterruptedException {
        bpsdashboardPage.AgentNavigateToAddPlot();
    }

    @And ("Check if Add Plot Content Year Updated to 2022")
    public void AgentCheckYearUpdateInAddPlot() {
        bpsdashboardPage.AgentCheckAddPlotSectionYearUpdate();
    }

    @And("Agent Navigate to Island Details")
    public void NavigateToIslandDetails() throws InterruptedException {
        bpsdashboardPage.AgentNavigateToIslandDetails();
    }

    @And ("Check if Island Details Content Year Updated to 2022")
    public void AgentCheckYearUpdateInIslandDetails() {
        bpsdashboardPage.AgentCheckIslandDetailsSectionYearUpdate();
    }

    @And("Agent Navigate to Organic Land Details")
    public void NavigateToOrganicLandDetails() throws InterruptedException {
        bpsdashboardPage.AgentNavigateToOrganicLandDetails();
    }

    @And ("Check if Organic Land Details Content Year Updated to 2022")
    public void AgentCheckYearUpdateInOrganicLandDetails() {
        bpsdashboardPage.AgentCheckOrganicLandDetailsSectionYearUpdate();
    }

    @And("Agent Navigate to Greening")
    public void NavigateToGreening() throws InterruptedException {
        bpsdashboardPage.AgentNavigateToGreening();
    }

    @And ("Check if Provisional Status Update Content Year in Greening Tab Updated to 2022")
    public void AgentCheckYearUpdateInProvisionalStatusUpdate() {
        bpsdashboardPage.AgentCheckProvisionalStatusTableContains2022();
    }

    @And("Agent Navigate to SIM")
    public void NavigateToSIM() throws InterruptedException {
        bpsdashboardPage.AgentNavigateToSIM();
    }

    @And("Agent Check SIM Section Text")
    public void AgentCheckSIMSectionText() {
        Assert.assertEquals(bpsdashboardPage.AgentCheckSIMSectionText(),"A pop-up with the following SIM warning:");
    }

    @And("Agent Navigate to Application Summary")
    public void NavigateToApplicationSummary() throws InterruptedException {
        bpsdashboardPage.AgentNavigateToApplicationSummary();
    }

    @And ("Check if Application Summary Content Year Updated to 2022")
    public void AgentCheckYearUpdateInApplicationSummary() {
        bpsdashboardPage.AgentCheckApplicationSummarySectionYearUpdate();
    }

    // endregion

    @When("Agent Click on My Clients")
    public void AgentClickOnMyClients() {
        loginPage.AgentClickOnMyClients();
    }

    // region BISS Code

    @When("Agent Click on the {string} hyperlink in the Quick Links Section")
    public void AgentClickOnQuickLinksInDashboard(String Arg0) throws InterruptedException {
        bpsdashboardPage.AgentClickOnQuickLinksViewClientsLink(Arg0);
        Thread.sleep(2000);
    }

    @And("Agent Click on View Clients Button in BISS Applications Section")
    public void AgentClickOnViewAllClientsButtonInApplicationsSection() {
        bpsdashboardPage.AgentClickOnTotalClientsButton();
    }

    @Then("Agent Click On Read More Button in News Section")
    public void AgentClickOnReadMoreButton() {
        bpsdashboardPage.AgentClickOnReadMoreNewsButton();
    }

    // endregion
}
