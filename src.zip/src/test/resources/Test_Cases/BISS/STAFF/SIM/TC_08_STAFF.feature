# ============================ TC_08_STAFF.feature ============================
@sim
Feature: TC_08_STAFF - SIM Amendments Core E2E Regression Pack

  # Legacy: "Regression Suite for SIM Amendments" (BISSAGL-7110 AT-TC-01 to 04)
  # Legacy had NO Background query block - herd A1071109 hardcoded in all 4 scenarios.
  # Kept as a literal: parcel Y2031000006 must exist on this herd for Section 1.
  #
  # LEGACY COVERAGE WARNING - carried forward honestly:
  #   AT-TC-03 (BISSAGL-14861) navigates to the SIM tab and STOPS. It has no assertion.
  #   Legacy comment on it reads "parcel with errors needed that can be cleared on Admin
  #   Inspection page" - i.e. the test data never existed. Section 3 reproduces it as-is
  #   and therefore asserts nothing. It should either get real data or be deleted.
  #   AT-TC-04's entire body after the SIM toggle was commented out in legacy.

  Background:
    Given user on staff login page
    When Staff logs in with the Username "agr4442"
    And Staff opens the "Basic Income Support for Sustainability" application

  @regression @staff @sim @e2e
  Scenario: AT-STAFF-SIM-CORE-E2E-01 - Staff amends SIM claimed area and verifies application totals

    # SECTION 1 : Amend SIM claimed area on parcel - AT-TC-01 (BISSAGL-14864)
    When Staff searches on the Home screen with the following details
      | field      | herdNumber |
      | herdValue  | A1071109   |
      | schemeYear | 2024       |
    And Staff clicks the "View" link number 1 in the "application-search-table" table
    Then Staff clicks on "SIM" Link in Navbar
    And Staff opens the SIM parcel "Y2031000006" side drawer
    And Staff enters value "2.25" in the "amendedClaimedArea" SIM side drawer field
    Then Staff clicks the "Save changes" button

    # SECTION 2 : Verify Original Application Total - AT-TC-02 (BISSAGL-14862)
    When Staff clicks on "Home" Link in Navbar
    And Staff searches on the Home screen with the following details
      | field      | herdNumber |
      | herdValue  | A1071109   |
      | schemeYear | 2023       |
    And Staff clicks the "View" link number 1 in the "application-search-table" table
    Then Staff clicks on "SIM" Link in Navbar
    And Staff verifies the value of the Original Application Total

    # SECTION 3 : Open SIM tab - AT-TC-03 (BISSAGL-14861)
    # NO ASSERTION IN LEGACY - test data was never created. See warning in header.
    When Staff clicks on "Home" Link in Navbar
    And Staff searches on the Home screen with the following details
      | field      | herdNumber |
      | herdValue  | A1071109   |
      | schemeYear | 2023       |
    And Staff clicks the "View" link number 1 in the "application-search-table" table
    Then Staff clicks on "SIM" Link in Navbar

    # SECTION 4 : Toggle SIM option - AT-TC-04 (BISSAGL-14860)
    When Staff clicks on "Home" Link in Navbar
    And Staff searches on the Home screen with the following details
      | field      | herdNumber |
      | herdValue  | A1071109   |
      | schemeYear | 2023       |
    And Staff clicks the "View" link number 1 in the "application-search-table" table
    Then Staff clicks on "SIM" Link in Navbar
    And Staff toggles the SIM option