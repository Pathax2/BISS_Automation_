// ===================================================================================================================================
// File          : ReportAssets.java
// Package       : reporting
// Description   : CSS and JavaScript of the dashboard report (DashboardReport), kept out of the page builder so both
//                 are easy to review. Everything is inline in the page - no fonts, scripts or styles from the internet.
//
//                 Theme: colours are CSS variables. The light values are the default; the dark values apply when the
//                 viewer chose dark (data-theme="dark" on <html>) or, before any choice, when Windows is in dark mode.
//                 Print and PDF always use the light values.
//                 Palette: the reference data-viz palette - series colours checked for colour-blind separation, status
//                 colours (good / warning / critical) kept apart from series colours and always shown with an icon.
//
// Author        : Aniket Pathare | aniket.pathare@government.ie
// Date Created  : 13-10-2026
// ===================================================================================================================================

package reporting;

final class ReportAssets
{
    private ReportAssets() { }

    private static final String LIGHT =
            "--page:#f9f9f7;--surface:#fcfcfb;--ink:#0b0b0b;--ink2:#52514e;--muted:#898781;--grid:#e1e0d9;--axis:#c3c2b7;"
          + "--line:rgba(11,11,11,.10);--hover:#f0efec;"
          + "--s1:#2a78d6;--s2:#eb6834;--s3:#1baf7a;--s4:#eda100;--s5:#e87ba4;--sg:#b9b8b0;"
          + "--good:#0ca30c;--goodtxt:#006300;--warntxt:#8a5a00;--crit:#d03b3b;--link:#1c5cab;"
          + "--q1:#cde2fb;--q2:#9ec5f4;--q3:#6da7ec;--q4:#3987e5;--q5:#256abf;--q6:#184f95;--cellon:#ffffff;";

    private static final String DARK =
            "--page:#0d0d0d;--surface:#1a1a19;--ink:#f0efec;--ink2:#c3c2b7;--muted:#898781;--grid:#2c2c2a;--axis:#383835;"
          + "--line:rgba(255,255,255,.10);--hover:#262624;"
          + "--s1:#3987e5;--s2:#d95926;--s3:#199e70;--s4:#c98500;--s5:#d55181;--sg:#5c5b57;"
          + "--good:#0ca30c;--goodtxt:#0ca30c;--warntxt:#fab219;--crit:#e66767;--link:#86b6ef;"
          + "--q1:#104281;--q2:#1c5cab;--q3:#256abf;--q4:#3987e5;--q5:#6da7ec;--q6:#9ec5f4;--cellon:#0d0d0d;";

    // Runs in <head> before the page is drawn, so a remembered theme never flashes the other one first
    static final String THEME_BOOT =
            "(function(){try{var t=localStorage.getItem('biss-report-theme');if(t==='dark'||t==='light'){document.documentElement.setAttribute('data-theme',t);}}catch(e){}})();";

    static final String CSS =
            ":root{color-scheme:light;" + LIGHT + "}"
          + "@media (prefers-color-scheme:dark){:root:not([data-theme=\"light\"]){color-scheme:dark;" + DARK + "}}"
          + ":root[data-theme=\"dark\"]{color-scheme:dark;" + DARK + "}"
          + "*{box-sizing:border-box}"
          + "body{margin:0;background:var(--page);color:var(--ink);font:14px/1.45 system-ui,-apple-system,\"Segoe UI\",Roboto,sans-serif}"
          + ".wrap{max-width:1680px;margin:0 auto;padding:24px 28px 36px}"
          + ".top{display:flex;justify-content:space-between;align-items:flex-end;gap:16px;flex-wrap:wrap}"
          + "h1{font-size:22px;margin:0 0 4px}.sub{color:var(--ink2);font-size:12.5px}"
          + ".actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap}"
          + ".btn{background:var(--surface);color:var(--ink);border:1px solid var(--line);border-radius:8px;padding:7px 12px;font:inherit;font-size:12.5px;cursor:pointer}"
          + ".btn:hover{background:var(--hover)}"
          + ".badge{font-size:11px;font-weight:700;letter-spacing:.05em;color:var(--ink2);border:1px solid var(--axis);border-radius:999px;padding:4px 10px}"
          + ".tabs{display:flex;gap:4px;margin:16px 0 18px;border-bottom:1px solid var(--grid);overflow-x:auto}"
          + ".tab{background:none;border:0;border-bottom:2px solid transparent;color:var(--ink2);padding:9px 16px;font:inherit;font-size:13.5px;cursor:pointer;white-space:nowrap}"
          + ".tab.on{color:var(--ink);font-weight:700;border-bottom-color:var(--ink)}"
          + ".panel{display:none}.panel.on{display:block}"
          + ".kpis{display:grid;gap:12px;margin-bottom:14px}.kpis.k6{grid-template-columns:repeat(6,1fr)}.kpis.k5{grid-template-columns:repeat(5,1fr)}"
          + ".kpi{background:var(--surface);border:1px solid var(--line);border-radius:10px;padding:13px 15px}"
          + ".kpi .k{font-size:12px;color:var(--ink2)}.kpi .v{font-size:28px;font-weight:700;margin:3px 0 1px}.kpi .d{font-size:12px;color:var(--muted)}"
          + ".row{display:grid;gap:14px;margin-bottom:14px}.r1{grid-template-columns:1fr}.r2{grid-template-columns:1fr 1fr}"
          + ".r2w{grid-template-columns:1.5fr 1fr}.r3{grid-template-columns:1.15fr 1fr .75fr}"
          + "@media (max-width:1150px){.r2,.r2w,.r3{grid-template-columns:1fr}.kpis.k6,.kpis.k5{grid-template-columns:repeat(2,1fr)}}"
          + ".card{background:var(--surface);border:1px solid var(--line);border-radius:10px;padding:15px 17px;min-width:0}"
          + ".card h3{margin:0 0 2px;font-size:14px}.hint{margin:0 0 12px;font-size:12px;color:var(--muted)}"
          + "svg.chart{max-width:100%;height:auto;display:block}"
          + ".s1{fill:var(--s1)}.s2{fill:var(--s2)}.s3{fill:var(--s3)}.s4{fill:var(--s4)}.s5{fill:var(--s5)}.sg{fill:var(--sg)}.sc{fill:var(--crit)}"
          + ".q1{fill:var(--q1)}.q2{fill:var(--q2)}.q3{fill:var(--q3)}.q4{fill:var(--q4)}.q5{fill:var(--q5)}.q6{fill:var(--q6)}"
          + ".ribbon{fill-opacity:.35;stroke:var(--surface);stroke-width:1}.ribbon:hover{fill-opacity:.6}.node{fill:var(--ink2)}"
          + ".grid{stroke:var(--grid);fill:var(--grid)}.axis{stroke:var(--axis)}"
          + ".cell0{fill:var(--surface);stroke:var(--grid)}.cellTxt{fill:var(--ink);font-size:13px;font-weight:700}.cellTxtOn{fill:var(--cellon);font-size:13px;font-weight:700}"
          + "text.lab{font-size:12px;fill:var(--ink2)}text.val{font-size:12px;fill:var(--ink2);font-variant-numeric:tabular-nums}"
          + "text.tick{font-size:11px;fill:var(--muted);font-variant-numeric:tabular-nums}text.axisTitle{font-size:10px;fill:var(--muted);letter-spacing:.08em}"
          + "g:hover>path,g:hover>rect{opacity:.85}"
          + ".legend{display:flex;flex-wrap:wrap;gap:14px;font-size:12px;color:var(--ink2);margin-bottom:10px;align-items:center}"
          + ".legend i{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:6px;vertical-align:-1px}"
          + ".legend i.s1{background:var(--s1)}.legend i.s2{background:var(--s2)}.legend i.s3{background:var(--s3)}.legend i.s4{background:var(--s4)}"
          + ".legend i.s5{background:var(--s5)}.legend i.sg{background:var(--sg)}"
          + ".ramp{display:inline-flex}.ramp i{width:20px;height:10px;border-radius:0;margin:0}"
          + ".ramp i.q1{background:var(--q1)}.ramp i.q2{background:var(--q2)}.ramp i.q3{background:var(--q3)}.ramp i.q4{background:var(--q4)}.ramp i.q5{background:var(--q5)}.ramp i.q6{background:var(--q6)}"
          + ".scroll{overflow-x:auto}"
          + ".tbl{width:100%;border-collapse:collapse;font-size:12.5px}"
          + ".tbl th{text-align:left;font-weight:600;color:var(--ink2);border-bottom:1px solid var(--axis);padding:6px 8px;white-space:nowrap}"
          + ".tbl td{border-bottom:1px solid var(--grid);padding:6px 8px;vertical-align:top}.tbl tbody tr:hover td{background:var(--hover)}"
          + ".r{text-align:right}.num,.mono{font-variant-numeric:tabular-nums}.mono{font-family:ui-monospace,Consolas,monospace;font-size:12px}"
          + ".muted{color:var(--muted)}.xp{color:var(--muted);font-size:11px;word-break:break-all}.fix{color:var(--ink2);min-width:220px}.msg{max-width:520px;word-break:break-word}"
          + ".st{font-weight:600;white-space:nowrap}.st.good{color:var(--goodtxt)}.st.crit{color:var(--crit)}.st.warn{color:var(--warntxt)}"
          + ".pill{display:inline-block;font-size:11.5px;font-weight:700;padding:2px 9px;border-radius:999px;border:1px solid var(--line);white-space:nowrap}"
          + ".pill.good{color:var(--goodtxt)}.pill.crit{color:var(--crit)}.pill.warn{color:var(--warntxt)}"
          + ".chip{display:inline-block;padding:1px 8px;border-radius:999px;font-size:11px;border:1px solid var(--grid);color:var(--ink2);white-space:nowrap}"
          + ".mod{display:inline-block;padding:1px 7px;border-radius:4px;font-size:10px;font-weight:700;letter-spacing:.04em;background:var(--grid);color:var(--ink2);margin-right:8px}"
          + ".mini{display:grid;grid-template-columns:1fr 1fr;gap:10px}.mini div{border:1px solid var(--grid);border-radius:8px;padding:10px 12px}"
          + ".mini b{display:block;font-size:22px}.mini span{font-size:12px;color:var(--ink2)}"
          + ".empty{color:var(--muted);font-size:12.5px;margin:8px 0}"
          + ".filters{display:flex;gap:10px;margin-bottom:14px;flex-wrap:wrap;align-items:center}"
          + ".filters input,.filters select{background:var(--surface);color:var(--ink);border:1px solid var(--line);border-radius:8px;padding:7px 10px;font:inherit;font-size:12.5px}"
          + ".filters input{min-width:260px}.count{font-size:12px;color:var(--muted)}"
          + ".cases details{background:var(--surface);border:1px solid var(--line);border-radius:10px;margin-bottom:8px}"
          + ".cases details.fail,.cases details.error{border-left:3px solid var(--crit)}.cases details.pass{border-left:3px solid var(--good)}"
          + ".cases summary{display:flex;gap:12px;align-items:center;padding:10px 14px;cursor:pointer;list-style:none}"
          + ".cases summary::-webkit-details-marker{display:none}"
          + ".idx{color:var(--muted);min-width:22px}.tcid{font-weight:700;min-width:120px}.desc{flex:1;color:var(--ink2)}.meta{color:var(--muted);font-size:12px;white-space:nowrap}"
          + ".casebody{padding:0 14px 14px}.evrow{display:flex;gap:14px;flex-wrap:wrap;margin:6px 0 10px;font-size:12.5px}"
          + "a{color:var(--link)}a.ev{text-decoration:none}a.ev:hover{text-decoration:underline}"
          + ".thumb{max-width:420px;max-height:240px;border:1px solid var(--line);border-radius:6px;margin:0 0 10px;display:block}"
          + ".err{border:1px solid var(--line);border-left:3px solid var(--crit);border-radius:8px;padding:8px 12px;margin:0 0 10px}"
          + ".err pre{margin:4px 0 0;white-space:pre-wrap;word-break:break-word;font:12px/1.5 ui-monospace,Consolas,monospace;color:var(--ink2)}"
          + ".steps .kw{color:var(--ink2)}.steps tr.scen td{background:var(--hover);font-weight:600;color:var(--ink2)}"
          + ".steps tr.failrow td{background:color-mix(in srgb,var(--crit) 8%,transparent)}.steperr{color:var(--crit);font-size:12px;margin-top:3px}"
          + ".foot{font-size:11.5px;color:var(--muted);margin-top:10px}"
          + "@media print{:root,:root[data-theme]{color-scheme:light;" + LIGHT + "}"
          + "body{background:#fff}.wrap{max-width:none;padding:0}.tabs,.actions .btn,.noprint{display:none!important}"
          + ".panel{display:block!important;break-before:page}.panel:first-of-type{break-before:auto}"
          + ".panel::before{content:attr(data-title);display:block;font-size:18px;font-weight:700;margin:0 0 10px}"
          + ".card,.kpi,.cases details{break-inside:avoid}.scroll{overflow:visible}.thumb{max-height:180px}}";

    static final String JS =
            "function curTheme(){var t=document.documentElement.getAttribute('data-theme');if(t)return t;"
          + "return (window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches)?'dark':'light';}"
          + "function themeLabel(){var b=document.getElementById('themeBtn');if(b)b.textContent=curTheme()==='dark'?'Light theme':'Dark theme';}"
          + "function toggleTheme(){var n=curTheme()==='dark'?'light':'dark';document.documentElement.setAttribute('data-theme',n);"
          + "try{localStorage.setItem('biss-report-theme',n);}catch(e){}themeLabel();}"
          + "function showTab(id){document.querySelectorAll('.panel').forEach(function(p){p.classList.toggle('on',p.id==='tab-'+id);});"
          + "document.querySelectorAll('.tab').forEach(function(t){t.classList.toggle('on',t.getAttribute('data-tab')===id);});"
          + "try{history.replaceState(null,'','#'+id);}catch(e){}}"
          + "function filterLedger(){var q=(document.getElementById('ledgerSearch').value||'').toLowerCase().trim();"
          + "var tc=document.getElementById('ledgerTc').value,oc=document.getElementById('ledgerOutcome').value,n=0,all=0;"
          + "document.querySelectorAll('#ledger tbody tr').forEach(function(r){all++;var ok=(!q||r.getAttribute('data-text').indexOf(q)>=0)"
          + "&&(!tc||r.getAttribute('data-tc')===tc)&&(!oc||r.getAttribute('data-outcome')===oc);r.style.display=ok?'':'none';if(ok)n++;});"
          + "var c=document.getElementById('ledgerCount');if(c)c.textContent=n+' of '+all+' row(s)';}"
          + "function filterCases(){var q=(document.getElementById('caseSearch').value||'').toLowerCase().trim(),st=document.getElementById('caseStatus').value;"
          + "var me=document.getElementById('caseModule'),mo=me?me.value:'';"
          + "document.querySelectorAll('.cases details').forEach(function(d){var ok=(!q||d.getAttribute('data-text').indexOf(q)>=0)"
          + "&&(!st||d.getAttribute('data-status')===st)&&(!mo||d.getAttribute('data-module')===mo);d.style.display=ok?'':'none';});}"
          + "function openAll(){document.querySelectorAll('details').forEach(function(d){d.open=true;});}"
          + "function printReport(){openAll();window.print();}"
          + "window.addEventListener('beforeprint',openAll);"
          + "(function(){themeLabel();var h=(location.hash||'').replace('#','');"
          + "if(h&&document.getElementById('tab-'+h))showTab(h);if(document.getElementById('ledger'))filterLedger();})();";
}
