Feature: TC_19_ENTS - Transfer Application E2E (Individual to Agent) and submits appeals

  # Migrated from: TC_08_ENTS.feature (legacy 8 scenarios)
  # Transferor: Individual ({transferor.login}) | Transferee: a client herd of {auto.agent} - the agent with the most herds (was aga6325, 5 herds)
  # All 8 transfer types covered: 206, 201, 202, 211, 203, 204, 212, 205
  #
  # New steps: individual logs in as transferor, individual creates transfer,
  #            agent logs in as transferee agent
  # Reused: TC_01_ENTS (send/capture), TC_05_ENTS (individual login pattern)
  #
  #
  # Runtime data (Playwright, 02-10-2026, same as TC_08_ENTS):
  #   "{transferor.login}" picks an individual with their own login (Individual Login query / vault pool ENTS_INDIVIDUAL)
  #   and that person's herd is the transferor. The transfereeAgent row {auto.agent} picks the agent with the most
  #   usable herds (never the transferor's own login); {transferee.herd} {transferee.name} come from that agent's pool
  #   and "{transferee.agent}" logs in as that agent to accept. Selenium values are kept in the section comments.
  #
  # Author: Aniket Pathare | Created: 31-03-2026

  Background:
    Given the agent user is on the login page
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers                 |
  @regression @transfers @individual-to-agent @e2e
  Scenario: AT-ENTS-TRANSFERS-E2E-19 - Individual completes all transfer types to Agent and submits appeals

    # ===========================================
    # SECTION 1 : Change of Legal Entity (206)
    # ===========================================

    # --- Transferor (Individual) ---

    And the individual creates a transfer application with the following details
      | transfereeHerd | {transferee.herd}|
      | transfereeName | {transferee.name}    |
      | transfereeAgent | {auto.agent}   |
      | transferType   | Change of Legal Entity |
      | entitlements   | 0.01           |
      | notes          | Test Notes     |
    And the agent uploads the transferor signature document
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Agent) ---
    When the agent logs out and re-logs in as the transferee agent "{transferee.agent}"
    And the agent opens the "Basic Income Support for Sustainability" application
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfers should be submitted successfully
    And Validate if Appeal can be made sucessfully

    # ===========================================
    # SECTION 2 : Inheritance (201)
    # ===========================================

    # --- Transferor (Individual) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers                 |
    And the individual creates a transfer application with the following details
      | transfereeHerd | {transferee.herd}|
      | transfereeName | {transferee.name}    |
      | transfereeAgent | {auto.agent}   |
      | transferType   | Inheritance of Entitlements |
      | entitlements   | 0.01           |
      | notes          | Test Notes     |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Agent) ---
    When the agent logs out and re-logs in as the transferee agent "{transferee.agent}"
    And the agent opens the "Basic Income Support for Sustainability" application
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfers should be submitted successfully
    And Validate if Appeal can be made sucessfully

    # ===========================================
    # SECTION 3 : Gift (202)
    # ===========================================

    # --- Transferor (Individual) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers                 |
    And the individual creates a transfer application with the following details
      | transfereeHerd | {transferee.herd}|
      | transfereeName | {transferee.name}    |
      | transfereeAgent | {auto.agent}   |
      | transferType   | Gift of Entitlements|
      | entitlements   | 0.01           |
      | notes          | Test Notes     |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Agent) ---
    When the agent logs out and re-logs in as the transferee agent "{transferee.agent}"
    And the agent opens the "Basic Income Support for Sustainability" application
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfers should be submitted successfully
    And Validate if Appeal can be made sucessfully

    # ===========================================
    # SECTION 4 : Lease (211)
    # ===========================================

    # --- Transferor (Individual) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers                 |
    And the individual creates a transfer application with the following details
      | transfereeHerd | {transferee.herd}|
      | transfereeName | {transferee.name}    |
      | transfereeAgent | {auto.agent}   |
      | transferType   | Lease of Entitlements|
      | entitlements   | 0.01           |
      | leaseYear      | Yes            |
      | notes          | Test Notes     |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Agent) ---
    When the agent logs out and re-logs in as the transferee agent "{transferee.agent}"
    And the agent opens the "Basic Income Support for Sustainability" application
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfers should be submitted successfully
    And Validate if Appeal can be made sucessfully

    # ===========================================
    # SECTION 5 : Merger (203)
    # ===========================================

    # --- Transferor (Individual) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers                 |
    And the individual creates a transfer application with the following details
      | transfereeHerd | {transferee.herd}|
      | transfereeName | {transferee.name}|
      | transfereeAgent | {auto.agent}   |
      | transferType   | Merger of 2 or more holdings (forming an unregistered Farm Partnership)|
      | entitlements   | 0.01           |
      | notes          | Test Notes     |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Agent) ---
    When the agent logs out and re-logs in as the transferee agent "{transferee.agent}"
    And the agent opens the "Basic Income Support for Sustainability" application
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfers should be submitted successfully
    And Validate if Appeal can be made sucessfully

    # ===========================================
    # SECTION 6 : Division (204)
    # ===========================================

    # --- Transferor (Individual) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers                 |
    And the individual creates a transfer application with the following details
      | transfereeHerd | {transferee.herd}|
      | transfereeName | {transferee.name}    |
      | transfereeAgent | {auto.agent}   |
      | transferType   | Division of Entitlements (Scission)|
      | entitlements   | 0.01           |
      | notes          | Test Notes     |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Agent) ---
    When the agent logs out and re-logs in as the transferee agent "{transferee.agent}"
    And the agent opens the "Basic Income Support for Sustainability" application
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfers should be submitted successfully
    And Validate if Appeal can be made sucessfully

    # ===========================================
    # SECTION 7 : Sale (212)
    # ===========================================

    # --- Transferor (Individual) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers                 |
    And the individual creates a transfer application with the following details
      | transfereeHerd | {transferee.herd}|
      | transfereeName | {transferee.name}    |
      | transfereeAgent | {auto.agent}   |
      | transferType   | Sale of Entitlements |
      | entitlements   | 0.01           |
      | notes          | Test Notes     |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Agent) ---
    When the agent logs out and re-logs in as the transferee agent "{transferee.agent}"
    And the agent opens the "Basic Income Support for Sustainability" application
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfers should be submitted successfully
    And Validate if Appeal can be made sucessfully

    # ===========================================
    # SECTION 8 : Change of Registration (205)
    # ===========================================

    # --- Transferor (Individual) ---
    When the individual logs in as transferor "{transferor.login}"
    And the agent opens the "Basic Income Support for Sustainability" application
    Then the agent should land on the BISS Home page
    When the agent navigates through the farmer side navigation tabs
      | Transfers                 |
    And the individual creates a transfer application with the following details
      | transfereeHerd | {transferee.herd}|
      | transfereeName | {transferee.name}    |
      | transfereeAgent | {auto.agent}   |
      | transferType   | Change of Registration Details|
      | entitlements   | 0.01           |
      | notes          | Test Notes     |
    And the agent sends the transfer for acceptance
    Then the transfer key should be captured

    # --- Transferee (Agent) ---
    When the agent logs out and re-logs in as the transferee agent "{transferee.agent}"
    And the agent opens the "Basic Income Support for Sustainability" application
    And the agent navigates to the "Home" and "My Clients" Left Menu Link
    And the agent switches to the "Transfers" tab on the My Client page
    And the agent completes the same agent transferee acceptance flow
      | transfereeHerd | {transferee.herd}|
      | notes          | Approved Test |
    Then the transfers should be submitted successfully
    And Validate if Appeal can be made sucessfully