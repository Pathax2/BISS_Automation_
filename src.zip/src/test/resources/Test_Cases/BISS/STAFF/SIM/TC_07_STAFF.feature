
# ============================ TC_07_STAFF.feature ============================
@sim
Feature: TC_07_STAFF - SIM Amendments and History Tab E2E Regression Pack

  # Legacy: "Regression Suite for SIM Amendments - History Tab" (BISSAGL-5444 AT-TC-01)
  # Legacy Background: Get 1 Herds with Submission from DataBase - but the DB step was
  # OVERRIDDEN in the scenario by a hardcoded herd G175C038, with the DB line commented out.
  # Herd G175C038 and its parcels G17202130 / G22814025 / G22813057 are kept as literals:
  # this test needs a herd with those SPECIFIC SIM parcels present, which no legacy query
  # expresses. Substituting a generic submitted herd would break the parcel steps.

  Background:
    Given user on staff login page
    When Staff logs in with the Username "agr4442"
    And Staff opens the "Basic Income Support for Sustainability" application

  @regression @staff @sim @history @e2e
  Scenario: AT-STAFF-SIM-HIST-E2E-01 - Staff performs SIM parcel amendments and verifies history

    # SECTION 1 : Open submitted herd application - AT-TC-01 (BISSAGL-14998)
    When Staff searches on the Home screen with the following details
      | field      | herdNumber |
      | herdValue  | G175C038   |
      | schemeYear | 2023       |
    And Staff clicks the "View" link number 1 in the "application-search-table" table
    Then Staff clicks on "SIM" Link in Navbar

    # SECTION 2 : Amend SIM found area + verify history
    When Staff opens the SIM parcel "G17202130" side drawer
    And Staff enters value "4" in the "simFoundArea" SIM side drawer field
    And Staff clicks the "Save changes" button
    Then Staff clicks on "Notes/History" Link in Navbar
    And Staff switches to the "History" tab
    Then Staff verifies the History tab shows activity

    # SECTION 3 : Amend SIM claimed area + verify history
    When Staff clicks on "SIM" Link in Navbar
    And Staff opens the SIM parcel "G22814025" side drawer
    And Staff enters value "6" in the "amendedClaimedArea" SIM side drawer field
    And Staff clicks the "Save changes" button
    Then Staff clicks on "Notes/History" Link in Navbar
    And Staff switches to the "History" tab
    Then Staff verifies the History tab shows activity

    # SECTION 4 : Toggle SIM indicator + verify history
    When Staff clicks on "SIM" Link in Navbar
    And Staff opens the SIM parcel "G22813057" side drawer
    And Staff clicks the "simIndicator" checkbox in the SIM parcel edit drawer
    And Staff clicks the "Save changes" button
    Then Staff clicks on "Notes/History" Link in Navbar
    And Staff switches to the "History" tab
    Then Staff verifies the History tab shows activity

    # SECTION 5 : Submit SIM + verify history
    When Staff clicks on "SIM" Link in Navbar
    And Staff clicks the "Submit" button
    And Staff enters SIM notes as "Test 7678"
    And Staff clicks the "Finish" button
    And Staff toggles the SIM option
    Then Staff clicks on "Notes/History" Link in Navbar
    And Staff switches to the "History" tab
    Then Staff verifies the History tab shows activity

    # SECTION 6 : Revert SIM to original state - post-test reset
    When Staff clicks on "SIM" Link in Navbar
    And Staff toggles the SIM option
    Then Staff clicks on "Notes/History" Link in Navbar
    And Staff switches to the "History" tab
    Then Staff verifies the History tab shows activity
    When Staff clicks on "SIM" Link in Navbar
    And Staff clicks the "Revert" button
    And Staff opens the SIM parcel "G22813057" side drawer
    And Staff clicks the "simIndicator" checkbox in the SIM parcel edit drawer
    And Staff clicks the "Save changes" button
    And Staff clicks the "Submit" button
    And Staff enters SIM notes as "Set for Test 7678"
    Then Staff clicks the "Finish" button