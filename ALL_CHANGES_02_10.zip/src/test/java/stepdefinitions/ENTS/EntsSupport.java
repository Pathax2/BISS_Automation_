// ===================================================================================================================================
// File          : EntsSupport.java
// Package       : stepdefinitions.ENTS
// Description   : Small shared helpers for the ENTS step definitions TC_11 to TC_15 (Playwright edition).
//                 Kept apart from EntsSession so EntsSession (already reviewed and run with TC_01_ENTS) stays unchanged.
//
//                   requireKeys(step, keys...)     - fails the step BEFORE any click when an Object Repository key is
//                                                    missing, and names every missing key in one message
//                   openBissApplication()          - portal home -> BISS application (search bar + BISS link)
//                   openMyClientsTab(tab)          - BISS -> My Clients -> the named tab (opens BISS first when needed)
//                   loginSkippingExpired(user, p)  - EntsSession.loginAs, but an expired SSO account is recorded in
//                                                    Hooks.EXPIRED_AGENTS and reported as false instead of failing
//
//                 Not a step definition class - no Cucumber annotations.
//
//                 02-10-2026: loginSkippingExpired also marks the login EXPIRED in the Test Data Vault, so no later run
//                 hands out a herd of that agent again (same as Hooks.markAgentExpired).
//
// Author        : Aniket Pathare | aniket.pathare@government.ie
// Date Created  : 22-09-2026 | Updated: 02-10-2026 (vault)
// ===================================================================================================================================

package stepdefinitions.ENTS;

import stepdefinitions.Hooks;
import utilities.ObjReader;
import utilities.TestDataVault;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import static commonFunctions.CommonFunctions.iAction;

final class EntsSupport
{
    private static final Logger log = Logger.getLogger(EntsSupport.class.getName());

    private EntsSupport() { }


    // ***************************************************************************************************************************************************************************************
    // Function Name : requireKeys
    // Description   : Checks that every Object Repository key a step needs is present BEFORE the step clicks anything.
    //                 Without it, a step would get half way (for example a transfer created but not sent) and then stop
    //                 on the first missing key. The message lists every missing key so they can all be added at once.
    // Parameters    : pStep (String) - step text, for the message | pKeys (String...) - Object Repository keys
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 22-09-2026
    // ***************************************************************************************************************************************************************************************
    static void requireKeys(String pStep, String... pKeys)
    {
        List<String> iMissing = new ArrayList<>();
        for (String iKey : pKeys)
        {
            if (!ObjReader.containsKey(iKey)) iMissing.add(iKey);
        }

        if (!iMissing.isEmpty())
        {
            throw new IllegalStateException("[OR] Step '" + pStep + "' needs these Object Repository keys, which are not in "
                    + "ObjectRepository.properties: " + String.join(", ", iMissing)
                    + ". Copy them from the Selenium repository before running this test case.");
        }
    }


    // ***************************************************************************************************************************************************************************************
    // Function Name : openBissApplication
    // Description   : From the portal home after a login: search box -> "Basic Income Support for Sustainability" -> BISS link.
    //                 Same clicks as the Selenium re-login blocks in TC_11_ENTS and TC_13_ENTS.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 22-09-2026
    // ***************************************************************************************************************************************************************************************
    static void openBissApplication()
    {
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iAppSearchBar"), null);
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iAppSearchBar"), "Basic Income Support for Sustainability");
        iAction("CLICK",   "XPATH", ObjReader.getLocator("iBissLink"), null);
    }


    // ***************************************************************************************************************************************************************************************
    // Function Name : openMyClientsTab
    // Description   : BISS -> My Clients -> the named tab (e.g. "NR/CISYF").
    //                 When the My Clients menu link is not on screen (the session is still on the portal home after a
    //                 login), the BISS application is opened first.
    //                 Change from Selenium: the Selenium herd-recovery loops in TC_13_ENTS opened BISS in one loop and not
    //                 in the other two; both now go through this helper.
    // Parameters    : pTabName (String) - tab label, e.g. "NR/CISYF" or "Transfers"
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 22-09-2026
    // ***************************************************************************************************************************************************************************************
    static void openMyClientsTab(String pTabName)
    {
        if (!EntsSession.isVisible(ObjReader.getLocator("iCLientLeftMenuLink"), EntsSession.PROBE_SECONDS))
        {
            log.info("[NAV] My Clients link not on screen - opening the BISS application first.");
            openBissApplication();
        }

        String iTab = ObjReader.getLocator("iMyClientsTabByName").replace("%s", pTabName);
        iAction("CLICK",       "XPATH", ObjReader.getLocator("iCLientLeftMenuLink"), null);
        iAction("WAITVISIBLE", "XPATH", iTab, null);
        iAction("CLICK",       "XPATH", iTab, null);
        log.info("[NAV] My Clients -> " + pTabName + " tab opened.");
    }


    // ***************************************************************************************************************************************************************************************
    // Function Name : loginSkippingExpired
    // Description   : Logs in with EntsSession.loginAs. When the SSO account has expired, the user is added to
    //                 Hooks.EXPIRED_AGENTS (and marked EXPIRED in the Test Data Vault) and false is returned, so a
    //                 herd-recovery loop can try the next candidate.
    //                 Change from Selenium: the Selenium performLogin called Hooks.markAgentExpired(), which also replaced
    //                 Hooks.RUNTIME_HERD with a herd from a different query (not a CISYF herd). Only the expired list is
    //                 updated here; the recovery loop picks the next CISYF herd itself.
    // Parameters    : pUsername (String) - login | pLogPrefix (String) - log prefix
    // Returns       : boolean - true = logged in, false = account expired
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 22-09-2026 | Updated: 02-10-2026 (vault)
    // ***************************************************************************************************************************************************************************************
    static boolean loginSkippingExpired(String pUsername, String pLogPrefix)
    {
        try
        {
            EntsSession.loginAs(pUsername, pLogPrefix);
            return true;
        }
        catch (IllegalStateException iExpired)
        {
            String iMessage = iExpired.getMessage() == null ? "" : iExpired.getMessage();
            if (!iMessage.contains("expired")) throw iExpired;

            Hooks.EXPIRED_AGENTS.add(pUsername.trim());
            if (TestDataVault.isEnabled())
            {
                try { TestDataVault.markLoginExpired(pUsername.trim(), "Account Expired at login (" + pLogPrefix + ")"); }
                catch (Exception iVault) { log.warning(pLogPrefix + " Vault update failed: " + iVault.getMessage()); }
            }
            log.warning(pLogPrefix + " " + pUsername + " has an expired SSO account - added to EXPIRED_AGENTS.");
            return false;
        }
    }
}
