package com.pages;

//import com.DB.storedprocedures.*;
import com.base.ActionClass;
//import com.base.IDataReader;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;
import static org.openqa.selenium.support.locators.RelativeLocator.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ApplicationPortalPage {


    WebDriver driver;
    ActionClass actions;
    Actions action;
    DatabaseQueriesPage databaseQueriesPage;

    public ApplicationPortalPage(WebDriver driver) {
        this.driver = driver;
        actions = new ActionClass(driver);
        databaseQueriesPage = new DatabaseQueriesPage(driver);
        action = new Actions(driver);
    }

    // region BPS Code

    // region ClientHome and Applicant Details Methods
    By NewApplicationClientRadioButton = By.id("optionsRadios7");
    By GLASApplicationClientRadioButton = By.id("optionsRadios8");
    By ViewClientWithHerdButton = By.id("agentCommonListViewButton");
    By PaginationButton = By.xpath("//body/div[3]/span[1]/div[1]/div[1]/div[1]/div[1]/div[2]/form[2]/input[7]");
    By StartNewApplicationButton = By.id("applicationsPortletNewApplicationLink");
    By ApplicantDetailsEmail = By.id("emailToChangeDetailsLink");
    By OrganicFarmingcheckBox = By.id("isOrganicCheckbox");
    By ActiveFarmerOptionsPanel = By.xpath("//body[1]/div[3]/span[1]/div[1]/form[1]/div[2]/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[4]/div[1]");
    By ActiveFarmerRealEstateOption = By.id("isNegRealEstate");
    By ActiveFarmerWaterworksOption = By.id("isNegWaterwork");
    By AgentClickOnIHaveLandChanges = By.id("singlePageSubmitApplication_N");
    By AgentClickOnIDoNotHaveLandChanges = By.id("singlePageSubmitApplication_N");
    By AgentDeleteApplicationDraft = By.id("deleteDraft");
    By ConfirmDeletingDraft = By.xpath("//body[1]/div[6]/div[3]/div[1]/button[1]");
    By ResumeApplciationButton = By.id("applicationsPortletResumeApplicationLink");
    By ApplicantDetailsNextButton = By.id("buttonNext");
    By LandDetailsNextButton = By.id("buttonNextToGreening");
    By ANCcheckbox = By.id("isANCCheckbox");
    By ANCCheckBoxText2022 = By.xpath("//input[@id='isANCCheckbox']/parent::label");

    By pageDropdown = By.xpath("//mat-card-content/lib-biss-paginator/div/mat-paginator/div/div/div[1]/mat-form-field");
    By lastPage =   By.xpath("//mat-option[5]");


    // Editing a Parcel Locators
    By ParcelOrganicStatus = By.id("organicStatus6");

    // Locators for future use
    By StartNewAmendmentButton = By.id("applicationsPortletNewAmendmentLink");


    // Clicking on the Pagination Button
    public void AgentClickOnPaginationButton() {
        actions.waitForVisibilityOfElement(PaginationButton, 10);
        actions.click(PaginationButton);
    }

    // Clicking on the View Client Button
    public void AgentClickOnViewClientButton() {
        actions.waitForVisibilityOfElement(ViewClientWithHerdButton, 10);
        actions.click(ViewClientWithHerdButton);
    }

    // Click on the Client Radio Button
    public void AgentClickOnNewApplicationClientRadioButton() {
        actions.waitForVisibilityOfElement(NewApplicationClientRadioButton, 10);
        actions.click(NewApplicationClientRadioButton);
    }

    // Click on GLAS Client Radio Button
    public void AgentclickOnGLASApplicationClientRadiobutton() {
        actions.waitForVisibilityOfElement(GLASApplicationClientRadioButton,15);
        actions.click(GLASApplicationClientRadioButton);
    }

    // Clicking on the Start New Amendment Button
    public void AgentClickOnStartAmendmentButton() {
        actions.waitForVisibilityOfElement(StartNewAmendmentButton, 10);
        actions.click(StartNewAmendmentButton);
    }

    // Clicking on the Start Application Button
    public void AgentClickOnStartApplicationButton() {
        actions.waitForVisibilityOfElement(StartNewApplicationButton, 10);
        actions.click(StartNewApplicationButton);
    }

    // Clicking on the Applicant Details Email Button
    public void AgentClickOnApplicantDetailsEmail() {
        actions.waitForVisibilityOfElement(ApplicantDetailsEmail, 10);
        actions.click(ApplicantDetailsEmail);
    }

    // Clicking on the Organic Farming Checkbox
    public void AgentClickOnOrganicFarmingCheckbox() {
        actions.waitForVisibilityOfElement(OrganicFarmingcheckBox, 10);
        actions.click(OrganicFarmingcheckBox);
    }

    // Clicking on the ANC Checkbox
    public void AgentClickOnANCCheckbox() {
        actions.waitForVisibilityOfElement(ANCcheckbox, 10);
        actions.click(ANCcheckbox);
    }

    // Checking ANC CheckBox Text
    public Boolean AgentCheckANCCheckBoxText() {
        actions.waitForVisibilityOfElement(ANCcheckbox,30);
        String ANCCheckBoxText = driver.findElement(ANCCheckBoxText2022).getText();
        Boolean ANCcheckFor2022 = ANCCheckBoxText.contains("2022");
        return ANCcheckFor2022;
    }

    // Visibility of Active Farmer Section
    public Boolean VisibilityOfActiverFarmerSection() {
        actions.waitForVisibilityOfElement(ActiveFarmerOptionsPanel, 10);
        Boolean ActiveFarmerSectionVisibility = driver.findElement(ActiveFarmerOptionsPanel).isDisplayed();
        return ActiveFarmerSectionVisibility;
    }

    // Clicking on the Real Estate Checkbox
    public void AgentClickOnRealEstateCheckbox() {
        actions.waitForVisibilityOfElement(ActiveFarmerRealEstateOption, 10);
        actions.click(ActiveFarmerRealEstateOption);
    }

    // Clicking on the Waterworks Checkbox
    public void AgentClickOnWaterworksCheckbox() {
        actions.waitForVisibilityOfElement(ActiveFarmerWaterworksOption, 10);
        actions.click(ActiveFarmerWaterworksOption);
    }

    // Click on I have Land Changes
    public void AgentClickOnIhaveLandChanges() {
        if(driver.findElements(AgentClickOnIHaveLandChanges).isEmpty() == false) {
            actions.click(AgentClickOnIHaveLandChanges);
        }
        else {
            AgentClickOnApplicantDetailsNextButton();
        }
    }


    // Delete a Draft Application
    public void DeleteDraftApplication() throws InterruptedException {
        if(driver.findElements(AgentDeleteApplicationDraft).isEmpty()==false) {
            actions.waitForVisibilityOfElement(AgentDeleteApplicationDraft, 15);
            actions.click(AgentDeleteApplicationDraft);
            Thread.sleep(2000);
            actions.click(ConfirmDeletingDraft);
        }
        else {
            System.out.println("No Draft Application Present");
        }
    }

    // Clicking on the Resume Application Button
    public void AgentClickOnResumeApplicationButton() {
        actions.waitForVisibilityOfElement(ResumeApplciationButton, 10);
        actions.click(ResumeApplciationButton);
    }

    // Clicking on the Applicant Details Next Button
    public void AgentClickOnApplicantDetailsNextButton() {
        actions.waitForVisibilityOfElement(ApplicantDetailsNextButton, 10);
        actions.click(ApplicantDetailsNextButton);
    }

    // Clicking on the Land Details Next Button
    public void AgentClickOnLandDetailsNextButton() {
        actions.waitForVisibilityOfElement(LandDetailsNextButton, 10);
        actions.click(LandDetailsNextButton);
    }
    // endregion

    //region Land Details Page Add Parcel Methods
    // Add Parcel
    By AgentAddParcel = By.id("landDetailsAddParcelButton");
    By AgentLandDetailsParcelSearchTextBox = By.name("landDetailsSerachParcelId");
    By AgentLandDetailsParcelSearchClaimButton = By.id("landDetailsParcelSearchSubmitButton");
    By LandDetailsParcelNotFoundMessage = By.id("landDetailsAddParcelSearchErrorMessage");
    By LandDetailsArchivedParcelMessage = By.id("currentIterationOfArchivedParcel");
    By LandDetailsClaimedParcelMessage = By.id("landDetailsAddParcelSearchErrorMessage");
    By ParcelSearchDialogNextButton = By.id("addParcelModalParcelShowAddMapDetailsBtnNext");
    By ParcelSearchDialogClaimedAreaField = By.id("addParcelModalAddParcelClaimedArea");
    By ParcelSearchDialogOwnershipStatusDropdown = By.id("addParcelModalAddParcelRentedInLand");
    By ParcelSearchDialogParcelUseDropdown = By.id("addparcelcropuse");
    By ParcelCommonageFractionNumerator = By.id("addParcelModalCommonageNumerator");
    By ParcelCommonageFractionDenominator = By.id("addParcelModalCommonageDenominator");
    By ChangeOfMEACheckbox = By.id("changeRefCheck6");
    By ChangeOfMEACheckBoxes = By.className("landDetailsChangeMea");
    By ChangeOfMEATextBox = By.id("changeRefAreaNoteTextArea8");
    By ChangeOfMEAErrorMessage = By.xpath("//body[1]/div[4]/span[1]/div[1]/div[3]/div[1]/div[1]/div[2]/form[1]/div[2]/div[1]/div[3]/div[1]/table[1]/tbody[7]/tr[2]/td[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/label[1]");
    By ParcelDeleteButton = By.id("deleteParcelBtn6");
    By ParcelUndoDeleteButton = By.id("undoDeleteBtn6");
    By LeaseExpiryDate = By.xpath("//body[1]/div[4]/span[1]/div[1]/div[3]/div[1]/div[1]/div[2]/form[1]/div[2]/div[1]/div[3]/div[1]/table[1]/tbody[3]/tr[2]/td[3]/div[1]/div[1]/div[1]/div[1]/div[1]/input[1]");
    By NoParcelorPlotInOrganicPageText = By.xpath("//body[1]/div[3]/span[1]/div[1]/div[2]/div[1]/div[1]/div[1]/form[1]/div[1]/p[1]");
    By AddParcelSelectCountyForMap = By.id("landDetailsSearchParcelFormMapCounty");
    By AddParcelSelectTownlandForMap = By.id("landDetailsSearchParcelFormMapTownland");
    By AddParcelDialogOpenMapButton = By.id("landDetailsSearchParcelOpenMap");
    By FeaturePublishedParcel = By.xpath("//td[contains(text(),'901002893')]");



    // Click on Published Parcel in Feature Box
    public void AgentClickOnPublishedParcel() {
        actions.waitForVisibilityOfElement(FeaturePublishedParcel,20);
        actions.clickUsingJS(FeaturePublishedParcel);
    }



    // Clicking on the Applicant Add Parcel Button
    public void AgentClickOnApplicantAddParcelButton() {
        actions.waitForVisibilityOfElement(AgentAddParcel, 15);
        actions.click(AgentAddParcel);
    }

    // Entering Land Details Parcel Number
    public void AgentEnterLandDetailsParcelNumber(String Arg0) {
        actions.waitForVisibilityOfElement(AgentLandDetailsParcelSearchTextBox, 30);
        actions.sendKeys(AgentLandDetailsParcelSearchTextBox, String.valueOf(Arg0));
    }

    // Select Add Parcel County For Map
    public void AgentSelectCountyForMap(String Arg0) {
        WebElement CountyForMap = driver.findElement(AddParcelSelectCountyForMap);
        actions.waitForVisibilityOfElement(AddParcelSelectCountyForMap, 30);
        Select dropdown = new Select(CountyForMap);
        dropdown.selectByVisibleText(Arg0);
    }

    // Select Add Parcel Townland For Map
    public void AgentSelectTownlandForMap(String Arg0) {
        WebElement TownlandForMap = driver.findElement(AddParcelSelectTownlandForMap);
        actions.waitForVisibilityOfElement(AddParcelSelectTownlandForMap, 30);
        Select dropdown = new Select(TownlandForMap);
        dropdown.selectByVisibleText(Arg0);
    }

    // Clicking on the Parcel Search Open Map Button
    public void AgentClickOnParcelSearchOpenMapButton() {
        actions.waitForVisibilityOfElement(AddParcelDialogOpenMapButton, 10);
        actions.click(AddParcelDialogOpenMapButton);
        actions.waitforSeconds(10);
    }

    // Clicking on the Parcel Search Claim Button
    public void AgentClickOnParcelSearchClaimButton() {
        actions.waitForVisibilityOfElement(AgentLandDetailsParcelSearchClaimButton, 10);
        actions.click(AgentLandDetailsParcelSearchClaimButton);
    }

    // Visibility of Parcel Not Found Message
    public String VisibilityOfParcelNotFoundMessage() {
        actions.waitForVisibilityOfElement(LandDetailsParcelNotFoundMessage, 10);
        //Boolean ParcelNotFoundMessageVisibility = driver.findElement(LandDetailsParcelNotFoundMessage).isDisplayed();
        String ParcelNotFoundMessage = driver.findElement(LandDetailsParcelNotFoundMessage).getText();
        return ParcelNotFoundMessage;
    }

    // Visibility of Parcel Archived Message
    public String VisibilityOfParcelArchivedMessage() {
        actions.waitForVisibilityOfElement(LandDetailsArchivedParcelMessage, 10);
        //Boolean ParcelNotFoundMessageVisibility = driver.findElement(LandDetailsParcelNotFoundMessage).isDisplayed();
        String ParcelArchivedMessage = driver.findElement(LandDetailsArchivedParcelMessage).getText();
        return ParcelArchivedMessage;
    }

    // Visibility of Parcel Claimed Message
    public String VisibilityOfParcelClaimedMessage() {
        actions.waitForVisibilityOfElement(LandDetailsClaimedParcelMessage, 10);
        //Boolean ParcelNotFoundMessageVisibility = driver.findElement(LandDetailsParcelNotFoundMessage).isDisplayed();
        String ParcelClaimedMessage = driver.findElement(LandDetailsClaimedParcelMessage).getText();
        return ParcelClaimedMessage;
    }

    // Visibility of Parcel Search Dialog Next Button
    public Boolean VisibilityOfParcelSearchDialogNextButton() {
        return driver.findElement(ParcelSearchDialogNextButton).isEnabled();

    }

    // Entering Claimed Area in Parcel Search Dialog Box
    public void AgentEnterClaimedAreaInParcelSearchDialog(String Arg0) {
        actions.waitForVisibilityOfElement(ParcelSearchDialogClaimedAreaField, 30);
        actions.sendKeys(ParcelSearchDialogClaimedAreaField, String.valueOf(Arg0));
    }

    // Selecting Ownership Status
    public void AgentSelectOwnershipStatus(String Arg0) {
        WebElement OwnershipStatus = driver.findElement(ParcelSearchDialogOwnershipStatusDropdown);
        actions.waitForVisibilityOfElement(ParcelSearchDialogOwnershipStatusDropdown, 30);
        Select dropdown = new Select(OwnershipStatus);
        dropdown.selectByVisibleText(Arg0);
    }

    // Selecting Parcel Use
    public void AgentSelectParcelUse(String Arg0) {
        WebElement ParcelUse = driver.findElement(ParcelSearchDialogParcelUseDropdown);
        actions.waitForVisibilityOfElement(ParcelSearchDialogParcelUseDropdown, 30);
        Select dropdown = new Select(ParcelUse);
        dropdown.selectByVisibleText(Arg0);
    }

    // Enter Parcel Commonage Factor Numerator value
    public void AgentEnterParcelCommonageFractionNumeratorValue() {
        actions.waitForVisibilityOfElement(ParcelCommonageFractionNumerator,15);
        actions.sendKeys(ParcelCommonageFractionNumerator,"4");
    }

    // Enter Parcel Commonage Factor Denominator value
    public void AgentEnterParcelCommonageFractionDenominatorValue() {
        actions.waitForVisibilityOfElement(ParcelCommonageFractionDenominator,15);
        actions.sendKeys(ParcelCommonageFractionDenominator,"6");
    }

    // Clicking on the Parcel Search Dialog Next Button
    public void AgentClickOnParcelSearchDialogNextButton() {
        actions.waitForVisibilityOfElement(ParcelSearchDialogNextButton, 10);
        actions.click(ParcelSearchDialogNextButton);
    }

    // Change the Organic Status of the map parcel
    public void AgentSelectMapParcel2OrganicStatus(String Arg0) {
        if ((driver.findElements(LandDetailsSecondPage)).isEmpty() == true) {
            WebElement MapParcel2Reference = driver.findElement(By.xpath("//div[contains(text(),'B1600100002')]"));
            WebElement MapParcel2OrganicStatusDropdown = driver.findElement(with(By.className("landDetailsOrganicStatus"))
                    .toRightOf(MapParcel2Reference));
            Select dropdown = new Select(MapParcel2OrganicStatusDropdown);
            dropdown.selectByVisibleText(Arg0);
        } else {
            WebElement MapParcel2Reference = driver.findElement(By.xpath("//div[contains(text(),'B1600100002')]"));
            WebElement MapParcel2OrganicStatusDropdown = driver.findElement(with(By.className("landDetailsOrganicStatus"))
                    .toRightOf(MapParcel2Reference));
            Select dropdown = new Select(MapParcel2OrganicStatusDropdown);
            dropdown.selectByVisibleText(Arg0);
        }
    }

    // Selecting Parcel Organic Status
    public void AgentSelectParcelOrganicStatus(String Arg0) {
        if((driver.findElements(LandDetailsSecondPage)).isEmpty()==true) {
            WebElement FirstCreatedParcel = driver.findElement(By.xpath("//div[contains(text(),'L1350400015')]"));
            WebElement OrganicStatus = driver.findElement(with(By.className("landDetailsOrganicStatus"))
                    .toRightOf(FirstCreatedParcel));
            Select dropdown = new Select(OrganicStatus);
            dropdown.selectByVisibleText(Arg0);

        }
        else {
            if (driver.findElements(By.xpath("//div[contains(text(),'L1350400015')]")).isEmpty() == false) {
                WebElement ParcelID = driver.findElement(By.xpath("//div[contains(text(),'L1350400015')]"));
                WebElement OrganicStatus = driver.findElement(with(By.tagName("select"))
                        .toRightOf(ParcelID));
                Select dropdown = new Select(OrganicStatus);
                dropdown.selectByVisibleText(Arg0);
            }
            else {
                actions.waitForVisibilityOfElement(LandDetailsSecondPage,15);
                actions.clickUsingJS(LandDetailsSecondPage);
                WebElement ParcelID = driver.findElement(By.xpath("//div[contains(text(),'L1350400015')]"));
                WebElement OrganicStatus = driver.findElement(with(By.className("landDetailsOrganicStatus"))
                        .toRightOf(ParcelID));
                Select dropdown = new Select(OrganicStatus);
                dropdown.selectByVisibleText(Arg0);
            }
        }
    }

    // Selecting Map Parcel Organic Status
    public void AgentSelectMapParcelOrganicStatus(String Arg0) {
        if((driver.findElements(LandDetailsSecondPage)).isEmpty()==true) {
            WebElement MapParcel = driver.findElement(By.xpath("//div[contains(text(),'B1600100002')]"));
            WebElement OrganicStatus = driver.findElement(with(By.className("landDetailsOrganicStatus"))
                    .toRightOf(MapParcel));
            Select dropdown = new Select(OrganicStatus);
            dropdown.selectByVisibleText(Arg0);
        }
        else {
            if (driver.findElements(By.xpath("//div[contains(text(),'L1350400015')]")).isEmpty() == false) {
                WebElement MapParcel = driver.findElement(By.xpath("//div[contains(text(),'B1600100002')]"));
                WebElement OrganicStatus = driver.findElement(with(By.tagName("select"))
                        .toRightOf(MapParcel));
                Select dropdown = new Select(OrganicStatus);
                dropdown.selectByVisibleText(Arg0);
            }
            else {
                actions.waitForVisibilityOfElement(LandDetailsSecondPage,15);
                actions.clickUsingJS(LandDetailsSecondPage);
                WebElement MapParcel = driver.findElement(By.xpath("//div[contains(text(),'B1600100002')]"));
                WebElement OrganicStatus = driver.findElement(with(By.className("landDetailsOrganicStatus"))
                        .toRightOf(MapParcel));
                Select dropdown = new Select(OrganicStatus);
                dropdown.selectByVisibleText(Arg0);
            }
        }
    }


    // Change Organic Status of the already present parcels
    public void ChangeOrganicStatusOfAlreadyPresentParcels(String Arg0) throws InterruptedException {
        int NumberOfParcelsInFirstPage = driver.findElements(landDetailsRows).size();
        System.out.println(NumberOfParcelsInFirstPage);
        if (NumberOfParcelsInFirstPage == 0) {
            System.out.println("Client has no parcels");
        }
        else
        {
            for (int i = NumberOfParcelsInFirstPage-1 ; i>=0 ; i--) {
                WebElement OrganicStatusDropdown = driver.findElement(By.id("organicStatus" + i));
                Select dropdown = new Select(OrganicStatusDropdown);
                dropdown.selectByVisibleText(Arg0);
                Thread.sleep(500);
            }
        }
        if((driver.findElements(By.xpath("//a[@class='ng-binding' and text()='2']")).isEmpty()) == false) {
            actions.clickUsingJS(LandDetailsSecondPage);
            int NumberOfParcelsInSecondPage = NumberOfParcelsInFirstPage + (driver.findElements(landDetailsRows).size());
            for (int i = NumberOfParcelsInSecondPage - 1 ; i>=NumberOfParcelsInFirstPage ; i--) {
                WebElement OrganicStatusDropdown = driver.findElement(By.id("organicStatus" + i));
                Select dropdown = new Select(OrganicStatusDropdown);
                dropdown.selectByVisibleText(Arg0);
                Thread.sleep(500);
            }
        }
        else {
            System.out.println("No second page on Land Details Tab");
        }
    }

    // Visibility of Change of MEA Checkbox
    public Boolean VisibilityOfChangeOfMEACheckbox() {
        Boolean ChangeOfMEACheckboxVisibility = driver.findElement(ChangeOfMEACheckbox).isDisplayed();
        return ChangeOfMEACheckboxVisibility;
    }

    // Finding ChangeOfMEA CheckBox
    public void FindChangeOfMEACheckBoxAndClick() {
        WebElement Plot1MEA = driver.findElement(By.className("landDetailsMea"));
        WebElement Plot1DigitisedArea = driver.findElement(By.className("landDetailsDigitisedArea"));
        WebElement Plot1CommonageFraction = driver.findElement(By.xpath("//td[contains(@id,'comNum')]"));
        WebElement Plot1OrganicStatus = driver.findElement(By.className("landDetailsOrganicStatus"));
        WebElement Plot1ID = driver.findElement(By.xpath("//div[contains(text(),'L1350400015')]"));
        WebElement MEACheckbox = driver.findElement(with(By.className("landDetailsChangeMea"))
                .toRightOf(Plot1MEA)
                .toRightOf(Plot1DigitisedArea)
                .toRightOf(Plot1CommonageFraction)
                .toRightOf(Plot1OrganicStatus)
                .toRightOf(Plot1ID));
        MEACheckbox.click();
    }

    // Click On Change of MEA Checkbox
    public void AgentClickOnChangeOfMEACheckBox() {
        if((driver.findElements(LandDetailsSecondPage)).isEmpty()==true) {
            FindChangeOfMEACheckBoxAndClick();
        }
        else {
            if (driver.findElements(By.xpath("//div[contains(text(),'L1350400015')]")).isEmpty() == false) {
                FindChangeOfMEACheckBoxAndClick();
            }
            else {
                actions.waitForVisibilityOfElement(LandDetailsSecondPage,15);
                actions.clickUsingJS(LandDetailsSecondPage);
                FindChangeOfMEACheckBoxAndClick();
            }
        }
    }

    // Finding Change Of MEA Note TextBox and Enter Note
    public void FindChangeOfMEATextBoxAndEnterNote(String Arg0) {
        WebElement Plot1ID = driver.findElement(By.xpath("//div[contains(text(),'L1350400015')]"));
        WebElement MEANoteTextBox  = driver.findElement(with(By.className("landDetailsChangeMeaNoteArea"))
                .below(Plot1ID));
        MEANoteTextBox.sendKeys(Arg0);
    }

    // Entering Note in MEA Text Box
    public void AgentEnterNoteInMEATextBox(String Arg0) throws InterruptedException {
        if((driver.findElements(LandDetailsSecondPage)).isEmpty()==true) {
            FindChangeOfMEATextBoxAndEnterNote(Arg0);
        }
        else {
            if (driver.findElements(By.xpath("//div[contains(text(),'L1350400015')]")).isEmpty() == false) {
                FindChangeOfMEATextBoxAndEnterNote(Arg0);
            }
            else {
                actions.waitForVisibilityOfElement(LandDetailsSecondPage,15);
                actions.clickUsingJS(LandDetailsSecondPage);
                FindChangeOfMEATextBoxAndEnterNote(Arg0);
            }
        }
    }


    // Finding ChangeOfMEA CheckBox
    public String FindChangeOfMEAMessage() {
        WebElement ChangeOfMEAMessageNote = driver.findElement(By.className("landDetailsChangeMeaNoteArea"));
        WebElement Plot1ID = driver.findElement(By.xpath("//div[contains(text(),'L1350400015')]"));
        String MEAErrorMessage  = driver.findElement(with(By.xpath("//label[contains(text(),'Please describe reason for requesting change of MEA')]"))
                .below(ChangeOfMEAMessageNote)
                .below(Plot1ID)).getText();
        return MEAErrorMessage;
    }

    // Visibility of Change Of MEA Message
    public void VisibilityOfChangeOfMEAMessage() {
        if((driver.findElements(LandDetailsSecondPage)).isEmpty()==true) {
            FindChangeOfMEAMessage();
        }
        else {
            if (driver.findElements(By.xpath("//div[contains(text(),'L1350400015')]")).isEmpty() == false) {
                FindChangeOfMEAMessage();
            }
            else {
                actions.waitForVisibilityOfElement(LandDetailsSecondPage,15);
                actions.clickUsingJS(LandDetailsSecondPage);
                FindChangeOfMEAMessage();
            }
        }
    }

    // Visibility of Lease Expiry Date
    public String VisibilityOfLeaseExpiryDate() {
        actions.waitForVisibilityOfElement(LeaseExpiryDate, 10);
        String LeaseExpiryDateText = driver.findElement(LeaseExpiryDate).getText();
        return LeaseExpiryDateText;
    }

    // Visibility of No Parcels or Plots Message
    public String VisibilityOfNoParcelsOrPlotsMessage() {
        actions.waitForVisibilityOfElement(NoParcelorPlotInOrganicPageText, 10);
        String NoParcelsOrPlotsText = driver.findElement(NoParcelorPlotInOrganicPageText).getText();
        //System.out.println(NoParcelsOrPlotsText);
        return NoParcelsOrPlotsText;
    }

    // Find Parcel Delete button and Click on it
    public void FindParcelDeleteButtonAndClick() {
        WebElement ParcelANCColumn = driver.findElement(By.cssSelector("[ng-if='ancApplication']"));
        WebElement ParcelUse = driver.findElement(By.className("landDetailsParcelUse"));
        WebElement ParcelOwnerShipStatus = driver.findElement(By.className("landDetailsOwnershipStatus"));
        WebElement ParcelClaimedArea = driver.findElement(By.className("landDetailsClaimedArea"));
        WebElement ParcelChangeOfMEA = driver.findElement(By.className("landDetailsChangeMea"));
        WebElement ParcelMEA = driver.findElement(By.className("landDetailsMea"));
        WebElement ParcelDigitisedArea = driver.findElement(By.className("landDetailsDigitisedArea"));
        WebElement ParcelCommonageFraction = driver.findElement(By.xpath("//td[contains(@id,'comNum')]"));
        WebElement ParcelOrganicStatus = driver.findElement(By.className("landDetailsOrganicStatus"));
        WebElement ParcelID = driver.findElement(By.xpath("//div[contains(text(),'L1350400015')]"));
        WebElement ParcelDeleteButton = driver.findElement(with(By.className("landDetailsDeleteParcelButton"))
                .toRightOf(ParcelANCColumn)
                .toRightOf(ParcelUse)
                .toRightOf(ParcelOwnerShipStatus)
                .toRightOf(ParcelClaimedArea)
                .toRightOf(ParcelChangeOfMEA)
                .toRightOf(ParcelMEA)
                .toRightOf(ParcelDigitisedArea)
                .toRightOf(ParcelCommonageFraction)
                .toRightOf(ParcelOrganicStatus)
                .toRightOf(ParcelID));
        ParcelDeleteButton.click();
    }


    // Agent Click on Delete Button for created parcel
    public void AgentClickOnParcelDeleteButton() {
        if((driver.findElements(LandDetailsSecondPage)).isEmpty()==true) {
            FindParcelDeleteButtonAndClick();
        }
        else {
            if (driver.findElements(By.xpath("//div[contains(text(),'L1350400015')]")).isEmpty() == false) {
                FindParcelDeleteButtonAndClick();
            }
            else {
                actions.waitForVisibilityOfElement(LandDetailsSecondPage,15);
                actions.clickUsingJS(LandDetailsSecondPage);
                FindParcelDeleteButtonAndClick();
            }
        }
    }

    // Find Parcel Undo Delete button and Click on it
    public void FindParcelUndoDeleteButtonAndClick() {
        WebElement ParcelANCColumn = driver.findElement(By.cssSelector("[ng-if='ancApplication']"));
        //WebElement ParcelGLASColumn = driver.findElement(By.cssSelector("[ng-if='glasApplication']"));
        WebElement ParcelUse = driver.findElement(By.className("landDetailsParcelUse"));
        WebElement ParcelOwnerShipStatus = driver.findElement(By.className("landDetailsOwnershipStatus"));
        WebElement ParcelClaimedArea = driver.findElement(By.className("landDetailsClaimedArea"));
        WebElement ParcelChangeOfMEA = driver.findElement(By.className("landDetailsChangeMea"));
        WebElement ParcelMEA = driver.findElement(By.className("landDetailsMea"));
        WebElement ParcelDigitisedArea = driver.findElement(By.className("landDetailsDigitisedArea"));
        WebElement ParcelCommonageFraction = driver.findElement(By.xpath("//td[contains(@id,'comNum')]"));
        WebElement ParcelOrganicStatus = driver.findElement(By.className("landDetailsOrganicStatus"));
        WebElement ParcelID = driver.findElement(By.xpath("//div[contains(text(),'L1350400015')]"));
        WebElement ParcelDeleteButton = driver.findElement(with(By.className("landDetailsUndoDeleteParcelButton"))
                .toRightOf(ParcelANCColumn)
                //.toRightOf(ParcelGLASColumn)
                .toRightOf(ParcelUse)
                .toRightOf(ParcelOwnerShipStatus)
                .toRightOf(ParcelClaimedArea)
                .toRightOf(ParcelChangeOfMEA)
                .toRightOf(ParcelMEA)
                .toRightOf(ParcelDigitisedArea)
                .toRightOf(ParcelCommonageFraction)
                .toRightOf(ParcelOrganicStatus)
                .toRightOf(ParcelID));
        ParcelDeleteButton.click();
    }

    // Agent Click on Undo Delete Button for created parcel
    public void AgentClickOnParcelUndoDeleteButton() {
        if((driver.findElements(LandDetailsSecondPage)).isEmpty()==true) {
            FindParcelUndoDeleteButtonAndClick();
        }
        else {
            if (driver.findElements(By.xpath("//div[contains(text(),'L1350400015')]")).isEmpty() == false) {
                FindParcelUndoDeleteButtonAndClick();
            }
            else {
                actions.waitForVisibilityOfElement(LandDetailsSecondPage,15);
                actions.clickUsingJS(LandDetailsSecondPage);
                FindParcelUndoDeleteButtonAndClick();
            }
        }
    }



    // Find Parcel Subdivide button and Click on it
    public void FindParcelSubDivideButtonAndClick(String Arg0) {
        WebElement ParcelANCColumn = driver.findElement(By.cssSelector("[ng-if='ancApplication']"));
        WebElement ParcelGLASColumn = driver.findElement(By.cssSelector("[ng-if='glasApplication']"));
        WebElement ParcelUse = driver.findElement(By.className("landDetailsParcelUse"));
        WebElement ParcelOwnerShipStatus = driver.findElement(By.className("landDetailsOwnershipStatus"));
        WebElement ParcelClaimedArea = driver.findElement(By.className("landDetailsClaimedArea"));
        WebElement ParcelChangeOfMEA = driver.findElement(By.className("landDetailsChangeMea"));
        WebElement ParcelMEA = driver.findElement(By.className("landDetailsMea"));
        WebElement ParcelDigitisedArea = driver.findElement(By.className("landDetailsDigitisedArea"));
        WebElement ParcelCommonageFraction = driver.findElement(By.xpath("//td[contains(@id,'comNum')]"));
        WebElement ParcelOrganicStatus = driver.findElement(By.className("landDetailsOrganicStatus"));
        //WebElement ParcelID = driver.findElement(By.xpath("//div[contains(text(),'L1350400015')]"));
        WebElement ParcelID = driver.findElement(By.xpath("//div[contains(text(),'"+Arg0+"')]"));
        WebElement ParcelDeleteButton = driver.findElement(By.className("landDetailsDeleteParcelButton"));
//        By ParcelSubdivideButtons  = By.cssSelector("button[class='landDetailsSubdivisionButton btn btn-default ng-scope']");
//                By.className("landDetailsSubdivisionButton btn btn-default ng-scope");
        WebElement ParcelSubdivideButton = driver.findElement(with(By.cssSelector("landDetailsSubdivisionButton.btn.btn-default.ng-scope"))
                .toRightOf(ParcelDeleteButton)
                .toRightOf(ParcelANCColumn)
                .toRightOf(ParcelGLASColumn)
                .toRightOf(ParcelUse)
                .toRightOf(ParcelOwnerShipStatus)
                .toRightOf(ParcelClaimedArea)
                .toRightOf(ParcelChangeOfMEA)
                .toRightOf(ParcelMEA)
                .toRightOf(ParcelDigitisedArea)
                .toRightOf(ParcelCommonageFraction)
                .toRightOf(ParcelOrganicStatus)
                .toRightOf(ParcelID));
        ParcelSubdivideButton.click();
    }

    By ParcelSubdivideButtons = By.id("addSubdivisionBtn1");

    // Agent Click on Subdivide Button for created parcel
    public void AgentClickOnParcelSubdivideButton(String Arg0) {
        if((driver.findElements(LandDetailsSecondPage)).isEmpty()==true) {
            //FindParcelDeleteButtonAndClick();
//            FindParcelSubDivideButtonAndClick(Arg0);
            actions.click(ParcelSubdivideButtons);
        }
        else {
            if (driver.findElements(By.xpath("//div[contains(text(),'"+Arg0+"')]")).isEmpty() == false) {
                //FindParcelDeleteButtonAndClick();
//                FindParcelSubDivideButtonAndClick(Arg0);
                actions.click(ParcelSubdivideButtons);
            }
            else {
                actions.waitForVisibilityOfElement(LandDetailsSecondPage,15);
                actions.clickUsingJS(LandDetailsSecondPage);
                //FindParcelDeleteButtonAndClick();
//                FindParcelSubDivideButtonAndClick(Arg0);
                actions.click(ParcelSubdivideButtons);
            }
        }
    }

    // endregion

    // region Land Details Page Add Plot Methods
    // Add Plot Dialog
    By AgentANCCheckBox = By.id("isANCCheckbox");
    By AgentAddPlot = By.id("landDetailsAddPlotButton");
    By AgentLandDetailsAddPlotSelectCounty = By.id("countyPlot");
    By AgentLandDetailsAddPlotSelectTownland = By.id("townlandPlot");
    By AgentLandDetailsAddPlotEnterPlotReference = By.id("plotRefPlot");
    By AgentLandDetailsAddPlotSelectOwnershipStatus = By.id("orlPlot");
    By AgentLandDetailsAddPlotEnterClaimedArea = By.id("claimedAreaPlot");
    By AgentLandDetailsAddPlotSelectPlotUse = By.id("plotUsePlot");
    By AgentLandDetailsAddPlotClickOnCommonagePlotCheckBox = By.id("addPlotModalAddCommonagePlotCheckbox");
    By AgentLandDetailsAddPlotIslandPlotCheckBox = By.id("IslandIndCheckbox");
    By Plot1OrganicStatus = By.id("organicStatus7");
    By Plot2OrganicStatus = By.id("organicStatus8");
    By AgentLandDetailsAddPlotClickOnSubmitMapByPostRadioBtn = By.id("optionsRadios3");
    By AgentLandDetailsAddPlotNextButton = By.id("addPlotCreatePlotBtn");
    By AgentLandDetailsAddPlotNextButtonToDrawMap = By.id("addPlotShowGisRedirect");
    By GISPageUsefulInfoDialogCloseButton = By.xpath("(//button[contains(@class,'ui-widget')]//child::span[contains(text(),'Close')])[2]");
    By AgentLandDetailsAddPlotClickOnUploadMapRadioBtn = By.id("optionsRadios2");
    By AgentLandDetailsAddPlotClickOnEditMapOnlineRadioBtn = By.id("optionsRadios1");
    By AgentAddedPlotOwnershipStatusDropdown = By.xpath("//body[1]/div[4]/span[1]/div[1]/div[3]/div[1]/div[1]/div[2]/form[1]/div[2]/div[1]/div[3]/div[1]/table[1]/tbody[9]/tr[1]/td[9]/div[1]/div[1]/div[1]/select[1]");
    By AgentAddedPlotCannotBeRentedErrorMessage = By.xpath("//body[1]/div[4]/span[1]/div[1]/div[3]/div[1]/div[1]/div[2]/form[1]/div[2]/div[1]/div[3]/div[1]/table[1]/tbody[9]/tr[1]/td[9]/div[1]/div[1]/div[1]/div[1]");
    By LandDetailsPageSaveButton = By.id("buttonSave");
    By LandDetailsANCLAbel = By.id("ancTitle");
    By LandDetailsGLASLabel = By.xpath("//body[1]/div[4]/span[1]/div[1]/div[3]/div[1]/div[1]/div[2]/form[1]/div[2]/div[1]/div[3]/div[1]/table[1]/thead[1]/tr[1]/th[10]");

    // Add Plot

    // Agent Click on ANC CheckBox
    public void AgentClickOnANCCheckBox() {
        actions.waitForVisibilityOfElement(AgentANCCheckBox, 10);
        actions.click(AgentANCCheckBox);
    }

    // Add Plot Button in Land Details Page
    public void AgentClickOnApplicantAddPlotButton() {
        actions.waitForVisibilityOfElement(AgentAddPlot, 10);
        actions.click(AgentAddPlot);
    }

    // Visibility of Island Plot CheckBox
    public Boolean VisibilityOfIslandPlotCheckBox() {
        actions.waitForVisibilityOfElement(AgentLandDetailsAddPlotIslandPlotCheckBox, 10);
        Boolean IslandPlotVisibility = driver.findElement(AgentLandDetailsAddPlotIslandPlotCheckBox).isDisplayed();
        return IslandPlotVisibility;
    }

    // Add Plot Selecting County
    public void AgentSelectAddPlotCounty(String Arg0) {
        WebElement AddPlotCounty = driver.findElement(AgentLandDetailsAddPlotSelectCounty);
        actions.waitForVisibilityOfElement(AgentLandDetailsAddPlotSelectCounty, 30);
        Select dropdown = new Select(AddPlotCounty);
        dropdown.selectByVisibleText(Arg0);
    }

    // Add Plot Selecting Townland
    public void AgentSelectAddPlotTownland(String Arg0) {
        WebElement AddPlotTownland = driver.findElement(AgentLandDetailsAddPlotSelectTownland);
        actions.waitForVisibilityOfElement(AgentLandDetailsAddPlotSelectTownland, 30);
        Select dropdown = new Select(AddPlotTownland);
        dropdown.selectByVisibleText(Arg0);
    }

    // Entering Add Plot Reference Number
    public void AgentEnterAddPlotPlotReferenceNumber(String Arg0) {
        actions.waitForVisibilityOfElement(AgentLandDetailsAddPlotEnterPlotReference, 30);
        actions.sendKeys(AgentLandDetailsAddPlotEnterPlotReference, String.valueOf(Arg0));
    }

    // Add Plot Selecting Ownership Status
    public void AgentSelectAddPlotOwnershipStatus(String Arg0) {
        WebElement AddPlotOwnershipStatus = driver.findElement(AgentLandDetailsAddPlotSelectOwnershipStatus);
        actions.waitForVisibilityOfElement(AgentLandDetailsAddPlotSelectOwnershipStatus, 30);
        Select dropdown = new Select(AddPlotOwnershipStatus);
        dropdown.selectByVisibleText(Arg0);
    }

    // Entering Add Plot Claimed Area
    public void AgentEnterAddPlotClaimedArea(String Arg0) {
        actions.waitForVisibilityOfElement(AgentLandDetailsAddPlotEnterClaimedArea, 30);
        actions.sendKeys(AgentLandDetailsAddPlotEnterClaimedArea, String.valueOf(Arg0));
    }

    // Add Plot Selecting Plot Use
    public void AgentSelectAddPlotPlotUse(String Arg0) {
        WebElement AddPlotPlotUse = driver.findElement(AgentLandDetailsAddPlotSelectPlotUse);
        actions.waitForVisibilityOfElement(AgentLandDetailsAddPlotSelectPlotUse, 30);
        Select dropdown = new Select(AddPlotPlotUse);
        dropdown.selectByVisibleText(Arg0);
    }

    // Clicking on the Add Plot Commonage Checkbox
    public void AgentClickOnAddPlotCommonageCheckbox() {
        actions.waitForVisibilityOfElement(AgentLandDetailsAddPlotClickOnCommonagePlotCheckBox, 10);
        actions.click(AgentLandDetailsAddPlotClickOnCommonagePlotCheckBox);
    }

    // Clicking on the Add Plot Submit Map Radio Button
    public void AgentClickOnAddPlotSubmitMapRadioButton() {
        actions.waitForVisibilityOfElement(AgentLandDetailsAddPlotClickOnSubmitMapByPostRadioBtn, 10);
        actions.click(AgentLandDetailsAddPlotClickOnSubmitMapByPostRadioBtn);
    }

    // Clicking on the Add Plot Edit Map Online Radio Button
    public void AgentClickOnAddPlotEditMapOnlineRadioButton() {
        actions.waitForVisibilityOfElement(AgentLandDetailsAddPlotClickOnEditMapOnlineRadioBtn, 10);
        actions.click(AgentLandDetailsAddPlotClickOnEditMapOnlineRadioBtn);
    }

    // Clicking on the Add Plot Upload Map Radio Button
    public void AgentClickOnAddPlotUploadMapRadioButton() {
        actions.waitForVisibilityOfElement(AgentLandDetailsAddPlotClickOnUploadMapRadioBtn, 10);
        actions.click(AgentLandDetailsAddPlotClickOnUploadMapRadioBtn);
    }

    // Clicking on the Add Plot Next Button
    public void AgentClickOnAddPlotNextButton() {
        actions.waitForVisibilityOfElement(AgentLandDetailsAddPlotNextButton, 10);
        actions.click(AgentLandDetailsAddPlotNextButton);
    }
    // Clicking on the Add Plot Next Button to Draw Map
    public void AgentClickOnAddPlotNextButtonToDrawMap() {
        actions.waitForVisibilityOfElement(AgentLandDetailsAddPlotNextButtonToDrawMap, 10);
        actions.click(AgentLandDetailsAddPlotNextButtonToDrawMap);
    }

    // Click on the Useful Information Dialog Close Button
    public void AgentClickOnUsefulInformationDialogCloseButton() {
        if(driver.findElements(GISPageUsefulInfoDialogCloseButton).isEmpty() == false) {
            actions.waitForVisibilityOfElement(GISPageUsefulInfoDialogCloseButton, 15);
            actions.clickUsingJS(GISPageUsefulInfoDialogCloseButton);
        }
        else {
            System.out.println("Useful Information Dialog not Displayed");
        }
    }

    // Checking if Add Plot Dialog Next Button Disabled
    public Boolean AgentCheckIfAddPlotDialogNextButtonStatus() {
        return driver.findElement(AgentLandDetailsAddPlotNextButton).isEnabled();
    }

    // Selecting Plot 1 Organic Status
    public void AgentSelectPlot1OrganicStatus(String Arg0) {
        if((driver.findElements(LandDetailsSecondPage)).isEmpty()==true) {
            WebElement FirstPlot = driver.findElement(By.xpath("//div[contains(text(),'T1261300010')]"));
            WebElement OrganicStatus = driver.findElement(with(By.className("landDetailsOrganicStatus"))
                    .toRightOf(FirstPlot));
            Select dropdown = new Select(OrganicStatus);
            dropdown.selectByVisibleText(Arg0);
        }
        else {
            if (driver.findElements(By.xpath("//div[contains(text(),'T1261300010')]")).isEmpty() == false) {
                WebElement ParcelID = driver.findElement(By.xpath("//div[contains(text(),'T1261300010')]"));
                WebElement OrganicStatus = driver.findElement(with(By.tagName("select")).toRightOf(ParcelID));
                Select dropdown = new Select(OrganicStatus);
                dropdown.selectByVisibleText(Arg0);
            }
            else {
                actions.waitForVisibilityOfElement(LandDetailsSecondPage,15);
                actions.clickUsingJS(LandDetailsSecondPage);
                WebElement FirstPlot = driver.findElement(By.xpath("//div[contains(text(),'T1261300010')]"));
                WebElement OrganicStatus = driver.findElement(with(By.className("landDetailsOrganicStatus"))
                        .toRightOf(FirstPlot));
                Select dropdown = new Select(OrganicStatus);
                dropdown.selectByVisibleText(Arg0);
            }
        }
    }

    // Selecting Plot 2 Organic Status
    public void AgentSelectPlot2OrganicStatus(String Arg0) {
        if((driver.findElements(LandDetailsSecondPage)).isEmpty()==true) {
//            int ParcelOrganicStatusDropdown = ParcelsCountReferenceForfields-2;
            WebElement SecondPlot = driver.findElement(By.xpath("//div[contains(text(),'T1261300011')]"));
            WebElement OrganicStatus = driver.findElement(with(By.className("landDetailsOrganicStatus"))
                    .toRightOf(SecondPlot));
            Select dropdown = new Select(OrganicStatus);
            dropdown.selectByVisibleText(Arg0);
        }
        else {
            actions.waitForVisibilityOfElement(LandDetailsSecondPage,15);
            actions.clickUsingJS(LandDetailsSecondPage);
            WebElement SecondPlot = driver.findElement(By.xpath("//div[contains(text(),'T1261300011')]"));
            WebElement OrganicStatus = driver.findElement(with(By.className("landDetailsOrganicStatus"))
                    .toRightOf(SecondPlot));
            Select dropdown = new Select(OrganicStatus);
            dropdown.selectByVisibleText(Arg0);
        }
    }

    // Selecting Map Plot Organic Status
    public void AgentSelectMapPlotOrganicStatus(String Arg0) {
        if((driver.findElements(LandDetailsSecondPage)).isEmpty()==true) {
            WebElement FirstPlot = driver.findElement(By.xpath("//div[contains(text(),'T1261300013')]"));
            WebElement OrganicStatus = driver.findElement(with(By.className("landDetailsOrganicStatus"))
                    .toRightOf(FirstPlot));
            Select dropdown = new Select(OrganicStatus);
            dropdown.selectByVisibleText(Arg0);
        }
        else {
            if (driver.findElements(By.xpath("//div[contains(text(),'T1261300013')]")).isEmpty() == false) {
                WebElement ParcelID = driver.findElement(By.xpath("//div[contains(text(),'T1261300013')]"));
                WebElement OrganicStatus = driver.findElement(with(By.tagName("select")).toRightOf(ParcelID));
                Select dropdown = new Select(OrganicStatus);
                dropdown.selectByVisibleText(Arg0);
            }
            else {
                actions.waitForVisibilityOfElement(LandDetailsSecondPage,15);
                actions.clickUsingJS(LandDetailsSecondPage);
                WebElement FirstPlot = driver.findElement(By.xpath("//div[contains(text(),'T1261300013')]"));
                WebElement OrganicStatus = driver.findElement(with(By.className("landDetailsOrganicStatus"))
                        .toRightOf(FirstPlot));
                Select dropdown = new Select(OrganicStatus);
                dropdown.selectByVisibleText(Arg0);
            }
        }
    }

    // Selecting Plot 2 Ownership Status
    public void AgentSelectPlot2OwnershipStatus(String Arg0) {
        if((driver.findElements(LandDetailsSecondPage)).isEmpty()==true) {
            List<WebElement> OwnershipStatusPlot2 = driver.findElements(By.className("landDetailsOwnershipStatus"));
            int CountOfOwnershipStatusDropdowns = OwnershipStatusPlot2.size()-3;
            WebElement OwnershipStatus = OwnershipStatusPlot2.get(CountOfOwnershipStatusDropdowns);
            Select dropdown = new Select(OwnershipStatus);
            dropdown.selectByVisibleText(Arg0);
        }
        else {
            actions.waitForVisibilityOfElement(LandDetailsSecondPage,15);
            actions.clickUsingJS(LandDetailsSecondPage);
            WebElement Plot1ClaimedArea = driver.findElement(By.className("landDetailsClaimedArea"));
            WebElement Plot1ChangeOfMEA = driver.findElement(By.className("landDetailsPlotSubdivisionAddNoteButton"));
            WebElement Plot1MEA = driver.findElement(By.className("landDetailsMea"));
            WebElement Plot1DigitisedArea = driver.findElement(By.className("landDetailsDigitisedArea"));
            WebElement Plot1CommonageFraction = driver.findElement(By.xpath("//td[contains(@id,'comNum')]"));
            WebElement Plot1OrganicStatus = driver.findElement(By.className("landDetailsOrganicStatus"));
            WebElement Plot1ID = driver.findElement(By.xpath("//div[contains(text(),'T1261300011')]"));
            WebElement TestDropdown = driver.findElement(with(By.className("landDetailsOwnershipStatus"))
                    .toRightOf(Plot1ClaimedArea)
                    .toRightOf(Plot1ChangeOfMEA)
                    .toRightOf(Plot1MEA)
                    .toRightOf(Plot1DigitisedArea)
                    .toRightOf(Plot1CommonageFraction)
                    .toRightOf(Plot1OrganicStatus)
                    .toRightOf(Plot1ID));
            Select dropdown = new Select(TestDropdown);
            dropdown.selectByVisibleText(Arg0);
        }
    }

    // Visibility of Plot Cannot Be Rented In Error Message
    public String VisibilityOfPlotCannotBeRentedInErrorMessage() {
        int ParcelsCountReferenceForfields = driver.findElements(By.className("landDetailsRowRentedInLandWarningMessage")).size()-3;
        //actions.waitForVisibilityOfElement(AgentAddedPlotCannotBeRentedErrorMessage, 10);
        List<WebElement> PlotCannotBeRentedErrorMessage = driver.findElements(By.className("landDetailsRowRentedInLandWarningMessage"));
        String PlotCannotBeRentedInErrorMessage = PlotCannotBeRentedErrorMessage.get(ParcelsCountReferenceForfields).getText();
        //String PlotCannotBeRentedInErrorMessage = driver.findElement(AgentAddedPlotCannotBeRentedErrorMessage).getText();
        return PlotCannotBeRentedInErrorMessage;
    }

    // Visibility of ANC Column Label
    public Boolean VisibilityOfANCColumnLabel() {
        actions.waitForVisibilityOfElement(LandDetailsANCLAbel, 10);
        Boolean ANCVisibility = driver.findElement(LandDetailsANCLAbel).isDisplayed();
        return ANCVisibility;
    }

    // Visibility of GLAS Column Label
    public Boolean VisibilityOfGLASColumnLabel() {
        actions.waitForVisibilityOfElement(LandDetailsGLASLabel, 10);
        Boolean GLASVisibility = driver.findElement(LandDetailsGLASLabel).isDisplayed();
        return GLASVisibility;
    }

    // Clicking on the Land Details Save Button
    public void AgentClickOnLandDetailsSaveButton() {
        actions.waitForVisibilityOfElement(LandDetailsPageSaveButton, 10);
        actions.click(LandDetailsPageSaveButton);
    }


    // Switch Land Details Page
    By LandDetailsFirstpage = By.xpath("//a[@class='ng-binding' and text()='1']");
    By LandDetailsSecondPage = By.xpath("//a[@class='ng-binding' and text()='2']");

    // Navigate to second page in Land Details Tab
    public void AgentNavigateToSecondTabInLandDetails() {
        if((driver.findElements(By.xpath("//a[@class='ng-binding' and text()='2']")).isEmpty()) == false) {
            actions.waitForVisibilityOfElement(LandDetailsSecondPage,15);
            actions.clickUsingJS(LandDetailsSecondPage);
        }
        else {
            System.out.println("Second page not present");
        }

    }

    // Navigate to first page in Land Details Tab
    public void AgentNavigateToFirstTabInLandDetails() {
        actions.waitForVisibilityOfElement(LandDetailsFirstpage,15);
        actions.clickUsingJS(LandDetailsFirstpage);
    }

    // endregion

    // region Edit Map
    By DrawButton = By.id("drawContinuation_Link");
    By ConfirmButton = By.id("confirm_draw");
    By AttributeNotes = By.id("BIP_NOTE_id");
    By InfoSectionConfirmButton = By.xpath("//div[@id = 'confirmControl_attrBtnHolderDiv']//child::input");
    By ReturnToLandDetailsPage = By.xpath("(//a[@id='measureBetweenContinuation_Link'])[2]");
    By InfoSectionNotesEmptyWarning = By.xpath("//span[contains(text(),'Note cannot be empty.')]");
    //By ExitToLandDetails = By.xpath("//")


    // Click on Edit Map Page Draw Button
    public void AgentClickOnEditMapPageDrawButton() {
        actions.waitForVisibilityOfElement(DrawButton,15);
        actions.clickUsingJS(DrawButton);
        actions.waitforSeconds(6);
    }

    public void AgentDrawMapBoundariesOnEditMapScreen() {

//        actions.waitforSeconds(2);

        Actions act = new Actions(driver);
        WebElement el = driver.findElement(By.xpath("//span[@id ='outer-west-resizer']"));
        act.moveToElement(el, 220, 300).doubleClick().build().perform();
        act.moveToElement(el, 200, 300).doubleClick().build().perform();
        act.moveToElement(el, 210, 300).doubleClick().build().perform();
        act.moveToElement(el, 205, 300).doubleClick().build().perform();
        act.contextClick();
        System.out.println("Map Drawn");
        actions.waitforSeconds(6);
    }

    public void AgentDrawMapBoundariesOnSplitMapScreen() {

        actions.waitforSeconds(2);

        Actions act = new Actions(driver);
        WebElement el = driver.findElement(By.xpath("//span[@id ='outer-west-resizer']"));
        act.moveToElement(el, 350, 320).doubleClick().build().perform();
        act.moveToElement(el, 370, 320).doubleClick().build().perform();
        act.moveToElement(el, 340, 320).doubleClick().build().perform();
        act.moveToElement(el, 375, 320).doubleClick().build().perform();
        act.contextClick();
        System.out.println("Map Drawn");
        actions.waitforSeconds(6);
    }

    // Click on Edit Map Page Confirm Button
    public void AgentClickOnEditMapPageConfirmButton() {
        actions.waitForVisibilityOfElement(ConfirmButton,15);
        actions.clickUsingJS(ConfirmButton);
    }

    // Enter the Attribute Notes
    public void AgentEnterAttributeNotes(String Arg0) {
        actions.waitForVisibilityOfElement(AttributeNotes,15);
        actions.sendKeys(AttributeNotes,Arg0);
    }

    // Click on Edit Map Info Section Confirm Button
    public void AgentClickOnEditMapPageInfoSectionConfirmButton() {
        actions.waitForVisibilityOfElement(InfoSectionConfirmButton,15);
        actions.clickUsingJS(InfoSectionConfirmButton);
    }

    // Check if warning message displayed in Info Section
    public String AgentCheckInfoSectionWarningMessage() {
        actions.waitForVisibilityOfElement(InfoSectionNotesEmptyWarning,20);
        String InfoSectionWarningMessage = driver.findElement(InfoSectionNotesEmptyWarning).getText();
        return InfoSectionWarningMessage;
    }

    // Click On Return to Land Details Page
    public void AgentClickOnReturnToLandDetails() {
        actions.waitForVisibilityOfElement(ReturnToLandDetailsPage,15);
        actions.clickUsingJS(ReturnToLandDetailsPage);
    }

    // Change the Organic Status of the map plot
    public void AgentSelectMapPlot2OrganicStatus(String Arg0) {
        if ((driver.findElements(LandDetailsSecondPage)).isEmpty() == true) {
            WebElement MapPlot2Reference = driver.findElement(By.xpath("//div[contains(text(),'T1261300013')]"));
            WebElement MapPlot2OrganicStatusDropdown = driver.findElement(with(By.className("landDetailsOrganicStatus"))
                    .toRightOf(MapPlot2Reference));
            Select dropdown = new Select(MapPlot2OrganicStatusDropdown);
            dropdown.selectByVisibleText(Arg0);
        } else {
            WebElement MapPlot2Reference = driver.findElement(By.xpath("//div[contains(text(),'T1261300013')]"));
            WebElement MapPlot2OrganicStatusDropdown = driver.findElement(with(By.className("landDetailsOrganicStatus"))
                    .toRightOf(MapPlot2Reference));
            Select dropdown = new Select(MapPlot2OrganicStatusDropdown);
            dropdown.selectByVisibleText(Arg0);
        }
    }
    // endregion

    // region Land Details Page Dynamic Logic Methods
    By landDetailsRows = By.className("landDetailsRow");
    // Find the number of Parcels to do dynamic operations



    // Delete the already present parcels
    public void DeleteAlreadyPresentParcels() throws InterruptedException {
        int NumberOfParcelsInFirstPage = driver.findElements(landDetailsRows).size();
        System.out.println(NumberOfParcelsInFirstPage);
        if (NumberOfParcelsInFirstPage == 0) {
            System.out.println("Client has no parcels");
        }
        else
        {
            for (int i = NumberOfParcelsInFirstPage-1 ; i>=0 ; i--) {
                WebElement DeleteButton = driver.findElement(By.id("deleteParcelBtn" + i));
                JavascriptExecutor executor = (JavascriptExecutor)driver;
                executor.executeScript("arguments[0].click();", DeleteButton);
                Thread.sleep(500);
            }
        }
        if((driver.findElements(By.xpath("//a[@class='ng-binding' and text()='2']")).isEmpty()) == false) {
            actions.clickUsingJS(LandDetailsSecondPage);
            int NumberOfParcelsInSecondPage = NumberOfParcelsInFirstPage + (driver.findElements(landDetailsRows).size());
            for (int i = NumberOfParcelsInSecondPage - 1 ; i>NumberOfParcelsInFirstPage ; i--) {
                WebElement DeleteButton = driver.findElement(By.id("deleteParcelBtn" + i));
                JavascriptExecutor executor = (JavascriptExecutor)driver;
                executor.executeScript("arguments[0].click();", DeleteButton);
                Thread.sleep(500);
            }
        }
        else {
            System.out.println("No second page on Land Details Tab");
        }
    }




    // endregion

    // region Organic Page Methods
    // Organic Page
    By BackButton = By.id("buttonBack");
    By ParcelOrPlotVisible = By.xpath("//tbody");
    By ReferenceClaimedAreaOfParcel = By.id("measurementL1350400015");
    By ReferenceAreaGreaterErrorMessage = By.id("referenceAreaErrorL1350400015");
    By ReferenceClaimedAreaOfPlot = By.id("measurementT1261300010");
    By ReferenceAreaEmptyErrorMessage = By.id("measurementErrorT1261300010");
    By OrganicPageNextButton = By.id("buttonNext");


    // Clicking on the Back Button
    public void AgentClickOnBackButton() {
        actions.waitForVisibilityOfElement(BackButton, 10);
        actions.click(BackButton);
    }

    // Enter New Reference Claimed Area for Parcel
    public void AgentEnterOrganicReferenceclaimedArea(String arg0) {
        if(driver.findElements(ReferenceClaimedAreaOfParcel).isEmpty()==true) {
            System.out.println("No Parcel Found in Organic Page");
        }
        else {
            actions.waitForVisibilityOfElement(ReferenceClaimedAreaOfParcel,15);
            actions.sendKeys(ReferenceClaimedAreaOfParcel, arg0);
        }

    }

    // Enter New Reference Claimed Area for Plot
    public void AgentEnterOrganicReferenceclaimedAreaForPlot(String arg0) {
        if(driver.findElements(ReferenceClaimedAreaOfPlot).isEmpty() == true) {
            System.out.println("No Plots found in the Organic Page");
        }
        else {
            actions.waitForVisibilityOfElement(ReferenceClaimedAreaOfPlot,15);
            driver.findElement(By.id("measurementT1261300010")).sendKeys(Keys.DELETE);
        }
    }

    // Visibility of Reference Area Greater Error Message
    public String ReferenceAreaGreaterErrorMessage() {
        actions.waitForVisibilityOfElement(ReferenceAreaGreaterErrorMessage, 10);
        String RefAreaGreaterErrorMessage = driver.findElement(ReferenceAreaGreaterErrorMessage).getText();
        return RefAreaGreaterErrorMessage;
    }

    // Enter New Reference Claimed Area for Plot
    public void AgentEnterOrganicReferenceclaimedAreaforPlot(String arg0) {
        actions.waitForVisibilityOfElement(ReferenceClaimedAreaOfParcel,15);
        actions.sendKeys(ReferenceClaimedAreaOfParcel, arg0);
    }

    // Visibility of Reference Area Empty Error Message
    public String ReferenceAreaEmptyErrorMessage() {
        actions.waitForVisibilityOfElement(ReferenceAreaEmptyErrorMessage, 10);
        String RefAreaEmptyErrorMessage = driver.findElement(ReferenceAreaEmptyErrorMessage).getText();
        return RefAreaEmptyErrorMessage;
    }

    // Click on Organic Page Next Button
    public void AgentClickOnOrganicPageNextButton() {
        actions.waitForVisibilityOfElement(OrganicPageNextButton,15);
        actions.click(OrganicPageNextButton);
    }
    // endregion

    // region Greening Page Organic Tab Methods
    // Greening Page Organic Tab
    By Parcel1Number = By.xpath("//td[contains(text(),'L1350400015')]");
    By Plot1Number = By.xpath("//td[contains(@class, 'text-left') and normalize-space(text()) = 'T1261300010']");
    By Plot2Number = By.xpath("//td[contains(@class, 'text-left') and normalize-space(text()) = 'T1261300011']");
    By GreeningExemptionCheckBox = By.id("organicExemptionGlobal");
    By GreeningPageNextButton = By.id("buttonNext");

    // Text from Parcel 1 Number Column
    public String TextOfParcel1Number() {
        actions.waitForVisibilityOfElement(Parcel1Number, 10);
        String Parcel1NumText = driver.findElement(Parcel1Number).getText();
        return Parcel1NumText;
    }

    // Text from Plot 1 Number Column
    public String TextOfPlot1Number() {
        actions.waitForVisibilityOfElement(Plot1Number, 10);
        String Plot1NumText = driver.findElement(Plot1Number).getText();
        return Plot1NumText;
    }

    // Text from Plot 2 Number Column
    public String TextOfPlot2Number() {
        actions.waitForVisibilityOfElement(Plot2Number, 10);
        String Plot2NumText = driver.findElement(Plot2Number).getText();
        return Plot2NumText;
    }

    // Check if the Greening Exmption Checkbox is enabled
    public Boolean GreeningExemptionEnabled() {
        actions.waitForVisibilityOfElement(GreeningExemptionCheckBox,15);
        Boolean ExemptionEnabled = driver.findElement(GreeningExemptionCheckBox).isEnabled();
        return ExemptionEnabled;
    }

    // Click on Greening Page Next Button to Navigate to GLAS Page
    public void NavigateToGLASPage() {
        if(driver.findElements(By.xpath("//a[contains(text(),'GLAS')]")).isEmpty()==true) {
            System.out.println("No GLAS Tab Displayed");
            System.out.println("Navigating to Application Summary Page");
            NavigateToApplicationSummaryPage();
        }
        else {
            do {
                actions.waitForVisibilityOfElement(GreeningPageNextButton,15);
                actions.click(GreeningPageNextButton);
            }
            while (((driver.findElements(By.id("areaActionMenuOption")).isEmpty())==true) );
        }
        // && ((driver.findElements(By.xpath("//li[@id='applicationSummaryMenuOption' and @class='active']"))).isEmpty()==true)
    }



    // Click on Greening Page Next Button to Navigate to Greening Crop Diversification Tab
    public void NavigateToGreeningCropDiversificationPage() {
        do {
            actions.waitForVisibilityOfElement(GreeningPageNextButton,15);
            actions.click(GreeningPageNextButton);
        }
        while ((driver.findElements(By.id("exemptionLabelText")).isEmpty())==true);
    }

    // Click on Greening Page Next Button to Navigate to Greening Summary Tab
    public void NavigateToGreeningSummaryPage() {
        do {
            actions.waitForVisibilityOfElement(GreeningPageNextButton,15);
            actions.click(GreeningPageNextButton);
        }
        while ((driver.findElements(By.xpath("//li[@id='greeningSummaryMenuOption' and @class='active']")).isEmpty())==true);
    }

    // Click on Greening Page Next Button to Navigate to Greening EFA Tab
    public void NavigateToGreeningEFAPage() {
        do {
            actions.waitForVisibilityOfElement(GreeningPageNextButton,15);
            actions.click(GreeningPageNextButton);
        }
        while ((driver.findElements(By.xpath("//li[@id='efaMenuOption' and @class='active']")).isEmpty())==true);
    }


    // endregion

    // region Greening Page Crop Diversification Tab
    // Greening Page Crop Diversification Tab
    By FiftyPercentExemptionCheckBox = By.id("cropDivExemption");
    By FiftyPercentExemptionText = By.id("exemptionLabelText");
    By GreeningPageCropDiversificationSaveButton = By.id("buttonSave");

    // Select the Fifty Percent Exemption CheckBox
    public void SelectFiftyPercentExemptionCheckBox() {
        actions.waitForVisibilityOfElement(FiftyPercentExemptionCheckBox,15);
        actions.click(FiftyPercentExemptionCheckBox);
    }

    // Click on the Fifty Percent Exemption Link
    public void ClickOnTheFiftyPercentExemptionLink() {
        actions.waitForVisibilityOfElement(FiftyPercentExemptionText,15);
        actions.click(FiftyPercentExemptionText);
    }

    // Click on the Greening Page Crop Diversification Save Button
    public void ClickOnGreeningPageCropDiversificationSaveButton() {
        actions.waitForVisibilityOfElement(GreeningPageCropDiversificationSaveButton,15);
        actions.click(GreeningPageCropDiversificationSaveButton);
    }
    // endregion

    // region Greening Page EFA Tab
    // Greening Page EFA Tab
    By CropDiversificationProvisionalStatus = By.xpath("//body[1]/div[3]/span[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]");
    By EFAProvisionalStatus = By.xpath("//body[1]/div[3]/span[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]");

    // Check if the Crop Diversion Provisional Status displayed
    public Boolean CheckVisibilityOfCDProvisionalStatus() {
        actions.waitForVisibilityOfElement(CropDiversificationProvisionalStatus,15);
        return driver.findElement(CropDiversificationProvisionalStatus).isDisplayed();
    }

    // Check if the EFA Provisional Status displayed
    public Boolean CheckVisibilityOfEFAProvisionalStatus() {
        actions.waitForVisibilityOfElement(EFAProvisionalStatus,15);
        return driver.findElement(EFAProvisionalStatus).isDisplayed();
    }
    // endregion

    // Greening Page Greening Summary Tab

    // region General GLAS Tab Methods
    // GLAS Tab
    By GLASTab = By.id("glasMenuOption");


    // Check for Visibility of GLAS Tab
    public boolean VisibilityOfGLASTab() {
        boolean visibility = true;
        if(driver.findElements(GLASTab).isEmpty()==true) {
            System.out.println("No GLASTab or Application");
        }
        else {
            actions.waitForVisibilityOfElement(GLASTab,15);
            visibility = driver.findElement(GLASTab).isEnabled();
        }
        return visibility;
    }
    // endregion

    // region GLAS Page All Tab Methods
    // GLAS All Tabs
    By GLASAreaActionsTab = By.id("areaActionMenuOption");
    By GLASAreaActionsFirstParcelClaimedArea = By.id("measurement20450_C10124090");
    By GLASAreaActionsFirstParcelClaimedAreaEmptyError = By.id("measurementError20450_C10124090");
    By GLASLinearActionsTab = By.id("linearActionMenuOption");
    By GLASNumericalActionsTab = By.id("numActionMenuOption");
    By GLASWholeFarmActionsTab = By.id("wholeFarmActionMenuOption");
    By GLASCommonageActionsTab = By.id("commonageActionMenuOption");
    By GLASPageNextButton = By.id("buttonNext");

    // Visibility of GLAS Area Actions Tab
    // To check if it is the first tab use the List of WebElements Con
    public void VisibilityOfGLASAreaActionsTab() {
        if(driver.findElements(GLASAreaActionsTab).isEmpty()==true) {
            System.out.println("GLAS Tab is not Present");
        }
        else {
            if(driver.findElement(GLASAreaActionsTab).isDisplayed()) {
                System.out.println("GLAS Tab is Visible");
            }
        }
    }

    // Click on GLAS Page Next Button to Navigate to GLAS Page
    public void NavigateToApplicationSummaryPage() {
        if(driver.findElements(By.xpath("//li[@id='applicationSummaryMenuOption' and @class='active']")).isEmpty()==false) {
            System.out.println("Agent is already on Application Summary Page");
        }
        else{
            do {
                actions.waitForVisibilityOfElement(GLASPageNextButton,15);
                actions.click(GLASPageNextButton);
            }
            while ((driver.findElements(By.xpath("//li[@id='applicationSummaryMenuOption' and @class='active']")).isEmpty())==true);
        }
    }

    // Claimed Area field Cleared for fist Parcel
    public void ClaimedAreaClearedForGLAsAreaActions() {
        if (driver.findElements(GLASAreaActionsTab).isEmpty()==true) {
            System.out.println("GLAS Tab not Present");
        }
        else if (driver.findElements(GLASAreaActionsFirstParcelClaimedArea).isEmpty()==true) {
            System.out.println("No Parcels Shown in the GLAS Area Actions Page");
        }
        else {
            actions.waitForVisibilityOfElement(GLASAreaActionsFirstParcelClaimedArea,15);
            driver.findElement(GLASAreaActionsFirstParcelClaimedArea).clear();
        }
    }

    // Enter Claimed Area and check if field is Numeric
    public String AgentCheckClaimedAreaForGLASAreaActionsIsNumeric() {
        actions.waitForVisibilityOfElement(GLASAreaActionsFirstParcelClaimedArea,15);
        driver.findElement(GLASAreaActionsFirstParcelClaimedArea).sendKeys("Te1s.t9s8");
        String ClaimedArea = driver.findElement(GLASAreaActionsFirstParcelClaimedArea).getText();
        return ClaimedArea;
    }



//    public void AgentCheckIfClaimedAreaFieldNumeric() {
//        int maxlenght=Integer.parseInt(actions.findElemts(EggPackerDetails).get(0).getAttribute("maxlength"));
//        Assert.assertEquals(maxlenght,400);
//    }
//
//    static SecureRandom rnd = new SecureRandom();
//
//    public String getRandomString(int len) {
//        String upper = "1.98";
//        String lower = upper.toLowerCase();
//        String finalstring=upper+" "+lower;
//        StringBuilder sb=new StringBuilder(len);
//        for (int i=0;i<len;i++){
//            sb.append(finalstring.charAt(rnd.nextInt(finalstring.length())));
//        }
//        return sb.toString();
//    }

    // Visibility of Claimed Area Empty Error
    public Boolean ClaimedAreaEmptyForGLASAreaActions() {
        Boolean visibility = false;
        if(driver.findElements(GLASAreaActionsFirstParcelClaimedAreaEmptyError).isEmpty()==true) {
            System.out.println("No Parcels or associate Error Messages on the Page");
        }
        else {
            actions.waitForVisibilityOfElement(GLASAreaActionsFirstParcelClaimedAreaEmptyError,15);
            visibility = driver.findElement(GLASAreaActionsFirstParcelClaimedAreaEmptyError).isDisplayed();
        }
        return visibility;
    }

    // Navigate to GLAS Linear Actions Tab
    public void ClickOnGLASLinearActionsTab() {
        if(driver.findElements(GLASLinearActionsTab).isEmpty() == true) {
            System.out.println("No Linear Actions Tab Displayed");
        }
        else {
            actions.waitForVisibilityOfElement(GLASLinearActionsTab,15);
            actions.click(GLASLinearActionsTab);
        }
    }

    // Navigate to GLAS Numerical Actions Tab
    public void ClickOnGLASNumericalActionsTab() {
        if(driver.findElements(GLASNumericalActionsTab).isEmpty() == true) {
            System.out.println("No Numerical Actions Tab Displayed");
        }
        else {
            actions.waitForVisibilityOfElement(GLASNumericalActionsTab, 15);
            actions.click(GLASNumericalActionsTab);
        }
    }

    // Navigate to GLAS Whole Farm Actions Tab
    public void ClickOnGLASWholeFarmActionsTab() {
        if(driver.findElements(GLASWholeFarmActionsTab).isEmpty() == true) {
            System.out.println("No Whole Farm Actions Tab Displayed");
        }
        else {
            actions.waitForVisibilityOfElement(GLASWholeFarmActionsTab, 15);
            actions.click(GLASWholeFarmActionsTab);
        }
    }

    // Navigate to GLAS Commonage Actions Tab
    public void ClickOnGLASCommonageActionsTab() {
        if(driver.findElements(GLASCommonageActionsTab).isEmpty() == true) {
            System.out.println("No Linear Actions Tab Displayed");
        }
        else {
            actions.waitForVisibilityOfElement(GLASCommonageActionsTab, 15);
            actions.click(GLASCommonageActionsTab);
        }
    }
    // endregion

    // region Application Summary Page Methods
    // Application Summary Page
    By Plot2Message = By.xpath("//body[1]/div[3]/span[1]/div[1]/div[2]/div[1]/div[3]/div[2]/div[1]/div[2]/span[1]");
    By Plot1Message = By.xpath("//body[1]/div[3]/span[1]/div[1]/div[2]/div[1]/div[3]/div[2]/div[1]/div[2]/span[3]");
    By PlotUploadDoc = By.id("plotListUploadMap");
    By PlotSubmitDoc = By.id("plotListSubmitDoc");
    By AgentApplicationNotes = By.id("txtAgentNotes");
    By PreSubmitChecklistLink = By.xpath("//body[1]/div[3]/span[1]/div[1]/div[2]/div[1]/div[3]/div[2]/div[1]/div[2]/a[1]");
    By PreSubmitCheckListCloseButton = By.xpath("//body[1]/div[3]/span[1]/div[3]/div[1]/div[1]/div[3]/button[1]");
    By IneligibleANCParcelsButton = By.id("applicationSummaryIneligibleANCParcels");
    By IneligibleParcelCheckBox = By.id("chkL1350400015");
    By SaveIneligibleParcelsButton = By.xpath("//body[1]/div[3]/span[1]/div[4]/div[1]/div[1]/div[3]/button[1]");
    By ApplicationSubmitButton = By.xpath("//button[contains(text(),'Submit Application')]");
    By TermsAndConditionsCheckBox = By.id("chkTermsAndConditions");
    By TermsAndConditionsPageLink = By.xpath("//body[1]/div[3]/span[1]/div[1]/div[2]/div[1]/div[3]/div[2]/div[1]/div[2]/div[2]/a[1]");
    //By ViewApplicationConfirmationButton = visitConfirmationButton
    //      By ReturnToPortal = visitPortal


    // Check The Submit Map By Post Message for Plot 2
    public String Plot2MapMessageText() {
        actions.waitForVisibilityOfElement(Plot2Message,15);
        String Plot2Text = driver.findElement(Plot2Message).getText();
        return Plot2Text;
    }

    // Check The Plot Number for Upload Map
    public String PlotNumberforUploadMap() {
        actions.waitForVisibilityOfElement(PlotUploadDoc,15);
        String PlotForUploadMap = driver.findElement(PlotUploadDoc).getText();
        return PlotForUploadMap;
    }

    // Check The Upload Map Message for Plot 1
    public String Plot1MapMessageText() {
        actions.waitForVisibilityOfElement(Plot1Message,15);
        String Plot1Text = driver.findElement(Plot1Message).getText();
        return Plot1Text;
    }

    // Check The Plot Number for Submit Map
    public String PlotNumberforSubmitMap() {
        actions.waitForVisibilityOfElement(PlotSubmitDoc,15);
        String PlotForSubmitMap = driver.findElement(PlotSubmitDoc).getText();
        return PlotForSubmitMap;
    }

    // Enter Agent Notes for Application
    public void AgentEnterNotesForApplication(String arg0) {
        actions.waitForVisibilityOfElement(AgentApplicationNotes,15);
        actions.sendKeys(AgentApplicationNotes, arg0);
    }

    // Click on Pre-Submit Checklist Link
    public void AgentClickOnPreSubmitcheckList() {
        actions.waitForVisibilityOfElement(PreSubmitChecklistLink,15);
        actions.click(PreSubmitChecklistLink);
    }

    // Click On Pre-Submit CheckList Close Button
    public void AgentClickOnCloseButton() {
        actions.waitForVisibilityOfElement(PreSubmitCheckListCloseButton,15);
        actions.click(PreSubmitCheckListCloseButton);
    }

    // Click on Application Summary Ineligible Parcels
    public void AgentClickOnIneligibleParcels() {
        actions.waitForVisibilityOfElement(IneligibleANCParcelsButton,15);
        actions.click(IneligibleANCParcelsButton);
    }

    // Select Ineligible Parcel CheckBox
    public void AgentSelectIneligibleParcel() {
        actions.waitForVisibilityOfElement(IneligibleParcelCheckBox,15);
        actions.click(IneligibleParcelCheckBox);
    }

    // Click on Save Ineligible Parcels Button
    public void AgentSaveIneligibleParcels() {
        actions.waitForVisibilityOfElement(SaveIneligibleParcelsButton,15);
        actions.click(SaveIneligibleParcelsButton);
    }

    //Navigate to Terms and Conditions Page
    public void NavigateToTermsAndConditionsPage() {
        actions.waitForVisibilityOfElement(TermsAndConditionsPageLink,15);
        actions.click(TermsAndConditionsPageLink);
    }

    // Check if Terms and Conditions Checkbox not Selected
    public Boolean TermsAndConditionsCheckboxNotSelected() {
        return driver.findElement(TermsAndConditionsCheckBox).isSelected();
    }

    // Check if Submit Button is Inactive
    public Boolean CheckIfSubmitButtonInActive() {
        return driver.findElement(ApplicationSubmitButton).isEnabled();
    }

    // Accept Terms and Conditions
    public void TermsAndConditionsAccpeted() {
        actions.waitForVisibilityOfElement(TermsAndConditionsCheckBox,15);
        actions.click(TermsAndConditionsCheckBox);
    }

    // Submit Application
    public void SubmitApplication() {
        actions.waitForVisibilityOfElement(ApplicationSubmitButton,15);
        actions.click(ApplicationSubmitButton);
    }

    // endregion

    // region Actions after Submit Application

    // Application Confirmation Screen
    By VisitConfirmationPage = By.xpath("//button[contains(text(),'View Application Confirmation')]");
    By VisitPortalPage = By.xpath("//button[contains(text(),'Return to Portal')]");
    By PrintCoverLetterButton = By.id("previewCoverLetterBtn");
    By ClosePrintCoverLetterButton = By.id("closePreviewCoverLetter");
    By ViewApplicationSummaryButton = By.id("previewApplicationSummaryBtn");
    By CloseApplicationSummaryButton = By.id("closePreviewApplicationSummary");
    By UploadDocumentationButton = By.xpath("//button[contains(text(),'Upload Documentation')]");
    By HomepageButton = By.id("btnFinish");

    // Click on Visit Confirmation Page
    public void ClickOnVisitConfirmation() {
        actions.waitForVisibilityOfElement(VisitConfirmationPage,15);
        actions.click(VisitConfirmationPage);
    }

    // Click on Visit Portal Page
    public void ClickOnVisitPortalPage() {
        actions.waitForVisibilityOfElement(VisitPortalPage,15);
        actions.click(VisitPortalPage);
    }

    // Click on the Print Cover Letter Button
    public void ClickOnPrintCoverLetterButton() {
        actions.waitForVisibilityOfElement(PrintCoverLetterButton, 15);
        actions.click(PrintCoverLetterButton);
    }

    // Click on Close Cover Letter Button
    public void ClickOnClosePrintCoverLetterButton() {
        actions.waitForVisibilityOfElement(ClosePrintCoverLetterButton,15);
        actions.click(ClosePrintCoverLetterButton);
    }

    // Click on View Application Summary Button
    public void ClickOnViewApplicationSummaryButton() {
        actions.waitForVisibilityOfElement(ViewApplicationSummaryButton,15);
        actions.click(ViewApplicationSummaryButton);
    }

    // Click on Close Application Summary Button
    public void ClickOnCloseApplicationSummaryButton() {
        actions.waitForVisibilityOfElement(CloseApplicationSummaryButton,15);
        actions.click(CloseApplicationSummaryButton);
    }

    // Click on Upload Documentation Button
    public void ClickOnUploadDocumentationButton() {
        actions.waitForVisibilityOfElement(UploadDocumentationButton, 15);
        actions.click(UploadDocumentationButton);
    }

    // Click on HomePage Button
    public void ClickOnHomepageButton() {
        actions.waitForVisibilityOfElement(HomepageButton,15);
        actions.click(HomepageButton);
    }

    // Print Cover Letter Button
    //Switch to frame id/name = pdfframe
    By PrintIcon = By.xpath("//*[@id=\"icon\"]/iron-icon");

    // Upload Documents Page
    By TransfersButton = By.xpath("//a[contains(text(),'Transfers')]");
    By NRYFSButton = By.xpath("//a[contains(text(),'NR/YFS')]");
    By ChooseFileButton = By.xpath("//input[contains(@type,'file')]");
    // Below Doctype is a Select Dropdown w options : Ther, Folio/LeaseAgreement, Commonage Evidence, Map, Inspections Correspondence, Sensitive Personal Documentation
    By UploadDocType = By.id("docTypes");
    By UploadButton = By.id("uploadDocumentChangesUploadButton");
    By BackToApplicationConfirmationButton = By.xpath("//button[contains(text(),'Application Confirmation')]");
    By UploadDocConfirmation = By.xpath("//body[1]/div[5]/div[3]/div[1]/button[1]");

    // Upload Document
    // RemoteWebElement Line has to be commented out to run locally but when pushing in code has to be uncommented
    public void UploadDocument() {
        actions.waitForVisibilityOfElement(ChooseFileButton,15);
        WebElement Choosefile = driver.findElement(By.xpath("//input[@type='file']"));
        // Has to be enabled while running on Grid if not in Driver Manager
        //((RemoteWebElement)driver).setFileDetector(new LocalFileDetector());
        Choosefile.sendKeys("C:/Users/Surya.Radhakrishnan/Desktop/Selenium JARs/TestData/Cover_Letter.pdf");
        // Path for Local Run
        //C:/Users/Surya.Radhakrishnan/BPS_Agent\BPS_Agent_DR_Scenarios_MIG/bps-agent-dr-scenarios-automation/src/main/resources/TestData/Cover_Letter.pdf
    }
    // Sending Path of File to Upload File
    String getfile() {
        return new File("./src/main/resources/TestData/Cover_Leter.pdf").getAbsolutePath();
    }

    // Select Type of Document being Uploaded
    public void SelectDocumentType(String Arg0){
        WebElement DocType = driver.findElement(UploadDocType);
        Select dropdown = new Select(DocType);
        dropdown.selectByVisibleText(Arg0);
    }

    // Click on the Upload Button
    public void ClickUploadButton() {
        actions.waitForVisibilityOfElement(UploadButton,15);
        actions.click(UploadButton);
    }

    // Outstanding BPS Applications Page Client
    By OutstandingApplicationsViewButton = By.id("agentCommonListViewButton");

    // Click on the View Button in the Outstanding BPS Applications Page
    public void ClickOnOutstandingBPSApplicationsViewButton() {
        //actions.waitForVisibilityOfElement(OutstandingApplicationsViewButton,15);
        driver.findElement(By.id("agentCommonListViewButton")).click();
        //actions.click(OutstandingApplicationsViewButton);
    }

    // Upload Document Confirmation
    public void ClickOnUploadFileConfirmation() {
        actions.waitForVisibilityOfElement(UploadDocConfirmation, 15);
        actions.click(UploadDocConfirmation);
    }

    // Click on Back To Application Confirmation Button
    public void ClickOnBackToApplicationConfirmation() {
        actions.waitForVisibilityOfElement(BackToApplicationConfirmationButton, 15);
        actions.click(BackToApplicationConfirmationButton);
    }

    // Locator to get the Herd Number
    By CurrentHerdNumber = By.id("clientDetailsHerdNumber");
    static String HerdNumberOfApplicationSubmitted;

    // Get the current Herd Number
    public String GetCurrentHerdNumber() {
        actions.waitForVisibilityOfElement(CurrentHerdNumber,15);
        //String HerdNumberOfApplicationSubmitted;
        HerdNumberOfApplicationSubmitted = driver.findElement(CurrentHerdNumber).getText();
        return HerdNumberOfApplicationSubmitted;
    }

    // endregion

    //region Database Cases Implementation

    // Implementing SQL Queries
    public void DevCDpsDataScript() {
        String value = "jdbc:oracle:thin:@//dbconn.agriculture.gov.ie:1532/DEVC.agriculture.gov.ie";
        String username = "DPS_DATA";
        String password = "DPS_DATA";

        try {
            Connection connection = DriverManager.getConnection(value, username, password);
            System.out.println("valuestring");

            //String HerdNumber = app.GetCurrentHerdNumber();

//            String sql = ("select pkco_audit.Set_Audit('DPS','DPS') from dual;\n" +
//                    "\n" +
//                    "declare\n" +
//                    "\n" +
//                    "v_app_id number;\n" +
//                    "\n" +
//                    "begin\n" +
//                    "\n" +
//                    "dbms_output.put_line('Holding Id='||get_hold('C1170099'));\n" +
//                    "\n" +
//                    "select app_id into v_app_id from tddp_application where app_applicant_holding_id = get_hold('C1170099') and app_syr_code = 2022;\n" +
//                    "\n" +
//                    "pkdp_application.DeleteApplication(v_app_id);\n" +
//                    "\n" +
//                    "commit;\n" +
//                    "\n" +
//                    "end;");
            String sql0 = ("set serveroutput on");
            String sql1 = ("conn DPS_DATA/DPS_DATA@DEVC");
            String sql2 = ("select pkco_audit.Set_Audit(\"DPS\",\"DPS\") from dual;");
            String sql3 = ("declare");
            String sql4 = ("v_app_id number;");
            String sql5 = ("begin");
            String sql6 = ("dbms_output.put_line('Holding Id='||get_hold('C1170099'));");
            String sql7 = ("select app_id into v_app_id from tddp_application where app_applicant_holding_id = get_hold('C1170099') and app_syr_code = 2022;");
            String sql8 = ("pkdp_application.DeleteApplication(v_app_id);");
            String sql9 = ("commit;");
            String sql10 = ("end;");


            // String sql = ("Select pln_app_id, gfi_herd_no, pln_plan_id, pln_ver_num, pln_plan_year From tdga_farm_info_generic, tdga_plan, tsga_plan_type where gfi_id =pln_gfi_id And gfi_sch_code = 4 And pln_plan_type = plt_plan_type_code");
            Statement statement = connection.createStatement();
            //ResultSet rs =
            //statement.executeQuery(sql0 + sql1 + sql2 + sql3 + sql4 +sql5 + sql6 + sql 7);
            //statement.executeQuery(sql0);
            //statement.executeQuery(sql1);
            statement.executeQuery(sql2);
            statement.executeQuery(sql3);
            statement.executeQuery(sql4);
            statement.executeQuery(sql5);
            statement.executeQuery(sql6);
            statement.executeQuery(sql7);
            statement.executeQuery(sql8);
            statement.executeQuery(sql9);
            statement.executeQuery(sql10);



//            while (rs.next()) {
//                //String pln_app_id = rs.getString(1);
//                System.out.println("Query is working");
//            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public void DeleteApplicationProcedure1() {
        Connection conn = null;
        String value = "jdbc:oracle:thin:@//dbconn.agriculture.gov.ie:1532/CENTEST.agriculture.gov.ie";
        String username = "BISS_DATA";
        String password = "BISS_DATA";
        try {
            conn = DriverManager.getConnection(value,username,password);
            CallableStatement cs = conn.prepareCall("{call applicationDeleter1(?)}");
            cs.registerOutParameter(1,Types.INTEGER);
            cs.execute();
            System.out.println("Execution Complete");
        } catch (SQLException e) {
            System.out.println(e);
            e.printStackTrace();
        }
        finally {
            try
            {
                conn.close();
            }
            catch (SQLException e)
            {
                System.out.println(e);
            }
        }
    }

    // endregion

    //Check pdf concept

    // endregion

    // region BISS code

    // region Common Elements

    // Agent navigate to pages through Side NavBar
    // Locators Arg Home , My Clients , Farmer Dashboard , Farm Details , Entitlement Position , Transfers , NR-CISYF , Correspondence
    public void AgentNavigateToPagesUsingSideNavBar(String Arg0) {
        if(Objects.equals(Arg0, "Transfers")) {
            By NavBarButtons = By.xpath("//mat-selection-list/descendant::span[contains(text(),'Transfer')]");
            actions.waitForVisibilityOfElement(NavBarButtons,30);
            actions.clickUsingJS(NavBarButtons);
        }
        else {
            By NavBarButtons = By.xpath("//mat-selection-list/descendant::span[contains(text(),'"+Arg0+"')]");
            actions.waitForVisibilityOfElement(NavBarButtons,30);
            actions.clickUsingJS(NavBarButtons);
        }
    }

    // Agent Click on the Next/Back Button
    // Locators Arg Next, Back, Submit
    public void AgentClickOnNextOrBackOrSubmitButton(String Arg0) throws InterruptedException {
        By BackAndNextButton = By.xpath("//button/descendant::span[contains(text(),'"+Arg0+"')]");
//        actions.waitForVisibilityOfElement(BackAndNextButton,30);
        Thread.sleep(4000);
        actions.clickUsingJS(BackAndNextButton);
    }

    public Boolean AgentVerifyNextOrBackOrSubmitButton(String Arg0) {
        By BackAndNextButton = By.xpath("//button/descendant::span[contains(text(),'"+Arg0+"')]");
        Boolean Visible = actions.waitForVisibilityOfElement(BackAndNextButton,30);
        return Visible;
    }

    // Agent Click on the Application Stepper
    // Locator Arg Check heading of each step and give as Argument
    public void AgentClickOnApplicationStepper(String Arg0) {
        By StepLink = By.xpath("//mat-step-header/descendant::div[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(StepLink,30);
        actions.clickUsingJS(StepLink);
    }

    // Agent Click on Buttons in Dialog Box
    // Locators Arg "No, cancel", "Yes, continue", "I understand", "Claim" , "Open Map" , "Cancel" , "Add" , "Cancel" , "Don't save" , "Save changes", "Next", "Yes, I confirm", "No, cancel"
    public void AgentClickOnDialogBoxButton(String Arg0) {
        if(Objects.equals(Arg0, "Open Map")) {
            By DialogBoxButton = By.xpath("//mat-dialog-container/descendant::button/span[contains(text(),'"+Arg0+"')]");
            actions.waitForVisibilityOfElement(DialogBoxButton,30);
            actions.clickUsingJS(DialogBoxButton);
            actions.clickUsingJS(DialogBoxButton);
        }
        else {
            By DialogBoxButton = By.xpath("//mat-dialog-container/descendant::button/span[contains(text(),'"+Arg0+"')]");
            actions.waitForVisibilityOfElement(DialogBoxButton,30);
            actions.clickUsingJS(DialogBoxButton);
            actions.waitforSeconds(5);
        }
    }

    // Agent Click on Close Dialog Button
    public void AgentCloseDialog() {
        By CloseButton = By.xpath("//mat-dialog-container/descendant::mat-icon[contains(text(),'close')]");
        actions.waitForVisibilityOfElement(CloseButton,30);
        actions.clickUsingJS(CloseButton);
    }

    // Agent Select Dropdown Values in Parcel and Plot Modals
    // Locators Arg0
    public void AgentSelectDropdownValues(String Arg0, String Arg1) {
        By SearchParcelDropdowns = By.xpath("//mat-select[@formcontrolname='"+Arg1+"']");
        actions.waitForVisibilityOfElement(SearchParcelDropdowns,30);
        actions.clickUsingJS(SearchParcelDropdowns);
        By CountyOrTownland = By.xpath("//span[contains(text(),'"+Arg0+"')]/ancestor::mat-option");
        actions.waitForVisibilityOfElement(CountyOrTownland, 30);
        actions.clickUsingJS(CountyOrTownland);
        actions.waitforSeconds(6);
    }

    // Store Herd Number of Application being created

    // endregion

    // region BISS Application Portal Dashboard

    // Click on the Farmer Dashboard Application Related Buttons
    // Locators Arg Delete draft, Continue application, Start application, Start amendment , Continue amendment , View entitlements
    public void AgentClickOnButtonsInFarmerDashboard(String Arg0) {
        By DashboardButtons = By.xpath("//button/descendant::span[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(DashboardButtons,30);
        actions.clickUsingJS(DashboardButtons);
    }

    // Agent Click on the links in the Farmer Dashboard
    // Locators Arg View , Read More
    public void AgentClickOnLinksInFarmerDashboard(String Arg0) {
        By FarmerDashboardLinks = By.xpath("//a[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(FarmerDashboardLinks,30);
        actions.clickUsingJS(FarmerDashboardLinks);
    }

    // Check if Application is in Draft state and delete draft
    public void AgentDeleteDraftIfStarted(String Arg0) throws InterruptedException {
        List<WebElement> DeleteDraft = driver.findElements(By.xpath("//button/descendant::span[contains(text(),'"+Arg0+"')]"));
        if(DeleteDraft.isEmpty()) {
//            AgentClickOnButtonsInFarmerDashboard("");
            System.out.println("Amendment not Started");
        }
        else {
            AgentClickOnButtonsInFarmerDashboard(Arg0);
            Thread.sleep(3000);
            AgentClickOnDialogBoxButton("Yes, delete");
//            driver.findElement(By.xpath("//mat-dialog-container/descendant::button/span[contains(text(),'Yes, delete')]")).click();
        }
    }



    // endregion

    // region Active Farmer Status Step

    // Agent Check Active Farmer Status if Active or Not Active
    // Arg0 : Grassland / Tillage
    // Arg1 : Grassland (Making Hay/Silage/Haylage, Topping, Other Grazing livestock e.g.Equines, Plan to purchase livestock in 2023 (payment may be delayed), Landscape Feature Maintenance, Other)
    public void AgentCheckActivityStatusLabelText(String FarmingPractice, String GrasslandOrTillageActivity) throws InterruptedException {
        String ActiveStatusText = driver.findElement(By.xpath("(//mat-card-content[contains(@class,'mat-card-content')]/descendant::div[3])[1]")).getText();
        String ActiveFarmer = driver.findElement(By.xpath("//div[@class='active-farmer-status-description']/div[1]")).getText();
        System.out.println(ActiveStatusText);

        if (Objects.equals(ActiveFarmer, "Not Active!")) {
            if (Objects.equals(FarmingPractice, "Grassland")) {
                //AgentClickOnCheckbox(GrasslandActivity);
                By RadioButton = By.xpath("//mat-radio-button/descendant::span[contains(text(),'" + FarmingPractice + "')]");
                actions.clickUsingJS(RadioButton);
                if (Objects.equals(GrasslandOrTillageActivity, "Others")) {
                    By OtherNotes = By.xpath("//textarea[@formcontrolname='note']");
                    actions.sendKeys(OtherNotes, "");
                } else {
                    By CheckBoxOptions = By.xpath("//mat-checkbox/descendant::span[contains(text(),'"+GrasslandOrTillageActivity+"')]");
                    actions.clickUsingJS(CheckBoxOptions);
                }
            }
            else if (Objects.equals(FarmingPractice, "Tillage")) {
                By RadioButton = By.xpath("//mat-radio-button/descendant::span[contains(text(),'" + FarmingPractice + "')]");
                actions.clickUsingJS(RadioButton);
                if (Objects.equals(GrasslandOrTillageActivity, "Others")) {
                    By OtherNotes = By.xpath("//textarea[@formcontrolname='note']");
                    actions.sendKeys(OtherNotes, "");
                } else {
                    By CheckBoxOptions = By.xpath("//mat-checkbox/descendant::span[contains(text(),'"+GrasslandOrTillageActivity+"')]");
                    actions.clickUsingJS(CheckBoxOptions);
                }
            }
        }
        else if (Objects.equals(ActiveFarmer,"Active Farmer")) {
            AgentClickOnNextOrBackOrSubmitButton("Next");
        }
    }

    // Agent Click on a Checkbox in Active Farmer Section
    // Locators Arg "Check the options for the Checkboxes"
    public void AgentClickOnCheckbox(String Arg0) {
        By CheckBoxOptions = By.xpath("//mat-checkbox/descendant::span[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(CheckBoxOptions,30);
        actions.clickUsingJS(CheckBoxOptions);
    }

    // Agent Check for Warning Message if Checkbox not selected
    public void AgentCheckActiveFarmerStatusWarning() {
        By WarningMessage=By.xpath("//mat-error[contains(text(),'You must select an option')]");
        actions.waitForVisibilityOfElement(WarningMessage,30);
        actions.clickUsingJS(WarningMessage);
    }

    // endregion

    // region Scheme Selection Step

    // Agent Click on Cards in the Scheme Selection Page
    // Locators Arg BISS , CRISS , ANC , Eco , Organics , SIM , Protein Aid Scheme
    public void AgentClickOnSchemeCard(String Arg0) {
        By SchemeCards = By.xpath("//mat-card/descendant::span[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(SchemeCards,30);
        actions.clickUsingJS(SchemeCards);
    }

    // endregion

    //region Land Details Step
    // Locators
    By CommonagePlotCheckBox = By.xpath("//span[contains(text(),'Commonage Plot')]");
    By MandatoryInfoWarning = By.xpath("//div[contains(text(),'Your application is missing mandatory information.')]");

    // Agent Check Mandatory Information Warning
    public void AgentCheckMandatoryInfoWarning() throws InterruptedException {
        Boolean visibility = driver.findElement(MandatoryInfoWarning).isDisplayed();
        if (visibility.equals(true)) {
            AgentClickOnNextOrBackOrSubmitButton("Back");
            AgentClickOnSchemeCard("Organics");
            AgentClickOnNextOrBackOrSubmitButton("Next");
            AgentClickOnDialogBoxButton("I understand");
        }
        else {
            System.out.println("No Mandatory Warnings");
        }
    }

    // Agent Check for Archived Parcel
    public void AgentCheckForArchivedParcelMessage() {
        By Warning = By.xpath("//div[contains(text(),'Your parcel has been archived, the new parcel iteration is below')]");
        WebElement WarningMessage = driver.findElement(Warning);
        if (WarningMessage.isDisplayed()){
            System.out.println("Parcel is Archived");
        }
    }

    // Agent Click On Parcel in List
    public void AgentClickOnParcelInList(String Arg0) {
        By ParcelInList = By.xpath("//td[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(ParcelInList,30);
        actions.clickUsingJS(ParcelInList);
        driver.findElement(CommonagePlotCheckBox);
    }

    // Agent Click on Add Plot/Parcel Button
    // Locators Arg Add parcel, Add plot
    public void AgentClickOnAddPlotOrAddParcelButton(String Arg0) {
        By AddPlotOrParcelButton = By.xpath("//button/descendant::span[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(AddPlotOrParcelButton, 30);
        actions.clickUsingJS(AddPlotOrParcelButton);
        actions.waitforSeconds(4);
    }

    // region Warning Messages

    // Check angular error Warning Messages in the dialog
    public String AgentCheckWarningMessageInDialog() {
        String DialogWarning = driver.findElement(By.xpath("//mat-error/descendant::span")).getText();
        return DialogWarning;
    }

    // Check biss error panel Warning Messages
    public String AgentCheckBissPanelWarningMessages() {
        String DialogWarning = driver.findElement(By.xpath("//biss-error-panel/descendant::div[contains(text(),'You have already claimed this parcel. To modify a claim on a parcel, please return to the land details list and amend the parcels details.')]")).getText();
        return DialogWarning;
    }


    // endregion

    // Agent populate input fields in Parcel or Plot modal
    // Locator Arg parcelInput , claimedArea , plotReference
    public void AgentEnterValueInAddPlotOrParcelDialog(String Arg0, String Arg1) {
        By ParcelSearchInput = By.xpath("//mat-dialog-container/descendant::input[@id='"+Arg1+"']");
        actions.waitForVisibilityOfElement(ParcelSearchInput,30);
        actions.sendKeys(ParcelSearchInput,Arg0);
    }

    // Agent Select Dropdown Values in Parcel and Plot Modals
    // Locators Arg county, townland , ownershipStatus , parcelUse , organicStatus , agriculturalActivity , plotUse
    public void AgentSelectDropdownValuesInParcelAndPlotModal(String Arg0, String Arg1) {
        By SearchParcelDropdowns = By.xpath("//mat-select[@formcontrolname='"+Arg1+"']");
        actions.waitForVisibilityOfElement(SearchParcelDropdowns,30);
        actions.clickUsingJS(SearchParcelDropdowns);
        By CountyOrTownland = By.xpath("//span[contains(text(),'"+Arg0+"')]/ancestor::mat-option");
        actions.waitForVisibilityOfElement(CountyOrTownland, 30);
        actions.clickUsingJS(CountyOrTownland);
        actions.waitforSeconds(6);
    }

    // Agent Click on Radio Buttons inside the Dialog Box
    // Locators Arg Edit Map Online , Upload Map , Submit Paper Map By Post
    public void AgentClickOnRadioButtonsInDialogBox(String Arg0) {
        By MapChangesRadioButton = By.xpath("//mat-radio-button/descendant::span[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(MapChangesRadioButton,30);
        actions.clickUsingJS(MapChangesRadioButton);
    }

    // Select Parcel On Map
    public void AgentSelectParcelOnMapScreen() {
        actions.waitforSeconds(5);
        Actions act = new Actions(driver);
        WebElement el = driver.findElement(By.xpath("//span[@id ='outer-west-resizer']"));
        act.moveToElement(el, 450, 234).click().build().perform();
        actions.waitforSeconds(2);
        act.moveToElement(el, 450, 234).click().build().perform();
        actions.waitforSeconds(2);
        act.moveToElement(el, 450, 234).click().build().perform();
        actions.waitforSeconds(2);
//        act.moveToElement(el, 450, 234).click().build().perform();
        System.out.println("Map Clicked");
        actions.waitforSeconds(5);
    }

    // Click on Select Feature Tool in GIS Application
    public void AgentClickOnSelectFeatureToolInGIS(String Arg0) {
        actions.waitforSeconds(4);
        By SelectFeature = By.xpath("//a/descendant::span[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(SelectFeature,50);
        actions.clickUsingJS(SelectFeature);
        actions.waitforSeconds(10);
    }

    // Claim Parcel On Map
    public void AgentClickOnMapPageClaimParcelButton() {
        By MapPageClaimParcelButton = By.xpath("//button[contains(text(),'Claim')]");
        actions.waitForVisibilityOfElement(MapPageClaimParcelButton,15);
        actions.clickUsingJS(MapPageClaimParcelButton);
    }

    // Clicking on the Commonage Plot Checkbox
    public void AgentClickOnCommonageCheckBox() {
        actions.waitForVisibilityOfElement(CommonagePlotCheckBox,30);
        actions.clickUsingJS(CommonagePlotCheckBox);
    }

    // Agent populate Commonage fraction Numerator and Denominator
    // Locator Arg commonageNumerator , commonageDenominator
    public void AgentPopulateCommonageFraction(String Arg0, String Arg1) {
        By CommonageFractionFields = By.xpath("//mat-dialog-container/descendant::input[@formcontrolname='"+Arg0+"']");
        actions.waitForVisibilityOfElement(CommonageFractionFields,30);
        actions.sendKeys(CommonageFractionFields,Arg1);
    }

    // Clicking on Add Plot Map Amendment Radio Buttons
    public void AgentClickOnRadioButton(String Arg0) {
        By PlotRadioButtons = By.xpath("//mat-radio-button/descendant::span[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(PlotRadioButtons,30);
        actions.clickUsingJS(PlotRadioButtons);
    }

    // Clicking on the Quick Filter Tabs
    // Locators Arg View All , Action Required
    public void AgentClickOnQuickFilterTabs(String Arg0) {
        By QuickFilterButtons = By.xpath("//mat-button-toggle-group/descendant::button/span[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(QuickFilterButtons,30);
        actions.clickUsingJS(QuickFilterButtons);
    }

    // Agent Click on SideNav Links in Map Application (To be used mainly after View Map Button in Parcel List)
    // Locators Arg0 'Select Feature', 'Deselect All', 'Measure', 'Toggle Legend', 'Close', Return to Land Details
    public void AgentClickOnNavLinksInMap(String Arg0) throws InterruptedException {
        By MapsNavLink = By.xpath("//a/descendant::span[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(MapsNavLink,30);
        actions.clickUsingJS(MapsNavLink);
        Thread.sleep(5000);
    }

    // region Side Drawer

    // Locators
    By EligibleHectareChange = By.xpath("//mat-dialog-container/descendant::div/mat-checkbox[@formcontrolname='requestChangeEh']/descendant::input");
    By ReasonForEhChangeTextBox = By.xpath("//mat-dialog-container/descendant::textarea[@formcontrolname='reasonEhChange']");

    // Agent Open Side Drawer for First Parcel in List
    public void AgentSelectFirstParcelInList() {
        By FirstParcel = By.xpath("(//td[contains(@class,'cdk-column-parcelRef')])[1]");
        actions.clickUsingJS(FirstParcel);
    }

    // Agent add 5.2 to Claimed Area Value and close side Drawer
    public void AgentChangeClaimedArea() throws InterruptedException {
        By ClaimedArea = By.xpath("(//td[contains(@class,'cdk-column-claimedArea')])[1]");
        BigDecimal ClaimedAreaText = new BigDecimal(driver.findElement(ClaimedArea).getText());
        AgentSelectFirstParcelInList();
        Thread.sleep(2000);
        By ClaimedAreaIDField = By.id("claimedArea");

        By ClaimedAreaField = By.xpath("//mat-dialog-container/descendant::input[@formcontrolname='claimedArea']");
        BigDecimal Constant = BigDecimal.valueOf(5.2);
//        float ClaimedAreaValue = Float.parseFloat(ClaimedAreaText);
        Thread.sleep(2000);
        driver.findElement(ClaimedAreaField).clear();
        Thread.sleep(2000);
        BigDecimal UpdatedValue = Constant.add(ClaimedAreaText);
        Thread.sleep(2000);
        actions.sendKeys(ClaimedAreaField, String.valueOf(UpdatedValue));
    }

    // Agent Change Claimed Area in AMS
    public void AgentChangeClaimedAreaInAMS() throws InterruptedException {
        By ClaimedAreaField = By.xpath("//mat-dialog-container/descendant::input[@formcontrolname='claimedArea']");
        BigDecimal Constant = BigDecimal.valueOf(0.5);
//        float ClaimedAreaValue = Float.parseFloat(ClaimedAreaText);
        Thread.sleep(2000);
        driver.findElement(ClaimedAreaField).clear();
        Thread.sleep(2000);
        BigDecimal UpdatedValue = Constant.add(BigDecimal.valueOf(14));
        Thread.sleep(2000);
        actions.sendKeys(ClaimedAreaField, String.valueOf(UpdatedValue));
        Thread.sleep(5000);
    }

    // Agent Open Side Drawer for Parcel/Plot by clicking on Parcel Number in list
    public void AgentClickOnPlotReferenceToOpenSideDrawer(String Arg0) {
        By PlotReference = By.xpath("//td/span[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(PlotReference,30);
        actions.clickUsingJS(PlotReference);
    }

    // Agent move to previous or next parcel or click close button in the Side Drawer
    // Locator Arg Close, Previous land, Next land
    public void AgentChangeParcelOrCloseSideDrawer(String Arg0) {
        By BackAndFrontButton = By.xpath("//mat-dialog-container/descendant::mat-icon[@aria-label="+Arg0+"]");
        actions.waitForVisibilityOfElement(BackAndFrontButton,30);
        actions.clickUsingJS(BackAndFrontButton);
    }

    // Agent Click on the Eligible Hectare Change Request CheckBox
    public void AgentClickOnReqEhChangeCheckBox() throws InterruptedException {
        actions.waitForVisibilityOfElement(EligibleHectareChange,50);
        actions.clickUsingJS(EligibleHectareChange);
    }

    // Agent Click on Eligible Hectare Change Request CheckBox and enter reason in TextBox
    public void AgentEnterReasonForEhChange(String Arg0) throws InterruptedException {
        // Enter Text
        actions.waitForVisibilityOfElement(ReasonForEhChangeTextBox,30);
        actions.sendKeys(ReasonForEhChangeTextBox,Arg0);
    }

    // Agent perform actions on parcel inside side drawer
    // Locators Arg Edit Map , Subdivide parcel, Delete parcel
    public void AgentClickOnActionsInEditParcelDrawer(String Arg0) {
        By ActionButtons = By.xpath("//button/descendant::mat-icon[@aria-label='"+Arg0+"']");
        actions.waitForVisibilityOfElement(ActionButtons,30);
        actions.clickUsingJS(ActionButtons);
    }

    // Agent Edit Value in Claimed Area Field
    public void AgentEditValueInSideDrawerFields() {
        By ClaimedAreaField = By.xpath("//mat-dialog-container/descendant::input[@formcontrolname='claimedArea']");
        actions.waitForVisibilityOfElement(ClaimedAreaField,30);
        actions.clickUsingJS(ClaimedAreaField);
    }


    // Click on the dropdown in the Side Drawer
    // Locator Arg ownershipStatus , parcelUse , organicStatus
    public void AgentOpenSideDrawerDropdown(String Arg0) {
        String Locator = "//mat-dialog-container/descendant::mat-select[@formcontrolname='"+Arg0+"']";
        By AddPlotDropdowns = By.xpath(Locator);
        actions.waitForVisibilityOfElement(AddPlotDropdowns, 30);
        actions.clickUsingJS(AddPlotDropdowns);
    }

    // Agent Select Value from Dropdown in Side Drawer
    public void AgentSelectValueFromSideDrawerDropdown(String Dropdown, String Value) {
        AgentOpenSideDrawerDropdown(Dropdown);
        By DropDownValue = By.xpath("//span[contains(text(),'"+Value+"')]/ancestor::mat-option");
        actions.waitForVisibilityOfElement(DropDownValue, 30);
        actions.clickUsingJS(DropDownValue);
    }

    // Agent Click on Buttons in Side Drawer
    // Locator Cancel, Save changes
    public void AgentClickOnSideDrawerButtons(String Arg0) {
        By SideDrawerButtons = By.xpath("//mat-dialog-container/descendant::button/span[text()=' "+Arg0+" ']");
        actions.waitForVisibilityOfElement(SideDrawerButtons,30);
        actions.clickUsingJS(SideDrawerButtons);
    }


    // Agent Check for Over Claim Warning
    public void AgentCheckForOverClaimWarning() {
        By OverClaimWarning = By.xpath("//div[contains(text(),'A parcel of land has an overclaim warning.')]");
        Boolean ClaimWarning = driver.findElement(OverClaimWarning).isDisplayed();
        List<WebElement> ClaimWarningVisibility = driver.findElements(OverClaimWarning);
        if (ClaimWarningVisibility.isEmpty()) {
            System.out.println("Overclaim Warning not displayed");
        }
        else {
            System.out.println("Overclaim Warning displayed");
        }
    }
    // endregion

    // Parcel or Plot List Methods

    //region Agent Click on any Action Column Button


    // Execution of Click Actions button by isolating the Switch Case logic to Action Class
    public void AgentClickActionButtonLogic(String ParcelNo, int ColumnCase, String ActionsColumnButton) throws InterruptedException {
        WebElement ActionsButtonColumn = actions.ClickActionsButton(ParcelNo,ColumnCase,ActionsColumnButton);
        actions.clickWebElementUsingJS(ActionsButtonColumn);
        Thread.sleep(5000);
        //        JavascriptExecutor executor = (JavascriptExecutor)driver;
//        executor.executeScript("arguments[0].click();", ActionsButtonColumn);
        //        WebElement ActionsButtonColumn = ClickActionsButton(ParcelNo,ColumnCase, ActionsColumnButton);
        //        actions.waitForVisibilityOfWebElement(ActionsButtonColumn,30);
        //        actions.clickWebElementUsingJS(ActionsButtonColumn);
    }

    // Click on the button in the Land Details page
    // Actions Column Locators : Open map, Subdivide parcel, Undo deletion
    // Agent find the row number of the parcel to be deleted
    public void RowNumberContainingParcelAndAction(String ParcelNo, String ActionsColumnButton) {
        List<WebElement> ParcelList = driver.findElements(By.xpath("//td[contains(@class,'cdk-column-parcelRef')]"));
        int NumberOfParcel = ParcelList.size();
        for (int n = 0; n <= NumberOfParcel; n++) {
            String ParcelNum = ParcelList.get(n).getText();
            if (ParcelNum.equals(ParcelNo))
            {
                n = n+1;
                List<WebElement> ParcelActionButton = driver.findElements(By.xpath("(//td[contains(@class,'cdk-column-options')])["+n+"]/descendant::button[contains(@title,'"+ActionsColumnButton+"')]"));
                if(ParcelActionButton.isEmpty())
                {
                    System.out.println(ActionsColumnButton+" is not present");
                    break;
                }
                else
                {
                    actions.ClickLandDetailsAction(n,ActionsColumnButton);
                    break;
                }
            }
        }
    }

    // Undo Deletion
    public void UndoDeletionOfParcel() {
        By UndoDeletion = By.xpath("//td/descendant::button[contains(@title,'Undo deletion')]");
        actions.waitForVisibilityOfElement(UndoDeletion,50);
        actions.clickUsingJS(UndoDeletion);
    }

        /**
//    public void PrintTheRowNumber(String ParcelNo) {
//        System.out.println("Parcel is present in the row : " + RowNumberContainingParcel(ParcelNo));
//    }
         N1010991
    // Agent Click on any Action Button for a particular Parcel (Main method to be called in stepdefinition)
    // ParcelNo : Pass the desired Parcel Number
    // Actions Column : map , delete , content_cut(subdivide parcel), undo
//    public void AgentClickOnActionsButtonInParcelList(String ParcelNo, String ActionsColumn) throws InterruptedException {
//        Boolean CommonageFraction = ! driver.findElements(By.xpath("//td[contains(@class,'mat-column-commonageFraction')]")).isEmpty();
//        Boolean AgriculturalActivity = ! driver.findElements(By.xpath("//td[contains(@class,'mat-column-maintenance')]")).isEmpty();
//        Boolean OrganicColumn = ! driver.findElements(By.xpath("//td[contains(@class,'mat-column-organicStatus')]")).isEmpty();
//        Boolean AncColumn = ! driver.findElements(By.xpath("//td[contains(@class,'mat-column-anc')]")).isEmpty();
//        Boolean Acres = ! driver.findElements(By.xpath("//td[contains(@class,'mat-column-acres')]")).isEmpty();
//
//        // New Logic with 5 Optional Columns
//        //00000
//        if (CommonageFraction.equals(false) && AgriculturalActivity.equals(false) && OrganicColumn.equals(false) && AncColumn.equals(false) && Acres.equals(false)) {
//            AgentClickActionButtonLogic(ParcelNo,0,ActionsColumn);
//        }
//        //00001
//        //00010
//        //00011
//        //00100
//        //00101
//        //00110
//        //00111
//        //01000
//        //01001
//        //01010
//        //01011
//        //01100
//        //01101
//        //01110
//        //01111
//        //10000
//        //10001
//        //10010
//        //10011
//        //10100
//        //10101
//        //10110
//        //10111
//        //11000
//        //11001
//        //11010
//        //11011
//        //11100
//        //11101
//        //11110
//        //11111
//
//
//        // Old Logic with four optional columns
//        //0000
//        if(CommonageFraction.equals(false) && AgriculturalActivity.equals(false) && OrganicColumn.equals(false) && AncColumn.equals(false)) {
//            AgentClickActionButtonLogic(ParcelNo,0,ActionsColumn);
//        }
//
//        //0001
//        else if(CommonageFraction.equals(false) && AgriculturalActivity.equals(false) && OrganicColumn.equals(false) && AncColumn.equals(true)) {
//            AgentClickActionButtonLogic(ParcelNo,1,ActionsColumn);
//        }
//
//        //0010
//        else if(CommonageFraction.equals(false) && AgriculturalActivity.equals(false) && OrganicColumn.equals(true) && AncColumn.equals(false)) {
//            AgentClickActionButtonLogic(ParcelNo,2,ActionsColumn);
//        }
//
//        //0011
//        else if(CommonageFraction.equals(false) && AgriculturalActivity.equals(false) && OrganicColumn.equals(true) && AncColumn.equals(true)) {
//            AgentClickActionButtonLogic(ParcelNo,3,ActionsColumn);
//        }
//
//        //0100
//        else if(CommonageFraction.equals(false) && AgriculturalActivity.equals(true) && OrganicColumn.equals(false) && AncColumn.equals(false)) {
//            AgentClickActionButtonLogic(ParcelNo,4,ActionsColumn);
//        }
//
//        //0101
//        else if(CommonageFraction.equals(false) && AgriculturalActivity.equals(true) && OrganicColumn.equals(false) && AncColumn.equals(true)) {
//            AgentClickActionButtonLogic(ParcelNo,5,ActionsColumn);
//        }
//
//        //0110
//        else if(CommonageFraction.equals(false) && AgriculturalActivity.equals(true) && OrganicColumn.equals(true) && AncColumn.equals(false)) {
//            AgentClickActionButtonLogic(ParcelNo,6,ActionsColumn);
//        }
//
//        //0111
//        else if(CommonageFraction.equals(false) && AgriculturalActivity.equals(true) && OrganicColumn.equals(true) && AncColumn.equals(true)) {
//            AgentClickActionButtonLogic(ParcelNo,7,ActionsColumn);
//        }
//
//        //1000
//        else if(CommonageFraction.equals(true) && AgriculturalActivity.equals(false) && OrganicColumn.equals(false) && AncColumn.equals(false)) {
//            AgentClickActionButtonLogic(ParcelNo,8,ActionsColumn);
//        }
//
//        //1001
//        else if(CommonageFraction.equals(true) && AgriculturalActivity.equals(false) && OrganicColumn.equals(false) && AncColumn.equals(true)) {
//            AgentClickActionButtonLogic(ParcelNo,9,ActionsColumn);
//        }
//
//        //1010
//        else if(CommonageFraction.equals(true) && AgriculturalActivity.equals(false) && OrganicColumn.equals(true) && AncColumn.equals(false)) {
//            AgentClickActionButtonLogic(ParcelNo,10,ActionsColumn);
//        }
//
//        //1011
//        else if(CommonageFraction.equals(true) && AgriculturalActivity.equals(false) && OrganicColumn.equals(true) && AncColumn.equals(true)) {
//            AgentClickActionButtonLogic(ParcelNo,11,ActionsColumn);
//        }
//
//        //1100
//        else if(CommonageFraction.equals(true) && AgriculturalActivity.equals(true) && OrganicColumn.equals(false) && AncColumn.equals(false)) {
//            AgentClickActionButtonLogic(ParcelNo,12,ActionsColumn);
//        }
//
//        //1101
//        else if(CommonageFraction.equals(true) && AgriculturalActivity.equals(true) && OrganicColumn.equals(false) && AncColumn.equals(true)) {
//            AgentClickActionButtonLogic(ParcelNo,13,ActionsColumn);
//        }
//
//        //1110
//        else if(CommonageFraction.equals(true) && AgriculturalActivity.equals(true) && OrganicColumn.equals(true) && AncColumn.equals(false)) {
//            AgentClickActionButtonLogic(ParcelNo,14,ActionsColumn);
//        }
//
//        //1111
//        else if(CommonageFraction.equals(true) && AgriculturalActivity.equals(true) && OrganicColumn.equals(true) && AncColumn.equals(true)) {
//            AgentClickActionButtonLogic(ParcelNo,15,ActionsColumn);
//        }
//    }
**/
    // endregion


    // endregion

    // region GAEC8 Step

    // Agent Select GAEC8 Contribution for a parcel
    public void AgentSelectGAEC8ContributionForAParcel(String ParcelNo, String Contribution) {
        WebElement ParcelNumber = driver.findElement(By.xpath("//td/div[contains(text(),'"+ParcelNo+"')]"));
        WebElement ParcelUse = driver.findElement(By.xpath("//td[contains(@class,'cdk-column-parcelUse')]"));
        WebElement GAEC8contribution = driver.findElement(with(By.xpath("//td/descendant::mat-select"))
                .toRightOf(ParcelUse)
                .toRightOf(ParcelNumber));
//        actions.waitForVisibilityOfWebElement(GAEC8contribution,50);
        actions.clickWebElementUsingJS(GAEC8contribution);
        By ContributionType = By.xpath("//span[contains(text(),'"+Contribution+"')]/ancestor::mat-option");
//        actions.waitForVisibilityOfElement(ContributionType, 50);
        actions.clickUsingJS(ContributionType);
    }

    // Agent Click on the View Map Button for a Particular Parcel
    public void AgentClickOnViewMapForParcel(String ParcelNo) {
        WebElement ParcelNumber = driver.findElement(By.xpath("//td/div[contains(text(),'"+ParcelNo+"')]"));
        WebElement ParcelUse = driver.findElement(By.xpath("//td[contains(@class,'cdk-column-parcelUse')]"));
        WebElement GAEC8contribution = driver.findElement(By.xpath("//td/descendant::mat-select"));
        WebElement ObligationArea = driver.findElement(By.xpath("//td[contains(@class,'cdk-column-parcelArea')]"));
        WebElement GAEC8Area = driver.findElement(By.xpath("//td[contains(@class,'cdk-column-totalSfnArea')]"));
        WebElement ClickMapButton = driver.findElement(with(By.xpath("//td/descendant::button[@aria-label='View map']"))
                .toRightOf(GAEC8Area)
                .toRightOf(ObligationArea)
                .toRightOf(GAEC8contribution)
                .toRightOf(ParcelUse)
                .toRightOf(ParcelNumber));
        ClickMapButton.click();
//        actions.waitForVisibilityOfWebElement(ClickMapButton,30);
//        actions.clickWebElementUsingJS(ClickMapButton);
    }

    // Agent Expand the Parcel In the List
    public void AgentExpandParcelInList(String Arg0) {
        WebElement ParcelNumber = driver.findElement(By.xpath("//td/div[contains(text(),'"+Arg0+"')]"));
        WebElement ParcelUse = driver.findElement(By.xpath("//td[contains(@class,'cdk-column-parcelUse')]"));
        WebElement GAEC8contribution = driver.findElement(By.xpath("//td/descendant::mat-select"));
        WebElement ObligationArea = driver.findElement(By.xpath("//td[contains(@class,'cdk-column-parcelArea')]"));
        WebElement GAEC8Area = driver.findElement(By.xpath("//td[contains(@class,'cdk-column-totalSfnArea')]"));
        WebElement MapButton = driver.findElement(By.xpath("//td/descendant::button[@aria-label='View map']"));
        WebElement ClickExpandButton = driver.findElement(with(By.xpath("//td[@title='Expand/Collapse']"))
                .toRightOf(MapButton)
                .toRightOf(GAEC8Area)
                .toRightOf(ObligationArea)
                .toRightOf(GAEC8contribution)
                .toRightOf(ParcelUse)
                .toRightOf(ParcelNumber));
        ClickExpandButton.click();
//        actions.waitForVisibilityOfWebElement(ClickExpandButton,30);
//        actions.clickWebElementUsingJS(ClickExpandButton);
    }

    // Agent hover over the information buttons to show detailed widget
    // locator Arg "sfn-status-contribution" , "sfn-area-info-block" , "land-table-container"
    public void AgentHoverOverInformationWidget(String Arg0) {
        Actions act = new Actions(driver);
        WebElement InfoButton = driver.findElement(By.xpath("//div[@class='"+Arg0+"']/descendant::mat-icon[1]"));
        act.moveToElement(InfoButton);
    }

    // Get the SFN Contribution Value
    public void CaptureSFNContributionValue() {
        WebElement ContributionValueText = driver.findElement(By.xpath("//div[@class='sfn-status-contribution-value']/descendant::span"));
        String ContributionValueString = ContributionValueText.getText();
        String[] Value = ContributionValueString.split("%");
        float ContributionValue = Float.parseFloat(Value[0]);
        Boolean ValueCheck = ContributionValue > 3;
        System.out.println(ValueCheck);
        if(ValueCheck.equals(true)) {
            System.out.println("Eligible for GAEC8");
        }
        else {
            System.out.println("Not Eligible for GAEC8");
        }
    }

    // endregion

    // region Eco Tab

    // Agent Select Checkbox for BISS Application without Eco-scheme
    public void AgentClickOnCheckBoxForNoEcoScheme() {
        By NoEcoCheckBox = By.xpath("//mat-card[contains(@class,'eco-opt-out')]/descendant::input[@type='checkbox']");
//        actions.waitForVisibilityOfElement(NoEcoCheckBox,30);
        actions.clickUsingJS(NoEcoCheckBox);
    }

    public void AgentCheckIfOptOutOfSchemePresentAndProceed() {
        List<WebElement> EcoSchemeOptOut = driver.findElements(By.xpath("//mat-card[contains(@class,'eco-opt-out')]/descendant::input[@type='checkbox']"));
        if(EcoSchemeOptOut.isEmpty()) {
            System.out.println("Agricultural Practices Selected");
        }
        else {
            By NoEcoCheckBox = By.xpath("//mat-card[contains(@class,'eco-opt-out')]/descendant::input[@type='checkbox']");
            Boolean ToggleStatus = driver.findElement(NoEcoCheckBox).isSelected();
            if(ToggleStatus.equals(true)){
                System.out.println("Eco Scheme Opted out Already");
            }
            else {
                AgentClickOnCheckBoxForNoEcoScheme();
            }
        }
    }

    // Toggle Switch for Eco Scheme Page
    public void EcoSchemeToggleClick(int n) {
        By ToggleButtonOfChoice = By.xpath("(//mat-slide-toggle)["+n+"]");
        actions.waitForVisibilityOfElement(ToggleButtonOfChoice,30);
        actions.clickUsingJS(ToggleButtonOfChoice);
    }

    // Agent Control Toggles in the Eco Page
    public void AgentControlTogglesInEcoPage(String EcoSchemeOption) {
//        WebElement OptionsForEcoHeading = driver.findElement(By.xpath("//td[contains(text(),'"+EcoSchemeOption+"')]"));
//        WebElement ToggleButton = driver.findElement(with(By.xpath("//mat-slide-toggle"))
//                .toRightOf(OptionsForEcoHeading));
//        actions.waitForVisibilityOfWebElement(ToggleButton,30);
//        actions.clickWebElementUsingJS(ToggleButton);
//

        switch (EcoSchemeOption) {
            case "AP1" : {
                int n = 1;
                EcoSchemeToggleClick(n);
                break;
            }
            case "AP2" : {
                int n = 2;
                EcoSchemeToggleClick(n);
                break;
            }
            case "AP4" : {
                int n = 3;
                EcoSchemeToggleClick(n);
                break;
            }
            case "AP5" : {
                int n = 4;
                EcoSchemeToggleClick(n);
                break;
            }
            case "AP6" : {
                int n = 5;
                EcoSchemeToggleClick(n);
                break;
            }
        }
    }

    // Agent Click on the Checkbox inside Eco Options
    public void AgentClickOnCheckBoxForEcoScheme(String EcoScheme) throws InterruptedException {
        if(EcoScheme.equals("ap6")){
            List <WebElement> CheckBoxes = driver.findElements(By.xpath("//div[contains(@class,'eco-"+EcoScheme+"-container')]/descendant::mat-checkbox/descendant::input[@type='checkbox']"));
            int Numofcheckboxes = CheckBoxes.size();
            System.out.println(Numofcheckboxes);
            for (int i=1;i<=Numofcheckboxes;i++) {
                By CheckBox = By.xpath("//div[contains(@class,'eco-"+EcoScheme+"-container')]/descendant::input["+i+"]");
//                actions.waitForVisibilityOfElement(CheckBox,50);
                actions.clickUsingJS(CheckBox);
            }
        }
        else {
            By CheckBox = By.xpath("//div[contains(@class,'eco-"+EcoScheme+"-container')]/descendant::mat-checkbox/descendant::input[@type='checkbox']");
            Thread.sleep(3000);
            actions.waitForVisibilityOfElement(CheckBox,30);
            actions.clickUsingJS(CheckBox);
        }
    }

    // Agent Click on Save and Select Button for Eco Options
    public void AgentClickOnSaveAndSelectButton(String EcoScheme) {
        By SaveAndSelectButton = By.xpath("//div[contains(@class,'eco-"+EcoScheme+"-container')]/descendant::button/span[contains(text(),'Save & Select')]");
        actions.waitForVisibilityOfElement(SaveAndSelectButton,50);
        actions.clickUsingJS(SaveAndSelectButton);
    }


    // Agent Click on Radio Button Options in AP4 Eco Scheme
    public void AgentClickOnRadioButtonInAP4Scheme(String Option) {
        By AP4SchemeRadioButtons = By.xpath("//input[@type='radio' and @value='"+Option+"']");
//        actions.waitForVisibilityOfElement(AP4SchemeRadioButtons,50);
        actions.clickUsingJS(AP4SchemeRadioButtons);
    }

    // Agent Select Fertiliser Spreader/Sprayer in AP5 Eco-Scheme
    public void AgentClickOnRadioButtonInAP5(String Type) throws InterruptedException {
        By AP5SchemeRadioButtons = By.xpath("//mat-radio-group[@formcontrolname='gpsType']/descendant::input[@value='"+Type+"']");
//        By AP5RadioButtons = By.xpath("//mat-radio-group[@formcontrolname='gpsType']");
        actions.scrollByUsingJS(AP5SchemeRadioButtons);
//        actions.waitForVisibilityOfElement(AP5SchemeRadioButtons,100);
        actions.clickUsingJS(AP5SchemeRadioButtons);
    }

    // Agent Select Approved Spreader for AP5
    // Locators Arg0 : selectedSpreaderManufacturer, spreaderModel
    // Locators Arg1 : Make or Model from dropdown
    public void AgentSelectDropdownValuesForApprovedSpreader(String Dropdown, String SpreaderChoice) {
        By SearchSpreaderDropdown = By.xpath("//mat-select[@formcontrolname='"+Dropdown+"']");
        actions.waitForVisibilityOfElement(SearchSpreaderDropdown,30);
        actions.clickUsingJS(SearchSpreaderDropdown);
        By ApprovedSpreader = By.xpath("//span[contains(text(),'"+SpreaderChoice+"')]/ancestor::mat-option");
        actions.waitForVisibilityOfElement(ApprovedSpreader, 30);
        actions.clickUsingJS(ApprovedSpreader);
        actions.waitforSeconds(4);
    }

    // Agent fill in Text Boxes in AP5 Scheme
    // Locators Arg : spreaderSerialNo, sprayerManufacturer, sprayerSerialNo, contractorName
    public void AgentFillInTheAP5TextBoxes(String Text, String AP5TextBoxType) {
        By AP5TextBoxes = By.xpath("//input[@formcontrolname='"+AP5TextBoxType+"']");
        actions.waitForVisibilityOfElement(AP5TextBoxes,50);
        actions.sendKeys(AP5TextBoxes,Text);
    }

    // Check Warning in Eco Page
    public void EcoWarningMessageCheck() {
        By EcoWarning = By.xpath("//span[contains(text(),'You must select 2 Agricultural Practices to proceed')]");
        List <WebElement> Warning = driver.findElements(EcoWarning);
        if(Warning.isEmpty()) {
            System.out.println("Eco Warning not Displayed");
        }
        else {
            System.out.println("Eco Warning Displayed");
        }
    }

    public Boolean CheckIfToggleEnabled() {
        By NoEcoCheckBox = By.xpath("//mat-card[contains(@class,'eco-opt-out')]/descendant::input[@type='checkbox']");
        Boolean ToggleStatus = driver.findElement(NoEcoCheckBox).isSelected();
        return ToggleStatus;
    }
    // endregion

    // region ACRES page
    public void CheckAcresPageAndClickNext() throws InterruptedException {
        By ACRESstepper = By.xpath("//mat-step-header/descendant::div[contains(text(),'ACRES')]");
        List<WebElement> ACRESvisibility = driver.findElements(ACRESstepper);
        if(ACRESvisibility.isEmpty()) {
            System.out.println("No ACRES Page");
        }
        else {
            AgentClickOnNextOrBackOrSubmitButton("Next");
        }
    }
    // endregion


    // region Review and Submit Tab

    // Agent Click on the Next Button in Review and Submit Screen
    public void AgentClickOnNextButtonInReviewAndSubmitScreen() throws InterruptedException {
        By NextButtonCounter = By.xpath("//button/descendant::span[contains(text(),'Next')]");
        int Arg0 = driver.findElements(NextButtonCounter).size();
        for(int i=1;i<=Arg0;i++)
        {
            By ReviewNextButton = By.xpath("(//button/descendant::span[contains(text(),'Next')])["+i+"]");
//            actions.waitForVisibilityOfElement(ReviewNextButton,30);
            actions.clickUsingJS(ReviewNextButton);
            Thread.sleep(3000);
        }
        Thread.sleep(5000);
    }

    // Agent Click on Terms and Conditions CheckBox
    public void AgentClickOnTermsAndConditionsCheckBox() {
        By TermsAndConditions = By.xpath("//mat-card[contains(@class,'terms-conditions')]/descendant::input[@type='checkbox']");
        actions.waitForVisibilityOfElement(TermsAndConditions,30);
        actions.clickUsingJS(TermsAndConditions);
    }

    // Submit Button code found in Common Area

    // endregion

    // region Documents Page post after Submitted Application

    // Upload Documentation Button
    // Can use the Submit button method

    // Application Summary Button
    // Can use the Submit Button

    // Application Summary Back Button
    // Can use common Back Button

    // Element from List of Letters
    // Arg : BISS Application Form
    public void AgentSelectFromListOfDocuments(String ListItem) {
        By ItemFromList = By.xpath("//b[contains(text(),'+"+ListItem+"')]");
        actions.waitForVisibilityOfElement(ItemFromList,50);
        actions.clickUsingJS(ItemFromList);
    }



   // region My Correspondence Page
    public String GetDateOfAmendmentApplication() {
        By AmendmentDateLoc = By.xpath("(//td[contains(@class,'cdk-column-dateIssued')])[1]");
        String AmendmentDate = driver.findElement(AmendmentDateLoc).getText();
        System.out.println("Amended Date : "+AmendmentDate);
        return AmendmentDate;
    }

    // endregion




    // region Junk Code (Used earlier and commented out now)

    // DB Code
//    public void getDBvalues() throws ClassNotFoundException, SQLException {
//        Class.forName("com.oracle.jdbc.Driver");
//        String url = "Connection String";
//        String username = "DPS_DATA";
//        String password = "DPS_DATA";
//
//        Connection conn = DriverManager.getConnection(url,username,password);
//        Statement stmnt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
//        ResultSet rs = stmnt.executeQuery("SQL Query");
//        rs.last();
//
//        int rows = rs.getRow();
//        System.out.println("No. of rows"+rows);
//
//        ResultSetMetaData rsmd = rs.getMetaData();
//        int cols = rsmd.getColumnCount();
//        System.out.println("No. of rows"+cols);
//
//        String data[][] = new String[rows][cols];
//
//        int i=0;
//        rs.beforeFirst();
//        while (rs.next())
//        {
//            for(int j=0;j<cols;j++)
//            {
//                data[i][j]=rs.getString(j+1);
//                System.out.println(data[i][j]);
//            }
//            i++;
//        }
//    }
//
//    // DB Code 2
//    protected static Connection conn = null;
//    protected static Statement stmnt = null;
//    protected static ResultSetMetaData rsmd = null;
//    protected static ResultSet rs1 = null;
//    protected static ResultSet rs2 = null;
//    protected static String query_Total_Row = "SQL Query";
//    protected static String query_ALL_RECORDS = "sql qUERY";
//    protected static int columnNumber;
//    protected static int rowNumber;
//    protected static SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
//
//    public static void main(String[] args) throws SQLException, IOException
//    {
//        try {
//        }
//        finally {
//
//        }
//    }
//            System.out.println("Connecting to Database..."+"\n"+df.format(new Date()))+""
//                    +"\n------------------------------------------------------------------------";
//            Cl
//        }
//    }

    // Locators

    //    By PlotReference = By.xpath("//input[@formcontrolname='plotReference']");
    //    By ParcelSearchTextBox = By.xpath("//label[contains(text(),'Parcel Search')]/parent::div/descendant::input");
    //    By AddPlotAddButton = By.xpath("//button//child::span[text()='Add']");

    // Methods

    // Agent Click on Delete Button for a particular Parcel
    //    public void AgentClickOnDeleteInParcelList(String Arg0) {
    //        By PlotReference = By.xpath("//td[contains(text(),'"+Arg0+"')]");
    //        WebElement PlotRef = driver.findElement(PlotReference);
    //        WebElement CommonageFractionColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-commonageFraction')]"));
    //        WebElement EligibleHectareColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-eligibleHectare')]"));
    //        WebElement ClaimedAreaColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-claimedArea')]"));
    //        WebElement OwnershipStatusColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-ownershipStatus')]"));
    //        WebElement ParcelUseColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-parcelUse')]"));
    //        WebElement AgriculturalActivityColumn = driver.findElement(By.xpath("//td[contains(@class,'mat-column-maintenance')]"));
    //        WebElement DeleteParcelButtonColumn = driver.findElement(with(By.xpath("//td/descendant::button/descendant::mat-icon[text()='delete']"))
    //                .toRightOf(AgriculturalActivityColumn)
    //                .toRightOf(ParcelUseColumn)
    //                .toRightOf(OwnershipStatusColumn)
    //                .toRightOf(ClaimedAreaColumn)
    //                .toRightOf(EligibleHectareColumn)
    //                .toRightOf(CommonageFractionColumn)
    //                .toRightOf(PlotRef));
    //        actions.waitForVisibilityOfWebElement(DeleteParcelButtonColumn,30);
    //        actions.clickWebElementUsingJS(DeleteParcelButtonColumn);
    //    }

    //    // Entering data in Add Plot/Parcel Modal Input Fields
    //    public void AgentEnterDataInPlotModalInputFields(String Arg0, String Arg1) {
    //        By PlotInput = By.xpath("//input[@formcontrolname='"+Arg0+"']");
    //        actions.waitForVisibilityOfElement(PlotInput, 30);
    //        actions.sendKeys(PlotInput, String.valueOf(Arg1));
    //    }

    //    // Clicking on the Add Plot/Parcel Buttons
    //    public void AgentClickOnAddPlotOrParcelButtons(String Arg0) {
    //        By AddPlotButtons = By.xpath("//button//child::span[contains(text(),'"+Arg0+"')]");
    //        actions.waitForVisibilityOfElement(AddPlotButtons,30);
    //        actions.clickUsingJS(AddPlotButtons);
    //    }

    //    // Enter Parcel Number to be Searched
    //    public void AgentEnterParcelToBeSearched(String Arg0) {
    //        actions.waitForVisibilityOfElement(ParcelSearchTextBox,30);
    //        actions.sendKeys(ParcelSearchTextBox,Arg0);
    //    }

    //    // Click on the Add Parcel Button
    //    public void AgentClickOnAddParcelButton() {
    //        actions.waitForVisibilityOfElement(AddPlotAddButton,30);
    //        actions.clickUsingJS(AddPlotAddButton);
    //    }

    //endregion

    //endregion

    // region Multiple Agents Login

    // endregion

    // region Agent Add Parcels And Plots
    public void AgentAddParcelsAndPlots() {

    }

    public void AddInvalidParcel() throws InterruptedException {
        AgentClickOnApplicationStepper("Land Details");
        AgentClickOnAddPlotOrAddParcelButton("Add parcel");
        AgentEnterValueInAddPlotOrParcelDialog("Invalid789","parcelInput");
        AgentClickOnDialogBoxButton("Claim");
        Thread.sleep(3000);
        AgentClickOnDialogBoxButton("Cancel");
    }

    public void AddArchivedParcel() {
        AgentClickOnApplicationStepper("Land Details");
        AgentClickOnAddPlotOrAddParcelButton("Add parcel");
        AgentEnterValueInAddPlotOrParcelDialog("H19112055","parcelInput");
        AgentClickOnDialogBoxButton("Claim");
        AgentCheckForArchivedParcelMessage();
        AgentClickOnDialogBoxButton("Cancel");
    }

    public void AddParcelToBatch(String ParcelNumber) {
        AgentClickOnApplicationStepper("Land Details");
        AgentClickOnAddPlotOrAddParcelButton("Add parcel");
        AgentEnterValueInAddPlotOrParcelDialog(ParcelNumber,"parcelInput");
        AgentClickOnDialogBoxButton("Claim");
        By EligibleHa = By.xpath("//span[@aria-label='Eligible hectare']");
        int Value = Integer.parseInt(driver.findElement(EligibleHa).getText())-1;
        String ClaimedArea = String.valueOf(Value);
        AgentEnterValueInAddPlotOrParcelDialog(ClaimedArea,"ClaimedArea");
        AgentSelectDropdownValuesInParcelAndPlotModal("Owned","ownershipStatus");
        AgentSelectDropdownValuesInParcelAndPlotModal("Apples","parcelUse");
        AgentSelectDropdownValuesInParcelAndPlotModal("Conventional","organicStatus");
        AgentClickOnDialogBoxButton("Add");
    }

    public void AddPlotToBatch(String County, String Plot, String RefNumber) {
        AgentClickOnApplicationStepper("Land Details");
        AgentClickOnAddPlotOrAddParcelButton("Add plot");
        AgentSelectDropdownValuesInParcelAndPlotModal(County,"county");
        AgentSelectDropdownValuesInParcelAndPlotModal(Plot,"townland");
        AgentEnterValueInAddPlotOrParcelDialog(RefNumber,"plotReference");
        AgentSelectDropdownValuesInParcelAndPlotModal("Owned","ownershipStatus");
        AgentSelectDropdownValuesInParcelAndPlotModal("Conventional","organicStatus");;
        AgentEnterValueInAddPlotOrParcelDialog("10","ClaimedArea");
        AgentSelectDropdownValuesInParcelAndPlotModal("Blackcurrants","plotUse");   
        AgentClickOnRadioButtonsInDialogBox("Submit Paper Map By Post");
        AgentClickOnDialogBoxButton("Next");
        AgentClickOnSideDrawerButtons("Cancel");
    }

    // endregion

    // region AMS
    By ViewButton = By.xpath("(//a[contains(text(),'View')])[1]");
    By AMSStatusIconRed = By.xpath("(//mat-icon[@data-mat-icon-name='ams-status-red'])[1]");

    // Agent click on the first View Button in the Pending List
    public void AgentClickOnViewButtonForFarmer() {
            actions.clickUsingJS(ViewButton);
    }

    // Agent click on Parcel with AMS Status Pending
    public void AgentClickOnFirstParcelWithAMSStatusPending() {
        actions.clickUsingJS(AMSStatusIconRed);
    }

    // Agent Click On Agree or Disagree option in the AMS Side Drawer
    public void AgreeOrDisagreeInSideDrawer(String Arg0) {
        By AgreeDisagreeButton = By.xpath("//mat-radio-group[@formcontrolname='userAgrees']/descendant::span[contains(text(),'"+Arg0+"')]");
        actions.clickUsingJS(AgreeDisagreeButton);
    }

    // Agent Click On Disagree Reason option in the AMS Side Drawer
    public void DisagreeReasonInSideDrawer(String Arg0) {
        By AgreeDisagreeButton = By.xpath("//mat-radio-group[@formcontrolname='reasonDescription']/descendant::span[contains(text(),'"+Arg0+"')]");
        actions.clickUsingJS(AgreeDisagreeButton);
    }
    // endregion

    // endregion


    // region ENTS code
    // Click on the View button for searched herd
    public void AgentClickOnViewLinkForSearchedHerd() {
        boolean ExpiredHerdCheck =  driver.findElements(By.xpath("//mat-icon[@aria-label ='red check mark for expired']")).isEmpty();
        if(ExpiredHerdCheck) {
            By Link = By.xpath("(//a[contains(text(),'View')])[1]");
            actions.clickUsingJS(Link);
        }
        else {
            By Link = By.xpath("(//a[contains(text(),'View')])[2]");
            actions.clickUsingJS(Link);
        }
    }

//    int n = 1;
//    //boolean ExpiredHerdCheck =  driver.findElements(By.xpath("(//mat-icon[@aria-label ='red check mark for expired'])["+n+"]")).isEmpty();
//    By ViewLink = By.xpath("//a[contains(text(),'View')])["+n+"]");
//        while(!driver.findElements(By.xpath("(//mat-icon[@aria-label ='red check mark for expired'])["+n+"]")).isEmpty()) {
//        n = n+1;
//    }
//        actions.clickUsingJS(ViewLink);

    // Click on button in screen
    // Arg : Create Transfer Application, View
    public void AgentClickOnButton(String Button) {
        By ButtonName = By.xpath("//button[text()='"+Button+"']");
        actions.clickUsingJS(ButtonName);
    }

    // Click on button in the personal details Dialog
    public void AgentClcikOnButtoninPersonalDetailsDialog(String Button) {
        By PersonalDetailsButton = By.xpath("//button/span[text()='"+Button+"']");
        List<WebElement> PersonalDetailsButtonList = driver.findElements(PersonalDetailsButton);
        if(PersonalDetailsButtonList.isEmpty()) {
            System.out.println("Personal Details Dialog not Present");
        }
        else {
            WebElement PersonalDialogButtonFromList = PersonalDetailsButtonList.get(0);
            actions.clickWebElementUsingJS(PersonalDialogButtonFromList);
        }
    }

    // Click on ETF Button in Screen
    public void AgentClickOnETFButton() {
        By ETFButton = By.xpath("//button/span[text()=' Access an application using Transfer Key ']");
        actions.clickUsingJS(ETFButton);
    }

    // Click on button in dialog box
    // Arg : Create Transfer Application, View
    public void AgentClickOnButtonInDialog(String Button) {
        By ButtonName = By.xpath("//mat-dialog-container/descendant::button[contains(text(),'"+Button+"')]");
        actions.clickUsingJS(ButtonName);
    }

    // Arg : Select
    public void AgentClickOnSelectLeaseYearButtonInDialog(String Button) {
        By ButtonName = By.xpath("(//mat-dialog-container/descendant::button[contains(text(),'"+Button+"')])[1]");
        actions.clickUsingJS(ButtonName);
    }

//    // Click on button in screen
//    // Arg : Add
//    public void AgentClickOnEntitlementsButton(String Button) {
//        By ButtonName = By.xpath("//button[contains(text(),'"+Button+"')]");
//        actions.clickUsingJS(ButtonName);
//    }

    // Click on the dropdown in the Side Drawer
    public void AgentOpenLeaseYearDropdown() {
        String Locator = "//mat-select";
        By AddPlotDropdowns = By.xpath(Locator);
        actions.clickUsingJS(AddPlotDropdowns);
    }

    // Agent Select Year in Transferee Search Dialog
    public void AgentSelectLeaseYear() {
        AgentOpenLeaseYearDropdown();
        By DropDownValue = By.xpath("//span[contains(text(),'2028')]/ancestor::mat-option");
        actions.clickUsingJS(DropDownValue);
    }

    // Agent Enter Text in Transferee Search Dialog
    // Arg : txeeHerd, txeeName
    public void AgentEnterTextInDialog(String Field, String Value) {
        By TextBox = By.xpath("//input[@formcontrolname='"+Field+"']");
        actions.sendKeys(TextBox,Value);
    }

    // Agent Select Start/End Date
    public void AgentSelectStartEndDate(String Herd) {
        By SelectButton = By.xpath("(//span[contains(text(),'"+Herd+"')]/ancestor::tr/descendant::button[contains(text(),'Select')])[1]");
        actions.clickUsingJS(SelectButton);
    }

    // Agent Select the Transfer Type
    // Arg : Inheritance - 201, Gift - 202, Merger - 203, Division - 204, Change Reg - 205, Change Ent - 206, Lease - 211, Sale - 212
    public void AgentSelectTransferType(String TransferType) {
        By RadioButton = By.xpath("//mat-radio-button/descendant::input[@value='"+TransferType+"']");
        actions.clickUsingJS(RadioButton);
    }



    By HerdSearchField = By.xpath("//input[@placeholder='Address, Name or Herd Number']");

    // Agent Search for a particular herd
    public void AgentSearchForHerdField(String Arg0) {
        actions.sendKeys(HerdSearchField,Arg0);
    }

    /* Entitlements Tab*/
    // Agent Click on Add Entitlements button
    public void AgentClickOnAddEntitlements() {
        By FirstAddButton = By.xpath("(//td/button[contains(text(),'Add')])[1]");
        actions.clickUsingJS(FirstAddButton);
    }

    // Agent Click on Add Entitlements button
    public void AgentClickOnAddManualEntitlements() {
        By ManualAddButton = By.xpath("//div/button[contains(text(),'Add Manual Entitlements')]");
        actions.clickUsingJS(ManualAddButton);
    }

    // Agent Check if Entitlements not present
    public Boolean AgentCheckEntitlementsNotPresent() {
        By FirstAddButton = By.xpath("//td/button[contains(text(),'Add')]");
        List<WebElement> AddButton = driver.findElements(FirstAddButton);
        return AddButton.isEmpty();
    }

    /* Summary Tab */
    // Agent Add notes to the Transfer of Entitlements Application
    public void AgentAddNotesToEntitlements(String Notes) throws InterruptedException {
        //By TextBox = By.xpath("//textarea");
        actions.waitforSeconds(2);
        List<WebElement> TextBoxCheck = driver.findElements(By.xpath("//textarea"));
        if(TextBoxCheck.isEmpty())
        {
            By RemoveSelectedEntitlement = By.xpath("//button[contains(text(),'Remove')]");
            actions.clickUsingJS(RemoveSelectedEntitlement);
            Thread.sleep(2000);
            By ConfirmRemove = By.xpath("//app-transfer-entitlement-remove-popup/descendant::button[contains(text(),'Remove')]");
            actions.clickUsingJS(ConfirmRemove);
            Thread.sleep(2000);
            By SecondAddButton = By.xpath("(//td/button[contains(text(),'Add')])[2]");
            actions.clickUsingJS(SecondAddButton);
            Thread.sleep(2000);
            AgentEnterTextInDialog("itsNumEntsTx", "1");
            Thread.sleep(2000);
            AgentClickOnButtonInDialog("Add");
            Thread.sleep(2000);
            AgentClickOnButton(" Next ");
            Thread.sleep(2000);
            actions.sendKeys(By.xpath("//textarea"),Notes);
        }
        else {
            actions.sendKeys(By.xpath("//textarea"),Notes);
        }
    }

    // Agent access the Transferor Form
    public void AgentClickOnLink(String LinkText) {
        By Link = By.xpath("//a[contains(text(),'"+LinkText+"')]");
        actions.clickUsingJS(Link);
    }

    /*Transferee Screen*/
    // Click on the View button in the Transferee Home Screen
    //J1320531
    public void TransfereeViewButtonClick(String TransfereeHerdNumber) {
        //(//button[contains(text(),'View')])[1]
        By TransferorReferenceNumber = By.xpath("//td[contains(text(),'"+TransfereeHerdNumber+"')]");
        List<WebElement> HerdNumbers = driver.findElements(TransferorReferenceNumber);
        int HerdNumberCount = HerdNumbers.size();
//        WebElement TransferorHerdNumber = HerdNumbers.get(HerdNumberCount-1);
//        By TransferorHerdNumber = By.xpath("(//td[contains(text(),'"+TransfereeHerdNumber+"')])["+HerdNumberCount+"]");
//        By TransferType = By.xpath("//td[contains(@class,'cdk-column-transferType')"); // and contains(text(),'Change of Legal Entity')]
//        By TransferStatus = By.xpath("//td[contains(@class,'cdk-column-transferStatus')"); // and contains(text(),'Awaiting Acceptance by Transferee')]
//        By TransferKey = By.xpath("//td[contains(@class,'cdk-column-transferKey')");
//        By LastModified = By.xpath("//td[contains(@class,'cdk-column-lastModified')");
//        By ViewButton = By.xpath("//button[contains(text(),'View')]");
//        WebElement TransfereeViewButton = driver.findElement(with(ViewButton)
//                .toRightOf(LastModified)
//                .toRightOf(TransferKey)
//                .toRightOf(TransferStatus)
//                .toRightOf(TransferType)
//                .toRightOf(TransferorHerdNumber));
//        WebElement TransfereeViewButton = driver.findElement(TransfereeLastViewButton);
//        TransfereeViewButton.click();
        By TransfereeLastViewButton = By.xpath("(//td[contains(text(),'J1320531')]/ancestor::tr/descendant::button[contains(text(),'View')])["+HerdNumberCount+"]");
        actions.clickUsingJS(TransfereeLastViewButton);
//        actions.clickUsingJS(TransfereeViewButton.get(ButtonCount-1));
    }

    // Click on View Button for Transferee from ETF
    public void AgentClickOnViewButtonForTransfereeFromETF(String TransfereeHerd) {
        By IndividualViewButton = By.xpath("//td[contains(text(),'"+TransfereeHerd+"')]/parent::tr/descendant::button[contains(text(),'View')]");
        actions.clickUsingJS(IndividualViewButton);
    }

    // Click on View Button for Individual Transferee from ETF
    public void AgentClickOnViewButtonForIndividualTransfereeFromETF(String TransfereeHerd) {
        By IndividualViewButton = By.xpath("//td[contains(text(),'"+TransfereeHerd+"')]/parent::tr/descendant::button[contains(text(),'View')]");
        List<WebElement> ViewButtons = driver.findElements(IndividualViewButton);
        int ViewButtonCount = ViewButtons.size();
        actions.clickWebElementUsingJS(ViewButtons.get(ViewButtonCount - 1));
        //actions.clickUsingJS(IndividualViewButton);
    }

    // Click on View Button in Transferee Screen
    public void AgentClickOnViewButtonInTransfereeScreen() {
        By ViewButton = By.xpath("//mat-card-title[contains(text(),'Transfers In Applications 2026')]/ancestor::mat-card/descendant::button[contains(text(),'View')]");
        List<WebElement> TransfereeViewButton = driver.findElements(ViewButton);
        int ButtonCount = TransfereeViewButton.size();
        actions.clickWebElementUsingJS(TransfereeViewButton.get(ButtonCount-1));
    }

    // Upload Document
    // RemoteWebElement Line has to be commented out to run locally but when pushing in code has to be uncommented
    public void UploadDocumentForTransfer() {
        //WebElement Choosefile = driver.findElement(By.xpath("//input[@type='file']"));
        // Has to be enabled while running on Grid if not in Driver Manager
        //((RemoteWebElement)driver).setFileDetector(new LocalFileDetector());
        // Path for Local Run
        //String FilePath = getPath();
       //Choosefile.sendKeys(FilePath);
        // Path for Remote run
       //Choosefile.sendKeys("C:/Users/Akanksha.Singh/Desktop/Selenium/TestData/download.pdf");
        if (driver instanceof RemoteWebDriver) {
            ((RemoteWebDriver) driver).setFileDetector(new LocalFileDetector());
        }
        WebElement Choosefile = driver.findElement(By.xpath("//input[@type='file']"));
        String FilePath = getPath();
        Choosefile.sendKeys(FilePath);
    }

    public String getPath() {
        return new File("src/main/resources/TestData/download.pdf").getAbsolutePath();
    }

    // Agent Select Type of Document in the Upload Doc Dialog
    public void AgentSelectDocumentTypeInDropdown(String DropdownName, String DocType) {
        By SearchParcelDropdowns = By.xpath("//mat-select[@id='"+DropdownName+"']");
        actions.clickUsingJS(SearchParcelDropdowns);
        actions.waitforSeconds(2);
        By DocumentType = By.xpath("//mat-option/span[contains(text(),'"+DocType+"')]");
        actions.clickUsingJS(DocumentType);
        actions.waitforSeconds(3);
    }

    // Agent Select Entitlement type in the Manual Entitlements Dialog
    public void AgentSelectEntitlementType(String Type) {
        By SearchParcelDropdowns = By.xpath("(//mat-select)[1]");
        actions.clickUsingJS(SearchParcelDropdowns);
        actions.waitforSeconds(2);
        By EntitlementType = By.xpath("//mat-option/span[text()='"+Type+"']");
        actions.clickUsingJS(EntitlementType);
        actions.waitforSeconds(3);
    }

    // Agent Select Lease End Year in the Manual Entitlements Dialog
    public void AgentSelectLeaseEndYear(String Year) {
        By SearchParcelDropdowns = By.xpath("(//mat-select)[2]");
        actions.clickUsingJS(SearchParcelDropdowns);
        actions.waitforSeconds(2);
        By EntitlementType = By.xpath("//mat-option/span[text()='"+Year+"']");
        actions.clickUsingJS(EntitlementType);
        actions.waitforSeconds(3);
    }

    // Agent Accept Terms and Conditions for Transfer
    public void AgentClickOnTermsAndConditionsCheckBoxForTransfers() {
        By CheckBox = By.xpath("//input[@type='checkbox']");
        actions.clickUsingJS(CheckBox);
    }

    private String TransferKeyText;

    // Agent Capture the Transfer Application Key
    public void AgentCaptureTransferKey() {
        By ApplicationKeyLink = By.xpath("//u[contains(@class,'ApplicationKey')]");
        TransferKeyText = driver.findElement(ApplicationKeyLink).getText();
        System.out.println(TransferKeyText);
    }

    // Agent Enter Text in Transferee Search Dialog
    public void AgentEnterTransferKeyInDialog(String Field) {
        By TextBox = By.xpath("//input[@formcontrolname='"+Field+"']");
        actions.sendKeys(TextBox,TransferKeyText);
    }

    public List<String> herdsOfCurrentAgentStrings;

    public void collectAllHerdsOfThatAgentWhichAreNotSubmitted() throws InterruptedException, IOException {
        By herdsOfAgent = By.xpath("//a[contains(text(),'View')]/preceding::td[1]");
        Thread.sleep(10000);
        driver.findElement(pageDropdown).click();
//        Select sl = new Select(driver.findElement(pageDropdown));
//        sl.selectByIndex(4);
        driver.findElement(lastPage).click();
        Thread.sleep(5000);
        List<WebElement> herdsOfCurrentAgent = driver.findElements(herdsOfAgent);
        //add string value from herdsOfCurrentAgent to herdsOfCurrentAgentStrings
        herdsOfCurrentAgentStrings = new ArrayList<>();
        for(WebElement iterator : herdsOfCurrentAgent){
            herdsOfCurrentAgentStrings.add(iterator.getText());
        }
        Thread.sleep(10000);
        By submittedTab = By.xpath("//button/span[contains(text(),' Submitted ')]");
        actions.clickUsingJS(submittedTab);
        //driver.findElement(submittedTab).click();
        Thread.sleep(5000);
        driver.findElement(pageDropdown).click();
        driver.findElement(lastPage).click();
        List<WebElement> submittedHerdsOfCurrentAgent = driver.findElements(herdsOfAgent);
        //add string value from submittedHerdsOfCurrentAgent to herdsOfCurrentAgentStrings
        List<String> submittedHerdsOfCurrentAgentStrings = new ArrayList<>();
        for(WebElement iterator : submittedHerdsOfCurrentAgent){
            submittedHerdsOfCurrentAgentStrings.add(iterator.getText());
        }
        //compare two list and remove submitted herd
        herdsOfCurrentAgentStrings.removeIf(submittedHerdsOfCurrentAgentStrings :: contains);
//        List<String> commonElements = new ArrayList<>();
//        for (String value : herdsOfCurrentAgentStrings) {
//            if (submittedHerdsOfCurrentAgentStrings.contains(value)) {
//                commonElements.add(value);
//                herdsOfCurrentAgentStrings.remove(value);
//            }
//        }
        String FilePath = "./src/main/resources/TestData/Herd With No NRCISYF Submission.xls";
        databaseQueriesPage.WritHerdToFile(herdsOfCurrentAgentStrings, FilePath, "Herd Number");
        System.out.println(herdsOfCurrentAgentStrings);
       // By viewAllTab = By.xpath("//button/span[contains(text(),' View all ')]");
        //driver.findElement(viewAllTab).click();

        //agentSearchForHerdNumberFieldAndEnterHerd(herdsOfCurrentAgentStrings.get(1));
}


    public void agentSearchForHerdNumberFieldAndEnterHerd(){
        System.out.println(herdsOfCurrentAgentStrings);
        actions.sendKeys(HerdSearchField, herdsOfCurrentAgentStrings.get(1));
        }

    public void agentSearchForHerdNumberFieldAndEnterHerd(int rowNum) throws IOException {
        String filePath = "./src/main/resources/TestData/Herd With No NRCISYF Submission.xls";
       // System.out.println(herdsOfCurrentAgentStrings);
        actions.sendKeys(HerdSearchField, databaseQueriesPage.getHerdNumberFromSpecifiedFile(rowNum,filePath));
    }

    }
    // endregion


