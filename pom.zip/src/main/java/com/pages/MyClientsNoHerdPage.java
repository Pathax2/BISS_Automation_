package com.pages;

import com.base.ActionClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class MyClientsNoHerdPage {

    WebDriver driver;
    ActionClass actions;

    By ClientRadioButton = By.id("optionsRadios2");
    By AgentViewButton = By.id("noHerdClientListViewButton");
    By AgentCreateClientAwaitingHerdButton = By.id("noHerdClientListCreateButton");
    By ClientAwaitingHerdFullName = By.id("noHerdClientNameInput");
    By ClientAwaitingHerdAddress1 = By.id("noHerdClientAddress1Input");
    By ClientAwaitingHerdAddress2 = By.id("noHerdClientAddress2Input");
    By ClientAwaitingHerdAddress3 = By.id("noHerdClientAddress3Input");
    By ClientAwaitingHerdPhoneNumber = By.id("noHerdClientPhoneNumberInput");
    By ClientAwaitingHerdBPSCheckBox = By.id("noHerdClientRefTypeInputBPS");
    By ClientAwaitingHerdTransfersCheckBox = By.id("noHerdClientRefTypeInputTOE");
    By ClientAwaitingHerdNRYFSCheckBox = By.id("noHerdClientRefTypeInputNRYFS");
    By ClientAwaitingHerdCreateClientButton = By.id("noHerdClientSubmitButton");
    By ClientAwaitingHerdConfirmationModalNoButton = By.id("createNoHerdClientPopupConfirm");
    By ClientAwaitingHerdConfirmationModalYesButton = By.id("createNoHerdClientPopupCancel");


    public MyClientsNoHerdPage(WebDriver driver) {
        this.driver = driver;
        actions = new ActionClass(driver);
    }

    // Clicking on the Client Radio button
    public void AgentClickOnClientRadioButton() {
        actions.waitForVisibilityOfElement(ClientRadioButton, 10);
        actions.click(ClientRadioButton);
    }

    // Clicking on the View Button
    public void AgentClickOnViewButton() {
        actions.waitForVisibilityOfElement(AgentViewButton, 10);
        driver.findElement(AgentViewButton).click();
    }

    // Clicking on the Create Client Awaiting Herd button
    public void AgentClickOnCreateClientAwaitingHerdNumberButton() {
        actions.waitForVisibilityOfElement(AgentCreateClientAwaitingHerdButton, 10);
        actions.click(AgentCreateClientAwaitingHerdButton);
    }

    // Entering Client Awaiting Herd FullName
    public void AgentEnterClientAwaitingHerdNumberDetailsFullName(String Arg0) {
        actions.waitForVisibilityOfElement(ClientAwaitingHerdFullName, 30);
        actions.sendKeys(ClientAwaitingHerdFullName, String.valueOf(Arg0));
    }

    // Entering Client Awaiting Herd Address1
    public void AgentEnterClientAwaitingHerdNumberDetailsAddress1(String Arg0) {
        actions.waitForVisibilityOfElement(ClientAwaitingHerdAddress1, 30);
        actions.sendKeys(ClientAwaitingHerdAddress1, String.valueOf(Arg0));
    }

    // Entering Client Awaiting Herd Address2
    public void AgentEnterClientAwaitingHerdNumberDetailsAddress2(String Arg0) {
        actions.waitForVisibilityOfElement(ClientAwaitingHerdAddress2, 30);
        actions.sendKeys(ClientAwaitingHerdAddress2, String.valueOf(Arg0));
    }

    // Entering Client Awaiting Herd Address3
    public void AgentEnterClientAwaitingHerdNumberDetailsAddress3(String Arg0) {
        actions.waitForVisibilityOfElement(ClientAwaitingHerdAddress3, 30);
        actions.sendKeys(ClientAwaitingHerdAddress3, String.valueOf(Arg0));
    }

    // Entering Client Awaiting Herd Contact Number
    public void AgentEnterClientAwaitingHerdNumberDetailsContactNumber(String Arg0) {
        actions.waitForVisibilityOfElement(ClientAwaitingHerdPhoneNumber, 30);
        actions.sendKeys(ClientAwaitingHerdPhoneNumber, String.valueOf(Arg0));
    }

    // Clicking on the Client Awaiting Herd BPS CheckBox
    public void AgentClickOnClientAwaitingHerdNumberDetailsBPSCheckBox() {
        actions.waitForVisibilityOfElement(ClientAwaitingHerdBPSCheckBox, 10);
        actions.click(ClientAwaitingHerdBPSCheckBox);
    }

    // Clicking on the Client Awaiting Herd Transfers CheckBox
    public void AgentClickOnClientAwaitingHerdNumberDetailsTransfersCheckBox() {
        actions.waitForVisibilityOfElement(ClientAwaitingHerdTransfersCheckBox, 10);
        actions.click(ClientAwaitingHerdTransfersCheckBox);
    }

    // Clicking on the Client Awaiting Herd NRYFS CheckBox
    public void AgentClickOnClientAwaitingHerdNumberDetailsNRYFSCheckBox() {
        actions.waitForVisibilityOfElement(ClientAwaitingHerdNRYFSCheckBox, 10);
        actions.click(ClientAwaitingHerdNRYFSCheckBox);
    }

    // Clicking on the Create Client Button
    public void AgentClickOnCreateClientButton() {
        actions.waitForVisibilityOfElement(ClientAwaitingHerdCreateClientButton, 10);
        actions.click(ClientAwaitingHerdCreateClientButton);
    }

    // Clicking on the Confirmation Modal No Button
    public void AgentClickOnClientAwaitingHerdConfirmationModalNoButton() {
        actions.waitForVisibilityOfElement(ClientAwaitingHerdConfirmationModalNoButton, 10);
        actions.click(ClientAwaitingHerdConfirmationModalNoButton);
    }

    // Clicking on the Confirmation Modal Yes Button
    public void AgentClickOnClientAwaitingHerdConfirmationModalYesButton() {
        actions.waitForVisibilityOfElement(ClientAwaitingHerdConfirmationModalYesButton, 10);
        actions.click(ClientAwaitingHerdConfirmationModalYesButton);
    }
}

