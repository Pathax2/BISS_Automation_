// ===================================================================================================================================
// File          : CommonFunctions.java
// Package       : commonFunctions
// Description   : Core reusable utility class for the BDD Cucumber PLAYWRIGHT automation framework.
//                 Provides browser lifecycle management, UI action execution, test data resolution,
//                 Word report generation, screenshot capture, and structured step logging.
//
//                 MIGRATION CONTRACT (Selenium -> Playwright):
//                   The public signature iAction(ActionType, IdentifyBy, ObjectName, Value) is UNCHANGED.
//                   ObjectRepository.properties XPaths are UNCHANGED (converted to "xpath=" selectors at runtime).
//                   Step definitions that only call iAction() and ObjReader need NO code change.
//                   getDriver() / getWait() are REMOVED. Use getPage() or UiHelpers instead.
//
// Author        : Aniket Pathare | aniket.pathare@goverment.ie
// Date Created  : 10-03-2026
// Updated       : 26-03-2026 - Phase 1: step log table, cover page metadata, clearStepLog()
// Updated       : 28-03-2026 - Self-healing LIST, Phase 2 reporting (root-cause categorisation, HTML report index)
// Updated       : 15-09-2026 - Selenium WebDriver replaced by Playwright (Locator auto-waiting, traces, container-safe)
// Updated       : 16-09-2026 - JavaScript click (JSCLICK action, click.strategy, jsClick) and Selenium-style executeScript()
// Updated       : 16-09-2026 - LIST/mat-select: pinned by id, opened via its trigger div, panel scoped by aria-controls
//                              (works for searchable lib-biss-select-search dropdowns and popover panels), selection verified
// Updated       : 16-09-2026 - LIST/mat-select: waits for a disabled dropdown (e.g. Townland until County has loaded),
//                              step-by-step search (full text, then the name before " - ", then the code, then no filter)
// Updated       : 16-09-2026 - LIST/mat-select: waits run inside the browser (faster); fixed false failure after a successful
//                              selection (panel was read after it closed); readable Playwright error messages in the step log
// Updated       : 17-09-2026 - Browser arguments converted to types Playwright for Java accepts (a Long timeout made every
//                              LIST fail); a dropdown that is already open is never clicked again
// Updated       : 18-09-2026 - browser.reuse: the browser stays open between test cases; shutdownBrowser() ends the run
// Updated       : 17-09-2026 - Report status follows the Cucumber scenario result. A failed action that the step definition
//                              caught (an "if present" check) is shown as HANDLED and no longer marks the test case FAIL
// ===================================================================================================================================

package commonFunctions;

import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.ElementHandle;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.PlaywrightException;
import com.microsoft.playwright.TimeoutError;
import com.microsoft.playwright.options.LoadState;
import com.microsoft.playwright.options.MouseButton;
import com.microsoft.playwright.options.SelectOption;
import com.microsoft.playwright.options.WaitForSelectorState;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import utilities.ConfigManager;
import utilities.ExcelUtilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import java.util.regex.Pattern;

public class CommonFunctions
{
    // -------------------------------------------------------------------------------------------------------------------------------
    // Framework Logger
    // -------------------------------------------------------------------------------------------------------------------------------
    public static final Logger log = Logger.getLogger(CommonFunctions.class.getName());

    // -------------------------------------------------------------------------------------------------------------------------------
    // File Paths and timeouts - resolved through ConfigManager (-D > BISS_ env var > profile file > base file)
    // -------------------------------------------------------------------------------------------------------------------------------
    private static final String  iExecutionControlFilePath = ConfigManager.getOrDefault("execution.control.path", "src/test/resources/Execution_Control_File/ExecutionControl.xlsx");
    private static final String  iReportDocsDirectoryPath  = ConfigManager.getOrDefault("report.docs.path", "Test_Report/docs");
    private static final double  iActionTimeoutMs          = ConfigManager.getInt("explicit.wait.seconds", 30) * 1000d;
    private static final double  iClickAttemptTimeoutMs    = ConfigManager.getInt("click.attempt.timeout.ms", 5000);
    private static final String  iClickStrategy            = ConfigManager.getOrDefault("click.strategy", "auto").trim().toLowerCase(Locale.ROOT);
    private static final double  iWaitVisibleTimeoutMs     = ConfigManager.getInt("wait.visible.seconds", 30) * 1000d;
    private static final double  iVerifyElementTimeoutMs   = ConfigManager.getInt("verify.element.timeout.seconds", 20) * 1000d;
    private static final double  iListOptionTimeoutMs      = ConfigManager.getInt("list.option.timeout.seconds", 30) * 1000d;
    private static final int     iPollIntervalMs           = ConfigManager.getInt("wait.polling.interval.ms", 250);
    private static final boolean iHighlightEnabled         = ConfigManager.getBool("highlight.enabled", false);
    private static final boolean iStrictLocators           = ConfigManager.getBool("locator.strict", false);
    private static final int     iCssZoomPercent           = ConfigManager.getInt("ui.zoom.percent", 100);

    private static final DataFormatter iDataFormatter = new DataFormatter();

    private static final DateTimeFormatter iLogDateTimeFormatter  = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
    private static final DateTimeFormatter iFileDateTimeFormatter = DateTimeFormatter.ofPattern("dd_MM_yyyy_HH_mm_ss");

    private static final Map<String, String> iDescriptionCache = new ConcurrentHashMap<>();
    private static volatile boolean          iDescriptionCacheLoaded = false;

    private static final java.util.List<StepLogEntry> iStepLog = new java.util.ArrayList<>();
    private static int iStepCounter  = 0;
    private static int iStepBoundary = 0;

    // -------------------------------------------------------------------------------------------------------------------------------
    // Browser-side JavaScript snippets (kept in one place so they are easy to review)
    // -------------------------------------------------------------------------------------------------------------------------------
    private static final String JS_HIGHLIGHT =
            "element => { const original = element.style.outline; element.style.outline = '3px solid red';"
                    + " setTimeout(() => { element.style.outline = original; }, 400); }";

    private static final String JS_TEXT_OR_VALUE =
            "element => { const text = (element.innerText || '').trim(); if (text.length > 0) { return text; }"
                    + " const value = element.value; return (value === undefined || value === null) ? '' : String(value).trim(); }";

    private static final String JS_CHECKED_STATE =
            "element => {"
                    + " if (element.tagName === 'LABEL' && element.control) { return element.control.checked; }"
                    + " if (element.tagName === 'INPUT') { return element.checked; }"
                    + " const host = element.closest('mat-radio-button, mat-checkbox, mat-slide-toggle, mat-list-option') || element;"
                    + " const input = host.querySelector('input[type=radio], input[type=checkbox]');"
                    + " if (input) { return input.checked; }"
                    + " const aria = host.getAttribute('aria-checked') || host.getAttribute('aria-selected');"
                    + " if (aria !== null) { return aria === 'true'; }"
                    + " return null; }";

    private static final String JS_IS_HIDDEN =
            "element => {"
                    + " if (element.getAttribute('aria-hidden') === 'true') { return true; }"
                    + " const style = window.getComputedStyle(element);"
                    + " if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') { return true; }"
                    + " const box = element.getBoundingClientRect();"
                    + " return box.width === 0 && box.height === 0; }";

    private static final String JS_WAIT_FOR_ANGULAR =
            "() => new Promise(resolve => {"
                    + " if (!window.getAllAngularTestabilities) { resolve(true); return; }"
                    + " const all = window.getAllAngularTestabilities();"
                    + " let pending = all.length;"
                    + " if (pending === 0) { resolve(true); return; }"
                    + " all.forEach(t => t.whenStable(() => { pending--; if (pending === 0) { resolve(true); } })); })";

    private static final String JS_CSS_ZOOM =
            "zoom => { const apply = () => { if (document.body) { document.body.style.zoom = zoom; } };"
                    + " if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', apply); } else { apply(); } }";

    // Same as Selenium: ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(...); arguments[0].click();", element)
    private static final String JS_CLICK =
            "element => { element.scrollIntoView({block: 'center', inline: 'nearest'}); element.click(); }";

    private static final String JS_SET_SEARCH_VALUE =
            "(element, text) => { element.focus(); element.value = text;"
                    + " element.dispatchEvent(new Event('input', {bubbles: true}));"
                    + " element.dispatchEvent(new KeyboardEvent('keyup', {bubbles: true, key: text.slice(-1)})); }";

    // mat-select helpers - each one is a single browser round trip
    private static final int SEARCH_SETTLE_MS   = 400;
    private static final int SEARCH_NO_MATCH_MS = 1500;   // a search that shows nothing new for 1.5 s -> try the next search
    private static final int LIST_NO_MATCH_MS   = 3000;   // a loaded list without the option, unchanged for 3 s -> fail now, not after 30 s

    private static final String JS_SELECT_STATE =
            "el => { const v = el.querySelector('.mat-mdc-select-value, .mat-select-value');"
                    + " return { id: el.id || '',"
                    + " open: el.getAttribute('aria-expanded') === 'true',"
                    + " disabled: el.getAttribute('aria-disabled') === 'true' || el.classList.contains('mat-mdc-select-disabled'),"
                    + " hasTrigger: !!el.querySelector('.mat-mdc-select-trigger, .mat-select-trigger'),"
                    + " value: (v ? v.textContent : '').replace(/\\s+/g, ' ').trim() }; }";

    private static final String JS_WAIT_SELECT =
            "(el, a) => new Promise(resolve => { const end = Date.now() + a.ms;"
                    + " const check = () => {"
                    + " const ok = a.want === 'open' ? el.getAttribute('aria-expanded') === 'true'"
                    + " : !(el.getAttribute('aria-disabled') === 'true' || el.classList.contains('mat-mdc-select-disabled'));"
                    + " if (ok || Date.now() > end) { resolve(ok); } else { setTimeout(check, 50); } };"
                    + " check(); })";

    private static final String JS_RESOLVE_PANEL =
            "(el, a) => new Promise(resolve => { const end = Date.now() + a.ms;"
                    + " const find = () => {"
                    + " const id = el.getAttribute('aria-controls');"
                    + " let p = id ? document.getElementById(id) : null;"
                    + " if (!p) { const all = Array.from(document.querySelectorAll(\"div[role='listbox']\")).filter(x => x.getBoundingClientRect().height > 0);"
                    + " p = all.length ? all[all.length - 1] : null; if (p && !p.id) { p.id = 'pw-panel-' + a.token; } }"
                    + " if (p) { resolve({ id: p.id,"
                    + " searchable: !!p.querySelector('mat-option.contains-mat-select-search, input.mat-select-search-input'),"
                    + " multiple: p.getAttribute('aria-multiselectable') === 'true' }); return; }"
                    + " if (Date.now() > end) { resolve(null); } else { setTimeout(find, 50); } };"
                    + " find(); })";

    private static final String JS_PICK_OPTION =
            "a => new Promise(resolve => {"
                    + " const end = Date.now() + a.ms; const norm = s => (s || '').replace(/\\s+/g, ' ').trim();"
                    + " const want = norm(a.text).toLowerCase(); let sig = null; let since = Date.now(); let last = [];"
                    + " const poll = () => {"
                    + " const panel = document.getElementById(a.panelId); const now = Date.now();"
                    + " if (!panel) { if (now > end) { resolve({ found: false, sample: 'panel closed' }); } else { setTimeout(poll, 50); } return; }"
                    + " const busy = !!panel.querySelector('mat-progress-spinner, mat-spinner, mat-progress-bar, .mat-mdc-progress-spinner');"
                    + " const opts = Array.from(panel.querySelectorAll('mat-option')).filter(o => !o.classList.contains('contains-mat-select-search') && o.getAttribute('aria-disabled') !== 'true');"
                    + " const texts = opts.map(o => norm(o.textContent)); last = texts;"
                    + " const s = texts.length + ':' + texts.join('|');"
                    + " if (busy || s !== sig) { sig = s; since = now; }"
                    + " const stable = now - since;"
                    + " if (stable >= a.settleMs) {"
                    + " let idx = -1;"
                    + " if (a.index >= 0) { idx = a.index < opts.length ? a.index : -1; }"
                    + " else { const low = texts.map(t => t.toLowerCase()); idx = low.indexOf(want);"
                    + " if (idx < 0) { const c = []; low.forEach((t, i) => { if (t.includes(want)) { c.push(i); } }); if (c.length === 1) { idx = c[0]; } } }"
                    + " if (idx >= 0) { document.querySelectorAll('[data-pw-pick]').forEach(e => e.removeAttribute('data-pw-pick'));"
                    + " opts[idx].setAttribute('data-pw-pick', a.token); resolve({ found: true, text: texts[idx] }); return; }"
                    + " if (a.noMatchMs >= 0 && stable >= a.noMatchMs && (texts.length > 0 || a.allowEmpty)) { resolve({ found: false, sample: describe(texts) }); return; } }"
                    + " if (now > end) { resolve({ found: false, sample: describe(last) }); return; }"
                    + " setTimeout(poll, 50); };"
                    + " const describe = t => t.length <= 30 ? t.join(' | ') : t.slice(0, 30).join(' | ') + ' | ... (' + t.length + ' options in total)';"
                    + " poll(); })";

    // Runs a Selenium-style script body: 'arguments[0]', 'arguments[1]' ... and 'return' work unchanged
    // (new lines around the body keep a trailing // comment in the script from swallowing the closing brace)
    private static final String JS_EXECUTE_SCRIPT_WRAPPER =
            "args => (function() {\n__SCRIPT__\n}).apply(null, args)";

    private static final String MAT_OPTION_CSS = "css=mat-option.optionListItem, mat-option:not(.contains-mat-select-search)";


    // ===============================================================================================================================
    // SECTION 1 : Page Accessors (replace getDriver / getWait)
    // ===============================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Function Name : getPage
    // Description   : Returns the Playwright Page bound to the current thread (replacement for getDriver()).
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Precondition  : launchBrowser() must have been called on this thread
    // Date Created  : 15-09-2026
    // ***************************************************************************************************************************************************************************************
    public static Page getPage()
    {
        return PlaywrightFactory.getPage();
    }

    public static BrowserContext getContext()
    {
        return PlaywrightFactory.getContext();
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : getDriver  (MIGRATION BRIDGE - remove once all step definitions are migrated)
    // Description   : Kept only so step definitions with an unused "import static ...CommonFunctions.getDriver;"
    //                 (TC_04, TC_05, TC_06, TC_07, TC_15_ENTS) still compile. Returns the Playwright Page.
    //                 Any code that calls WebDriver methods on it will fail to compile - which is intended.
    // Date Created  : 15-09-2026
    // ***************************************************************************************************************************************************************************************
    @Deprecated
    public static Page getDriver()
    {
        return getPage();
    }

    private static Page requirePage()
    {
        Page iPage = PlaywrightFactory.getPage();
        if (iPage == null)
        {
            throw new RuntimeException("Playwright Page is not initialised on this thread. Call launchBrowser() before iAction().");
        }
        return iPage;
    }


    // ===============================================================================================================================
    // SECTION 2 : Timestamp Utilities
    // ===============================================================================================================================

    public static String getCurrentTimestamp()
    {
        return LocalDateTime.now().format(iLogDateTimeFormatter);
    }

    public static String getCurrentFileTimestamp()
    {
        return LocalDateTime.now().format(iFileDateTimeFormatter);
    }


    // ===============================================================================================================================
    // SECTION 3 : Structured Step Logging
    // ===============================================================================================================================

    private static void logStepStart(String pActionType, String pIdentifyBy, String pObjectName, String pValue)
    {
        log.info("[" + getCurrentTimestamp() + "] STEP START | ActionType=" + pActionType
                + " | IdentifyBy=" + pIdentifyBy
                + " | Object=" + pObjectName
                + " | Value=" + maskForLog(pActionType, pValue));
    }

    private static void logStepPass(String pActionType, String pIdentifyBy, String pObjectName, String pValue, long pDurationInMilliSeconds)
    {
        log.info("[" + getCurrentTimestamp() + "] STEP PASS  | ActionType=" + pActionType
                + " | IdentifyBy=" + pIdentifyBy
                + " | Object=" + pObjectName
                + " | Value=" + maskForLog(pActionType, pValue)
                + " | Duration=" + pDurationInMilliSeconds + " ms");
    }

    private static void logStepFail(String pActionType, String pIdentifyBy, String pObjectName, String pValue, long pDurationInMilliSeconds, String pReason)
    {
        log.severe("[" + getCurrentTimestamp() + "] STEP FAIL  | ActionType=" + pActionType
                + " | IdentifyBy=" + pIdentifyBy
                + " | Object=" + pObjectName
                + " | Value=" + maskForLog(pActionType, pValue)
                + " | Duration=" + pDurationInMilliSeconds + " ms"
                + " | Reason=" + firstLine(pReason));
    }

    // Container logs are shipped to CI - never print the raw password typed into a password field
    private static String maskForLog(String pActionType, String pValue)
    {
        if (pValue == null) { return ""; }
        if ("TEXTBOX".equalsIgnoreCase(pActionType) && iMaskNextValue.get()) { return "****"; }
        return pValue;
    }

    private static final ThreadLocal<Boolean> iMaskNextValue = ThreadLocal.withInitial(() -> Boolean.FALSE);

    // Playwright for Java messages start with "Error {" - show the real message and the last call-log line instead
    private static String firstLine(String pText)
    {
        if (pText == null) { return ""; }
        int    iBreak = pText.indexOf('\n');
        String iFirst = iBreak < 0 ? pText : pText.substring(0, iBreak);
        if (!iFirst.trim().startsWith("Error {")) { return iFirst; }

        java.util.regex.Matcher iMessage = Pattern.compile("message='([^\\n]*)").matcher(pText);
        String iResult = iMessage.find() ? iMessage.group(1).trim() : iFirst;

        String iLastCall = "";
        for (String iLine : pText.split("\\R"))
        {
            String iTrim = iLine.replaceAll("\\u001B\\[[0-9;]*m", "").trim();
            if (iTrim.startsWith("- ")) { iLastCall = iTrim.replaceFirst("^-\\s*-?\\s*", ""); }
        }
        return iLastCall.isEmpty() ? iResult : iResult + " | " + iLastCall;
    }

    // ===============================================================================================================================
    // SECTION 4 : String Utilities
    // ===============================================================================================================================

    private static String sanitizeFileName(String pInput)
    {
        if (pInput == null || pInput.trim().isEmpty())
        {
            return "Unnamed";
        }

        return pInput.trim().replaceAll("[\\\\/:*?\"<>|\\s]+", "_");
    }

    private static String cssQuote(String pValue)
    {
        return "\"" + pValue.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }


    // ===============================================================================================================================
    // SECTION 5 : Browser Lifecycle
    // ===============================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Function Name : launchBrowser
    // Description   : Starts Playwright for the requested browser (via PlaywrightFactory) and navigates to the URL.
    //                 Signature unchanged from the Selenium version so Hooks and TestRunner behave the same.
    // Parameters    : pBrowserType (String) - CHROME | CHROMIUM | EDGE | FIREFOX | WEBKIT
    //                 pUrl         (String) - application URL to navigate to
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Created  : 10-03-2026 | Updated: 15-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    public static void launchBrowser(String pBrowserType, String pUrl)
    {
        try
        {
            if (pBrowserType == null || pBrowserType.trim().isEmpty())
            {
                throw new RuntimeException("Browser type cannot be blank. Supported values: CHROME, CHROMIUM, EDGE, FIREFOX, WEBKIT.");
            }

            if (pUrl == null || pUrl.trim().isEmpty())
            {
                throw new RuntimeException("URL cannot be blank.");
            }

            Page iPage = PlaywrightFactory.start(pBrowserType);

            // Optional replacement for the old per-action document.body.style.zoom='84%' hack.
            // Off by default (100). A fixed 1920x1080 viewport normally makes zoom unnecessary.
            if (iCssZoomPercent > 0 && iCssZoomPercent != 100)
            {
                String iZoom = iCssZoomPercent + "%";
                PlaywrightFactory.getContext().addInitScript("(" + JS_CSS_ZOOM + ")('" + iZoom + "')");
                log.info("[" + getCurrentTimestamp() + "] CSS zoom applied to every page : " + iZoom);
            }

            // A reused browser must not carry a token from the previous test case. Storage belongs to a web address,
            // so it is wiped for the application address BEFORE the page opens. No effect on a fresh browser.
            PlaywrightFactory.clearSiteStorageIfReused(iPage, pUrl.trim());

            iPage.navigate(pUrl.trim());

            log.info("[" + getCurrentTimestamp() + "] Browser ready | Browser=" + pBrowserType.toUpperCase(Locale.ROOT)
                    + " | " + PlaywrightFactory.getBrowserVersion() + " | URL=" + pUrl);
        }
        catch (Exception iException)
        {
            PlaywrightFactory.stop(true, "launch_failure");
            throw new RuntimeException("Browser launch failed for browser [" + pBrowserType + "] : " + iException.getMessage(), iException);
        }
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : closeBrowser
    // Description   : Closes the Playwright graph on this thread. Keeps the trace when the test failed.
    // Parameters    : pTestFailed (boolean) - true when any scenario in the test case failed
    //                 pTestCaseID (String)  - used to name the trace zip
    // Returns       : String - trace zip path or empty string
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Created  : 10-03-2026 | Updated: 15-09-2026 (Playwright + trace)
    // ***************************************************************************************************************************************************************************************
    public static String closeBrowser(boolean pTestFailed, String pTestCaseID)
    {
        if (PlaywrightFactory.getPage() == null)
        {
            log.warning("[" + getCurrentTimestamp() + "] closeBrowser called but no active page found on this thread.");
            return "";
        }

        String iTrace = PlaywrightFactory.stop(pTestFailed, pTestCaseID);

        // With browser.reuse=true the browser stays open for the next test case; TestRunner closes it at the end
        log.info("[" + getCurrentTimestamp() + "] "
                + (PlaywrightFactory.getPage() == null ? "Browser closed successfully." : "Test case finished - browser kept open for the next one."));
        return iTrace;
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : shutdownBrowser
    // Description   : Closes the browser for good after the last test case of the run (TestRunner calls this).
    //                 Needed because browser.reuse=true keeps it open between test cases.
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Created  : 18-09-2026
    // ***************************************************************************************************************************************************************************************
    public static void shutdownBrowser()
    {
        PlaywrightFactory.shutdown();
    }

    public static void closeBrowser()
    {
        closeBrowser(false, "run");
    }


    // ===============================================================================================================================
    // SECTION 6 : Locator Helpers
    // ===============================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Function Name : toSelector
    // Description   : Converts the framework IdentifyBy + locator value into a Playwright selector string.
    //                   XPATH           -> xpath=<value>        (all current Object Repository entries)
    //                   ID / NAME       -> css=[id="..."] / css=[name="..."]
    //                   CSS             -> css=<value>
    //                   CLASSNAME       -> css=[class~="..."]
    //                   TAGNAME         -> css=<tag>
    //                   LINKTEXT        -> css=a:text-is("...")
    //                   PARTIALLINKTEXT -> css=a:has-text("...")
    //                   PLAYWRIGHT      -> value used as-is (text=..., role=..., data-testid=..., chained >> selectors)
    // Parameters    : pIdentifyBy (String) - locator strategy
    //                 pObjectName (String) - locator value
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Created  : 15-09-2026
    // ***************************************************************************************************************************************************************************************
    public static String toSelector(String pIdentifyBy, String pObjectName)
    {
        String iValue = pObjectName.trim();

        switch (pIdentifyBy.trim().toUpperCase(Locale.ROOT))
        {
            case "XPATH":
                return iValue.startsWith("xpath=") ? iValue : "xpath=" + iValue;

            case "ID":
                return "css=[id=" + cssQuote(iValue) + "]";

            case "NAME":
                return "css=[name=" + cssQuote(iValue) + "]";

            case "CSS":
            case "CSSSELECTOR":
            case "CSS_SELECTOR":
                return iValue.startsWith("css=") ? iValue : "css=" + iValue;

            case "CLASSNAME":
            case "CLASS_NAME":
                return "css=[class~=" + cssQuote(iValue) + "]";

            case "TAGNAME":
            case "TAG_NAME":
                return "css=" + iValue;

            case "LINKTEXT":
            case "LINK_TEXT":
                return "css=a:text-is(" + cssQuote(iValue) + ")";

            case "PARTIALLINKTEXT":
            case "PARTIAL_LINK_TEXT":
                return "css=a:has-text(" + cssQuote(iValue) + ")";

            case "PLAYWRIGHT":
            case "PW":
            case "SELECTOR":
                return iValue;

            default:
                throw new RuntimeException("Unsupported IdentifyBy value : '" + pIdentifyBy
                        + "'. Supported values: ID, NAME, XPATH, CSS, CSSSELECTOR, CSS_SELECTOR, CLASSNAME, CLASS_NAME, "
                        + "TAGNAME, TAG_NAME, LINKTEXT, LINK_TEXT, PARTIALLINKTEXT, PARTIAL_LINK_TEXT, PLAYWRIGHT");
        }
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : getLocator
    // Description   : Returns a Playwright Locator for the current page.
    //                 locator.strict=false (default) -> first match, same behaviour as Selenium findElement().
    //                 locator.strict=true            -> Playwright strict mode (fails when more than one element matches).
    // Parameters    : pIdentifyBy (String) - locator strategy
    //                 pObjectName (String) - locator value
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Created  : 15-09-2026
    // ***************************************************************************************************************************************************************************************
    public static Locator getLocator(String pIdentifyBy, String pObjectName)
    {
        Locator iLocator = requirePage().locator(toSelector(pIdentifyBy, pObjectName));
        return iStrictLocators ? iLocator : iLocator.first();
    }

    private static Locator.WaitForOptions waitState(WaitForSelectorState pState, double pTimeoutMs)
    {
        return new Locator.WaitForOptions().setState(pState).setTimeout(pTimeoutMs);
    }

    private static void waitVisible(Locator pLocator)
    {
        pLocator.waitFor(waitState(WaitForSelectorState.VISIBLE, iActionTimeoutMs));
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : highlightElement
    // Description   : Draws a temporary red outline around the element (non-blocking). Controlled by highlight.enabled.
    //                 Disabled by default in the docker profile - it adds no value in headless runs.
    // Parameters    : pLocator (Locator) - target element
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Created  : 10-03-2026 | Updated: 15-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    public static void highlightElement(Locator pLocator)
    {
        if (!iHighlightEnabled || pLocator == null) { return; }

        try
        {
            pLocator.evaluate(JS_HIGHLIGHT, null, new Locator.EvaluateOptions().setTimeout(2000));
        }
        catch (Exception iException)
        {
            log.fine("Unable to highlight element : " + iException.getMessage());
        }
    }

    public static void scrollIntoView(Locator pLocator)
    {
        try
        {
            pLocator.scrollIntoViewIfNeeded(new Locator.ScrollIntoViewIfNeededOptions().setTimeout(5000));
        }
        catch (Exception iException)
        {
            log.warning("[" + getCurrentTimestamp() + "] Unable to scroll element into view : " + firstLine(iException.getMessage()));
        }
    }

    private static void sleepOnPage(Page pPage, int pMillis)
    {
        pPage.waitForTimeout(pMillis);
    }

    private static Boolean readCheckedState(Locator pLocator)
    {
        Object iState = pLocator.evaluate(JS_CHECKED_STATE);
        return iState instanceof Boolean ? (Boolean) iState : null;
    }

    private static String readTextOrValue(Locator pLocator)
    {
        Object iText = pLocator.evaluate(JS_TEXT_OR_VALUE);
        return iText == null ? "" : String.valueOf(iText).trim();
    }

    // Playwright sends java.util.regex.Pattern to the browser as a JavaScript RegExp, so Pattern.quote()
    // (which produces \Q...\E - unsupported in JavaScript) must NOT be used. Escape the characters manually.
    private static Pattern exactTextPattern(String pText)
    {
        return Pattern.compile("^\\s*" + escapeForJsRegex(pText.trim()) + "\\s*$", Pattern.CASE_INSENSITIVE);
    }

    public static String escapeForJsRegex(String pText)
    {
        return pText.replaceAll("[.*+?^${}()|\\[\\]\\\\/]", "\\\\$0");
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : clickWithFallback
    // Description   : Click used by every CLICK-type action. Behaviour depends on click.strategy:
    //                   auto   (default) - Step 1: normal Playwright click (waits for visible, stable, enabled, not covered).
    //                                      Step 2: if Step 1 fails for any reason within click.attempt.timeout.ms
    //                                      (overlay intercepts it, element hidden or disabled, timeout), a JavaScript
    //                                      click is used - same safety net as the Selenium
    //                                      ElementClickInterceptedException -> executeScript("arguments[0].click()").
    //                                      If both fail, the error shows both reasons.
    //                   js               - always a JavaScript click (the Selenium JavascriptExecutor way).
    //                   native           - normal Playwright click only, no fallback (full explicit wait).
    // Parameters    : pLocator    (Locator) - element to click
    //                 pObjectName (String)  - locator text for logs
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Created  : 15-09-2026 | Updated: 16-09-2026 (click.strategy)
    // ***************************************************************************************************************************************************************************************
    public static void clickWithFallback(Locator pLocator, String pObjectName)
    {
        if ("js".equals(iClickStrategy))
        {
            jsClick(pLocator, pObjectName);
            return;
        }

        if ("native".equals(iClickStrategy))
        {
            pLocator.click();
            return;
        }

        // Step 1 : normal Playwright click (real mouse click, like WebElement.click())
        try
        {
            pLocator.click(new Locator.ClickOptions().setTimeout(iClickAttemptTimeoutMs));
            return;
        }
        catch (PlaywrightException iNormalClickError)
        {
            // TimeoutError is a PlaywrightException, so blocked, covered, hidden and not-yet-enabled elements all land here.
            // A closed page or browser cannot be clicked at all - report that straight away instead of trying JavaScript.
            String iReason = firstLine(iNormalClickError.getMessage());
            if (isPageClosed(iNormalClickError))
            {
                throw iNormalClickError;
            }

            log.warning("[" + getCurrentTimestamp() + "] Normal click failed within " + (long) iClickAttemptTimeoutMs
                    + " ms. Retrying with JavaScript click for locator : " + pObjectName + " | " + iReason);

            // Step 2 : JavaScript click - executeScript("arguments[0].click();", element)
            try
            {
                jsClick(pLocator, pObjectName);
            }
            catch (RuntimeException iJsClickError)
            {
                throw new RuntimeException("Click failed for locator : " + pObjectName
                        + " | Normal click : " + iReason
                        + " | JavaScript click : " + firstLine(iJsClickError.getMessage()), iJsClickError);
            }
        }
    }

    private static boolean isPageClosed(Throwable pError)
    {
        String iMessage = pError.getMessage() == null ? "" : pError.getMessage().toLowerCase(Locale.ROOT);
        return iMessage.contains("target page, context or browser has been closed")
                || iMessage.contains("target closed")
                || iMessage.contains("browser has been closed");
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : jsClick
    // Description   : JavaScript click - the Playwright equivalent of
    //                   ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element)
    //                 Scrolls the element to the centre first. Works even when an overlay covers the element or the
    //                 element is not considered visible, because no mouse event is simulated.
    //                 Waits (explicit.wait.seconds) for the element to exist in the page before clicking.
    // Parameters    : pLocator    (Locator) - element to click
    //                 pObjectName (String)  - locator text for logs (may be blank)
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Created  : 16-09-2026
    // ***************************************************************************************************************************************************************************************
    public static void jsClick(Locator pLocator, String pObjectName)
    {
        if (pLocator == null)
        {
            throw new RuntimeException("jsClick: locator cannot be null.");
        }

        pLocator.evaluate(JS_CLICK);
        log.info("[" + getCurrentTimestamp() + "] JavaScript click performed" + (pObjectName == null || pObjectName.isBlank() ? "" : " | Object=" + pObjectName));
    }

    public static void jsClick(Locator pLocator)
    {
        jsClick(pLocator, "");
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : jsClick
    // Description   : JavaScript click by IdentifyBy + locator, e.g.
    //                   CommonFunctions.jsClick("XPATH", ObjReader.getLocator("iLoginbtn"));
    //                 Same result as iAction("JSCLICK", ...) but without a step-log row.
    // Parameters    : pIdentifyBy (String) - XPATH | CSS | ID | ... | PLAYWRIGHT
    //                 pObjectName (String) - locator value
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Created  : 16-09-2026
    // ***************************************************************************************************************************************************************************************
    public static void jsClick(String pIdentifyBy, String pObjectName)
    {
        jsClick(getLocator(pIdentifyBy, pObjectName), pObjectName);
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : executeScript
    // Description   : Selenium-compatible JavaScript executor. Paste the script exactly as it was written for
    //                 JavascriptExecutor: 'arguments[0]', 'arguments[1]' ... and 'return' work unchanged.
    //                 Locator arguments are turned into DOM elements (like WebElement arguments in Selenium);
    //                 strings, numbers, booleans, lists and maps are passed as plain values.
    //
    //                 Selenium                                                              Playwright
    //                 js.executeScript("arguments[0].click();", element)                -> executeScript("arguments[0].click();", locator)
    //                 js.executeScript("arguments[0].scrollIntoView(true);", element)   -> executeScript("arguments[0].scrollIntoView(true);", locator)
    //                 js.executeScript("arguments[0].value=arguments[1];", element, v)  -> executeScript("arguments[0].value=arguments[1];", locator, v)
    //                 js.executeScript("return document.readyState;")                  -> executeScript("return document.readyState;")
    //
    // Parameters    : pScript (String)    - JavaScript function body
    //                 pArgs   (Object...) - Locator, ElementHandle, String, Number, Boolean, List or Map values
    // Returns       : Object - the value returned by the script (String, Number, Boolean, List, Map or null)
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Created  : 16-09-2026
    // ***************************************************************************************************************************************************************************************
    public static Object executeScript(String pScript, Object... pArgs)
    {
        if (pScript == null || pScript.trim().isEmpty())
        {
            throw new RuntimeException("executeScript: script cannot be blank.");
        }

        Page                iPage    = requirePage();
        List<Object>        iArgs    = new ArrayList<>();
        List<ElementHandle> iHandles = new ArrayList<>();

        try
        {
            if (pArgs != null)
            {
                for (Object iArg : pArgs)
                {
                    if (iArg instanceof Locator)
                    {
                        ElementHandle iHandle = ((Locator) iArg).elementHandle();
                        iHandles.add(iHandle);
                        iArgs.add(iHandle);
                    }
                    else
                    {
                        iArgs.add(toJsArg(iArg));
                    }
                }
            }

            return iPage.evaluate(JS_EXECUTE_SCRIPT_WRAPPER.replace("__SCRIPT__", pScript), iArgs);
        }
        finally
        {
            for (ElementHandle iHandle : iHandles)
            {
                try { iHandle.dispose(); } catch (Exception iIgnored) { }
            }
        }
    }


    // ===============================================================================================================================
    // SECTION 7 : iAction - Per-Type Private Action Methods
    // ===============================================================================================================================

    private static void performClick(Locator pLocator, String pObjectName)
    {
        waitVisible(pLocator);
        highlightElement(pLocator);
        clickWithFallback(pLocator, pObjectName);
    }

    // JavaScript click: needs the element in the page, not necessarily visible or uncovered
    private static void performJsClick(Locator pLocator, String pObjectName)
    {
        pLocator.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.ATTACHED).setTimeout(iActionTimeoutMs));
        highlightElement(pLocator);
        jsClick(pLocator, pObjectName);
    }

    private static void performDoubleClick(Locator pLocator)
    {
        waitVisible(pLocator);
        highlightElement(pLocator);
        pLocator.dblclick();
    }

    private static void performRightClick(Locator pLocator)
    {
        waitVisible(pLocator);
        highlightElement(pLocator);
        pLocator.click(new Locator.ClickOptions().setButton(MouseButton.RIGHT));
    }

    private static void performHover(Locator pLocator)
    {
        waitVisible(pLocator);
        highlightElement(pLocator);
        pLocator.hover();
    }

    private static void performTextBox(Locator pLocator, String pValue)
    {
        if (pValue == null)
        {
            throw new RuntimeException("TEXTBOX action requires a non-null value.");
        }

        waitVisible(pLocator);
        highlightElement(pLocator);
        // fill() waits for the element to be enabled and editable (not readonly), clears it, then types the value
        // and fires input/change events - which Angular reactive forms need.
        pLocator.fill(pValue);
    }

    private static void performClearTextBox(Locator pLocator)
    {
        waitVisible(pLocator);
        highlightElement(pLocator);
        pLocator.clear();
    }

    private static void performRadioButton(Locator pLocator, String pObjectName)
    {
        waitVisible(pLocator);
        highlightElement(pLocator);

        Boolean iChecked = readCheckedState(pLocator);

        if (Boolean.TRUE.equals(iChecked))
        {
            log.info("[" + getCurrentTimestamp() + "] Radio button is already selected. No click performed.");
            return;
        }

        clickWithFallback(pLocator, pObjectName);
    }

    private static void performCheckBox(Locator pLocator, String pObjectName, String pValue)
    {
        if (pValue == null || pValue.trim().isEmpty())
        {
            throw new RuntimeException("CHECKBOX action requires CHECK or UNCHECK as value.");
        }

        waitVisible(pLocator);
        highlightElement(pLocator);

        String  iCheckboxAction = pValue.trim().toUpperCase(Locale.ROOT);
        Boolean iChecked        = readCheckedState(pLocator);

        if ("CHECK".equals(iCheckboxAction))
        {
            if (Boolean.TRUE.equals(iChecked))
            {
                log.info("[" + getCurrentTimestamp() + "] Checkbox is already checked. No click performed.");
            }
            else
            {
                clickWithFallback(pLocator, pObjectName);
            }
        }
        else if ("UNCHECK".equals(iCheckboxAction))
        {
            if (Boolean.TRUE.equals(iChecked))
            {
                clickWithFallback(pLocator, pObjectName);
            }
            else if (iChecked == null)
            {
                log.warning("[" + getCurrentTimestamp() + "] Checkbox state could not be read for " + pObjectName + ". No click performed.");
            }
            else
            {
                log.info("[" + getCurrentTimestamp() + "] Checkbox is already unchecked. No click performed.");
            }
        }
        else
        {
            throw new RuntimeException("CHECKBOX only accepts CHECK or UNCHECK. Passed value : '" + pValue + "'");
        }
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : performList
    // Description   : Self-healing dropdown handler supporting mat-select, native <select>, and Angular Material
    //                 options rendered inside cdk-overlay-container / mat-dialog portals / popover panels.
    //                   1. tag = mat-select                          -> performMatSelect
    //                   2. tag = select                              -> performNativeSelect (Playwright selectOption)
    //                   3. wrapper that contains a mat-select        -> performMatSelect on the inner mat-select
    //                      (lib-biss-select-search, mat-form-field, ...)
    //                   4. the mat-select trigger div itself         -> performMatSelect on the parent mat-select
    //                   5. anything else                             -> performOverlayOptionClick (root-scoped visible mat-option)
    // Date Updated  : 16-09-2026 (Playwright - wrapper and trigger-div support)
    // ***************************************************************************************************************************************************************************************
    private static void performList(Page pPage, Locator pLocator, String pValue)
    {
        if (pValue == null || pValue.trim().isEmpty())
        {
            throw new RuntimeException("LIST action requires a selection value.");
        }

        waitVisible(pLocator);
        highlightElement(pLocator);

        String iTagName   = String.valueOf(pLocator.evaluate("element => element.tagName.toLowerCase()")).trim();
        String iListValue = pValue.trim();

        log.info("[" + getCurrentTimestamp() + "] LIST | tag=<" + iTagName + "> | value=" + iListValue);

        if ("mat-select".equals(iTagName))
        {
            performMatSelect(pPage, pLocator, iListValue);
            return;
        }

        if ("select".equals(iTagName))
        {
            performNativeSelect(pLocator, iListValue);
            return;
        }

        Locator iInnerSelect = pLocator.locator("css=mat-select");
        if (iInnerSelect.count() > 0)
        {
            log.info("[" + getCurrentTimestamp() + "] LIST | <" + iTagName + "> wraps a mat-select - using the inner mat-select.");
            performMatSelect(pPage, iInnerSelect.first(), iListValue);
            return;
        }

        Locator iParentSelect = pLocator.locator("xpath=ancestor::mat-select[1]");
        if (iParentSelect.count() > 0)
        {
            log.info("[" + getCurrentTimestamp() + "] LIST | <" + iTagName + "> is inside a mat-select - using the parent mat-select.");
            performMatSelect(pPage, iParentSelect.first(), iListValue);
            return;
        }

        log.warning("[" + getCurrentTimestamp() + "] LIST | tag=<" + iTagName
                + "> is not a recognised dropdown tag. Attempting overlay direct-option click for value: '" + iListValue + "'");
        performOverlayOptionClick(pPage, iListValue);
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : performOverlayOptionClick
    // Description   : Fallback for mat-option elements rendered in the CDK overlay portal (e.g. mat-select inside a mat-dialog).
    //                 Finds the first VISIBLE mat-option in the document whose text equals pValue (case-insensitive).
    // Date Updated  : 15-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    private static void performOverlayOptionClick(Page pPage, String pValue)
    {
        Locator iOption = pPage.locator(MAT_OPTION_CSS)
                .filter(new Locator.FilterOptions().setHasText(exactTextPattern(pValue)))
                .locator("visible=true")
                .first();

        try
        {
            iOption.waitFor(waitState(WaitForSelectorState.VISIBLE, iListOptionTimeoutMs));
        }
        catch (TimeoutError iTimeout)
        {
            throw new RuntimeException("Option '" + pValue + "' not found in DOM via root-scoped search. Available: "
                    + String.join(" | ", pPage.locator(MAT_OPTION_CSS).allInnerTexts()), iTimeout);
        }

        scrollIntoView(iOption);
        highlightElement(iOption);
        clickWithFallback(iOption, "mat-option '" + pValue + "'");
        log.info("[" + getCurrentTimestamp() + "] OVERLAY-LIST | Option clicked: '" + pValue + "'");
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : performMatSelect
    // Description   : Angular Material <mat-select> handler (standard and searchable ngx-mat-select-search dropdowns,
    //                 panels in the CDK overlay container or in a popover). Accepts INDEX:, VISIBLETEXT:, VALUE: or plain text.
    //                 Built for speed: every wait runs INSIDE the browser (50 ms polling, one round trip) instead of
    //                 many small Playwright calls.
    //                   0. Read id / open / disabled state in one call and pin the dropdown by id
    //                      (an XPath such as "first empty dropdown" moves to another dropdown once this one has a value).
    //                   1. Open: wait while disabled (Townland before County), click the .mat-mdc-select-trigger div,
    //                      fall back to a JavaScript click on it, then the Enter key.
    //                   2. Find THIS dropdown's panel through aria-controls; read searchable / multiple once, while it is open.
    //                   3. Searchable: type the text (force - the box sits inside an aria-disabled mat-option).
    //                      If the option does not show, search again with the name before " - ", the code after it,
    //                      then an empty box.
    //                   4. The browser marks the matching option once the list has stopped changing, Playwright clicks it.
    //                   5. Check the dropdown now shows the chosen text.
    // Date Updated  : 16-09-2026 (Playwright - in-browser waits, no attribute reads on a closed panel)
    // ***************************************************************************************************************************************************************************************
    private static void performMatSelect(Page pPage, Locator pSelect, String pValue)
    {
        long   iStart = System.currentTimeMillis();
        String iToken = Long.toString(System.nanoTime(), 36);

        // STEP 0 : STATE + PIN BY ID
        Map<String, Object> iState    = selectState(pSelect);
        String              iSelectId = str(iState.get("id"));
        Locator iSelect = iSelectId.isEmpty() ? pSelect : pPage.locator("css=mat-select[id='" + iSelectId + "']");
        String  iName   = "mat-select" + (iSelectId.isEmpty() ? "" : " #" + iSelectId);

        // STEP 1 : OPEN
        openMatSelect(iSelect, iName, iState);

        // STEP 2 : PANEL (read everything we need now, while it is open)
        Map<String, Object> iPanelInfo = asMap(iSelect.evaluate(JS_RESOLVE_PANEL, mapOf("token", iToken, "ms", (int) iActionTimeoutMs)));
        if (iPanelInfo == null || str(iPanelInfo.get("id")).isEmpty())
        {
            log.warning("[" + getCurrentTimestamp() + "] MAT-SELECT | No panel found for " + iName
                    + ". Delegating to overlay option click for value: '" + pValue + "'");
            performOverlayOptionClick(pPage, pValue);
            return;
        }

        String  iPanelId   = str(iPanelInfo.get("id"));
        boolean iSearch    = Boolean.TRUE.equals(iPanelInfo.get("searchable"));
        boolean iMultiple  = Boolean.TRUE.equals(iPanelInfo.get("multiple"));
        Locator iPanel     = pPage.locator("css=[id='" + iPanelId + "']");

        // STEP 3 + 4 : FIND THE OPTION
        String  iUpper = pValue.toUpperCase(Locale.ROOT);
        String  iText;
        int     iIndex = -1;

        if (iUpper.startsWith("INDEX:"))
        {
            iIndex = Integer.parseInt(pValue.substring("INDEX:".length()).trim());
            iText  = "";
        }
        else if (iUpper.startsWith("VISIBLETEXT:"))
        {
            iText = pValue.substring("VISIBLETEXT:".length()).trim();
        }
        else if (iUpper.startsWith("VALUE:"))
        {
            iText = pValue.substring("VALUE:".length()).trim();
            log.warning("MAT-SELECT | VALUE: prefix treated as visible text.");
        }
        else
        {
            iText = pValue.trim();
        }

        Map<String, Object> iPick;
        if (iSearch && iIndex < 0)
        {
            iPick = searchAndPick(pPage, iPanel, iPanelId, iText, iToken);
        }
        else
        {
            iPick = pickOption(pPage, iPanelId, iText, iIndex, iToken, 0, LIST_NO_MATCH_MS, false, iListOptionTimeoutMs);
        }

        if (iPick == null || !Boolean.TRUE.equals(iPick.get("found")))
        {
            pPage.keyboard().press("Escape");
            throw new RuntimeException("MAT-SELECT | No option found matching: '" + (iIndex >= 0 ? "INDEX:" + iIndex : iText) + "' in " + iName
                    + "\nAvailable: " + (iPick == null ? "" : str(iPick.get("sample"))));
        }

        String  iPicked = str(iPick.get("text"));
        Locator iTarget = iPanel.locator("css=mat-option[data-pw-pick='" + iToken + "']");
        try
        {
            iTarget.click(new Locator.ClickOptions().setTimeout(Math.min(iClickAttemptTimeoutMs, 3000)));
        }
        catch (PlaywrightException iClickError)
        {
            if (isPageClosed(iClickError)) { throw iClickError; }

            // The list was redrawn between marking and clicking (late filter) - mark the option again once and click it
            log.warning("[" + getCurrentTimestamp() + "] MAT-SELECT | Click on '" + iPicked + "' did not land ("
                    + firstLine(iClickError.getMessage()) + ") - finding the option again.");
            Map<String, Object> iAgain = pickOption(pPage, iPanelId, iIndex >= 0 ? "" : iText, iIndex, iToken, 1000, -1, false, 10000);
            if (iAgain == null || !Boolean.TRUE.equals(iAgain.get("found")))
            {
                throw new RuntimeException("MAT-SELECT | Option '" + iPicked + "' disappeared from " + iName + " before it could be clicked.", iClickError);
            }
            clickWithFallback(iTarget, "mat-option '" + iPicked + "'");
        }

        // STEP 5 : CLOSE + VERIFY (the panel is not read again after the click - it may already be gone)
        if (!iMultiple)
        {
            waitPanelClosed(iPanel);
        }

        String iShown = str(selectState(iSelect).get("value"));
        String iWant  = iIndex >= 0 ? iPicked : iText;
        if (iShown.toLowerCase(Locale.ROOT).contains(iWant.toLowerCase(Locale.ROOT)) || iMultiple)
        {
            log.info("[" + getCurrentTimestamp() + "] MAT-SELECT | " + iName + " = '" + iShown + "' ("
                    + (System.currentTimeMillis() - iStart) + " ms" + (iSearch ? ", searchable" : "") + ")");
            return;
        }

        throw new RuntimeException("MAT-SELECT | Option '" + iPicked + "' was clicked but " + iName + " shows '" + iShown + "'.");
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : searchAndPick
    // Description   : Searchable dropdowns do not all filter the same way (whole label, name only, server-side).
    //                 Searches with the full text, then the name before " - ", then the code after it, then an empty box,
    //                 and stops at the first search that shows the option. A search that leaves the list unchanged
    //                 without the option for 1.5 s counts as "no match" and the next search is tried. With the empty box,
    //                 a full list without the option for 3 s fails the step straight away.
    // Date Created  : 16-09-2026
    // ***************************************************************************************************************************************************************************************
    private static Map<String, Object> searchAndPick(Page pPage, Locator pPanel, String pPanelId, String pText, String pToken)
    {
        Locator iSearchInput = pPanel.locator("css=input.mat-select-search-input:not(.mat-select-search-hidden)").first();

        List<String> iTerms = new ArrayList<>();
        iTerms.add(pText);
        int iDash = pText.indexOf(" - ");
        if (iDash > 0)
        {
            iTerms.add(pText.substring(0, iDash).trim());
            iTerms.add(pText.substring(iDash + 3).trim());
        }
        iTerms.add("");

        Map<String, Object> iLast = null;
        for (int i = 0; i < iTerms.size(); i++)
        {
            String  iTerm     = iTerms.get(i);
            boolean iLastTerm = i == iTerms.size() - 1;

            typeIntoSelectSearch(iSearchInput, iTerm);

            // 400 ms of an unchanged list after typing covers debounced filters; the last search waits the full timeout
            iLast = pickOption(pPage, pPanelId, pText, -1, pToken, SEARCH_SETTLE_MS,
                    iLastTerm ? LIST_NO_MATCH_MS : SEARCH_NO_MATCH_MS, !iLastTerm,
                    iLastTerm ? iListOptionTimeoutMs : Math.min(iListOptionTimeoutMs, 10000));
            if (iLast != null && Boolean.TRUE.equals(iLast.get("found")))
            {
                if (i > 0)
                {
                    log.info("[" + getCurrentTimestamp() + "] MAT-SELECT | '" + pText + "' found after searching '" + iTerm + "'");
                }
                return iLast;
            }
            log.warning("[" + getCurrentTimestamp() + "] MAT-SELECT | '" + pText + "' not shown after searching '" + iTerm + "'"
                    + (iLastTerm ? "." : " - trying the next search."));
        }
        return iLast;
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : pickOption
    // Description   : One browser round trip. Polls the panel every 50 ms until the option list has not changed for
    //                 pSettleMs and a matching option exists, then marks it with data-pw-pick=<token>.
    //                 Match: exact text (case-insensitive, spaces ignored at both ends), else the ONLY option that contains
    //                 the text; or the option at pIndex when pIndex >= 0.
    //                 pNoMatchMs  : give up early when the list has not changed for this long (-1 = never)
    //                 pAllowEmpty : an empty list also counts as "no match" (true while searching - the filter may hide everything)
    // Returns       : {found:true, text} | {found:false, sample} (no match after pNoMatchMs of a stable list, or timeout)
    // Date Created  : 16-09-2026
    // ***************************************************************************************************************************************************************************************
    private static Map<String, Object> pickOption(Page pPage, String pPanelId, String pText, int pIndex, String pToken,
                                                  int pSettleMs, int pNoMatchMs, boolean pAllowEmpty, double pTimeoutMs)
    {
        Map<String, Object> iArgs = mapOf("panelId", pPanelId, "text", pText, "index", pIndex, "token", pToken,
                "settleMs", pSettleMs, "noMatchMs", pNoMatchMs, "allowEmpty", pAllowEmpty, "ms", (int) pTimeoutMs);
        return asMap(pPage.evaluate(JS_PICK_OPTION, iArgs));
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : openMatSelect
    // Description   : Opens a mat-select. Waits (in the browser) while it is disabled, e.g. Townland until County has loaded.
    //                 Angular Material listens for the click on the inner .mat-mdc-select-trigger div.
    //                 Order: normal click on the trigger div, JavaScript click on it, Enter key on the mat-select.
    // Date Created  : 16-09-2026 | Updated: 16-09-2026 (in-browser waits)
    // ***************************************************************************************************************************************************************************************
    private static void openMatSelect(Locator pSelect, String pName, Map<String, Object> pState)
    {
        if (Boolean.TRUE.equals(pState.get("open")))
        {
            return;
        }

        if (Boolean.TRUE.equals(pState.get("disabled")))
        {
            log.info("[" + getCurrentTimestamp() + "] MAT-SELECT | " + pName + " is disabled - waiting for it to be enabled.");
            if (!waitSelect(pSelect, "enabled", (long) iActionTimeoutMs))
            {
                throw new RuntimeException("MAT-SELECT | " + pName + " is still disabled after " + (long) iActionTimeoutMs
                        + " ms. A dropdown it depends on (e.g. County for Townland) may not have been set.");
            }
        }

        Locator iTrigger = Boolean.TRUE.equals(pState.get("hasTrigger"))
                ? pSelect.locator("css=.mat-mdc-select-trigger, .mat-select-trigger").first()
                : pSelect;

        // 1. Normal click
        try
        {
            iTrigger.click(new Locator.ClickOptions().setTimeout(iClickAttemptTimeoutMs));
        }
        catch (PlaywrightException iClickError)
        {
            if (isPageClosed(iClickError)) { throw iClickError; }
            log.warning("[" + getCurrentTimestamp() + "] MAT-SELECT | Normal click did not reach " + pName + " : " + firstLine(iClickError.getMessage()));
        }
        if (waitSelect(pSelect, "open", 1500)) { return; }

        // 2. JavaScript click on the trigger div (checked again first - a click on an open dropdown closes it)
        if (Boolean.TRUE.equals(selectState(pSelect).get("open"))) { return; }
        log.warning("[" + getCurrentTimestamp() + "] MAT-SELECT | " + pName + " did not open - retrying with JavaScript click on the trigger.");
        try
        {
            jsClick(iTrigger, pName + " trigger");
        }
        catch (PlaywrightException iJsError)
        {
            log.warning("[" + getCurrentTimestamp() + "] MAT-SELECT | JavaScript click failed : " + firstLine(iJsError.getMessage()));
        }
        if (waitSelect(pSelect, "open", 1500)) { return; }

        // 3. Keyboard
        if (Boolean.TRUE.equals(selectState(pSelect).get("open"))) { return; }
        log.warning("[" + getCurrentTimestamp() + "] MAT-SELECT | " + pName + " still closed - trying the Enter key.");
        try
        {
            pSelect.focus();
            pSelect.press("Enter");
        }
        catch (PlaywrightException iKeyError)
        {
            log.warning("[" + getCurrentTimestamp() + "] MAT-SELECT | Enter key failed : " + firstLine(iKeyError.getMessage()));
        }
        if (waitSelect(pSelect, "open", 1500)) { return; }

        throw new RuntimeException("MAT-SELECT | " + pName + " did not open (normal click, JavaScript click and Enter key all tried).");
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : typeIntoSelectSearch
    // Description   : Types into the ngx-mat-select-search box of an open panel.
    //                 The box sits inside <mat-option aria-disabled="true">; Playwright treats everything under an
    //                 aria-disabled ancestor as disabled, so fill() needs force=true (Selenium sendKeys ignored aria-disabled).
    //                 Fallback: set the value with JavaScript and fire the input event Angular listens to.
    // Date Created  : 16-09-2026
    // ***************************************************************************************************************************************************************************************
    private static void typeIntoSelectSearch(Locator pSearchInput, String pText)
    {
        try
        {
            pSearchInput.fill(pText, new Locator.FillOptions().setForce(true).setTimeout(3000));
            return;
        }
        catch (PlaywrightException iFillError)
        {
            log.warning("[" + getCurrentTimestamp() + "] MAT-SELECT | fill() on the search box failed, setting it with JavaScript : "
                    + firstLine(iFillError.getMessage()));
        }

        try
        {
            pSearchInput.evaluate(JS_SET_SEARCH_VALUE, pText, new Locator.EvaluateOptions().setTimeout(3000));
        }
        catch (PlaywrightException iJsError)
        {
            log.warning("[" + getCurrentTimestamp() + "] MAT-SELECT | Could not type into the search box, picking from the full list : "
                    + firstLine(iJsError.getMessage()));
        }
    }

    // Reads id, open, disabled, trigger presence and the displayed value in one call
    private static Map<String, Object> selectState(Locator pSelect)
    {
        Map<String, Object> iState = asMap(pSelect.evaluate(JS_SELECT_STATE));
        return iState == null ? new java.util.HashMap<>() : iState;
    }

    // Polls inside the browser every 50 ms (one round trip). pWant = "open" | "enabled"
    // A failing check is NOT treated as "closed": that would send a JavaScript click that closes an open dropdown.
    private static boolean waitSelect(Locator pSelect, String pWant, long pTimeoutMs)
    {
        return Boolean.TRUE.equals(pSelect.evaluate(JS_WAIT_SELECT, mapOf("want", pWant, "ms", (int) pTimeoutMs)));
    }

    private static void waitPanelClosed(Locator pPanel)
    {
        try
        {
            pPanel.waitFor(waitState(WaitForSelectorState.HIDDEN, 5000));
        }
        catch (Exception iIgnored)
        {
            log.fine("MAT-SELECT | Panel still open after selection (slow animation).");
        }
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> asMap(Object pValue)
    {
        return pValue instanceof Map ? (Map<String, Object>) pValue : null;
    }

    private static String str(Object pValue)
    {
        return pValue == null ? "" : String.valueOf(pValue);
    }

    private static Map<String, Object> mapOf(Object... pKeyValues)
    {
        Map<String, Object> iMap = new java.util.LinkedHashMap<>();
        for (int i = 0; i + 1 < pKeyValues.length; i += 2)
        {
            iMap.put(String.valueOf(pKeyValues[i]), toJsArg(pKeyValues[i + 1]));
        }
        return iMap;
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : toJsArg
    // Description   : Playwright for Java only sends Integer, Double, Boolean, String, Date, List, Map, arrays and element
    //                 handles to the browser. Any other type (Long, Float, Short, Character ...) fails with
    //                 "Unsupported type of argument". This converts them: whole numbers -> Integer (Double if too big),
    //                 other numbers -> Double, Character -> String; lists and maps are converted value by value.
    // Date Created  : 17-09-2026
    // ***************************************************************************************************************************************************************************************
    public static Object toJsArg(Object pValue)
    {
        if (pValue instanceof Long || pValue instanceof Short || pValue instanceof Byte || pValue instanceof java.util.concurrent.atomic.AtomicInteger)
        {
            long iLong = ((Number) pValue).longValue();
            return (iLong >= Integer.MIN_VALUE && iLong <= Integer.MAX_VALUE) ? (Object) (int) iLong : (Object) (double) iLong;
        }
        if (pValue instanceof Float || pValue instanceof java.math.BigDecimal)
        {
            return ((Number) pValue).doubleValue();
        }
        if (pValue instanceof Character)
        {
            return String.valueOf(pValue);
        }
        if (pValue instanceof List)
        {
            List<Object> iList = new ArrayList<>();
            for (Object iItem : (List<?>) pValue) { iList.add(toJsArg(iItem)); }
            return iList;
        }
        if (pValue instanceof Map)
        {
            Map<String, Object> iMap = new java.util.LinkedHashMap<>();
            for (Map.Entry<?, ?> iEntry : ((Map<?, ?>) pValue).entrySet()) { iMap.put(String.valueOf(iEntry.getKey()), toJsArg(iEntry.getValue())); }
            return iMap;
        }
        return pValue;
    }

    private static void performNativeSelect(Locator pLocator, String pListValue)
    {
        String       iUpperValue = pListValue.toUpperCase(Locale.ROOT);
        SelectOption iOption;

        if (iUpperValue.startsWith("VISIBLETEXT:"))
        {
            iOption = new SelectOption().setLabel(pListValue.substring("VISIBLETEXT:".length()).trim());
        }
        else if (iUpperValue.startsWith("VALUE:"))
        {
            iOption = new SelectOption().setValue(pListValue.substring("VALUE:".length()).trim());
        }
        else if (iUpperValue.startsWith("INDEX:"))
        {
            iOption = new SelectOption().setIndex(Integer.parseInt(pListValue.substring("INDEX:".length()).trim()));
        }
        else
        {
            iOption = new SelectOption().setLabel(pListValue);
        }

        pLocator.selectOption(iOption);
        log.info("[" + getCurrentTimestamp() + "] NATIVE SELECT | Selected: '" + pListValue + "'");
    }

    private static void performDragDrop(Locator pSource, String pValue)
    {
        if (pValue == null || pValue.trim().isEmpty())
        {
            throw new RuntimeException("DRAGDROP action requires target locator in format IDENTIFYBY:::LOCATORVALUE.");
        }

        String[] iTargetDetails = pValue.split(":::", 2);

        if (iTargetDetails.length != 2)
        {
            throw new RuntimeException("DRAGDROP value format is invalid. Expected: IDENTIFYBY:::LOCATORVALUE. Received: '" + pValue + "'");
        }

        Locator iTarget = getLocator(iTargetDetails[0].trim(), iTargetDetails[1].trim());

        waitVisible(pSource);
        waitVisible(iTarget);
        highlightElement(pSource);
        highlightElement(iTarget);
        pSource.dragTo(iTarget);
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : performUploadFile
    // Description   : Sets files on an <input type=file>. Works on HIDDEN inputs - no JavaScript un-hiding needed.
    //                 Relative paths are resolved against the project root (user.dir), which is /app in the container.
    // Date Updated  : 15-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    private static void performUploadFile(Locator pLocator, String pValue)
    {
        if (pValue == null || pValue.trim().isEmpty())
        {
            throw new RuntimeException("UPLOADFILE action requires a file path.");
        }

        Path iPath = resolveFilePath(pValue);
        pLocator.waitFor(waitState(WaitForSelectorState.ATTACHED, iActionTimeoutMs));
        pLocator.setInputFiles(iPath);
    }

    public static Path resolveFilePath(String pValue)
    {
        Path iPath = Paths.get(pValue.trim().replace('\\', '/'));
        if (!iPath.isAbsolute())
        {
            iPath = Paths.get(System.getProperty("user.dir")).resolve(iPath);
        }

        if (!Files.exists(iPath))
        {
            throw new RuntimeException("Upload file not found : " + iPath
                    + " (paths are case-sensitive inside the Linux container)");
        }
        return iPath;
    }

    private static void performWaitVisible(Locator pLocator, String pObjectName)
    {
        try
        {
            pLocator.waitFor(waitState(WaitForSelectorState.VISIBLE, iWaitVisibleTimeoutMs));
            scrollIntoView(pLocator);
            highlightElement(pLocator);
        }
        catch (Exception iException)
        {
            throw new RuntimeException("WAITVISIBLE failed for locator: " + pObjectName + " | Reason: " + firstLine(iException.getMessage()), iException);
        }
    }

    private static Locator performWaitClickable(Page pPage, Locator pLocator, String pObjectName)
    {
        waitVisible(pLocator);

        long iDeadline = System.currentTimeMillis() + (long) iActionTimeoutMs;
        while (!pLocator.isEnabled())
        {
            if (System.currentTimeMillis() > iDeadline)
            {
                throw new RuntimeException("WAITCLICKABLE timed out. Element is still disabled : " + pObjectName);
            }
            sleepOnPage(pPage, iPollIntervalMs);
        }

        scrollIntoView(pLocator);
        return pLocator;
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : performWaitInvisible
    // Description   : Waits until a spinner/overlay is gone. "Gone" means: not in DOM, aria-hidden=true, display:none,
    //                 visibility:hidden, opacity 0, or zero size. (Playwright's own HIDDEN state treats opacity 0 as
    //                 visible, so the MDC spinner needs this custom check - same rules as the Selenium version.)
    // Date Updated  : 15-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    private static void performWaitInvisible(Page pPage, String pSelector, String pObjectName)
    {
        String  iSelector = resolveSpinnerSelector(pSelector, pObjectName);
        Locator iAll      = pPage.locator(iSelector);
        long    iDeadline = System.currentTimeMillis() + (long) iActionTimeoutMs;

        log.info("[" + getCurrentTimestamp() + "] WAITINVISIBLE - watching locator : " + pObjectName);

        while (!isGone(iAll))
        {
            if (System.currentTimeMillis() > iDeadline)
            {
                throw new RuntimeException("WAITINVISIBLE timed out. Spinner still visible after " + (long) iActionTimeoutMs
                        + " ms | Locator: " + pObjectName);
            }
            sleepOnPage(pPage, iPollIntervalMs);
        }

        log.info("[" + getCurrentTimestamp() + "] WAITINVISIBLE - spinner dismissed successfully : " + pObjectName);
    }

    private static boolean isGone(Locator pAll)
    {
        try
        {
            if (pAll.count() == 0) { return true; }
            Object iHidden = pAll.first().evaluate(JS_IS_HIDDEN, null, new Locator.EvaluateOptions().setTimeout(2000));
            return Boolean.TRUE.equals(iHidden);
        }
        catch (PlaywrightException iException)
        {
            // Element detached between count() and evaluate() - poll again, the next count() will be 0
            return false;
        }
    }

    private static String resolveSpinnerSelector(String pSelector, String pObjectName)
    {
        if (pObjectName != null && (
                pObjectName.contains("mdc-circular-progress__gap-patch") ||
                        pObjectName.contains("name()='circle'") ||
                        pObjectName.contains("name()='svg'")))
        {
            log.info("[" + getCurrentTimestamp() + "] WAITINVISIBLE - SVG spinner locator detected. Watching parent .mdc-circular-progress container.");
            return "css=.mdc-circular-progress";
        }

        return pSelector;
    }

    private static void performScrollToElement(Locator pLocator)
    {
        waitVisible(pLocator);
        scrollIntoView(pLocator);
        highlightElement(pLocator);
    }

    private static String performGetText(Page pPage, Locator pLocator, String pObjectName)
    {
        waitVisible(pLocator);

        long   iDeadline = System.currentTimeMillis() + (long) iActionTimeoutMs;
        String iText     = readTextOrValue(pLocator);

        while (iText.isEmpty())
        {
            if (System.currentTimeMillis() > iDeadline)
            {
                throw new RuntimeException("GETTEXT timed out. Element has no text or value : " + pObjectName);
            }
            sleepOnPage(pPage, iPollIntervalMs);
            iText = readTextOrValue(pLocator);
        }

        scrollIntoView(pLocator);
        highlightElement(pLocator);
        log.info("[" + getCurrentTimestamp() + "] GETTEXT value captured : '" + iText + "'");
        return iText;
    }

    private static String performVerifyText(Locator pLocator, String pValue)
    {
        if (pValue == null)
        {
            throw new RuntimeException("VERIFYTEXT action requires an expected value.");
        }

        waitVisible(pLocator);
        scrollIntoView(pLocator);
        highlightElement(pLocator);

        String  iActualText = readTextOrValue(pLocator);
        String  iTrimmed    = pValue.trim();
        String  iUpper      = iTrimmed.toUpperCase(Locale.ROOT);
        String  iResolvedExpected;
        String  iMatchMode;
        boolean iVerificationPassed;

        if (iUpper.startsWith("EXACT:"))
        {
            iResolvedExpected   = iTrimmed.substring("EXACT:".length()).trim();
            iMatchMode          = "EXACT";
            iVerificationPassed = iActualText.equalsIgnoreCase(iResolvedExpected);
        }
        else if (iUpper.startsWith("STARTSWITH:"))
        {
            iResolvedExpected   = iTrimmed.substring("STARTSWITH:".length()).trim();
            iMatchMode          = "STARTSWITH";
            iVerificationPassed = iActualText.toLowerCase(Locale.ROOT).startsWith(iResolvedExpected.toLowerCase(Locale.ROOT));
        }
        else
        {
            iResolvedExpected   = iUpper.startsWith("CONTAINS:") ? iTrimmed.substring("CONTAINS:".length()).trim() : iTrimmed;
            iMatchMode          = "CONTAINS";
            iVerificationPassed = iActualText.toLowerCase(Locale.ROOT).contains(iResolvedExpected.toLowerCase(Locale.ROOT));
        }

        if (!iVerificationPassed)
        {
            throw new AssertionError("VERIFYTEXT failed [Mode=" + iMatchMode + "]"
                    + " | Expected : '" + iResolvedExpected + "'"
                    + " | Actual   : '" + iActualText + "'");
        }

        return iActualText;
    }

    private static void performVerifyElement(Locator pLocator, String pObjectName)
    {
        try
        {
            pLocator.waitFor(waitState(WaitForSelectorState.VISIBLE, iVerifyElementTimeoutMs));
        }
        catch (TimeoutError iTimeout)
        {
            throw new AssertionError("VERIFYELEMENT failed. Element not visible after " + (long) iVerifyElementTimeoutMs + " ms: " + pObjectName);
        }

        scrollIntoView(pLocator);
        highlightElement(pLocator);
    }

    private static void performCalendar(Locator pLocator, String pValue)
    {
        if (pValue == null || pValue.trim().isEmpty())
        {
            throw new RuntimeException("CALENDAR action requires a date value.");
        }

        waitVisible(pLocator);
        scrollIntoView(pLocator);
        highlightElement(pLocator);

        try
        {
            pLocator.fill("", new Locator.FillOptions().setTimeout(2000));
        }
        catch (Exception iIgnored)
        {
            log.fine("CALENDAR | fill('') not possible, falling back to keyboard clear.");
        }

        pLocator.click();
        pLocator.press("ControlOrMeta+A");
        pLocator.press("Delete");
        pLocator.pressSequentially(pValue, new Locator.PressSequentiallyOptions().setDelay(20));
        pLocator.press("Tab");
    }


    // ===============================================================================================================================
    // SECTION 8 : iAction - Public Entry Point (signature unchanged)
    // ===============================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Function Name : iAction
    // Description   : Performs reusable UI actions dispatched to dedicated private methods per action type.
    //                 Supports: CLICK, JSCLICK, DOUBLECLICK, RIGHTCLICK, HOVER, MOUSEHOVER, TEXTBOX, CLEARTEXTBOX,
    //                           RADIOBUTTON, CHECKBOX, LIST, DRAGDROP, UPLOADFILE, WAITVISIBLE, WAITCLICKABLE,
    //                           WAITINVISIBLE, SCROLLTOELEMENT, GETTEXT, VERIFYTEXT, VERIFYELEMENT,
    //                           CALENDAR (also accepts legacy typo CALENDER)
    // Parameters    : pActionType   (String) - action to perform (case-insensitive)
    //                 pIdentifyBy   (String) - locator strategy (XPATH, CSS, ID, ... or PLAYWRIGHT)
    //                 pObjectName   (String) - locator value
    //                 pValueToEnter (String) - input value where applicable; supports TD:ColumnName syntax
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Created  : 10-03-2026 | Updated: 15-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    public static String iAction(String pActionType, String pIdentifyBy, String pObjectName, String pValueToEnter)
    {
        String iReturnedText = "";
        long   iStartTime    = System.currentTimeMillis();

        iMaskNextValue.set(pValueToEnter != null && isSensitiveReference(pValueToEnter));

        try
        {
            Page iPage = requirePage();

            if (pActionType == null || pActionType.trim().isEmpty())
            {
                throw new RuntimeException("Action type cannot be blank.");
            }

            if (pIdentifyBy == null || pIdentifyBy.trim().isEmpty())
            {
                throw new RuntimeException("IdentifyBy cannot be blank.");
            }

            if (pObjectName == null || pObjectName.trim().isEmpty())
            {
                throw new RuntimeException("ObjectName cannot be blank.");
            }

            String  iResolvedValue = resolveValue(pValueToEnter);
            String  iSelector      = toSelector(pIdentifyBy, pObjectName);
            Locator iLocator       = getLocator(pIdentifyBy, pObjectName);
            String  iActionType    = pActionType.trim().toUpperCase(Locale.ROOT);

            logStepStart(iActionType, pIdentifyBy, pObjectName, iResolvedValue);

            switch (iActionType)
            {
                case "CLICK":
                    performClick(iLocator, pObjectName);
                    break;

                case "JSCLICK":
                case "JAVASCRIPTCLICK":
                    performJsClick(iLocator, pObjectName);
                    break;

                case "DOUBLECLICK":
                    performDoubleClick(iLocator);
                    break;

                case "RIGHTCLICK":
                    performRightClick(iLocator);
                    break;

                case "HOVER":
                case "MOUSEHOVER":
                    performHover(iLocator);
                    break;

                case "TEXTBOX":
                    performTextBox(iLocator, iResolvedValue);
                    break;

                case "CLEARTEXTBOX":
                    performClearTextBox(iLocator);
                    break;

                case "RADIOBUTTON":
                    performRadioButton(iLocator, pObjectName);
                    break;

                case "CHECKBOX":
                    performCheckBox(iLocator, pObjectName, iResolvedValue);
                    break;

                case "LIST":
                    performList(iPage, iLocator, iResolvedValue);
                    break;

                case "DRAGDROP":
                    performDragDrop(iLocator, iResolvedValue);
                    break;

                case "UPLOADFILE":
                    performUploadFile(iLocator, iResolvedValue);
                    break;

                case "WAITVISIBLE":
                    performWaitVisible(iLocator, pObjectName);
                    break;

                case "WAITCLICKABLE":
                    performWaitClickable(iPage, iLocator, pObjectName);
                    break;

                case "WAITINVISIBLE":
                    performWaitInvisible(iPage, iSelector, pObjectName);
                    break;

                case "SCROLLTOELEMENT":
                    performScrollToElement(iLocator);
                    break;

                case "GETTEXT":
                    iReturnedText = performGetText(iPage, iLocator, pObjectName);
                    break;

                case "VERIFYTEXT":
                    iReturnedText = performVerifyText(iLocator, iResolvedValue);
                    break;

                case "VERIFYELEMENT":
                    performVerifyElement(iLocator, pObjectName);
                    break;

                case "CALENDAR":
                case "CALENDER": // Legacy alias retained for backward compatibility - use CALENDAR going forward
                    performCalendar(iLocator, iResolvedValue);
                    break;

                default:
                    throw new RuntimeException("Unsupported action type : '" + pActionType + "'.");
            }

            long iDuration = System.currentTimeMillis() - iStartTime;
            logStepPass(iActionType, pIdentifyBy, pObjectName, iResolvedValue, iDuration);
            appendToStepLog(iActionType, pObjectName, displayValue(pValueToEnter, iResolvedValue), "PASS", iDuration, "", "");
        }
        catch (Exception | AssertionError iException)
        {
            long   iDuration  = System.currentTimeMillis() - iStartTime;
            String iRootCause = classifyException(iException);
            logStepFail(pActionType, pIdentifyBy, pObjectName, pValueToEnter, iDuration, iException.getMessage());
            appendToStepLog(pActionType, pObjectName, pValueToEnter, "FAIL", iDuration, firstLine(iException.getMessage()), iRootCause);
            throw new RuntimeException("iAction failed | Action=[" + pActionType + "] | Object=[" + pObjectName + "] | Reason : "
                    + firstLine(iException.getMessage()), iException);
        }
        finally
        {
            iMaskNextValue.set(Boolean.FALSE);
        }

        return iReturnedText;
    }

    private static boolean isSensitiveReference(String pValue)
    {
        String iLower = pValue.toLowerCase(Locale.ROOT);
        return iLower.contains("password") || iLower.contains("pin") || iLower.contains("otp") || iLower.contains("secret");
    }

    // The Word report shows TD:Password rather than the password itself
    private static String displayValue(String pRawValue, String pResolvedValue)
    {
        if (pRawValue != null && isSensitiveReference(pRawValue)) { return pRawValue.trim().startsWith("TD:") ? pRawValue.trim() : "****"; }
        return pResolvedValue;
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : waitForAngular
    // Description   : Waits for DOMContentLoaded and for all Angular testabilities to become stable.
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Updated  : 15-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    public static void waitForAngular()
    {
        Page iPage = requirePage();
        iPage.waitForLoadState(LoadState.DOMCONTENTLOADED);
        iPage.evaluate(JS_WAIT_FOR_ANGULAR);
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : waitForVisibilityOfElement
    // Description   : Waits up to pTimeInSec for the element to be visible and returns its Locator.
    //                 Replaces waitForVisibilityOfElement(By, int).
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Updated  : 15-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    public static Locator waitForVisibilityOfElement(String pIdentifyBy, String pObjectName, int pTimeInSec)
    {
        Locator iLocator = getLocator(pIdentifyBy, pObjectName);
        iLocator.waitFor(waitState(WaitForSelectorState.VISIBLE, pTimeInSec * 1000d));
        return iLocator;
    }


    // ===============================================================================================================================
    // SECTION 9 : Verification Utilities
    // ===============================================================================================================================

    public static String verifyErrorMessage(String pActualErrorMessage, String pExpectedErrorMessage)
    {
        if (pActualErrorMessage == null)
        {
            throw new AssertionError("Actual error message is NULL. Expected message was : '" + pExpectedErrorMessage + "'");
        }

        if (pExpectedErrorMessage == null || pExpectedErrorMessage.trim().isEmpty())
        {
            throw new AssertionError("Expected error message cannot be NULL or empty.");
        }

        String iActualMessage   = pActualErrorMessage.trim();
        String iExpectedMessage = pExpectedErrorMessage.trim();

        if (!iActualMessage.toLowerCase(Locale.ROOT).contains(iExpectedMessage.toLowerCase(Locale.ROOT)))
        {
            throw new AssertionError("Error message validation FAILED"
                    + "\n  Expected (partial match) : '" + iExpectedMessage + "'"
                    + "\n  Actual message           : '" + iActualMessage + "'");
        }

        log.info("[" + getCurrentTimestamp() + "] Error message verified successfully"
                + " | Expected : '" + iExpectedMessage + "'"
                + " | Actual : '" + iActualMessage + "'");

        return "Error message verified: '" + iExpectedMessage + "'";
    }


    // ===============================================================================================================================
    // SECTION 10 : Screenshot
    // ===============================================================================================================================

    public static String takeScreenshot(String pStepName)
    {
        return utilities.ScreenshotManager.captureViewport(getPage(), pStepName);
    }


    // ===============================================================================================================================
    // SECTION 11 : Word Report (unchanged logic - screenshot calls now pass the Playwright Page)
    // ===============================================================================================================================

    public static void clearStepLog()
    {
        iStepLog.clear();
        iStepCounter  = 0;
        iStepBoundary = 0;
        log.info("[" + getCurrentTimestamp() + "] Step log cleared for new test case.");
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : markGherkinStepStart
    // Description   : Remembers where the current Gherkin step starts in the step log.
    //                 Called by reporting.CucumberStepListener when a feature-file step starts.
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Created  : 17-09-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized void markGherkinStepStart()
    {
        iStepBoundary = iStepLog.size();
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : markGherkinStepPassed
    // Description   : Called by reporting.CucumberStepListener when a feature-file step PASSED.
    //                 Any iAction FAIL row written during that step was caught by the step definition on purpose
    //                 (for example "click the warning if present"), so it becomes HANDLED:
    //                   - shown in amber in the Word step log, with its reason
    //                   - not counted as a failure, so it no longer turns the test case status to FAIL
    //                 When the step itself fails, its FAIL rows stay FAIL.
    // Returns       : int - number of rows changed to HANDLED
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Created  : 17-09-2026
    // ***************************************************************************************************************************************************************************************
    public static synchronized int markGherkinStepPassed()
    {
        int iChanged = 0;
        for (int i = Math.max(0, iStepBoundary); i < iStepLog.size(); i++)
        {
            StepLogEntry iEntry = iStepLog.get(i);
            if ("FAIL".equals(iEntry.iStatus))
            {
                iEntry.iStatus = "HANDLED";
                iChanged++;
            }
        }
        iStepBoundary = iStepLog.size();

        if (iChanged > 0)
        {
            log.info("[" + getCurrentTimestamp() + "] STEP HANDLED | " + iChanged + " failed action(s) in this step were handled by the"
                    + " step definition (optional element not present) - not counted as a test failure.");
        }
        return iChanged;
    }

    private static void appendToStepLog(String pAction, String pLocator, String pValue,
                                        String pStatus, long pDurationMs, String pFailReason,
                                        String pRootCause)
    {
        try
        {
            iStepCounter++;

            String iDisplayValue = pValue;
            if ("TEXTBOX".equalsIgnoreCase(pAction) && pValue != null && isSensitiveReference(pValue) && !pValue.trim().startsWith("TD:"))
            {
                iDisplayValue = "****";
            }

            iStepLog.add(new StepLogEntry(iStepCounter, pAction, pLocator,
                    iDisplayValue, pStatus, pDurationMs, pFailReason, pRootCause));
        }
        catch (Exception iException)
        {
            log.warning("[" + getCurrentTimestamp() + "] Step log append failed: " + iException.getMessage());
        }
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : classifyException
    // Description   : Returns a short root-cause label for the step log. Same six buckets as the Selenium version,
    //                 mapped from Playwright errors:
    //                   ASSERTION_ERROR    - AssertionError from VERIFYTEXT / VERIFYELEMENT
    //                   CLICK_INTERCEPTED  - "intercepts pointer events", "not enabled", "not editable"
    //                   STALE_ELEMENT      - "not attached to the DOM", "detached"
    //                   ELEMENT_NOT_FOUND  - TimeoutError while waiting for a locator to become visible/attached
    //                   TIMEOUT            - any other TimeoutError / "timed out"
    //                   UNEXPECTED_ERROR   - anything else
    // Date Updated  : 15-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    public static String classifyException(Throwable pException)
    {
        if (pException == null)
        {
            return "UNEXPECTED_ERROR";
        }

        boolean       iSawTimeout = false;
        StringBuilder iMessages   = new StringBuilder();

        for (Throwable iCause = pException; iCause != null; iCause = iCause.getCause())
        {
            if (iCause instanceof AssertionError) { return "ASSERTION_ERROR"; }
            if (iCause instanceof TimeoutError)   { iSawTimeout = true; }
            if (iCause.getMessage() != null)      { iMessages.append(' ').append(iCause.getMessage().toLowerCase(Locale.ROOT)); }
            if (iCause.getCause() == iCause)      { break; }
        }

        String iMessage = iMessages.toString();

        if (iMessage.contains("verifytext failed") || iMessage.contains("verifyelement failed"))
        {
            return "ASSERTION_ERROR";
        }

        if (iMessage.contains("intercepts pointer events") || iMessage.contains("element is not enabled")
                || iMessage.contains("element is not editable") || iMessage.contains("not interactable"))
        {
            return "CLICK_INTERCEPTED";
        }

        if (iMessage.contains("not attached to the dom") || iMessage.contains("detached"))
        {
            return "STALE_ELEMENT";
        }

        if (iSawTimeout && (iMessage.contains("waiting for locator") || iMessage.contains("to be visible")
                || iMessage.contains("to be attached")))
        {
            return "ELEMENT_NOT_FOUND";
        }

        if (iSawTimeout || iMessage.contains("timed out") || iMessage.contains("timeout"))
        {
            return "TIMEOUT";
        }

        if (iMessage.contains("not found"))
        {
            return "ELEMENT_NOT_FOUND";
        }

        return "UNEXPECTED_ERROR";
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : startWordReport
    // Description   : Creates a Word (.docx) report with a full cover page and metadata table.
    //                 Returns {XWPFDocument, String} - document object and file path.
    // Parameters    : pTestCaseID (String) - currently executing test case ID
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Created  : 10-03-2026 | Updated: 15-09-2026 (Engine + Browser Version rows)
    // ***************************************************************************************************************************************************************************************
    public static Object[] startWordReport(String pTestCaseID)
    {
        try
        {
            if (pTestCaseID == null || pTestCaseID.trim().isEmpty())
            {
                throw new RuntimeException("TestCase_ID cannot be blank while creating Word report.");
            }

            String iDescription = getDescriptionFromExecutionControl(pTestCaseID);
            String iTimestamp   = getCurrentFileTimestamp();
            String iStartedAt   = getCurrentTimestamp();

            String iEnvironment = System.getProperty("environment",         "-");
            String iBrowser     = System.getProperty("browser",             "-");
            String iBuildNumber = System.getProperty("bamboo.buildNumber",  "LOCAL");
            String iBuildPlan   = System.getProperty("bamboo.buildPlanKey", "-");
            String iRetryCount  = System.getProperty("retry.count",         "1");
            String iHerd        = System.getProperty("TD:HerdNumber",       "-");
            String iUsername    = System.getProperty("TD:Username",         "-");
            String iHost        = System.getenv().getOrDefault("HOSTNAME", "local");

            File iDocsDirectory = new File(iReportDocsDirectoryPath);
            if (!iDocsDirectory.exists()) { iDocsDirectory.mkdirs(); }

            String       iFileName = sanitizeFileName(pTestCaseID) + "_" + iTimestamp + ".docx";
            String       iFullPath = iDocsDirectory.getAbsolutePath() + File.separator + iFileName;
            XWPFDocument iDocument = new XWPFDocument();

            XWPFParagraph iTitlePara = iDocument.createParagraph();
            iTitlePara.setAlignment(ParagraphAlignment.CENTER);
            XWPFRun iTitleRun = iTitlePara.createRun();
            iTitleRun.setBold(true);
            iTitleRun.setFontSize(18);
            iTitleRun.setFontFamily("Calibri");
            iTitleRun.setText("BISS Automation - Test Execution Report");
            iTitleRun.addBreak();

            XWPFParagraph iSubPara = iDocument.createParagraph();
            iSubPara.setAlignment(ParagraphAlignment.CENTER);
            XWPFRun iSubRun = iSubPara.createRun();
            iSubRun.setBold(true);
            iSubRun.setFontSize(13);
            iSubRun.setFontFamily("Calibri");
            iSubRun.setText(pTestCaseID + "  -  " + iDescription);
            iSubRun.addBreak();
            iSubRun.addBreak();

            String[][] iMetaRows = {
                    { "Test Case ID",    pTestCaseID  },
                    { "Description",     iDescription },
                    { "Environment",     iEnvironment },
                    { "Browser",         iBrowser     },
                    { "Engine",          "Playwright (" + PlaywrightFactory.getBrowserVersion() + ")" },
                    { "Execution Host",  iHost        },
                    { "Herd Number",     iHerd        },
                    { "Username",        iUsername    },
                    { "Build Number",    iBuildNumber },
                    { "Build Plan",      iBuildPlan   },
                    { "Retry Count",     iRetryCount  },
                    { "Started At",      iStartedAt   }
            };

            org.apache.poi.xwpf.usermodel.XWPFTable iMetaTable = iDocument.createTable(iMetaRows.length, 2);
            iMetaTable.setWidth("80%");

            for (int i = 0; i < iMetaRows.length; i++)
            {
                org.apache.poi.xwpf.usermodel.XWPFTableRow iRow = iMetaTable.getRow(i);

                org.apache.poi.xwpf.usermodel.XWPFTableCell iLabel = iRow.getCell(0);
                iLabel.setColor("D9D9D9");
                XWPFRun iLabelRun = iLabel.getParagraphArray(0).createRun();
                iLabelRun.setBold(true);
                iLabelRun.setFontSize(10);
                iLabelRun.setFontFamily("Calibri");
                iLabelRun.setText(iMetaRows[i][0]);

                XWPFRun iValueRun = iRow.getCell(1).getParagraphArray(0).createRun();
                iValueRun.setFontSize(10);
                iValueRun.setFontFamily("Calibri");
                iValueRun.setText(iMetaRows[i][1]);
            }

            iDocument.createParagraph().createRun().addBreak();
            XWPFRun iSectionRun = iDocument.createParagraph().createRun();
            iSectionRun.setBold(true);
            iSectionRun.setFontSize(12);
            iSectionRun.setFontFamily("Calibri");
            iSectionRun.setText("Execution Log");
            iSectionRun.addBreak();

            try (FileOutputStream iOut = new FileOutputStream(iFullPath))
            {
                iDocument.write(iOut);
            }

            log.info("[" + getCurrentTimestamp() + "] Word report created : " + iFullPath);
            return new Object[]{iDocument, iFullPath};
        }
        catch (Exception iException)
        {
            log.severe("[" + getCurrentTimestamp() + "] Failed to create Word report : " + iException.getMessage());
            throw new RuntimeException("Failed to create Word report : " + iException.getMessage(), iException);
        }
    }

    public static void captureStepScreenshot(XWPFDocument pDocument, String pDocPath, String pStepLabel)
    {
        utilities.ScreenshotManager.captureAndEmbed(getPage(), pDocument, pStepLabel);
    }

    public static String addScreenshotToReport(XWPFDocument pDocument, String pDocPath, String pTestCaseID)
    {
        return utilities.ScreenshotManager.captureForFailure(getPage(), pDocument, pTestCaseID);
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : finalizeWordReport
    // Description   : Appends the full step execution log table then writes the document to disk (single write point).
    // Parameters    : pDocument (XWPFDocument) - active in-memory Word document object
    //                 pDocPath  (String)        - report full file path
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Created  : 10-03-2026 | Updated: 26-03-2026 (step log table added before save)
    // ***************************************************************************************************************************************************************************************
    public static void finalizeWordReport(XWPFDocument pDocument, String pDocPath)
    {
        finalizeWordReport(pDocument, pDocPath, null);
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : finalizeWordReport (with scenario status)
    // Description   : Same as above, but the overall PASS/FAIL comes from Cucumber (pScenarioStatus), which is what the
    //                 console, ExecutionControl.xlsx and the HTML suite report show. Hooks passes it.
    //                 Without it (null), the status is FAIL when the step log holds a FAIL row.
    // Parameters    : pDocument       (XWPFDocument) - active in-memory Word document object
    //                 pDocPath        (String)       - report full file path
    //                 pScenarioStatus (String)       - PASS | FAIL | null
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Created  : 17-09-2026
    // ***************************************************************************************************************************************************************************************
    public static void finalizeWordReport(XWPFDocument pDocument, String pDocPath, String pScenarioStatus)
    {
        try
        {
            if (pDocument == null)
            {
                log.warning("[" + getCurrentTimestamp() + "] Word document is null. Finalize step skipped.");
                return;
            }

            if (pDocPath == null || pDocPath.trim().isEmpty())
            {
                throw new RuntimeException("Word report path is blank. Cannot finalize report.");
            }

            int iPassCount    = 0;
            int iFailCount    = 0;
            int iHandledCount = 0;
            Map<String, Integer> iRootCauseCounts = new java.util.LinkedHashMap<>();

            for (StepLogEntry iEntry : iStepLog)
            {
                if ("PASS".equals(iEntry.iStatus))
                {
                    iPassCount++;
                }
                else if ("HANDLED".equals(iEntry.iStatus))
                {
                    iHandledCount++;
                }
                else
                {
                    iFailCount++;
                    if (!iEntry.iRootCause.isEmpty())
                    {
                        iRootCauseCounts.merge(iEntry.iRootCause, 1, Integer::sum);
                    }
                }
            }

            int    iTotalSteps    = iPassCount + iFailCount + iHandledCount;
            int    iCountedSteps  = iPassCount + iFailCount;
            String iPassRate      = iCountedSteps == 0 ? "N/A" : String.format("%.1f%%", (iPassCount * 100.0) / iCountedSteps);
            String iOverallStatus = (pScenarioStatus == null || pScenarioStatus.isBlank())
                    ? (iFailCount == 0 ? "PASS" : "FAIL")
                    : ("PASS".equalsIgnoreCase(pScenarioStatus.trim()) ? "PASS" : "FAIL");
            boolean iOverallPass  = "PASS".equals(iOverallStatus);

            if (!iStepLog.isEmpty())
            {
                XWPFRun iHeadRun = pDocument.createParagraph().createRun();
                iHeadRun.setBold(true);
                iHeadRun.setFontSize(12);
                iHeadRun.setFontFamily("Calibri");
                iHeadRun.setText("Step Execution Log  (" + iStepLog.size() + " steps)");
                iHeadRun.addBreak();

                org.apache.poi.xwpf.usermodel.XWPFTable iTable = pDocument.createTable(iStepLog.size() + 2, 7);
                iTable.setWidth("100%");

                String[] iHeaders = { "#", "Action", "Element (locator)", "Value", "Status", "Duration", "Root Cause" };
                org.apache.poi.xwpf.usermodel.XWPFTableRow iHeaderRow = iTable.getRow(0);
                for (int c = 0; c < iHeaders.length; c++)
                {
                    org.apache.poi.xwpf.usermodel.XWPFTableCell iCell = iHeaderRow.getCell(c);
                    iCell.setColor("1F4E79");
                    XWPFRun iRun = iCell.getParagraphArray(0).createRun();
                    iRun.setBold(true);
                    iRun.setFontSize(9);
                    iRun.setFontFamily("Calibri");
                    iRun.setColor("FFFFFF");
                    iRun.setText(iHeaders[c]);
                }

                for (int r = 0; r < iStepLog.size(); r++)
                {
                    StepLogEntry iEntry    = iStepLog.get(r);
                    boolean      iPassed   = "PASS".equals(iEntry.iStatus);
                    boolean      iHandled  = "HANDLED".equals(iEntry.iStatus);
                    String       iRowColor = iPassed ? "C6EFCE" : (iHandled ? "FFEB9C" : "FFC7CE");

                    org.apache.poi.xwpf.usermodel.XWPFTableRow iRow = iTable.getRow(r + 1);

                    String[] iCellValues = {
                            String.valueOf(iEntry.iStepNumber),
                            iEntry.iAction,
                            iEntry.iLocator,
                            iEntry.iValue,
                            iEntry.iStatus,
                            iEntry.iDurationMs + " ms",
                            iEntry.iRootCause
                    };

                    for (int c = 0; c < iCellValues.length; c++)
                    {
                        org.apache.poi.xwpf.usermodel.XWPFTableCell iCell = iRow.getCell(c);
                        iCell.setColor(iRowColor);
                        XWPFRun iRun = iCell.getParagraphArray(0).createRun();
                        iRun.setFontSize(8);
                        iRun.setFontFamily("Calibri");

                        if (c == 4)
                        {
                            iRun.setBold(true);
                            iRun.setColor(iPassed ? "375623" : (iHandled ? "9C5700" : "9C0006"));
                        }
                        else if (c == 6)
                        {
                            iRun.setBold(!iPassed);
                            iRun.setColor(iPassed ? "808080" : "C55A11");
                        }

                        if (c == 5 && !iPassed && !iEntry.iFailReason.isEmpty())
                        {
                            iRun.setText(iEntry.iDurationMs + " ms  -  " + iEntry.iFailReason);
                        }
                        else
                        {
                            iRun.setText(iCellValues[c]);
                        }
                    }
                }

                org.apache.poi.xwpf.usermodel.XWPFTableRow iSummaryRow = iTable.getRow(iStepLog.size() + 1);
                String iSummaryBg = iOverallPass ? "375623" : "9C0006";

                String[] iSumValues = {
                        "TOTAL: " + iTotalSteps,
                        "PASS: " + iPassCount + (iHandledCount > 0 ? "  HANDLED: " + iHandledCount : ""),
                        "FAIL: " + iFailCount,
                        "PASS RATE: " + iPassRate,
                        iOverallStatus,
                        "",
                        ""
                };

                for (int c = 0; c < iSumValues.length; c++)
                {
                    org.apache.poi.xwpf.usermodel.XWPFTableCell iCell = iSummaryRow.getCell(c);
                    iCell.setColor(iSummaryBg);
                    XWPFRun iRun = iCell.getParagraphArray(0).createRun();
                    iRun.setBold(true);
                    iRun.setFontSize(9);
                    iRun.setFontFamily("Calibri");
                    iRun.setColor("FFFFFF");
                    iRun.setText(iSumValues[c]);
                }

                pDocument.createParagraph().createRun().addBreak();

                if (iFailCount > 0)
                {
                    XWPFRun iFailHeadRun = pDocument.createParagraph().createRun();
                    iFailHeadRun.setBold(true);
                    iFailHeadRun.setFontSize(11);
                    iFailHeadRun.setFontFamily("Calibri");
                    iFailHeadRun.setColor("9C0006");
                    iFailHeadRun.setText("Failure Summary");
                    iFailHeadRun.addBreak();

                    if (!iRootCauseCounts.isEmpty())
                    {
                        org.apache.poi.xwpf.usermodel.XWPFTable iRcTable = pDocument.createTable(iRootCauseCounts.size() + 1, 2);
                        iRcTable.setWidth("50%");

                        org.apache.poi.xwpf.usermodel.XWPFTableRow iRcHeader = iRcTable.getRow(0);
                        for (int c = 0; c < 2; c++)
                        {
                            org.apache.poi.xwpf.usermodel.XWPFTableCell iCell = iRcHeader.getCell(c);
                            iCell.setColor("C55A11");
                            XWPFRun iRun = iCell.getParagraphArray(0).createRun();
                            iRun.setBold(true);
                            iRun.setFontSize(9);
                            iRun.setFontFamily("Calibri");
                            iRun.setColor("FFFFFF");
                            iRun.setText(c == 0 ? "Root Cause Category" : "Count");
                        }

                        int iRcRowIdx = 1;
                        for (Map.Entry<String, Integer> iEntry : iRootCauseCounts.entrySet())
                        {
                            org.apache.poi.xwpf.usermodel.XWPFTableRow iRcRow = iRcTable.getRow(iRcRowIdx++);
                            iRcRow.getCell(0).setColor("FBE4D5");
                            iRcRow.getCell(1).setColor("FBE4D5");

                            XWPFRun iLabelRun = iRcRow.getCell(0).getParagraphArray(0).createRun();
                            iLabelRun.setFontSize(9);
                            iLabelRun.setFontFamily("Calibri");
                            iLabelRun.setBold(true);
                            iLabelRun.setColor("C55A11");
                            iLabelRun.setText(iEntry.getKey());

                            XWPFRun iCountRun = iRcRow.getCell(1).getParagraphArray(0).createRun();
                            iCountRun.setFontSize(9);
                            iCountRun.setFontFamily("Calibri");
                            iCountRun.setText(String.valueOf(iEntry.getValue()));
                        }

                        pDocument.createParagraph().createRun().addBreak();
                    }

                    List<StepLogEntry> iFailedSteps = new java.util.ArrayList<>();
                    for (StepLogEntry iEntry : iStepLog)
                    {
                        if ("FAIL".equals(iEntry.iStatus))
                        {
                            iFailedSteps.add(iEntry);
                        }
                    }

                    org.apache.poi.xwpf.usermodel.XWPFTable iFailTable = pDocument.createTable(iFailedSteps.size() + 1, 4);
                    iFailTable.setWidth("100%");

                    String[] iFHeaders = { "#", "Action  /  Element", "Root Cause", "Reason" };
                    org.apache.poi.xwpf.usermodel.XWPFTableRow iFHeader = iFailTable.getRow(0);
                    for (int c = 0; c < iFHeaders.length; c++)
                    {
                        org.apache.poi.xwpf.usermodel.XWPFTableCell iCell = iFHeader.getCell(c);
                        iCell.setColor("9C0006");
                        XWPFRun iRun = iCell.getParagraphArray(0).createRun();
                        iRun.setBold(true);
                        iRun.setFontSize(9);
                        iRun.setFontFamily("Calibri");
                        iRun.setColor("FFFFFF");
                        iRun.setText(iFHeaders[c]);
                    }

                    for (int r = 0; r < iFailedSteps.size(); r++)
                    {
                        StepLogEntry iFs = iFailedSteps.get(r);
                        org.apache.poi.xwpf.usermodel.XWPFTableRow iFRow = iFailTable.getRow(r + 1);

                        String[] iFValues = {
                                String.valueOf(iFs.iStepNumber),
                                iFs.iAction + "  /  " + iFs.iLocator,
                                iFs.iRootCause,
                                iFs.iFailReason
                        };

                        for (int c = 0; c < iFValues.length; c++)
                        {
                            org.apache.poi.xwpf.usermodel.XWPFTableCell iCell = iFRow.getCell(c);
                            iCell.setColor("FFC7CE");
                            XWPFRun iRun = iCell.getParagraphArray(0).createRun();
                            iRun.setFontSize(8);
                            iRun.setFontFamily("Calibri");
                            iRun.setBold(c == 2);
                            if (c == 2) { iRun.setColor("9C0006"); }
                            iRun.setText(iFValues[c]);
                        }
                    }

                    pDocument.createParagraph().createRun().addBreak();
                }
            }
            else
            {
                XWPFRun iNoSteps = pDocument.createParagraph().createRun();
                iNoSteps.setFontSize(9);
                iNoSteps.setFontFamily("Calibri");
                iNoSteps.setColor("808080");
                iNoSteps.setText("(No step log entries recorded for this test case.)");
                iNoSteps.addBreak();
            }

            XWPFRun iEndRun = pDocument.createParagraph().createRun();
            iEndRun.setBold(true);
            iEndRun.setFontSize(9);
            iEndRun.setFontFamily("Calibri");
            iEndRun.setText("Execution completed at: " + getCurrentTimestamp());

            try (FileOutputStream iOut = new FileOutputStream(pDocPath))
            {
                pDocument.write(iOut);
            }

            pDocument.close();

            log.info("[" + getCurrentTimestamp() + "] Word report finalized : " + pDocPath);

            String iTestCaseID = new File(pDocPath).getName()
                    .replaceAll("_\\d{2}_\\d{2}_\\d{4}_\\d{2}_\\d{2}_\\d{2}\\.docx$", "")
                    .replace("_", " ");
            writeHtmlReportIndex(pDocPath, iTestCaseID, iOverallStatus);
        }
        catch (Exception iException)
        {
            log.severe("[" + getCurrentTimestamp() + "] Failed to finalize Word report : " + iException.getMessage());
            throw new RuntimeException("Failed to finalize Word report : " + iException.getMessage(), iException);
        }
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : writeHtmlReportIndex
    // Description   : Creates or appends one row into Test_Report/docs/ReportIndex.html (unchanged logic).
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Created  : 28-03-2026
    // ***************************************************************************************************************************************************************************************
    public static void writeHtmlReportIndex(String pDocPath, String pTestCaseID, String pStatus)
    {
        try
        {
            File iReportDir = new File(iReportDocsDirectoryPath);
            if (!iReportDir.exists()) { iReportDir.mkdirs(); }

            File    iIndexFile = new File(iReportDir.getAbsolutePath() + File.separator + "ReportIndex.html");
            String  iTimestamp = getCurrentTimestamp();
            String  iDocFile   = new File(pDocPath).getName();
            boolean iPassed    = "PASS".equalsIgnoreCase(pStatus);

            String iBadgeBg = iPassed ? "#375623" : "#9C0006";
            String iRowBg   = iPassed ? "#C6EFCE" : "#FFC7CE";

            if (!iIndexFile.exists())
            {
                try (PrintWriter iWriter = new PrintWriter(iIndexFile, StandardCharsets.UTF_8.name()))
                {
                    iWriter.println("<!DOCTYPE html>");
                    iWriter.println("<html lang='en'><head><meta charset='UTF-8'>");
                    iWriter.println("<title>BISS Automation - Report Index</title>");
                    iWriter.println("<style>");
                    iWriter.println("  body  { font-family: Calibri, Arial, sans-serif; margin: 24px; background: #f5f5f5; }");
                    iWriter.println("  h1    { color: #1F4E79; font-size: 22px; margin-bottom: 4px; }");
                    iWriter.println("  p.sub { color: #555; font-size: 13px; margin-top: 0; }");
                    iWriter.println("  .stats { display: flex; gap: 16px; margin: 16px 0; }");
                    iWriter.println("  .stat  { background: #fff; border: 1px solid #ddd; border-radius: 6px; padding: 10px 20px; font-size: 14px; }");
                    iWriter.println("  .stat span { font-size: 24px; font-weight: bold; display: block; }");
                    iWriter.println("  .pass-c { color: #375623; } .fail-c { color: #9C0006; }");
                    iWriter.println("  table { border-collapse: collapse; width: 100%; background: #fff; border-radius: 6px; overflow: hidden; box-shadow: 0 1px 4px rgba(0,0,0,.1); }");
                    iWriter.println("  th    { background: #1F4E79; color: #fff; padding: 8px 12px; text-align: left; font-size: 13px; }");
                    iWriter.println("  td    { padding: 7px 12px; font-size: 12px; border-bottom: 1px solid #eee; }");
                    iWriter.println("  .badge { color: #fff; padding: 2px 10px; border-radius: 12px; font-size: 11px; font-weight: bold; }");
                    iWriter.println("  a     { color: #1F4E79; text-decoration: none; }");
                    iWriter.println("  a:hover { text-decoration: underline; }");
                    iWriter.println("</style></head><body>");
                    iWriter.println("<h1>&#128196; BISS Automation - Test Execution Report Index</h1>");
                    iWriter.println("<p class='sub'>Generated: " + iTimestamp + " &nbsp;|&nbsp; Auto-updated after each test case</p>");
                    iWriter.println("<div class='stats'>");
                    iWriter.println("  <div class='stat'>Total<span id='sTot'>0</span></div>");
                    iWriter.println("  <div class='stat pass-c'>Pass<span id='sPass'>0</span></div>");
                    iWriter.println("  <div class='stat fail-c'>Fail<span id='sFail'>0</span></div>");
                    iWriter.println("  <div class='stat'>Pass Rate<span id='sRate'>-</span></div>");
                    iWriter.println("</div>");
                    iWriter.println("<table><thead><tr>");
                    iWriter.println("  <th>#</th><th>Test Case</th><th>Status</th><th>Finished At</th><th>Report</th>");
                    iWriter.println("</tr></thead><tbody id='tBody'>");
                    iWriter.println("<!-- ROWS -->");
                    iWriter.println("</tbody></table>");
                    iWriter.println("<script>");
                    iWriter.println("(function(){ var rows=document.querySelectorAll('#tBody tr');");
                    iWriter.println("  var tot=rows.length, pass=0, fail=0;");
                    iWriter.println("  rows.forEach(function(r){ if(r.dataset.s==='PASS') pass++; else fail++; });");
                    iWriter.println("  document.getElementById('sTot').textContent=tot;");
                    iWriter.println("  document.getElementById('sPass').textContent=pass;");
                    iWriter.println("  document.getElementById('sFail').textContent=fail;");
                    iWriter.println("  document.getElementById('sRate').textContent=tot?Math.round(pass*100/tot)+'%':'-';");
                    iWriter.println("})();");
                    iWriter.println("</script></body></html>");
                }
                log.info("[" + getCurrentTimestamp() + "] HTML report index created: " + iIndexFile.getAbsolutePath());
            }

            String iCurrentContent = new String(Files.readAllBytes(iIndexFile.toPath()), StandardCharsets.UTF_8);
            int    iRowCount       = (iCurrentContent.split("<tr data-s=").length - 1) + 1;

            String iNewRow = String.format(
                    "<tr data-s='%s' style='background:%s;'>"
                            + "<td>%d</td>"
                            + "<td>%s</td>"
                            + "<td><span class='badge' style='background:%s;'>%s</span></td>"
                            + "<td>%s</td>"
                            + "<td><a href='%s'>&#128196; %s</a></td>"
                            + "</tr>",
                    pStatus.toUpperCase(Locale.ROOT),
                    iRowBg,
                    iRowCount,
                    escapeHtml(pTestCaseID),
                    iBadgeBg,
                    pStatus.toUpperCase(Locale.ROOT),
                    iTimestamp,
                    escapeHtml(iDocFile),
                    escapeHtml(iDocFile)
            );

            String iUpdated = iCurrentContent.replace("<!-- ROWS -->", iNewRow + System.lineSeparator() + "<!-- ROWS -->");

            Files.write(iIndexFile.toPath(),
                    iUpdated.getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE);

            log.info("[" + getCurrentTimestamp() + "] HTML report index updated: " + iIndexFile.getName()
                    + " | TC=" + pTestCaseID + " | Status=" + pStatus);
        }
        catch (Exception iException)
        {
            log.warning("[" + getCurrentTimestamp() + "] Failed to update HTML report index: " + iException.getMessage());
        }
    }

    private static String escapeHtml(String pInput)
    {
        if (pInput == null) { return ""; }
        return pInput
                .replace("&",  "&amp;")
                .replace("<",  "&lt;")
                .replace(">",  "&gt;")
                .replace("\"", "&quot;")
                .replace("'",  "&#39;");
    }


    // ===============================================================================================================================
    // SECTION 12 : Test Data Resolution
    // ===============================================================================================================================

    public static String getTestDataValue(String pColumnName)
    {
        return ExcelUtilities.getCurrentTestDataValue(pColumnName);
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : resolveValue
    // Description   : Resolves the actual runtime value.
    //                   "TD:Column" -> 1. environment variable TD_<COLUMN>   (container secret, e.g. TD_PASSWORD)
    //                                  2. system property td.<Column>         (-Dtd.Password=...)
    //                                  3. current TestData.xlsx row           (unchanged behaviour)
    //                   anything else -> returned as-is
    // Parameters    : pValue (String) - direct value or TD:ColumnName syntax
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Created  : 10-03-2026 | Updated: 15-09-2026 (secret override layer for containers)
    // ***************************************************************************************************************************************************************************************
    public static String resolveValue(String pValue)
    {
        if (pValue == null)
        {
            return null;
        }

        if (pValue.trim().startsWith("TD:"))
        {
            String iColumnName = pValue.trim().substring(3).trim();

            String iEnvName  = "TD_" + iColumnName.toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]", "_");
            String iEnvValue = System.getenv(iEnvName);
            if (iEnvValue != null && !iEnvValue.isEmpty())
            {
                return iEnvValue;
            }

            String iPropValue = System.getProperty("td." + iColumnName);
            if (iPropValue != null && !iPropValue.isEmpty())
            {
                return iPropValue;
            }

            return getTestDataValue(iColumnName);
        }

        return pValue;
    }


    // ===============================================================================================================================
    // SECTION 13 : ExecutionControl.xlsx - Description Cache & Reader (unchanged)
    // ===============================================================================================================================

    public static void loadDescriptionCache()
    {
        if (iDescriptionCacheLoaded)
        {
            return;
        }

        synchronized (iDescriptionCache)
        {
            if (iDescriptionCacheLoaded)
            {
                return;
            }

            try (FileInputStream iFileInputStream = new FileInputStream(iExecutionControlFilePath);
                 Workbook iWorkbook = WorkbookFactory.create(iFileInputStream))
            {
                Sheet iSheet = iWorkbook.getSheetAt(0);

                if (iSheet == null)
                {
                    throw new RuntimeException("Sheet at index 0 is not present in : " + iExecutionControlFilePath);
                }

                Row iHeaderRow = iSheet.getRow(0);

                if (iHeaderRow == null)
                {
                    throw new RuntimeException("Header row is missing in ExecutionControl.xlsx.");
                }

                int iTestCaseIDColumnIndex  = -1;
                int iDescriptionColumnIndex = -1;

                for (int iColIdx = 0; iColIdx < iHeaderRow.getLastCellNum(); iColIdx++)
                {
                    String iColumnName = getCellValue(iHeaderRow, iColIdx).trim();

                    if (iColumnName.equalsIgnoreCase("TestCase_ID"))
                    {
                        iTestCaseIDColumnIndex = iColIdx;
                    }
                    else if (iColumnName.equalsIgnoreCase("Description"))
                    {
                        iDescriptionColumnIndex = iColIdx;
                    }
                }

                if (iTestCaseIDColumnIndex == -1 || iDescriptionColumnIndex == -1)
                {
                    throw new RuntimeException("Required columns TestCase_ID and/or Description not found in ExecutionControl.xlsx.");
                }

                for (int iRowIdx = 1; iRowIdx <= iSheet.getLastRowNum(); iRowIdx++)
                {
                    Row iRow = iSheet.getRow(iRowIdx);

                    if (iRow == null)
                    {
                        continue;
                    }

                    String iTestCaseID  = getCellValue(iRow, iTestCaseIDColumnIndex).trim();
                    String iDescription = getCellValue(iRow, iDescriptionColumnIndex).trim();

                    if (!iTestCaseID.isEmpty())
                    {
                        iDescriptionCache.put(iTestCaseID.toUpperCase(Locale.ROOT), iDescription);
                    }
                }

                iDescriptionCacheLoaded = true;
                log.info("[" + getCurrentTimestamp() + "] ExecutionControl description cache loaded. Total entries: " + iDescriptionCache.size());
            }
            catch (Exception iException)
            {
                throw new RuntimeException("Failed to load ExecutionControl.xlsx into description cache : " + iException.getMessage(), iException);
            }
        }
    }

    private static String getDescriptionFromExecutionControl(String pTestCaseID)
    {
        if (!iDescriptionCacheLoaded)
        {
            loadDescriptionCache();
        }

        String iDescription = iDescriptionCache.get(pTestCaseID.trim().toUpperCase(Locale.ROOT));

        if (iDescription == null)
        {
            throw new RuntimeException("No description found in ExecutionControl.xlsx for TestCase_ID : '" + pTestCaseID + "'.");
        }

        return iDescription;
    }

    private static String getCellValue(Row pRow, int pColumnIndex)
    {
        if (pRow == null || pRow.getCell(pColumnIndex) == null)
        {
            return "";
        }

        return iDataFormatter.formatCellValue(pRow.getCell(pColumnIndex));
    }


    // ===============================================================================================================================
    // SECTION 14 : StepLogEntry - Inner class (unchanged)
    // ===============================================================================================================================

    public static class StepLogEntry
    {
        public final int    iStepNumber;
        public final String iAction;
        public final String iLocator;
        public final String iValue;
        public String       iStatus;     // PASS | FAIL | HANDLED (not final: a caught FAIL becomes HANDLED)
        public final long   iDurationMs;
        public final String iTimestamp;
        public final String iFailReason;
        public final String iRootCause;

        public StepLogEntry(int pStep, String pAction, String pLocator,
                            String pValue, String pStatus, long pDurationMs,
                            String pFailReason, String pRootCause)
        {
            this.iStepNumber = pStep;
            this.iAction     = pAction     == null ? "" : pAction.trim();
            this.iLocator    = pLocator    == null ? "" : cap(pLocator.trim(), 60);
            this.iValue      = pValue      == null ? "" : pValue.trim();
            this.iStatus     = pStatus     == null ? "FAIL" : pStatus.trim().toUpperCase(Locale.ROOT);
            this.iDurationMs = pDurationMs;
            this.iTimestamp  = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss.SSS"));
            this.iFailReason = pFailReason == null ? "" : cap(pFailReason.trim(), 120);
            this.iRootCause  = pRootCause  == null ? "" : pRootCause.trim();
        }

        private static String cap(String s, int max)
        {
            return (s == null || s.length() <= max) ? s : s.substring(0, max) + "...";
        }
    }
}
