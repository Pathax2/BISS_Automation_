# ====================================================================================================================================
# File          : TC_12_STAFF.feature
# Purpose       : Scheme Selection BISS CRISS MSSM RCSM E2E Regression Pack
#                 Modernised from the legacy staff scenarios - single chained E2E Scenario with
#                 # SECTION markers mapping back to the original AT-TC ids.
# Data          : URL launched by Hooks (Config sheet, by environment). Password resolved from the
#                 TestData.xlsx Password column via the TD: mechanism. Herd/parcel/reference values
#                 supplied in-feature via DataTable (no row references).
# Step Defs     : StaffSteps.java (stepdefinitions.STAFF)
# Locators      : ObjectRepository.properties - Staff sections
# Author        : Aniket Pathare | aniket.pathare@government.ie
# Created       : 14-07-2026
# ====================================================================================================================================

Feature: TC_12_STAFF - Scheme Selection BISS CRISS MSSM RCSM E2E Regression Pack

  Background:
    Given user on staff login page
    When Staff logs in with the Username "agr4442"
    And Staff opens the "Basic Income Support for Sustainability" application

  @regression @staff @scheme-selection @e2e
  Scenario: AT-STAFF-SCHEME-E2E-01 - Staff verifies scheme cards and toggles scheme selection on amendments

    # SECTION 1 : Verify BISS + CRISS cards and details - AT-TC-01 (BISSAGL-14880)
    When Staff searches on the Home screen with the following details
      | field      | herdNumber |
      | herdValue  | J1400098   |
      | schemeYear | 2024       |
    And Staff clicks the "Amend" link number 1 in the "application-search-table" table
    Then Staff verifies Scheme Selection card "1" has title "BISS"
    And Staff verifies Scheme Selection card "1" acronym full form is "Basic Income Support for Sustainability"
    When Staff clicks the "BISS" scheme card View Details link
    Then Staff verifies the "Basic Income Support for Sustainability" View Details dialog content
    When Staff clicks the "Close" button
    Then Staff verifies Scheme Selection card "2" has title "CRISS"
    And Staff verifies Scheme Selection card "2" acronym full form is "Complementary Redistributive Income Support for Sustainability"
    When Staff clicks the "CRISS" scheme card View Details link
    Then Staff verifies the "Complementary Redistributive Income Support for Sustainability" View Details dialog content
    When Staff clicks the "Close" button
    Then Staff verifies a toggle is present for the "BISS" scheme
    And Staff verifies a toggle is present for the "CRISS" scheme

    # SECTION 2 : Add CRISS + Protein, submit, verify history, then reset - AT-TC-02 (BISSAGL-14879)
    When Staff clicks the "CRISS" Scheme Selection card
    And Staff clicks the "Protein Aid Scheme" Scheme Selection card
    And Staff clicks the "Next" button
    And Staff clicks the "Submit Changes" button
    And Staff clicks the "OK" button
    Then Staff clicks on "Notes/History" Link in Navbar
    And Staff switches to the "History" tab
    Then Staff verifies the Admin Check entry is "Amendment Submitted" in the History screen
    When Staff clicks on "BISS Amendments" Link in Navbar
    And Staff clicks the "CRISS" Scheme Selection card
    And Staff clicks the "Protein Aid Scheme" Scheme Selection card
    And Staff clicks the "Next" button
    Then Staff clicks the "Submit Changes" button

    # SECTION 3 : Verify MSSM + RCSM cards - AT-TC-03 (BISSAGL-14893)
    When Staff clicks on "Home" Link in Navbar
    And Staff searches on the Home screen with the following details
      | field      | herdNumber |
      | herdValue  | J1400098   |
      | schemeYear | 2024       |
    And Staff clicks the "Amend" link number 1 in the "application-search-table" table
    Then Staff verifies scheme card title "MSSM" with abbreviation "Multi Species Sward Measure"
    And Staff verifies scheme card title "RCSM" with abbreviation "Red Clover Silage Measure"