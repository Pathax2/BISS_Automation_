// ===================================================================================================================================
// File          : TC_06.java
// Package       : stepdefinitions
// Description   : Step definitions for TC_06 - Regression Suite for Bugs and Features in BISS - 1.
//
//                 Active Scenario:
//
//                   AT-TC-01 : Correspondence upload + View Correspondence verification
//                                - Login -> My Clients -> herd search -> Correspondence tab
//                                - Document type selection from dropdown
//                                - File upload and submit via stepper
//                                - Navigate to Transfers tab -> herd search -> View -> View Correspondence
//
//                 Reused steps (defined elsewhere, bound automatically by Cucumber):
//                   "the agent user is on the login page"                             -> TC_03.java
//                   "the agent logs into the application..."                          -> TC_03.java
//                   "the agent opens the {string} application"                        -> TC_03.java
//                   "the agent should land on the BISS Home page"                     -> TC_03.java
//                   "the agent navigates to the {string} and {string} Left Menu Link" -> TC_03.java
//                   "the agent opens a farmer dashboard using herd data"              -> TC_03.java
//                   "the farmer dashboard should be displayed"                        -> TC_03.java
//                   "the agent navigates through the farmer side navigation tabs"     -> TC_03.java
//                   "each requested side navigation tab should open successfully"     -> TC_03.java
//
//                 Shared with TC_03.feature (Correspondence section) - same step text, one definition here:
//                   "the agent clicks on the {string} stepper button"
//                   "the agent selects {string} from the Document type dropdown"
//                   "the agent uploads a document in Correspondence"
//
//                 Playwright migration notes:
//                   - The only Selenium reference was an unused "import static ...getDriver" - removed.
//                   - Every step goes through iAction, which is already Playwright-based, so the step logic is unchanged.
//                   - UPLOADFILE now uses Playwright setInputFiles, which works on the hidden <input type=file> directly.
//                     The file must exist, otherwise the step fails with the full resolved path in the message.
//                   - LIST detects mat-select automatically and picks the option from the overlay panel.
//
// Author        : Aniket Pathare | aniket.pathare@government.ie
// Date Created  : 26-03-2026
// Updated       : 16-09-2026 - Migrated to Playwright (removed Selenium import, header notes)
// Updated       : 17-09-2026 - "switches to the ... tab" step matches "My Client page" and "My Clients page"
// ===================================================================================================================================

package stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import utilities.ObjReader;

import java.io.File;
import java.util.logging.Logger;

import static commonFunctions.CommonFunctions.iAction;

public class TC_06
{
    private static final Logger log = Logger.getLogger(TC_06.class.getName());


    // ===================================================================================================================================
    //  STEPPER BUTTON - Generic click for any stepper/wizard button by visible text
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent clicks on the {string} stepper button
    // Description   : Clicks the "Upload a document" button on the Correspondence page.
    //                 The parameter is only logged - the locator iUploadDocumentBtn uses contains(normalize-space()),
    //                 so the leading space in the feature file (" Upload a document") does not matter.
    // Parameters    : pButtonText (String) - visible button label e.g. "Upload a document"
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 26-03-2026
    // Date Updated  : 16-09-2026 (Playwright - no change in logic)
    // ***************************************************************************************************************************************************************************************
    @Then("the agent/individual clicks on the {string} stepper button")
    public void theAgentClicksOnTheStepperButton(String pButtonText)
    {
        log.info("[STEP] Then the agent clicks on the stepper button: " + pButtonText.trim());

        // "Upload a document" button on the Correspondence page
        iAction("CLICK", "XPATH", ObjReader.getLocator("iUploadDocumentBtn"), null);
    }


    // ===================================================================================================================================
    //  CORRESPONDENCE - DOCUMENT TYPE SELECTION
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent selects {string} from the Document type dropdown
    // Description   : Selects the given value from the Document type mat-select in the Correspondence upload form.
    //                 iAction LIST opens the mat-select and clicks the matching mat-option in the overlay panel.
    // Parameters    : pValue (String) - option text e.g. "Commonage Evidence"
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 26-03-2026
    // Date Updated  : 16-09-2026 (Playwright - no change in logic)
    // ***************************************************************************************************************************************************************************************
    @And("the agent/individual selects {string} from the Document type dropdown")
    public void theAgentSelectsFromDropdown(String pValue)
    {
        log.info("[STEP] And the agent selects '" + pValue + "' from the Document type dropdown");

        iAction("LIST", "XPATH", ObjReader.getLocator("iDocumentTypeSelect"), pValue);
    }


    // ===================================================================================================================================
    //  CORRESPONDENCE - FILE UPLOAD
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent uploads a document in Correspondence
    // Description   : Sets the file on the hidden file input on the Correspondence page, then clicks Upload.
    //                 Default file : <project root>/src/test/resources/Test_Data/Cover_Letter.pdf
    //                 Override     : -Dcorrespondence.upload.path=C:\path\to\file.pdf  (a relative path is resolved from the project root)
    //                 Playwright setInputFiles never opens the OS file picker and works on hidden inputs, same as Selenium sendKeys.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 26-03-2026
    // Date Updated  : 16-09-2026 (Playwright - no change in logic)
    // ***************************************************************************************************************************************************************************************
    @And("the agent/individual uploads a document in Correspondence")
    public void theAgentUploadsADocumentInCorrespondence()
    {
        log.info("[STEP] And the agent/individual uploads a document in Correspondence");

        String iFilePath = System.getProperty("correspondence.upload.path",
                System.getProperty("user.dir")
                        + File.separator + "src"
                        + File.separator + "test"
                        + File.separator + "resources"
                        + File.separator + "Test_Data"
                        + File.separator + "Cover_Letter.pdf");

        iAction("UPLOADFILE", "XPATH", ObjReader.getLocator("iCorrespondenceFileUpload"), iFilePath);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iUploadBtn"), null);
        log.info("Document uploaded: " + iFilePath);
    }


    // ===================================================================================================================================
    //  TRANSFERS - HERD SEARCH
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent switches to the {string} tab on the My Client(s) page
    // Description   : Clicks the named tab header on the My Clients page (e.g. "Transfers", "Applications").
    //                 "Client(s)" is Cucumber optional text: the step matches both "My Client page" and "My Clients page".
    //                 TC_06.feature uses "My Clients page", which did not match the old text "My Client page"
    //                 (Cucumber reported the step as undefined).
    // Parameters    : pTabName (String) - visible tab label e.g. "Transfers"
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 26-03-2026
    // Date Updated  : 17-09-2026 (Playwright - step text accepts Client / Clients)
    // ***************************************************************************************************************************************************************************************
    @And("the agent switches to the {string} tab on the My Client(s) page")
    public void theAgentSwitchesToTheTabOnTheMyClientsPage(String pTabName)
    {
        log.info("[STEP] And the agent switches to the '" + pTabName + "' tab on the My Clients page");

        // The My Clients page uses mat-tab-group - target the tab label by its visible text
        iAction("CLICK", "XPATH", "//div[@role='tab'][.//span[normalize-space()='" + pTabName + "']]", null);
//        iAction("CLICK", "XPATH","//span[contains(text(),'" + pTabName + "')]",null);
    }


    // ***************************************************************************************************************************************************************************************
    // Step          : the agent searches for a transfer herd number
    // Description   : Enters the herd number into the Transfers tab search field and clicks Search.
    //                 The Transfers tab has its own search input, separate from the My Clients herd search in TC_03.
    //                 NOTE: the herd is still hardcoded to A1240326, exactly as in the Selenium version.
    //                       Swap in Hooks.RUNTIME_HERD (commented line) when the DB-selected herd should be used.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 26-03-2026
    // Date Updated  : 16-09-2026 (Playwright - no change in logic)
    // ***************************************************************************************************************************************************************************************
    @When("the agent searches for a transfer herd number")
    public void theAgentSearchesForTransferHerdNumber()
    {
        log.info("[STEP] When the agent searches for a transfer herd number (runtime herd: " + Hooks.RUNTIME_HERD + ", searched: A1240326)");

        //iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iTransfersHerdSearchField"), Hooks.RUNTIME_HERD);
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iTransfersHerdSearchField"), "A1240326");

        // Search button filters the Transfers table
        iAction("CLICK", "XPATH", ObjReader.getLocator("iTransfersSearchBtn"), null);
    }


    // ===================================================================================================================================
    //  TRANSFERS - VIEW LINK AND VIEW CORRESPONDENCE
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent clicks on the View link for the searched herd
    // Description   : Clicks the View link in the Transfers results table. If several rows match, the first is clicked
    //                 (iAction always acts on the first match, the same as Selenium findElement).
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 26-03-2026
    // Date Updated  : 16-09-2026 (Playwright - no change in logic)
    // ***************************************************************************************************************************************************************************************
    @Then("the agent clicks on the View link for the searched herd")
    public void theAgentClicksOnViewLinkForSearchedHerd()
    {
        log.info("[STEP] Then the agent clicks on the View link for the searched herd");

        iAction("CLICK", "XPATH", ObjReader.getLocator("iTransfersViewLink"), null);
    }


    // ***************************************************************************************************************************************************************************************
    // Step          : the agent clicks on the View Correspondence link in the dashboard
    // Description   : Clicks the View Correspondence link on the farmer dashboard reached from the Transfers tab View action.
    //                 Needs the key iViewCorrespondenceLink in ObjectRepository.properties (the step is commented out in
    //                 TC_06.feature today).
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 26-03-2026
    // Date Updated  : 16-09-2026 (Playwright - no change in logic)
    // ***************************************************************************************************************************************************************************************
    @And("the agent clicks on the View Correspondence link in the dashboard")
    public void theAgentClicksOnViewCorrespondenceLink()
    {
        log.info("[STEP] And the agent clicks on the View Correspondence link in the dashboard");

        iAction("CLICK", "XPATH", ObjReader.getLocator("iViewCorrespondenceLink"), null);
    }
}
