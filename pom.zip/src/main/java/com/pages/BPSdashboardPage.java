package com.pages;

import com.base.ActionClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

import static org.openqa.selenium.support.locators.RelativeLocator.with;

public class BPSdashboardPage {

    WebDriver driver;
    ActionClass actions;

    // region Agent Dashboard Locators

    By BPSHomeScreen = By.xpath("//a//descendant::span[contains(text(),'Home')]");
    // This Tab is a Dropdown
    By AgentToolsDropDownTab = By.id("agentToolsNavLink");
    By MyClientsTab = By.id("agentToolsNavLinkMyClients");
    By MyClientsWithNoHerdNumberTab = By.id("agentToolsNavLinkMyClientNoHerdNumber");
    By ChecksByMonitoringTab = By.id("agentToolsNavLinkoutstandingChecksByMonitoring");
    By BPSApplicationsTab = By.id("agentToolsNavLinkBPSApplication");
    By AgentDashboardTab = By.id("agentToolsEmsAgentDashboard");
    By OutstandingBPSErrorsTab = By.id("agentToolsNavLinkOutstandingSPSErrors");
    By StaffExitBPSApp = By.xpath("//a[contains(text(),'Exit BPS')]");
    By HomeDropdownButton = By.xpath("//body[1]/nav[1]/div[1]/div[1]/div[2]/ul[1]/li[1]/a[1]");
    By ClientOption = By.xpath("//body[1]/nav[1]/div[1]/div[1]/div[2]/ul[1]/li[1]/ul[1]/li[1]/a[1]");
    By AgentOption = By.xpath("//body[1]/nav[1]/div[1]/div[1]/div[2]/ul[1]/li[1]/ul[1]/li[2]/a[1]");
    By NewsSectionHeading = By.xpath("//span[@id='newsExplanation']//parent::h3[contains(text(),'News')]");
    By ViewAgentNewsPageLink = By.xpath("//a[@id='newsPortletViewLink' and contains(text(),'View >>')]");
    By SearchHerdField = By.xpath("//input[@id='herdNumberSelected']");
    By SearchHerdButton = By.xpath("//button[@id='searchHerdSearchButton']");
    By ViewSearchedHerd = By.xpath("//input[@id='clientSearchViewSelectedResultButton']");
    By HelpLink = By.xpath("//a[contains(text(),'Help')]");
    By ContactUsLink = By.xpath("//a[contains(text(),'Contact Us')]");

    // endregion


    // region Help Window Locators

    // Help Tab Locators
    By FilingYourBPSApplicationLink = By.xpath("//a[contains(text(),'Filing') and contains(text(),'Your') and contains(text(),'BPS') and contains(text(),'Application')]");
    By PartnerShipInformationHeading = By.xpath("//b[contains(text(),'Partnership Information')]");
    By ANC2021Content = By.xpath("html//body/p[8]/b/span[1]/font/b[1]");
    By YFSContent2021Para = By.xpath("/html/body/p[9]");
    By YFSContent2022Para = By.xpath("/html/body/p[10]");
    By GLAS2ndPara = By.xpath("/html/body/p[13]");
    By GLAS3rdPara = By.xpath("/html/body/p[14]");
    By SubmittingANoChangeCase = By.xpath("//a[contains(text(),'Submitting') and contains(text(),'a') and contains(text(),'No') and contains(text(),'Change') and contains(text(),'Case')]");
    By SubmittingNoChangeCaseText = By.xpath("/html/body/p[4]/span[2]/font");
    By LandParcelDetails = By.xpath("//a[contains(text(),'Land') and contains(text(),'Parcel') and contains(text(),'Details')]");
    By LandParcelDetailsPopUpSection = By.xpath("//h2[contains(text(),\"Pop Up's\")]");
    By AddPlot = By.xpath("//a[contains(text(),'Add') and contains(text(),'Plot')]");
    By AddPlotContent = By.xpath("/html/body");
    By IslandDetails = By.xpath("//a[contains(text(),'Island') and contains(text(),'Details')]");
    By IslandDetailsContent = By.xpath("/html/body");
    By OrganicLandDetails = By.xpath("//a[contains(text(),'Organic') and contains(text(),'Land') and contains(text(),'Details')]");
    By Greening = By.xpath("//a[@id='I_19']");
    By GreeningTabProvisionalStatusHeading = By.xpath("//h2/span/span/font/b[contains(text(),'Provisional Status Table')]");
    By SIMTab = By.xpath("//a[@id='I_20']");
    By SIMTabText = By.xpath("/html/body/p[20]");
    By ApplicationSummary = By.xpath("//a[@id='I_23']");
    By ApplicationSummaryContent = By.xpath("/html/body");


    // Help Window Frames
    By NavigationPageFrame = By.id("minibar_navpane");
    By NavigationPageSubFrame = By.id("navpane");
    By NavigationLinksFrame = By.id("tocIFrame");
    By ContentPageFrame = By.id("topic");

    // endregion


    public BPSdashboardPage(WebDriver driver) {
        this.driver = driver;
        actions = new ActionClass(driver);
    }

    // region BPS Code

    // region Agent Search for Herd

    // Agent Enter Herd Number to be Searched
    public void AgentEnterHerd(String Arg0) {
        actions.waitForVisibilityOfElement(SearchHerdField,30);
        actions.sendKeys(SearchHerdField,Arg0);
    }

    // Agent Click on the Search Herd Button
    public void AgentClickOnSearchHerdButton() {
        actions.waitForVisibilityOfElement(SearchHerdButton,30);
        actions.clickUsingJS(SearchHerdButton);
    }

    // Agent Click on the Searched Herd View Button
    public void AgentClickOnSearchedHerdViewButton() {
        actions.waitForVisibilityOfElement(ViewSearchedHerd,30);
        actions.clickUsingJS(ViewSearchedHerd);
    }
    // endregion

    // region Anciliary Links

    // Agent Click on the Help Link
    public void AgentClickOnHelpLink() {
        actions.waitForVisibilityOfElement(HelpLink,30);
        actions.clickUsingJS(HelpLink);
    }

    // Agent Click on the Contact Us Link
    public void AgentClickOnContactUsLink() {
        actions.waitForVisibilityOfElement(ContactUsLink,30);
        actions.clickUsingJS(ContactUsLink);
    }

    // endregion


    // region Help Window Cases Implementation

    // region Code to Switch Frames

    public void SwitchToNavBarFrame() {
        driver.switchTo().frame(1);
        actions.waitForVisibilityOfFrameAndSwitch(NavigationPageFrame,30);
        actions.waitForVisibilityOfFrameAndSwitch(NavigationPageSubFrame,30);
        actions.waitForVisibilityOfFrameAndSwitch(NavigationLinksFrame,30);
    }

    public void SwitchToContentFrame() {
        driver.switchTo().defaultContent();
        driver.switchTo().frame(1);
        actions.waitForVisibilityOfFrameAndSwitch(ContentPageFrame,30);
    }

    // endregion

    // region Filing you BPS Application Online

    //  Agent Navigate to Filing your BPS Application Online Tab
    public void AgentNavigateToFilingBPSApplicationOnline() throws InterruptedException {
        SwitchToNavBarFrame();
        actions.waitForVisibilityOfElement(FilingYourBPSApplicationLink,15);
        actions.clickUsingJS(FilingYourBPSApplicationLink);
        Thread.sleep(2000);
    }


    // Verify Partnership Information Year
    public Boolean AgentCheckPartnerShipInformationContains() {
        SwitchToContentFrame();
        WebElement PartnerShipInfo = driver.findElement(with(By.tagName("p"))
                        .below(PartnerShipInformationHeading));
        String PartnerShipInfoText= PartnerShipInfo.getText();
        Boolean Year = (PartnerShipInfoText.contains("2022")) && (!(PartnerShipInfoText.contains("2021")));
        return Year;
    }

    // Verify ANC Year Update to 2022
    public Boolean AgentCheckANCContains2022() {
        WebElement ANC2022Para = driver.findElement(ANC2021Content);
        String ANC2022Text = ANC2022Para.getText();
        System.out.println(ANC2022Text);
        Boolean year2022 = (ANC2022Text.contains("2022")) && (!(ANC2022Text.contains("2021")));
        return year2022;
    }

    // Verify YFS Year 1st Para Update to 2021
    public Boolean AgentCheckYFS1stParaContains2021() {
        WebElement YFS2021Para = driver.findElement(YFSContent2021Para);
        String YFS2021ParaText = YFS2021Para.getText();
        System.out.println(YFS2021ParaText);
        Boolean year2021 = (YFS2021ParaText.contains("2021")) && (!(YFS2021ParaText.contains("2022")));
        return year2021;
    }

    // Verify YFS 2nd Para Update to 2022
    public Boolean AgentCheckYFS2ndParaContains2022() {
        WebElement YFS2022Para = driver.findElement(YFSContent2022Para);
        String YFS2022ParaText = YFS2022Para.getText();
        System.out.println(YFS2022ParaText);
        Boolean year2022 = (YFS2022ParaText.contains("2022")) && (!(YFS2022ParaText.contains("2021")));
        return year2022;
    }

    // Verify GLAS 2nd Para Update to 2022
    public Boolean AgentCheckGLAS2ndParaContains2022() {
        WebElement GLAS2022Para = driver.findElement(GLAS2ndPara);
        String GLAS2022ParaText = GLAS2022Para.getText();
        System.out.println(GLAS2022ParaText);
        Boolean year12022 = (GLAS2022ParaText.contains("2022")) && (!(GLAS2022ParaText.contains("2021")));
        return year12022;
    }

    // Verify GLAS 3rd Para Update to 2022
    public Boolean AgentCheckGLAS3rdParaContains2022() {
        WebElement GLAS2022Para = driver.findElement(GLAS3rdPara);
        String GLAS2022ParaText = GLAS2022Para.getText();
        System.out.println(GLAS2022ParaText);
        Boolean year22022 = (GLAS2022ParaText.contains("2022")) && (!(GLAS2022ParaText.contains("2021")));
        return year22022;
    }

    //endregion

    // region Submitting a No Change Case

    //  Agent Navigate to Submitting A No Change Case Tab
    public void AgentNavigateToSubmittingANoChangeCase() throws InterruptedException {
        SwitchToNavBarFrame();
        actions.waitForVisibilityOfElement(SubmittingANoChangeCase,15);
        actions.clickUsingJS(SubmittingANoChangeCase);
        Thread.sleep(2000);
    }

    // Verify Submitting A No Change Case Content Update to 2022
    public Boolean AgentCheckSubmittingANoChangeCaseContentUpdateTo2022() {
        SwitchToContentFrame();
        WebElement NoChange2022Para = driver.findElement(SubmittingNoChangeCaseText);
        String NoChange2022ParaParaText = NoChange2022Para.getText();
        Boolean year2022 = (NoChange2022ParaParaText.contains("2022")) && (!(NoChange2022ParaParaText.contains("2021")));
        return year2022;
    }

    // endregion

    // region Land Parcel

    //  Agent Navigate to Land Parel Details Tab
    public void AgentNavigateToLandParcelDetails() throws InterruptedException {
        SwitchToNavBarFrame();
        actions.waitForVisibilityOfElement(LandParcelDetails,15);
        actions.clickUsingJS(LandParcelDetails);
        Thread.sleep(2000);
    }

    // Check if the Pop Up Section is present
    public void AgentCheckPopUpSection() {
        SwitchToContentFrame();
        actions.waitForVisibilityOfElement(LandParcelDetailsPopUpSection,30);
        actions.clickUsingJS(LandParcelDetailsPopUpSection);
    }

    // endregion

    // region Add Plot

    //  Agent Navigate to Add Plot Tab
    public void AgentNavigateToAddPlot() throws InterruptedException {
        SwitchToNavBarFrame();
        actions.waitForVisibilityOfElement(AddPlot,15);
        actions.clickUsingJS(AddPlot);
        Thread.sleep(2000);
    }

    // Check if the Content Section of Add Plot updated to 2022
    public Boolean AgentCheckAddPlotSectionYearUpdate() {
        SwitchToContentFrame();
        WebElement AddPlot2022 = driver.findElement(IslandDetailsContent);
        String AddPlot2022Text = AddPlot2022.getText();
        Boolean year2022 = (AddPlot2022Text.contains("2022")) && (!(AddPlot2022Text.contains("2021")));
        return year2022;
    }

    // endregion

    // region Island Details

    //  Agent Navigate to Add Plot Tab
    public void AgentNavigateToIslandDetails() throws InterruptedException {
        SwitchToNavBarFrame();
        actions.waitForVisibilityOfElement(IslandDetails,15);
        actions.clickUsingJS(IslandDetails);
        Thread.sleep(2000);
    }

    // Check if the Content Section of Island Details updated to 2022
    public Boolean AgentCheckIslandDetailsSectionYearUpdate() {
        SwitchToContentFrame();
        WebElement IslandDetails2022 = driver.findElement(AddPlotContent);
        String IslandDetails2022Text = IslandDetails2022.getText();
        Boolean year2022 = (IslandDetails2022Text.contains("2022")) && (!(IslandDetails2022Text.contains("2021")));
        return year2022;
    }

    // endregion

    // region Organic Land Details

    //  Agent Navigate to Organic Land Details Tab
    public void AgentNavigateToOrganicLandDetails() throws InterruptedException {
        SwitchToNavBarFrame();
        actions.waitForVisibilityOfElement(OrganicLandDetails,15);
        actions.clickUsingJS(OrganicLandDetails);
        Thread.sleep(2000);
    }

    // Check if the Content Section of Organic Land Details updated to 2022
    public Boolean AgentCheckOrganicLandDetailsSectionYearUpdate() {
        SwitchToContentFrame();
        WebElement OrganicLandDetails2022 = driver.findElement(AddPlotContent);
        String OrganicLandDetails2022Text = OrganicLandDetails2022.getText();
        Boolean year2022 = (OrganicLandDetails2022Text.contains("2022")) && (!(OrganicLandDetails2022Text.contains("2021")));
        return year2022;
    }

    // endregion

    // region Greening

    //  Agent Navigate to Greening Tab
    public void AgentNavigateToGreening() throws InterruptedException {
        SwitchToNavBarFrame();
        actions.waitForVisibilityOfElement(Greening,15);
        actions.clickUsingJS(Greening);
        Thread.sleep(2000);
    }

    // Verify Provisional Status Table Year
    public Boolean AgentCheckProvisionalStatusTableContains2022() {
        SwitchToContentFrame();
        WebElement ProvisionalStatusTableYear = driver.findElement(with(By.tagName("span"))
                .below(GreeningTabProvisionalStatusHeading));
        String ProvisionalStatusTableYearText= ProvisionalStatusTableYear.getText();
        Boolean Year = (ProvisionalStatusTableYearText.contains("2022")) && (!(ProvisionalStatusTableYearText.contains("2021")));
        return Year;
    }

    // endregion


    // region Straw Incorporation Measure (SIM)

    //  Agent Navigate to SIM Tab
    public void AgentNavigateToSIM() throws InterruptedException {
        SwitchToNavBarFrame();
        actions.waitForVisibilityOfElement(SIMTab,15);
        actions.clickUsingJS(SIMTab);
        Thread.sleep(2000);
    }

    // Check if the Content Section of SIM contains specified Heading
    public String AgentCheckSIMSectionText() {
        SwitchToContentFrame();
        String SIMSectionText = driver.findElement(SIMTabText).getText();
        return SIMSectionText;
    }
    // endregion

    // region Application Summary

    //  Agent Navigate to Application Summary Tab
    public void AgentNavigateToApplicationSummary() throws InterruptedException {
        SwitchToNavBarFrame();
        actions.waitForVisibilityOfElement(ApplicationSummary,15);
        actions.clickUsingJS(ApplicationSummary);
        Thread.sleep(2000);
    }

    // Check if the Content Section of Application Summary updated to 2022
    public Boolean AgentCheckApplicationSummarySectionYearUpdate() {
        SwitchToContentFrame();
        WebElement ApplicationSummary2022 = driver.findElement(ApplicationSummaryContent);
        String ApplicationSummary2022Text = ApplicationSummary2022.getText();
        Boolean year2022 = (ApplicationSummary2022Text.contains("2022")) && (!(ApplicationSummary2022Text.contains("2021")));
        return year2022;
    }

    // endregion

    // endregion


    // region Click on Agent Tools Dropdown Links

    // Clicking on the My Clients Tab
    public void AgentClickOnMyClientsTab() {
        actions.waitForVisibilityOfElement(AgentToolsDropDownTab, 30);
        actions.click(AgentToolsDropDownTab);
        actions.waitForVisibilityOfElement(MyClientsTab, 30);
        actions.click(MyClientsTab);
    }

    // Clicking on the My Clients With No Herd Number Tab
    public void AgentClickOnMyClientsWithNoHerdNumberTab() {
        actions.waitForVisibilityOfElement(AgentToolsDropDownTab, 30);
        actions.click(AgentToolsDropDownTab);
        actions.waitForVisibilityOfElement(MyClientsWithNoHerdNumberTab, 30);
        actions.click(MyClientsWithNoHerdNumberTab);
    }

    // Clicking on the Checks By Monitoring Tab
    public void AgentClickOnChecksByMonitoringTab() {
        actions.waitForVisibilityOfElement(AgentToolsDropDownTab, 30);
        driver.findElement(AgentToolsDropDownTab).click();
        actions.waitForVisibilityOfElement(ChecksByMonitoringTab, 30);
        driver.findElement(ChecksByMonitoringTab).click();
    }

    // Clicking on the BPS Applications Tab
    public void AgentClickOnBPSApplicationsTab() {
        actions.waitForVisibilityOfElement(AgentToolsDropDownTab, 30);
        driver.findElement(AgentToolsDropDownTab).click();
        actions.waitForVisibilityOfElement(BPSApplicationsTab, 30);
        driver.findElement(BPSApplicationsTab).click();
    }

    // Clicking on the Agent Dashboard Tab
    public void AgentClickOnAgentDashboardTab() {
        actions.waitForVisibilityOfElement(AgentToolsDropDownTab, 30);
        driver.findElement(AgentToolsDropDownTab).click();
        actions.waitForVisibilityOfElement(AgentDashboardTab, 30);
        driver.findElement(AgentDashboardTab).click();
    }

    // Clicking on the Outstanding BPS Errors Tab
    public void AgentClickOnOutstandingBPSErrorsTab() {
        actions.waitForVisibilityOfElement(AgentToolsDropDownTab, 30);
        driver.findElement(AgentToolsDropDownTab).click();
        actions.waitForVisibilityOfElement(OutstandingBPSErrorsTab, 30);
        driver.findElement(OutstandingBPSErrorsTab).click();
    }

    // endregion


    // region Click on other Agent Dashboard NavBar Links

    // Navigate to Client Homepage
    public void AgentNavigateToClientHomePage() {
        actions.waitForVisibilityOfElement(HomeDropdownButton, 30);
        driver.findElement(HomeDropdownButton).click();
        actions.waitForVisibilityOfElement(ClientOption, 30);
        driver.findElement(ClientOption).click();
    }

    // Navigate to Agent Homepage
    public void AgentNavigateToAgentHomePage() {
        actions.waitForVisibilityOfElement(HomeDropdownButton, 30);
        driver.findElement(HomeDropdownButton).click();
        actions.waitForVisibilityOfElement(AgentOption, 30);
        driver.findElement(AgentOption).click();
    }

    // Clicking on the BPS Agent Home Screen Tab
    public void StaffClickOnBPSAgentHomeScreenTab() {
        actions.waitForVisibilityOfElement(BPSHomeScreen, 30);
        driver.findElement(BPSHomeScreen).click();
    }

    // Clicking on the Logout Link
    public void StaffClickOnExtBPSAppLink() {
        actions.waitForVisibilityOfElement(StaffExitBPSApp, 30);
        actions.clickUsingJS(StaffExitBPSApp);
    }

    // endregion


    // region Check on Agent Dashboard page Elements

    // Agent Check if the News Section present
    public Boolean AgentCheckNewsSection() {
        actions.waitForVisibilityOfElement(NewsSectionHeading,30);
        Boolean NewsHeadingVisibility = driver.findElement(NewsSectionHeading).isDisplayed();
        return NewsHeadingVisibility;
    }

    // Agent Navigate to News Page
    public void AgentClickOnViewInNewsSection() {
        actions.waitForVisibilityOfElement(ViewAgentNewsPageLink,30);
        actions.clickUsingJS(ViewAgentNewsPageLink);
    }
    // endregion

// endregion

    // region BISS Dashboard Page

    // region Main Elements

    // Agent Click on Agent Number on Top Right Corner
    public void AgentClickOnMyAccountButton() {
        By MyAccountButton = By.xpath("//button[@aria-label='My account']");
        actions.waitForVisibilityOfElement(MyAccountButton,30);
        actions.clickUsingJS(MyAccountButton);
    }

    // Agent Click on Exit Button in My Account Menu
    public void AgentClickOnExitButton() {
        By ExitLink = By.xpath("//a[contains(text(),'Exit')]");
        //actions.waitForVisibilityOfElement(MyAccountButton,30);
        actions.clickUsingJS(ExitLink);
    }

    // Agent Click on the Contact Us Button in Top Right Corner
    public void AgentClickOnContactUsButton() {
        By MyAccountButton = By.xpath("//button[@aria-label='Contact']");
        actions.waitForVisibilityOfElement(MyAccountButton,30);
        actions.clickUsingJS(MyAccountButton);
    }

    // Agent Click on the Side Navbar Elements
    // Locator Arg Home, My Clients
    public void AgentClickOnDashboardSidenavElements(String Arg0) {
        By SidenavButtons = By.xpath("//a/descendant::span[contains(text(),'"+Arg0+"')]");
        actions.waitForVisibilityOfElement(SidenavButtons,30);
        actions.clickUsingJS(SidenavButtons);
    }

    // endregion


    //region Applications Section

    // Locators
    By ViewTotalClients = By.xpath("//mat-card-title[contains(text(),'BISS Applications 2023')]/parent::mat-card/descendant::a[contains(text(),'View clients')]");

    // Click on the Total Clients Button
    public void AgentClickOnTotalClientsButton() {
        actions.waitForVisibilityOfElement(ViewTotalClients,30);
        actions.clickUsingJS(ViewTotalClients);
    }

    // endregion

    // region News Section

    // Agent Click on the Read More Link in News section
    // Locator Arg "Read More"
    public void AgentClickOnReadMoreNewsButton() {
        By ReadMoreLink = By.xpath("//a[contains(text(),'Read More')]");
        actions.waitForVisibilityOfElement(ReadMoreLink,30);
        actions.clickUsingJS(ReadMoreLink);
    }

    // Click on the News View Button
    // Use the method in MyClients Page
    // Locators Arg "Next page" , "Previous Page"
    public void AgentClickOnNewsNextAndPreviousButton(String Arg0) {
        By NewsNextAndPreviousButton = By.xpath("//button[@aria-label='"+Arg0+"']");
        actions.waitForVisibilityOfElement(NewsNextAndPreviousButton,30);
        actions.clickUsingJS(NewsNextAndPreviousButton);
    }

    // endregion

    // region Quick Links Section

    // Agent Click on View Client Button in Quick Links Section
    // Locators Arg "Transfer of Entitlements" , "CISYF"
    public void AgentClickOnQuickLinksViewClientsLink(String Arg0) {
        By TransferOfEntitlementsViewClientsLink = By.xpath("//div[contains(text(),'"+Arg0+"')]/parent::div/descendant::a[contains(text(),'View clients')]");
        actions.waitForVisibilityOfElement(TransferOfEntitlementsViewClientsLink,30);
        actions.clickUsingJS(TransferOfEntitlementsViewClientsLink);
    }

    // endregion

    // endregion

}


// Dummy Test Code
//        WebDriverWait wait = new WebDriverWait(driver,60);
//        wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt("content"));
//        actions.waitForVisibilityOfFrame(NavigationPageFrame,30);
//        Actions action = new Actions(driver);
//        WebElement FilingLink = driver.findElement(FilingYourBPSApplicationLink);
//        action.moveToElement(FilingLink).click();