Feature: Regression Pack for Active Farmer History Notes - In Progress to be cleared

  Background:
     Given user on staff login page

  @regression
  Scenario: AT-TC-00 - Queries required for BISSAGL-7777
    Then Get 5 Herds with Admin Check Not Started from Database

  @tmslink=BISSAGL-14850
  @regression
  Scenario: AT-TC-01 - BISS_24.1.Sprint_6 TC1 for BISSAGL-7777 Active Farmer - System Notes for History Screen
    When Login with the Username "agr4442"
    And enter password
    Then Staff Select Data Protection CheckBox
    And clicks on Login button
    And Click on the Basic Income Support for Sustainability application
    Then Staff Enter Value as Herd Number with Admin Check Not Started from row 2 in the "herdNumber" field
    #Then Staff Enter "herdNumber" value as "L1631133"
    Then Staff Select "schemeYear" dropdown value as "2024"
    Then Staff Click on the "Search" button
    And Staff Click On the "application-search-table" table "View" link number 1
    Then Staff Click on "Active Farmer" Link in Navbar
    Then Staff Click on the "Start admin check" button
    Then Staff Click on the "Send" button
    Then Staff Click on "Notes/History" Link in Navbar
    And Staff switch to the "History" tab
    Then Staff verify Admin Check Entry is "Active Farmer Admin Check in Progress Stop has been Applied with comment: Admin check started manually" in History Screen

  @tmslink=BISSAGL-14842
  @regression
  Scenario: AT-TC-02 - BISS_24.1.Sprint_6 TC2 for BISSAGL-7777 Active Farmer - System Notes for History Screen
    When Login with the Username "agr4442"
    And enter password
    Then Staff Select Data Protection CheckBox
    And clicks on Login button
    And Click on the Basic Income Support for Sustainability application
    #G1911251
 #   Then Staff Enter "herdNumber" value as "L1631133"
    Then Staff Enter Value as Herd Number with Admin Check Not Started from row 2 in the "herdNumber" field
    Then Staff Select "schemeYear" dropdown value as "2024"
    Then Staff Click on the "Search" button
    And Staff Click On the "application-search-table" table "View" link number 1
    Then Staff Click on "Active Farmer" Link in Navbar
#    Then Staff Click on the "Start admin check" button
#    Then Staff Click on the "Send" button
    Then Staff Select "APPROVED" as Admin Check Result
    Then Staff Enter "Test Note" as Admin Notes
    Then Staff Click on the "Save changes" button
    Then Staff Click on "Notes/History" Link in Navbar
    And Staff switch to the "History" tab
    Then Staff verify Admin Check Entry is "Active Farmer Admin Check in Progress Stop has been Lifted with comment: Test Note" in History Screen

  @tmslink=BISSAGL-14840
  @regression
  Scenario: AT-TC-03 - BISS_24.1.Sprint_6 TC3 for BISSAGL-7777 Active Farmer - System Notes for History Screen
    When Login with the Username "agr4442"
    And enter password
    Then Staff Select Data Protection CheckBox
    And clicks on Login button
    And Click on the Basic Income Support for Sustainability application
    #G1911251
#    Then Staff Enter "herdNumber" value as "P1091091"
    Then Staff Enter Value as Herd Number with Admin Check Not Started from row 4 in the "herdNumber" field
    Then Staff Select "schemeYear" dropdown value as "2024"
    Then Staff Click on the "Search" button
    And Staff Click On the "application-search-table" table "View" link number 1
    Then Staff Click on "Active Farmer" Link in Navbar
    Then Staff Click on the "Start admin check" button
    Then Staff Click on the "Send" button
    Then Staff Select "REJECTED" as Admin Check Result
    Then Staff Enter "Test Note" as Admin Notes
    Then Staff Click on the "Save changes" button
    Then Staff Click on the "Start appeal process" button
    Then Staff Click on the "Yes, Appeal" button
    Then Staff Click on the "Upload document" button
    And Upload Document in Correspondence
    Then Staff Click on the "Submit" button
    Then Staff Select "APPROVED" as Admin Check Result
    Then Staff Enter "Appeal Approved" as Admin Notes
    Then Staff Click on the "Save changes" button
    Then Staff Click on "Notes/History" Link in Navbar
    And Staff switch to the "History" tab
    Then Staff verify Admin Check Entry is "Active Farmer Admin Check in Progress Stop has been Lifted with comment: Appeal Approved" in History Screen
