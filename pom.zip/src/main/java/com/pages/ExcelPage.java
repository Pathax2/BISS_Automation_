package com.pages;

import com.base.ActionClass;
import com.stepdefinitions.IDataReader;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class ExcelPage {



    WebDriver driver;
    ActionClass actions;
    LoginPage loginpage;

    // region Write to Excel

//    public void WriteHerdToFile(String HerdNumber) throws IOException {
//        String file1 = getExcelfile();
//            FileInputStream fs = new FileInputStream(file1);
//            //Creating a workbook
//            XSSFWorkbook workbook = new XSSFWorkbook(fs);
//            // Get the sheet number
//            XSSFSheet sheet = workbook.getSheetAt(0);
//            // Get the first empty row
//            int EmptyRow = sheet.getLastRowNum()+1;
//            XSSFRow TargetRow = sheet.getRow(EmptyRow);
//            // Save the HerdNumber in the Excel for Deleting Application Post Run
//        try{
//            TargetRow.getCell(0).setCellValue(HerdNumber);
//        } catch (Exception e) {
//            System.out.println(e);
//        }
//    }

//    public void WriteHerdToFile1(String HerdNumber) throws IOException {
//        String file1 = getExcelfile();
//        FileInputStream file = new FileInputStream(file1);
//        HSSFWorkbook strWorkBook = new HSSFWorkbook(file);
//        HSSFSheet sheet = strWorkBook.getSheet("Sheet 1");
//
//// Retrieve the row and check for null
//        HSSFRow sheetrow = sheet.getRow(0);
//        if(sheetrow == null){
//            //logger.info("CREATING ROW"+rowNo);
//            sheetrow = sheet.createRow(0);
//        }
//// Update the value of a cell
//        HSSFCell cell = sheetrow.getCell(0);
//
//        if(cell == null){
//            //logger.info("CREATING COLUMN " + columnNo);
//            cell = sheetrow.createCell(0); }
//
//        cell.setCellValue(HerdNumber);
//
//        FileOutputStream outFile = new FileOutputStream(file1);
//        strWorkBook.write(outFile);
//        outFile.close();
//    }

    static HSSFWorkbook hwb = new HSSFWorkbook();
    static HSSFSheet sheet = hwb.createSheet("new sheet");
    static HSSFRow rowhead = sheet.createRow((short) 0);
    static HSSFRow row = sheet.createRow((short) 1);

//    public ExcelPage(WebDriver driver) {
//        this.driver = driver;
//        actions = new ActionClass(driver);
//    }
    //static int count = 1;

    public void WriteHerdToFile1(String HerdNumber) {
        try {
            File herdfile = new File("./src/main/resources/TestData/Herd to be Deleted.xls");
            if(herdfile.exists()){
                FileInputStream fis = new FileInputStream(herdfile);
                Workbook wrkbk = WorkbookFactory.create(fis);
                Sheet sheet = wrkbk.getSheetAt(0);
                int rowCount = sheet.getLastRowNum();
                Row row = sheet.createRow(++rowCount);
                Cell cell = row.createCell(0);
                cell.setCellValue(HerdNumber);
                fis.close();
                FileOutputStream outputStream = new FileOutputStream(herdfile);
                wrkbk.write(outputStream);
                wrkbk.close();
                outputStream.close();
                System.out.println("Value Updated");
            }
            else {
                rowhead.createCell((short) 0).setCellValue("Herd Number");
                row.createCell((short) 0).setCellValue(HerdNumber);
                FileOutputStream fileOut = new FileOutputStream(herdfile);
                hwb.write(fileOut);
                fileOut.close();
                System.out.println("Your excel file has been generated!");
            }
        }
        catch (Exception ex) {
            System.out.println(ex);
        }
    }

    public void WriteAgentToFile(String Agent) {
        try {
            File agentfile = new File("./src/main/resources/TestData/LoginAgent.xls");
            if(agentfile.exists()){
                FileInputStream fis = new FileInputStream(agentfile);
                Workbook wrkbk = WorkbookFactory.create(fis);
                Sheet sheet = wrkbk.getSheetAt(0);
                int rowCount = sheet.getLastRowNum();
                Row row = sheet.createRow(++rowCount);
                Cell cell = row.createCell(0);
                cell.setCellValue(Agent);
                fis.close();
                FileOutputStream outputStream = new FileOutputStream(agentfile);
                wrkbk.write(outputStream);
                wrkbk.close();
                outputStream.close();
                System.out.println("Value Updated");
            }
            else {
                rowhead.createCell((short) 0).setCellValue("Agent Number");
                row.createCell((short) 0).setCellValue(Agent);
                FileOutputStream fileOut = new FileOutputStream(agentfile);
                hwb.write(fileOut);
                fileOut.close();
                System.out.println("Your excel file has been generated!");
            }
        }
        catch (Exception ex) {
            System.out.println(ex);
        }
    }

    public String GetLastAgentNumber() throws  IOException {
        File agentFile = new File("./src/main/resources/TestData/LoginAgent.xls");
        FileInputStream fis = new FileInputStream(agentFile);
        Workbook wrkbk = new HSSFWorkbook(fis);
        Sheet sheet = wrkbk.getSheetAt(0);
        Iterator<Row> iterator = sheet.iterator();
        List<String> AgentNumbers = new ArrayList<>();
//        int rowCount = sheet.getLastRowNum();
//        Cell cell = row.getCell(rowCount);
//        String LastAgent = cell.getStringCellValue();
        while (iterator.hasNext()) {
            Row nextRow = iterator.next();
            Iterator<Cell> cellIterator = nextRow.cellIterator();

            while (cellIterator.hasNext()) {
                Cell cell = cellIterator.next();
                String AgentNumber = cell.getStringCellValue();
                AgentNumbers.add(AgentNumber);
            }
        }
        int AgentNumber = AgentNumbers.size();
        String LastAgent = AgentNumbers.get(AgentNumber-1);
        System.out.println(LastAgent);
        wrkbk.close();
        fis.close();
        return LastAgent;
    }

//    private  void store(String HerdNumber) {
//        if(row.getCell(0)!=null){
//            row.createCell((short) (row.getLastCellNum()+1)).setCellValue(HerdNumber);
//        }
//        else {
//            row.createCell((short) 0).setCellValue(HerdNumber);
//        }
//
//    }

    String getExcelfile() {
        return new File("./src/main/resources/TestData/Herd to be Deleted.xlsx").getAbsolutePath();
    }

    // endregion

    // region Batch Loading
    // Try to use the herds from the Excel Spreadsheet
//    public void GetAgentNumberAsArray(IDataReader dataTable) throws InterruptedException {
//        List<String> ownerIDs = dataTable.getAllRows();
//        for (int i=0 ; i<ownerIDs.size() ;i++) {
//            String currentherd = ownerIDs.get(i);
//            String Split1 = currentherd.replaceAll("\\[","");
//            String Split2 = Split1.replaceAll("]","");
//            String Split3[] = Split2.split("\\.");
//            String HerdNumber = Split3[0];
//            By Username =  By.id("mat-input-sso-lib-username-field-0");
//            actions.sendKeys(Username,HerdNumber);
//            AgentEnterLinearCutsEntitlementIDNumber(EntitlementID);
//            AgentClickOnLinearcutsSearchHerdButton();
//            System.out.println("For the EMS Owner ID : "+Split3[0]+" with Herd Number : "+AgentGetOnEMSOwnerHerd());
            //CalculationSelection();
//            EntitlementsSummary2022Iteration();
//        }
        //System.out.println(herdnumbers.size());
//    }

    // endregion

    // region Read from Excel

    public List<String> GetAgentNumberAsArray() throws IOException {
        File agentFile = new File("./src/main/resources/TestData/AgentsBatch.xlsx");
        FileInputStream fis = new FileInputStream(agentFile);
        Workbook wrkbk = new XSSFWorkbook(fis);
        Sheet sheet = wrkbk.getSheetAt(0);
        Iterator<Row> iterator = sheet.iterator();
        List<String> AgentNumbers = new ArrayList<>();
        while (iterator.hasNext()) {
            Row nextRow = iterator.next();
            Iterator<Cell> cellIterator = nextRow.cellIterator();

            while (cellIterator.hasNext()) {
                Cell cell = cellIterator.next();
                String AgentNumber = cell.getStringCellValue();
                AgentNumbers.add(AgentNumber);
            }
        }
        wrkbk.close();
        fis.close();
        return AgentNumbers;
    }




    public List<String> getAllRows() throws IOException {
        File agentFile = new File("./src/main/resources/TestData/AgentsBatch.xlsx");
        FileInputStream fis = new FileInputStream(agentFile);
        XSSFWorkbook wrkbk = new XSSFWorkbook(fis);
        XSSFSheet sheet = wrkbk.getSheetAt(0);
        List<String> data = new ArrayList<>();
        try  {
            XSSFSheet targetsheet = sheet;
            Iterator<Row> iterator = targetsheet.iterator();
            while (iterator.hasNext()) {
                Row nextRow = iterator.next();
                Iterator<Cell> cellIterator = nextRow.cellIterator();
                while (cellIterator.hasNext()) {
                    Cell cell = cellIterator.next();
                    String AgentNumber = cell.getStringCellValue();
                    data.add(AgentNumber);
                }
            }
            wrkbk.close();
            fis.close();
            System.out.println(Collections.unmodifiableList(data));
            return Collections.unmodifiableList(data);
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }

//    private List<String> getData1(XSSFSheet sheet) {
//        Iterator<Row> iterator = sheet.iterator();
//        List<String> AgentNumbers = new ArrayList<>();
//        while (iterator.hasNext()) {
//            Row nextRow = iterator.next();
//            Iterator<Cell> cellIterator = nextRow.cellIterator();
//
//            while (cellIterator.hasNext()) {
//                Cell cell = cellIterator.next();
//                String AgentNumber = cell.getStringCellValue();
//                AgentNumbers.add(AgentNumber);
//            }
//        }
//        wrkbk.close();
//        fis.close();
//        return AgentNumbers;
//        return Collections.unmodifiableList(data);
//    }
//
//    private List<String> getData(XSSFSheet sheet) {
//        //List<Map<String, String>> data = new ArrayList<Map<String, String>>();
//        List<String> data = new ArrayList<>();
//        //List<String> headers = getHeaders(sheet);
//
//        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
//            //Map<String, String> rowMap = new HashedMap<String, String>();
//            List<Double> rowMap = new ArrayList<>();
//            XSSFRow row = sheet.getRow(i);
//            forEachWithCounter(row, (index, cell) -> {
//                //rowMap.put(headers.get(index), cell.getStringCellValue());
//                rowMap.add(cell.getNumericCellValue());
//            });
//            data.add(String.valueOf(rowMap));
//        }
//        return Collections.unmodifiableList(data);
//    }
    // endregion
}





