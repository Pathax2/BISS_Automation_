# ====================================================================================================================================
# File          : TC_16_STAFF.feature
# Purpose       : OpenShift Search and Navigation E2E Regression Pack
#                 Modernised from the legacy staff scenarios - single chained E2E Scenario with
#                 # SECTION markers mapping back to the original AT-TC ids.
# Data          : URL launched by Hooks (Config sheet, by environment). Password resolved from the
#                 TestData.xlsx Password column via the TD: mechanism. Herd/parcel/reference values
#                 supplied in-feature via DataTable (no row references).
# Step Defs     : StaffSteps.java (stepdefinitions.STAFF)
# Locators      : ObjectRepository.properties - Staff sections
# Author        : Aniket Pathare | aniket.pathare@government.ie
# Created       : 14-07-2026
# ====================================================================================================================================

Feature: TC_16_STAFF - OpenShift Search and Navigation E2E Regression Pack

  Background:
    Given user on OpenShift staff login page

  @regression @staff @openshift @search @e2e
  Scenario: AT-STAFF-OS-SEARCH-E2E-01 - Staff performs herd, reference and parcel searches on OpenShift and switches herd tabs

    # SECTION 1 : Switch tabs on dashboard side menu - AT-TC-01 (BISSAGL-12669)
    When Staff logs in with the Username "agr4442"
    And Staff opens the "Basic Income Support for Sustainability" application
    Then Staff clicks on "Coordination" Link in Navbar
    And Staff clicks on "Home" Link in Navbar

    # SECTION 2 : Search with reference number - AT-TC-02 (BISSAGL-12669)
    When Staff searches on the Home screen with the following details
      | field          | referenceNumber |
      | referenceValue | 23C4304B        |
      | schemeYear     | 2023            |

    # SECTION 3 : Search with herd number - AT-TC-03 (BISSAGL-12669)
    When Staff searches on the Home screen with the following details
      | field      | herdNumber |
      | herdValue  | P1751946   |
      | schemeYear | 2024       |

    # SECTION 4 : Parcel search on Parcels tab - AT-TC-04 (BISSAGL-12669)
    When Staff switches to the "Parcels" tab
    And Staff searches on the Home screen with the following details
      | field       | parcelNumber |
      | parcelValue | A1120600028  |
      | schemeYear  | 2024         |

    # SECTION 5 : Switch tabs within a herd - AT-TC-09 (BISSAGL-12669)
    When Staff clicks on "Home" Link in Navbar
    And Staff searches on the Home screen with the following details
      | field      | herdNumber |
      | herdValue  | P1751946   |
      | schemeYear | 2024       |
    And Staff clicks the "View" link number 1 in the "application-search-table" table
    Then Staff clicks on "Payments" Link in Navbar
    And Staff clicks on "Correspondence" Link in Navbar
    And Staff clicks on "Errors/Stops" Link in Navbar
    And Staff clicks on "Inspections" Link in Navbar
    And Staff clicks on "Notes/History" Link in Navbar
    And Staff clicks on "BISS Application" Link in Navbar
    And Staff clicks on "SIM" Link in Navbar