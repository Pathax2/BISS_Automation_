# ====================================================================================================================================
# File          : TC_13_STAFF.feature
# Purpose       : Active Farmer Admin Check and Appeals E2E Regression Pack
#                 Modernised from the legacy staff scenarios - single chained E2E Scenario with
#                 # SECTION markers mapping back to the original AT-TC ids.
# Data          : URL launched by Hooks (Config sheet, by environment). Password resolved from the
#                 TestData.xlsx Password column via the TD: mechanism. Herd/parcel/reference values
#                 supplied in-feature via DataTable (no row references).
# Step Defs     : StaffSteps.java (stepdefinitions.STAFF)
# Locators      : ObjectRepository.properties - Staff sections
# Author        : Aniket Pathare | aniket.pathare@government.ie
# Created       : 14-07-2026
# ====================================================================================================================================

Feature: TC_13_STAFF - Active Farmer Admin Check and Appeals E2E Regression Pack

  Background:
    Given user on staff login page

  @regression @staff @active-farmer @admin-check @appeals @e2e
  Scenario: AT-STAFF-ADMIN-E2E-01 - Staff runs the Active Farmer admin check and appeal process end to end

    # SECTION 1 : Start admin check + system note in history - AT-TC-01 (BISSAGL-14850)
    When Staff logs in with the Username "agr4442"
    And Staff opens the "Basic Income Support for Sustainability" application
    And Staff searches on the Home screen with the following details
      | field      | herdNumber |
      | herdValue  | L1631133   |
      | schemeYear | 2024       |
    And Staff clicks the "View" link number 1 in the "application-search-table" table
    Then Staff clicks on "Active Farmer" Link in Navbar
    And Staff clicks the "Start admin check" button
    And Staff clicks the "Send" button
    Then Staff clicks on "Notes/History" Link in Navbar
    And Staff switches to the "History" tab
    Then Staff verifies the Admin Check entry is "Active Farmer Admin Check in Progress Stop has been Applied with comment: Admin check started manually" in the History screen

    # SECTION 2 : Reject, appeal, upload, approve - AT-TC-03 (BISSAGL-14840)
    When Staff clicks on "Home" Link in Navbar
    And Staff searches on the Home screen with the following details
      | field      | herdNumber |
      | herdValue  | P1091091   |
      | schemeYear | 2024       |
    And Staff clicks the "View" link number 1 in the "application-search-table" table
    Then Staff clicks on "Active Farmer" Link in Navbar
    And Staff clicks the "Start admin check" button
    And Staff clicks the "Send" button
    And Staff selects "REJECTED" as the Admin Check result
    And Staff enters "Test Note" as Admin notes
    And Staff clicks the "Save changes" button
    And Staff clicks the "Start appeal process" button
    And Staff clicks the "Yes, Appeal" button
    And Staff clicks the "Upload document" button
    And Staff uploads a document in Correspondence
    And Staff clicks the "Submit" button
    And Staff selects "APPROVED" as the Admin Check result
    And Staff enters "Appeal Approved" as Admin notes
    And Staff clicks the "Save changes" button
    Then Staff clicks on "Notes/History" Link in Navbar
    And Staff switches to the "History" tab
    Then Staff verifies the Admin Check entry is "Active Farmer Admin Check in Progress Stop has been Lifted with comment: Appeal Approved" in the History screen
