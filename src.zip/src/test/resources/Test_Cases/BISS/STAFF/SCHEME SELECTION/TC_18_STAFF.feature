Feature: TC_S18 - Regression Pack for Active Farmer and Admin Process History Notes

  # ──────────────────────────────────────────────────────────────────────────
  # Purpose:
  #   Validates navigation to the Active Farmer screen for herd A1220864 (2024).
  #   Further admin check actions (start check, save result, appeal) are in progress
  #   pending full workflow enablement.
  #
  # Common Background:
  #   Staff login as agr4442 → open BISS application.
  #
  # DB Data:
  #   No DB pool step required. Herd A1220864 is a fixed test herd.
  #
  # Notes:
  #   1. TC01 is a navigation-only scenario — it confirms the Active Farmer
  #      section is accessible via the side navigation bar.
  #   2. The commented-out steps in the legacy file (start admin check, send,
  #      select result, save) will be added here when the workflow is enabled.
  #
  # Author  : Aniket Pathare | aniket.pathare@government.ie
  # Created : 2026-05-14
  # ──────────────────────────────────────────────────────────────────────────

  Background:
    Given the staff user is on the staff login page
    When the staff user logs in with username "agr4442"
    And the staff user selects the data protection checkbox and clicks login
    And the staff user opens the "Basic Income Support for Sustainability" application

  @tmsLink=BISSAGL-14837 @regression
  Scenario: TC_S18 - Active Farmer and Admin Process History Notes regression

    # ── TC01: Navigate to Active Farmer section for A1220864 (2024) ──────────
    When the staff user searches for herd "A1220864" for scheme year "2024" and views the application
    Then the "Active Farmer" section should be accessible via the side navigation bar
