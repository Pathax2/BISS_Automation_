package com.stepdefinitions;


import com.base.ConfigReader;
import com.base.DriverManager;
import com.pages.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
//import sun.tools.jconsole.Tab;

import java.io.IOException;
import java.util.Properties;

public class BPSApplicationSteps {

    LoginPage loginPage;
    BPSApplicationsPage bpsapplicationsPage;
    ApplicationPortalPage applicationportalPage;
    MyClientsPage myClientsPage;
    WebDriver driver;
    Properties prop;
    ConfigReader configReader;
    DriverManager driverManager;
    BPSdashboardPage bpsdashboardPage;

    public BPSApplicationSteps(DriverManager driverManager){
        try {
//            driver = driverManager.getDriver();
            this.driverManager=driverManager;
            driver=driverManager.getDriverInstance();
            loginPage = new LoginPage(driver);
            bpsdashboardPage = new BPSdashboardPage(driver);
            applicationportalPage = new ApplicationPortalPage(driver);
            bpsapplicationsPage = new BPSApplicationsPage(driver);
            myClientsPage = new MyClientsPage(driver);
            configReader = new ConfigReader();
            prop = configReader.init_prop();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    // region BPS Code

    @And("Agent is on BPS Applications Page")
    public void BPSApplicationsPage() {
        String title = driver.getTitle();
        System.out.println("title of BPS Applications" + title);
    }


    @Then("Agent Navigates to Submitted Applications Tab")
    public void AgentClickOnSubmittedApplicationsTab() throws InterruptedException {
        bpsapplicationsPage.AgentClickOnSubmittedApplicationsTab();
        Thread.sleep(2000);
    }

    @And("Agent Navigates to Outstanding Applications Tab")
    public void AgentClickOnOutstandingApplicationsTab() throws InterruptedException {
        bpsapplicationsPage.AgentClickOnOutstandingApplicationsTab();
        Thread.sleep(3000);
    }

    @And("Agent Navigates to Draft Applications Tab")
    public void AgentClickOnDraftApplicationsTab() throws InterruptedException {
        bpsapplicationsPage.AgentClickOnDraftApplicationsTab();
        Thread.sleep(2000);
    }

    @And("Agent Navigates to Paid Clients Tab")
    public void AgentClickOnPaidClientsTab() throws InterruptedException {
        bpsapplicationsPage.AgentClickOnPaidClientsTab();
        Thread.sleep(2000);
    }

    @Then("Check if Print Preview Button is Visible")
    public void AgentCheckPrintPreviewVisibility() throws InterruptedException {
        bpsapplicationsPage.VisibilityOfPrintPreviewButton();
    }

    @Then("Agent Clicks on Print Preview Button")
    public void AgentClicksOnPrintPreviewButton() throws InterruptedException {
        bpsapplicationsPage.AgentClickOnPrintPreviewButton();
    }

    @And("Check if Download Button is Visible")
    public void AgentCheckDownloadButtonVisibility() throws InterruptedException {
        Assert.assertTrue(bpsapplicationsPage.VisibilityOfDownloadButton());
    }

    @Then("Agent Clicks on Download Button")
    public void AgentClicksOnDownloadButton() throws InterruptedException {
        bpsapplicationsPage.AgentClickOnDownloadButton();
        Thread.sleep(5000);
    }

    @Then("Agent Clicks on Client Radio Button")
    public void AgentClicksOnClientRadioButton() throws InterruptedException {
        bpsapplicationsPage.AgentClickOnBPSApplicationsClientRadioButton();
    }

    @Then("Agent Clicks on View Button")
    public void AgentClicksOnViewButton() throws InterruptedException {
        bpsapplicationsPage.AgentClickOnBPSApplicationsViewButton();
    }

    @And("Check if No Clients are Displayed")
    public void AgentCheckClientListVisibility() throws InterruptedException {
        bpsapplicationsPage.CheckIfNoCLientsDisplayed();
    }

    @Then("Agent View Dashboard for Expanded Farmer")
    public void AgentClickOnExpandedFarmer() throws InterruptedException, IOException {
        myClientsPage.AgentClickOnViewDashboard();
        Thread.sleep(5000);
    }

    // endregion

    // region BISS Code

    @And("Staff Click On the {string} table {string} link number {int}")
    public void StaffClickOnViewLink(String Table, String Link, int LinkNo) throws InterruptedException {
        bpsdashboardPage.StaffClickOnViewButton(Table, Link, LinkNo);
        Thread.sleep(5000);
    }

    @And("Staff Click on the {string} Action Button")
    public void StaffClickOnActionButton(String Action) throws InterruptedException {
        bpsdashboardPage.StaffClickOnParcelSearchAction(Action);
        Thread.sleep(5000);
    }

    @Then("Staff Hover over the {string} info icon")
    public void StaffHoverOnInfoIcon(String InfoName) throws InterruptedException {
        bpsdashboardPage.StaffMoveCursorToInfoIcon(InfoName);
        Thread.sleep(5000);
    }

    @Then("Staff Click on the {string} CheckBox")
    public void StaffClickOnCheckBox(String CheckBox) throws InterruptedException {
        bpsdashboardPage.StaffTickCheckBox(CheckBox);
        Thread.sleep(4000);
    }


    @Then("Staff Check if Force Majeure Selected and Click")
    public void StaffCheckForceMajeureAndClick() {
        bpsapplicationsPage.CheckIfForceMajeureCheckBoxSelectedAndCheck();
    }

    @And("Agent Click On {string} tab in the My Clients Page")
    public void AgentSwitchTabsinMyClientsPage(String TabName) {
        bpsapplicationsPage.AgentSwitchTabsInMyClientsPage(TabName);
    }

    @And("Agent Check if {string} Dropdown is Present")
    public void AgentCheckIfDropdownPresent(String DropdownName) {
        Assert.assertFalse(bpsapplicationsPage.AgentCheckDropdownPresence(DropdownName));
    }

    @Then("Agent Check if {string} tab is present")
    public void AgentCheckIfLandDetailsOrPaymentsTabPresent(String TabName) {
        Assert.assertFalse(bpsapplicationsPage.AgentCheckIfTabsPresentInAorPPage(TabName));
    }

    @And("Agent Click on the {string} Tab")
    public void AgentClickOnTheTabInAorPScreen(String TabName) {
        bpsapplicationsPage.AgentSwitchBetweenLandDetailsAndPaymentsTab(TabName);
    }

    @Then("Agent Check if {string} message displayed")
    public void AgentCheckIfMessageDisplayed(String Message) {
        Assert.assertEquals(bpsapplicationsPage.AgentCheckNoRecordsMessage(), Message);
    }


    // endregion


    // region Payments
    @And("Staff Check if {string} header exists in Payment summary Table")
    public void StaffCheckPaymentHeaders(String Header) throws InterruptedException {
        bpsdashboardPage.StaffCheckPaymentSummaryHeadings(Header);
        Thread.sleep(2000);
    }

    @Then("Staff Check for {string} header below respective heading")
    public void StaffCheckAmountHeadingForHeaders(String AmountHeader) throws InterruptedException {
        bpsdashboardPage.StaffCheckHeaderAmountEuroSymbols(AmountHeader);
        Thread.sleep(1000);
    }


    @And("Staff Check if {int} Reduction Type header exists in Payment summary Table")
    public void StaffCheckReductionTypeHeader(int Order) throws InterruptedException {
        bpsdashboardPage.StaffCheckPaymentSummaryInternalRowHeaders(Order);
        Thread.sleep(1000);
    }



    @And("Staff Check if {string} header type 1 exists in Payments Page")
    public void StaffCheckReductionTypeHeaders(String Header) throws InterruptedException {
        bpsdashboardPage.StaffCheckReductionTypeHeadings(Header);
        Thread.sleep(2000);
    }

    @And("Staff Check if {string} header type 2 exists in Payments Page")
    public void StaffCheckReductionTypeHeaders2(String Header) throws InterruptedException {
        bpsdashboardPage.StaffCheckReductionTypeHeadings2(Header);
        Thread.sleep(2000);
    }

    @And("Staff Check if {string} header type 3 exists in Payments Page")
    public void StaffCheckReductionTypeHeaders3(String Header) throws InterruptedException {
        bpsdashboardPage.StaffCheckReductionTypeHeadings3(Header);
        Thread.sleep(2000);
    }

    @And("Staff Check if {string} header type 4 exists in Payments Page")
    public void StaffCheckReductionTypeHeaders4(String Header) throws InterruptedException {
        bpsdashboardPage.StaffCheckReductionTypeHeadings4(Header);
        Thread.sleep(2000);
    }


    //StaffCheckTotalDPSPayment
    @And("Staff Check Total DPS Payment for Herd")
    public void StaffCheckDPSPaymentValue() {
        Assert.assertEquals(bpsdashboardPage.StaffCheckTotalDPSPayment(),bpsdashboardPage.StaffCalculateTotalNetPayments());
    }

    // endregion

    // region AMS
    @Then("Staff Switch to Partner Herd {string} Tab")
    public void StaffSwitchToPartnerHerdTab(String Herd) {
        bpsdashboardPage.StaffSwitchBetweenPartnerHerdTabs(Herd);
    }

    @And("Staff Check if {string} Header Tab present in AMS screen")
    public void StaffCheckHeadersForAMSPageTable(String Header) {
        bpsdashboardPage.StaffCheckHeadersInAMSTab(Header);
    }

    @Then("Staff Check if AMS SchemeYear Dropdown Value populated")
    public void StaffCheckIfSchemeYearFieldPopulated() {
        if(bpsdashboardPage.StaffGetAMSSchemeYearDropdwownValue()==null){
            System.out.println("AMS SchemeYear not populated");
        }
        else {
            System.out.println("AMS SchemeYear populated as : "+ bpsdashboardPage.StaffGetAMSSchemeYearDropdwownValue());
        }
    }

    @And("Staff Hover over {string} Info Widget to Check Tooltip")
    public void StaffHoverOverTooltip(String Status) {
        applicationportalPage.AgentHoverOverInformationWidget(Status);
    }

    @And("Staff Check that Pagination Functionality working fine on AMS page")
    public void StaffCheckPaginationSectionWorking() {
        bpsdashboardPage.StaffCheckAndNavigateAMSPagination();
    }

    @Then("Staff Check {string} Client Details in AMS page")
    public void StaffCheckClientDetails(String ClientDetails) {
        bpsdashboardPage.StaffCheckClientDetails(ClientDetails);
    }

    // endregion

    // region SIM
    @When("Agent scroll to the {string} no SIM parcel")
    public void AgentScrollToNoSIMParcel(String Parcel) throws InterruptedException {
        applicationportalPage.AgentScrollToNoHerdParcel(Parcel);
        Thread.sleep(5000);
    }

    @When("Staff Check If SIM Panel Selected")
    public void StaffCheckSIMPanelSelected() throws InterruptedException {
        Thread.sleep(3000);
        Assert.assertTrue(applicationportalPage.SelectedSIMPanelVisibility());
        System.out.println("SIM Panel Selected");
    }

    @Then("Staff Click On {string} Parcel Row")
    public void StaffClickOnParcelRow(String Row) {
        applicationportalPage.ClickOnParcelToOpenDrawer(Row);
    }

    @Then("Staff Click On {string} SIM Parcel")
    public void StaffOpenNoSIMParcelDrawer(String Parcel) throws InterruptedException {
        applicationportalPage.StaffOpenSideDrawerForSIMCheck(Parcel);
        Thread.sleep(5000);
    }



    @And("Staff Click On SIM Indicator CheckBox")
    public void StaffClickOnSIMIndicatorCheckBox() throws InterruptedException {
        applicationportalPage.StaffClickOnSIMIndicatorCheckBox();
    }

    @Then("Staff Enter Value {string} in {string} Side Drawer Filed")
    public void StaffEditSideDrawerField(String Value, String Field) throws InterruptedException {
        applicationportalPage.AgentEditValueInSideDrawerFields(Value, Field);
        Thread.sleep(3000);
    }

    @Then("Staff Enter Higher Value in the {string} Side Drawer Field")
    public  void StaffEnterHigherValueInSideDrawerField(String Field) throws InterruptedException {
        applicationportalPage.AgentChangeSIMFoundArea(Field);
        Thread.sleep(3000);
    }

    @And("Staff Check Overclaim Error Message")
    public void StaffCheckOverClaimMessage() throws InterruptedException {
        applicationportalPage.StaffCheckOverClaimWarning();
        Assert.assertEquals(applicationportalPage.StaffCheckOverClaimWarning(),"value must be equal or less than EH");
        Thread.sleep(2000);
    }

    @And("Staff Check Missing Note Error Message")
    public void StaffCheckMissingNoteMessage() throws InterruptedException {
        applicationportalPage.StaffCheckMissingNoteWarning();
        Assert.assertEquals(applicationportalPage.StaffCheckMissingNoteWarning(),"Missing SIM Application comment/note");
        Thread.sleep(2000);
    }

    @Then("Staff Add Note as {string} while Submitting SIM Application")
    public void StaffAddNoteForSIMApplication(String Value) {
        applicationportalPage.StaffAddNoteToSIMApplication(Value);
    }

    //endregion




}
