# ====================================================================================================================================
# TC_11_STAFF.feature
# ====================================================================================================================================
@maps @regression @staff @parcels:10
Feature: TC_11_STAFF - Parcel Search Format Tolerance

  # Migrated from legacy "Regression Pack for Map Printing Case Sensitive"
  # (BISSAGL-8080 AT-TC-01 to 05).
  #
  # BUSINESS FLOW
  #   Parcel numbers are entered by hand and arrive in inconsistent formats. The search must
  #   normalise case and tolerate stray characters, resolving to the same parcel either way.
  #
  # WHAT THIS VALIDATES
  #   Intended: lower case, upper case, trailing special characters, invalid values and a
  #   blank value all behave correctly on the parcel search.
  #
  # LEGACY DEFECT - THIS PACK NO LONGER TESTS WHAT IT IS NAMED FOR
  #   The commented-out literals show the original intent:
  #     AT-TC-01 "o1170800024"   lower case
  #     AT-TC-02 "O1170800024"   upper case
  #     AT-TC-03 "O1060300013*"  trailing special character
  #     AT-TC-04 "4354543648894" invalid
  #     AT-TC-05 " "             blank
  #   When the pack was moved to DB-driven data, those literals were replaced with parcel
  #   rows 11-15 - which are all valid, correctly-cased LPIS parcels. Sections 1-3 now search
  #   three valid parcels three times, and Section 5 searches a fourth. The case-insensitivity
  #   and blank-input coverage was lost silently in the refactor.
  #   Sections 1-3 and 5 below preserve the current (weakened) behaviour rather than invent
  #   new coverage. Section 4 keeps the invalid literals that ARE still live in legacy.
  #   ACTION: restore intent by deriving case variants from one DB parcel at runtime -
  #   e.g. "the next LPIS parcel in lower case" - which needs a step def, not new test data.


  Background:
    Given the staff user is logged in to the BISS internal portal as "agr11612"
    And the staff user is on the Map Printing screen


  @e2e @validation
  Scenario: Staff searches parcels in varying formats and reaches the generation settings

    # SECTION 1 - AT-TC-01 (BISSAGL-14833) - intended: lower case
    When the staff user searches Map Printing with no parcel number
    When the staff user searches Map Printing for the next LPIS parcel for scheme year "2023"
    When the staff user requests a map with the following settings
      | parcels | single              |
      | mapType | Full Color Ortho A4 |
      | legend  | yes                 |
    Then the map generation request should be accepted
    And the generated map should reach its final status


    # SECTION 2 - AT-TC-02 (BISSAGL-14832) - intended: upper case
    When the staff user searches Map Printing with no parcel number
    When the staff user searches Map Printing for the next LPIS parcel for scheme year "2023"
    When the staff user requests a map with the following settings
      | parcels | single              |
      | mapType | Full Color Ortho A4 |
      | legend  | yes                 |
    Then the map generation request should be accepted
    And the generated map should reach its final status


    # SECTION 3 - AT-TC-03 (BISSAGL-14831) - intended: trailing special character
    When the staff user searches Map Printing with no parcel number
    When the staff user searches Map Printing for the next LPIS parcel for scheme year "2023"
    When the staff user requests a map with the following settings
      | parcels | single              |
      | mapType | Full Color Ortho A4 |
      | legend  | yes                 |
    Then the map generation request should be accepted
    And the generated map should reach its final status


    # SECTION 4 - AT-TC-04 (BISSAGL-14824)
    # Validates: three malformed parcel values in sequence. Legacy asserts the settings
    # section is still available after each - i.e. the screen does not break on bad input.
    When the staff user searches Map Printing with no parcel number
    When the staff user searches Map Printing for the next LPIS parcel for scheme year "2023"
    When the staff user requests a map with the following settings
      | parcels | single              |
      | mapType | Full Color Ortho A4 |
      | legend  | yes                 |
    Then the map generation request should be accepted
    And the generated map should reach its final status


    When the staff user searches Map Printing with no parcel number
    When the staff user searches Map Printing for each of the following invalid parcels for scheme year "2023"
      | hdgfhggdfhjkdhj |
      | 345dhf564gh48   |


    # SECTION 5 - AT-TC-05 (BISSAGL-14823) - intended: blank value
    When the staff user searches Map Printing for the next LPIS parcel for scheme year "2023"
