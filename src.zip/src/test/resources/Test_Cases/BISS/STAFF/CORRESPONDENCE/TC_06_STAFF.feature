# ============================ TC_06_STAFF.feature ============================
@letters
Feature: TC_06_STAFF - BISS Letters Coordination Amendments E2E Regression Pack

  # Legacy: "Regression Suite for BISS Letters" (BISSAGL-7301 AT-TC-01, 02)
  # Legacy Background: Get 5 Herds with Admin Check Not Started from Database
  #                     -> @staffdata + herds:5:admincheck
  # Legacy searched by "Reference Number from row 2" but loaded Admin-Check-Not-Started herds -
  # a mismatch in the legacy itself. Reference numbers are loaded explicitly here instead.
  #
  # NOTE: legacy AT-TC-01 and AT-TC-02 are BYTE-IDENTICAL - same herd, same steps, same
  # assertions, differing only in @tmslink (14914 vs 14913). Merged into one section rather
  # than duplicated. Confirm with the test owner whether AT-TC-02 was meant to differ.


  Background:
    Given user on staff login page
    When Staff logs in with the Username "agr4442"
    And Staff opens the "Basic Income Support for Sustainability" application

  @regression @staff @letters @coordination @e2e
  Scenario: AT-STAFF-LETTERS-E2E-01 - Staff moves all parcels to a new herd via Coordination Amendments

    # SECTION 1 : Move all to new herd - AT-TC-01 (BISSAGL-14914) / AT-TC-02 (BISSAGL-14913)
    When Staff searches on the Home screen using database reference 2 with the following details
      | field      | referenceNumber |
      | schemeYear | 2023            |
    And Staff clicks the "View" link number 1 in the "application-search-table" table
    Then Staff clicks on "Coordination Amendments" Link in Navbar
    And Staff enters value "U1222127" in the "newHerdNo" field
    And Staff clicks the "Start" button
    And Staff clicks the "Move all to new herd" button
    Then Staff clicks the "Save" button