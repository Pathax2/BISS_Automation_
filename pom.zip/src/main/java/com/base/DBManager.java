//package com.base;
//
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.sql.Connection;
//import java.sql.Statement;
//
//public class DBManager {
//    // for testing only should be removed later
//    public static void main(String[] args) throws SQLException {
//        String q = "Select * from Products";
//        String[][] result = FetchDataFromDB(q);
//        System.out.println(result);
//    }
//
//    public static String[][] FetchDataFromDB(String query)  throws SQLException {
//        String url =  "Connection String";
//        DBConnectionManager DBInstance = DBConnectionManager.getInstance(url);
//        Connection conn = DBInstance.getConnection();
//        Statement stat = conn.createStatement();
//        ResultSet rs = stat.executeQuery(query);
//
//        // To get total number of Column returned
//        int columncount = rs.getMetaData().getColumnCount();
//
//        // To get total number fo rows returned
//        rs.last(); //move the rs to the last row
//        int rowcount = rs.getRow(); //this will give the index of last row
//        rs.beforeFirst(); // this will bring it back to first record
//
//        // Create an Object
//        String[][] result = new String[rowcount][columncount];
//        int i=0;
//        while (rs.next()) {
//            for (int j=0; j<columncount; j++) {
//                result[i][j] = rs.getString(j+1);
//            }
//            i=i+1;
//        }
//        return result;
//    }
//}
