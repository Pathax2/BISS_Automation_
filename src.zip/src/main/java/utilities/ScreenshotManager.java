// ===================================================================================================================================
// File          : ScreenshotManager.java
// Package       : utilities
// Description   : Central visual evidence manager for the BISS automation framework (Playwright edition).
//
//                 Owns ALL screenshot capture and Word document image embedding.
//                   CAPTURE  - viewport, full-page (native in Playwright), element
//                   EMBED    - captureAndEmbed()    on-demand step screenshot into Word doc
//                              captureForFailure()  failure screenshot into Word doc
//                   DIVIDER  - appendScenarioDivider()  green/red scenario header in Word doc (unchanged)
//                   CLEANUP  - auto-delete screenshots older than retention period (unchanged)
//                   BYTES    - captureBytes() for Cucumber scenario.attach() (shows inline in Cucumber HTML report)
//
//                 Selenium -> Playwright changes:
//                   WebDriver parameter           -> Page
//                   TakesScreenshot.getScreenshotAs -> page.screenshot()
//                   window resize for full page   -> ScreenshotOptions.setFullPage(true)
//                   manual crop for element       -> locator.screenshot()
//
// Author        : Aniket Pathare | aniket.pathare@goverment.ie
// Date Created  : 10-03-2026
// Updated       : 26-03-2026 - Phase 1 Word report embedding moved here from CommonFunctions
// Updated       : 15-09-2026 - Playwright Page / Locator
// ===================================================================================================================================

package utilities;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.Document;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Logger;

public class ScreenshotManager
{
    private static final Logger log = Logger.getLogger(ScreenshotManager.class.getName());

    private static final String iScreenshotsDirectory = ConfigManager.getOrDefault("report.screenshots.path", "Test_Report/screenshots");
    private static final int    iRetentionDays        = ConfigManager.getInt("screenshot.retention.days", 30);

    private static final DateTimeFormatter iTimestampFormatter = DateTimeFormatter.ofPattern("dd_MM_yyyy_HH_mm_ss_SSS");
    private static final DateTimeFormatter iDisplayFormatter   = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss.SSS");

    static
    {
        cleanupOldScreenshots();
    }

    private ScreenshotManager() {}


    // ===============================================================================================================================
    // SECTION 1 : CAPTURE
    // ===============================================================================================================================

    public static String captureViewport(Page pPage, String pStepName)
    {
        try
        {
            if (pPage == null)
            {
                throw new RuntimeException("Page is null. Cannot capture viewport screenshot.");
            }

            ensureDirectoryExists();
            String iFilePath = buildFilePath(pStepName, "viewport");
            pPage.screenshot(new Page.ScreenshotOptions().setPath(Paths.get(iFilePath)));

            log.info("[ScreenshotManager] Viewport screenshot : " + iFilePath);
            return iFilePath;
        }
        catch (Exception iException)
        {
            throw new RuntimeException("[ScreenshotManager] Viewport capture failed : " + iException.getMessage(), iException);
        }
    }

    public static String captureFullPage(Page pPage, String pStepName)
    {
        try
        {
            if (pPage == null)
            {
                throw new RuntimeException("Page is null. Cannot capture full-page screenshot.");
            }

            ensureDirectoryExists();
            String iFilePath = buildFilePath(pStepName, "fullpage");
            pPage.screenshot(new Page.ScreenshotOptions().setPath(Paths.get(iFilePath)).setFullPage(true));

            log.info("[ScreenshotManager] Full-page screenshot : " + iFilePath);
            return iFilePath;
        }
        catch (Exception iException)
        {
            log.warning("[ScreenshotManager] Full-page capture failed, falling back to viewport : " + iException.getMessage());
            return captureViewport(pPage, pStepName);
        }
    }

    public static String captureElement(Page pPage, Locator pElement, String pStepName)
    {
        try
        {
            if (pPage == null || pElement == null)
            {
                throw new RuntimeException("Page or element is null. Cannot capture element screenshot.");
            }

            ensureDirectoryExists();
            String iFilePath = buildFilePath(pStepName, "element");
            pElement.screenshot(new Locator.ScreenshotOptions().setPath(Paths.get(iFilePath)));

            log.info("[ScreenshotManager] Element screenshot : " + iFilePath);
            return iFilePath;
        }
        catch (Exception iException)
        {
            log.warning("[ScreenshotManager] Element capture failed, falling back to viewport : " + iException.getMessage());
            return captureViewport(pPage, pStepName);
        }
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : captureBytes
    // Description   : Returns a PNG screenshot as bytes (no file). Used by Hooks to attach evidence to the Cucumber
    //                 scenario so it appears inside the Cucumber HTML / JSON report. Returns null on failure.
    // Parameters    : pPage (Page) - active page on current thread
    // Author        : Aniket Pathare | aniket.pathare@goverment.ie
    // Date Created  : 15-09-2026
    // ***************************************************************************************************************************************************************************************
    public static byte[] captureBytes(Page pPage)
    {
        try
        {
            return pPage == null ? null : pPage.screenshot();
        }
        catch (Exception iException)
        {
            log.warning("[ScreenshotManager] captureBytes failed : " + iException.getMessage());
            return null;
        }
    }


    // ===============================================================================================================================
    // SECTION 2 : EMBED
    // ===============================================================================================================================

    public static void captureAndEmbed(Page pPage, XWPFDocument pDocument, String pStepLabel)
    {
        try
        {
            if (pPage == null)
            {
                log.warning("[ScreenshotManager] captureAndEmbed - page is null, skipping. Label: " + pStepLabel);
                return;
            }

            if (pDocument == null)
            {
                log.warning("[ScreenshotManager] captureAndEmbed - document is null, skipping. Label: " + pStepLabel);
                return;
            }

            String iSafeLabel   = sanitize(pStepLabel == null || pStepLabel.isBlank() ? "Step" : pStepLabel);
            String iTimestamp   = LocalDateTime.now().format(iTimestampFormatter);
            String iDisplayTime = LocalDateTime.now().format(iDisplayFormatter);
            String iPngFileName = iSafeLabel + "_step_" + iTimestamp + ".png";
            String iPngPath     = buildAbsolutePath(iPngFileName);

            ensureDirectoryExists();
            pPage.screenshot(new Page.ScreenshotOptions().setPath(Paths.get(iPngPath)));
            log.info("[ScreenshotManager] Step screenshot saved : " + iPngPath);

            XWPFParagraph iCaptionParagraph = pDocument.createParagraph();
            XWPFRun       iCaptionRun       = iCaptionParagraph.createRun();
            iCaptionRun.setBold(true);
            iCaptionRun.setFontSize(9);
            iCaptionRun.setFontFamily("Calibri");
            iCaptionRun.setColor("1F4E79");
            iCaptionRun.setText("  STEP CAPTURE: " + pStepLabel + "   |   " + iDisplayTime);
            iCaptionRun.addBreak();

            embedImage(pDocument, iPngPath, iPngFileName);
            pDocument.createParagraph().createRun().addBreak();

            log.info("[ScreenshotManager] Step screenshot embedded. Label: " + pStepLabel);
        }
        catch (Exception iException)
        {
            log.warning("[ScreenshotManager] captureAndEmbed failed for [" + pStepLabel + "] : " + iException.getMessage());
        }
    }

    public static String captureForFailure(Page pPage, XWPFDocument pDocument, String pTestCaseID)
    {
        String iPngPath = "";

        try
        {
            if (pPage == null)
            {
                log.warning("[ScreenshotManager] captureForFailure - page is null, skipping.");
                return iPngPath;
            }

            ensureDirectoryExists();

            String iTimestamp   = LocalDateTime.now().format(iTimestampFormatter);
            String iDisplayTime = LocalDateTime.now().format(iDisplayFormatter);
            String iPngFileName = sanitize(pTestCaseID) + "_FAIL_" + iTimestamp + ".png";
            iPngPath            = buildAbsolutePath(iPngFileName);

            // Full page on failure - shows content below the fold that the viewport would miss
            pPage.screenshot(new Page.ScreenshotOptions().setPath(Paths.get(iPngPath)).setFullPage(true));
            log.info("[ScreenshotManager] Failure screenshot saved : " + iPngPath);

            if (pDocument != null)
            {
                XWPFParagraph iCaptionParagraph = pDocument.createParagraph();
                XWPFRun       iCaptionRun       = iCaptionParagraph.createRun();
                iCaptionRun.setBold(true);
                iCaptionRun.setFontSize(9);
                iCaptionRun.setFontFamily("Calibri");
                iCaptionRun.setColor("C00000");
                iCaptionRun.setText("  FAILURE: " + pTestCaseID + "   |   " + iDisplayTime);
                iCaptionRun.addBreak();

                embedImage(pDocument, iPngPath, iPngFileName);
                pDocument.createParagraph().createRun().addBreak();

                log.info("[ScreenshotManager] Failure screenshot embedded in Word report.");
            }
        }
        catch (Exception iException)
        {
            log.severe("[ScreenshotManager] captureForFailure failed : " + iException.getMessage());
        }

        return iPngPath;
    }


    // ===============================================================================================================================
    // SECTION 3 : WORD DOC STRUCTURE - scenario divider (unchanged)
    // ===============================================================================================================================

    public static void appendScenarioDivider(XWPFDocument pDocument, String pScenarioName,
                                             boolean pPassed, long pDurationMs)
    {
        try
        {
            if (pDocument == null) { return; }

            String iStatus      = pPassed ? "PASSED" : "FAILED";
            String iFillColor   = pPassed ? "70AD47" : "FF0000";
            String iTextColor   = "FFFFFF";
            long   iSecs        = (pDurationMs / 1000) % 60;
            long   iMins        = pDurationMs / (1000 * 60);
            String iDuration    = iMins > 0 ? iMins + "m " + iSecs + "s" : iSecs + "s";
            String iDisplayTime = LocalDateTime.now().format(iDisplayFormatter);

            pDocument.createParagraph().createRun().addBreak();

            XWPFParagraph iDivParagraph = pDocument.createParagraph();
            iDivParagraph.setAlignment(ParagraphAlignment.LEFT);

            org.openxmlformats.schemas.wordprocessingml.x2006.main.CTPPr iPPr = iDivParagraph.getCTP().addNewPPr();
            org.openxmlformats.schemas.wordprocessingml.x2006.main.CTShd iShd = iPPr.addNewShd();
            iShd.setVal(org.openxmlformats.schemas.wordprocessingml.x2006.main.STShd.CLEAR);
            iShd.setColor("auto");
            iShd.setFill(iFillColor);

            XWPFRun iDivRun = iDivParagraph.createRun();
            iDivRun.setBold(true);
            iDivRun.setFontSize(11);
            iDivRun.setFontFamily("Calibri");
            iDivRun.setColor(iTextColor);
            iDivRun.setText("  " + iStatus
                    + "  |  " + pScenarioName
                    + "  |  Duration: " + iDuration
                    + "  |  " + iDisplayTime);

            pDocument.createParagraph().createRun().addBreak();

            log.info("[ScreenshotManager] Scenario divider added : " + pScenarioName + " [" + iStatus + "]");
        }
        catch (Exception iException)
        {
            log.warning("[ScreenshotManager] appendScenarioDivider failed : " + iException.getMessage());
        }
    }


    // ===============================================================================================================================
    // SECTION 4 : CLEANUP (unchanged)
    // ===============================================================================================================================

    public static void cleanupOldScreenshots()
    {
        if (iRetentionDays <= 0)
        {
            log.info("[ScreenshotManager] Screenshot cleanup disabled (retention.days=0).");
            return;
        }

        try
        {
            File iDir = new File(iScreenshotsDirectory);
            if (!iDir.exists() || !iDir.isDirectory()) { return; }

            LocalDate iCutoff  = LocalDate.now().minusDays(iRetentionDays);
            File[]    iFiles   = iDir.listFiles((dir, name) -> name.endsWith(".png"));
            int       iDeleted = 0;

            if (iFiles == null) { return; }

            for (File iFile : iFiles)
            {
                LocalDate iFileDate = new java.util.Date(iFile.lastModified())
                        .toInstant()
                        .atZone(java.time.ZoneId.systemDefault())
                        .toLocalDate();

                if (iFileDate.isBefore(iCutoff) && iFile.delete()) { iDeleted++; }
            }

            if (iDeleted > 0)
            {
                log.info("[ScreenshotManager] Cleaned up " + iDeleted + " screenshot(s) older than " + iRetentionDays + " days.");
            }
        }
        catch (Exception iException)
        {
            log.warning("[ScreenshotManager] Cleanup failed : " + iException.getMessage());
        }
    }


    // ===============================================================================================================================
    // SECTION 5 : PRIVATE HELPERS (unchanged)
    // ===============================================================================================================================

    private static void embedImage(XWPFDocument pDocument, String pPngPath, String pPngFileName) throws Exception
    {
        XWPFParagraph iImageParagraph = pDocument.createParagraph();
        XWPFRun       iImageRun       = iImageParagraph.createRun();

        try (InputStream iInputStream = new FileInputStream(pPngPath))
        {
            iImageRun.addPicture(
                    iInputStream,
                    Document.PICTURE_TYPE_PNG,
                    pPngFileName,
                    Units.toEMU(450),
                    Units.toEMU(300)
            );
        }
    }

    private static String buildFilePath(String pStepName, String pType)
    {
        String iSafeName  = sanitize(pStepName);
        String iTimestamp = LocalDateTime.now().format(iTimestampFormatter);
        return iScreenshotsDirectory + File.separator + iSafeName + "_" + pType + "_" + iTimestamp + ".png";
    }

    private static String buildAbsolutePath(String pFileName)
    {
        return iScreenshotsDirectory + File.separator + pFileName;
    }

    private static String sanitize(String pInput)
    {
        if (pInput == null || pInput.trim().isEmpty()) { return "Unnamed"; }
        return pInput.trim().replaceAll("[\\\\/:*?\"<>|\\s]+", "_");
    }

    private static void ensureDirectoryExists()
    {
        File iDir = new File(iScreenshotsDirectory);
        if (!iDir.exists()) { iDir.mkdirs(); }
    }
}
