// ===================================================================================================================================
// File          : TC_13_ENTS.java
// Package       : stepdefinitions.ENTS
// Description   : Step definitions for TC_13_ENTS - NRCISYF End-to-End Regression Pack.
//                 Also used by TC_15_ENTS, TC_16_ENTS and TC_21_ENTS to TC_25_ENTS (NRCISYF submissions + appeal).
//
//                 Covers the full NRCISYF business flow:
//                   - Herd search and landing page validation
//                   - Category selection (A, B, C, A+C, B+C, invalid A+B)
//                   - Individual / Joint Herdowner / Company entity setup
//                   - Qualification details (single + per-member loop)
//                   - Document upload (DataTable loop)
//                   - Submission with declaration
//                   - Save and Exit
//                   - Custom institution / qualification not in list
//                   - Upload dialog close / file format validation
//                   - Post-submission document verification
//
//                 Runtime herd: Hooks @Before("@tc13") picks a herd with no NR/CISYF application and its agent
//                 (Hooks.CISYF_HERD / Hooks.CISYF_USERNAME). The Background login uses that agent.
//
//                 Reused steps (defined elsewhere, bound automatically by Cucumber):
//                   "the agent user is on the login page"                               -> TC_03.java
//                   "the agent logs into the application with valid credentials and OTP" -> TC_03.java
//                   "the agent opens the {string} application"                          -> TC_03.java
//                   "the agent should land on the BISS Home page"                       -> TC_03.java
//                   "the agent navigates to the {string} and {string} Left Menu Link"   -> TC_03.java
//                   "the agent navigates through the farmer side navigation tabs"      -> TC_03.java
//                   "the agent switches to the {string} tab on the My Client(s) page"   -> TC_06.java
//                   "Validate if Appeal can be made sucessfully"                        -> ENTS/TC_01_ENTS.java
//
//                 Playwright edition (22-09-2026):
//                   - Same step texts, same ObjectRepository keys, same flow, same retry limits (15 / 95 / 10).
//                   - findElement / JavascriptExecutor / FluentWait / WebDriverWait replaced by Playwright locators.
//                   - The two private login / logout copies are gone: EntsSession.logout and EntsSupport.loginSkippingExpired.
//                     An expired account is added to Hooks.EXPIRED_AGENTS and the next candidate is tried. The Selenium
//                     copy called Hooks.markAgentExpired(), which also replaced Hooks.RUNTIME_HERD with a non-CISYF herd.
//                   - After a re-login the recovery loops all go through EntsSupport.openMyClientsTab, which opens BISS
//                     first when needed. In Selenium only the search loop opened BISS; the other two clicked My Clients
//                     on the portal home page.
//                   - Herd search waits for the row that holds THIS herd before clicking View (lesson from the Transfer
//                     Out list: straight after Search the table can still show unfiltered rows). Thread.sleep removed.
//                   - "If present" clicks (OK button, CISYF prompt buttons, Correspondence link) probe for the button
//                     for PROBE_SECONDS instead of waiting the full action timeout inside a try/catch.
//                   - clearAndEnterDate keeps the Selenium sequence: remove disabled, focus, Ctrl+A, Delete, clear with
//                     events, type, Tab, read back, JavaScript fallback.
//
//                 Test data (02-10-2026, utilities.NrcisyfTestData):
//                   - The next herd for Apply / Edit comes from the vault pool ENTS_YOUNG_FARMER (TC_00_DATA) or Simon's
//                     "ENTS Young Farmer herds" query: herd + agent in ONE row, no BISS_INET login query per candidate.
//                     Only when that has nothing left, the Selenium BISS_DATA + BISS_INET lookup runs, unchanged.
//                   - A herd that already shows "View Application" when opened is marked BAD in the vault; a herd whose
//                     application was submitted or saved is marked USED; the agent's herd that is not in the NR/CISYF
//                     list is marked BAD. Young Farmer herds are never reused (one NR/CISYF application per herd).
//                   - "the agent views the submitted NRCISYF application": the herd submitted earlier in THIS run is
//                     opened first (TC_13 Section 23 follows the submissions); the Selenium query for any submitted
//                     herd runs only when nothing was submitted in this run.
//
// Author        : Aniket Pathare | aniket.pathare@government.ie
// Date Created  : 31-03-2026 | Updated: 02-10-2026 (Young Farmer data + vault)
// ===================================================================================================================================

package stepdefinitions.ENTS;

import com.microsoft.playwright.Locator;
import commonFunctions.UiHelpers;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;
import org.junit.jupiter.api.Assertions;
import stepdefinitions.Hooks;
import utilities.NrcisyfTestData;
import utilities.ObjReader;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import static commonFunctions.CommonFunctions.iAction;
import static stepdefinitions.ENTS.EntsSession.PROBE_SECONDS;
import static stepdefinitions.ENTS.EntsSession.countOf;
import static stepdefinitions.ENTS.EntsSession.isVisible;
import static stepdefinitions.ENTS.EntsSession.pause;
import static stepdefinitions.ENTS.EntsSession.xp;

public class TC_13_ENTS
{
    private static final Logger log = Logger.getLogger(TC_13_ENTS.class.getName());

    private static final String NRCISYF_TAB     = "NR/CISYF";
    private static final String CHECKED_CLASS   = "mat-mdc-checkbox-checked";
    private static final String TEST_DATA_DIR   = System.getProperty("user.dir")
            + java.io.File.separator + "src" + java.io.File.separator + "test"
            + java.io.File.separator + "resources" + java.io.File.separator + "Test_Data" + java.io.File.separator;


    // ===================================================================================================================================
    //  SECTION 1 : HERD SEARCH AND LANDING PAGE
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent searches for the NRCISYF herd and opens the application
    // Description   : Types Hooks.CISYF_HERD into the NR/CISYF search box, waits for the row of that herd and clicks View.
    //                 When the herd does not show for this agent: the herd is marked BAD in the vault, the next Young
    //                 Farmer herd is taken (a herd of the SAME agent when there is one - then no re-login), the agent
    //                 logs out and in when needed, My Clients -> NR/CISYF, and retry, up to 15 attempts (as in Selenium).
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 02-10-2026 (next herd from NrcisyfTestData)
    // ***************************************************************************************************************************************************************************************
    @When("the agent searches for the NRCISYF herd and opens the application")
    public void theAgentSearchesForTheNRCISYFHerdAndOpensTheApplication()
    {
        log.info("[STEP] When the agent searches for the NRCISYF herd and opens the application | herd=" + Hooks.CISYF_HERD);

        final int MAX_RETRIES = 15;

        for (int iAttempt = 1; iAttempt <= MAX_RETRIES; iAttempt++)
        {
            log.info("[TC13-SEARCH] Attempt " + iAttempt + "/" + MAX_RETRIES + " | herd=" + Hooks.CISYF_HERD + " | agent=" + Hooks.CISYF_USERNAME);

            if (searchAndOpenHerd(Hooks.CISYF_HERD, "iTransfersHerdSearchField", "iTransfersSearchBtn", true))
            {
                log.info("[TC13-SEARCH] Herd landing page opened: " + Hooks.CISYF_HERD);
                return;
            }

            log.warning("[TC13-SEARCH] No result row for herd=" + Hooks.CISYF_HERD + " on attempt " + iAttempt + " - taking the next herd.");

            if (iAttempt == MAX_RETRIES)
            {
                throw new RuntimeException("[TC13-SEARCH] Herd " + Hooks.CISYF_HERD + " not found in NR/CISYF tab after " + MAX_RETRIES
                        + " attempts. Herd may not be accessible for agent " + Hooks.CISYF_USERNAME);
            }

            // The herd is not in this agent's list: never hand it out again, take another one (same agent preferred)
            NrcisyfTestData.markNotListed(Hooks.CISYF_HERD, Hooks.CISYF_USERNAME);
            String[] iNext = NrcisyfTestData.nextHerd(Hooks.CISYF_USERNAME, Hooks.BLACKLISTED_HERDS, Hooks.EXPIRED_AGENTS, "herd not listed");

            if (iNext != null && iNext[1].equalsIgnoreCase(Hooks.CISYF_USERNAME))
            {
                // Same agent - just search the new herd
                Hooks.CISYF_HERD   = iNext[0];
                Hooks.RUNTIME_HERD = iNext[0];
                log.info("[TC13-SEARCH] Next herd of the same agent: " + iNext[0] + " - retrying search.");
                continue;
            }

            String iHerd = iNext == null ? Hooks.CISYF_HERD : iNext[0];
            String iUser = iNext == null ? Hooks.CISYF_USERNAME : iNext[1];
            if (iNext == null) log.warning("[TC13-SEARCH] No other Young Farmer herd - logout + fresh login as " + iUser + " (Selenium behaviour).");

            Hooks.CISYF_HERD       = iHerd;
            Hooks.CISYF_USERNAME   = iUser;
            Hooks.RUNTIME_HERD     = iHerd;
            Hooks.RUNTIME_USERNAME = iUser;

            EntsSession.logout();
            if (!EntsSupport.loginSkippingExpired(iUser, "[TC13-RELOGIN]"))
            {
                if (iNext == null)
                {
                    throw new RuntimeException("[TC13-SEARCH] Agent " + iUser + " expired during re-login - cannot continue.");
                }
                log.warning("[TC13-SEARCH] Agent " + iUser + " expired - trying the next herd.");
                continue;
            }

            EntsSupport.openMyClientsTab(NRCISYF_TAB);
            log.info("[TC13-SEARCH] Re-navigated to NR/CISYF tab - retrying search.");
        }
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the NRCISYF landing page should be displayed
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @Then("the NRCISYF landing page should be displayed")
    public void theNRCISYFLandingPageShouldBeDisplayed()
    {
        log.info("[STEP] Then the NRCISYF landing page should be displayed");
        iAction("WAITVISIBLE",   "XPATH", ObjReader.getLocator("iNRCISYFLandingHeader"), null);
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iNRCISYFLandingHeader"), null);
        log.info("NRCISYF landing page confirmed.");
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the NRCISYF closing date should display {string}
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @And("the NRCISYF closing date should display {string}")
    public void theNRCISYFClosingDateShouldDisplay(String pExpectedDate)
    {
        log.info("[STEP] And the NRCISYF closing date should display: " + pExpectedDate);
        iAction("VERIFYTEXT", "XPATH", ObjReader.getLocator("iNRCISYFCloseDate"), pExpectedDate);
        log.info("NRCISYF close date verified: " + pExpectedDate);
    }


    // ===================================================================================================================================
    //  SECTION 2 : CATEGORY DIALOG - OPEN / CLOSE / INFO ICONS
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent opens the NRCISYF Apply or Edit dialog
    // Description   : Clicks Apply / Edit. When the herd is already Submitted (View Application) or neither button is
    //                 shown, recovers up to 95 times (as in Selenium): the herd is marked BAD in the vault (unless it
    //                 was submitted in this run), the next Young Farmer herd is taken (same agent preferred - then only
    //                 the search is repeated), otherwise logout, login, My Clients -> NR/CISYF, search, open the landing
    //                 page, try again. The Selenium BISS_DATA + BISS_INET lookup runs only when the Young Farmer data
    //                 has nothing left.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 02-10-2026 (next herd from NrcisyfTestData)
    // ***************************************************************************************************************************************************************************************
    @When("the agent opens the NRCISYF Apply or Edit dialog")
    public void theAgentOpensTheNRCISYFApplyOrEditDialog()
    {
        log.info("[STEP] When the agent opens the NRCISYF Apply or Edit dialog");

        final int    MAX_RETRIES      = 95;
        final String YEAR             = System.getProperty("herd.year", "2026").trim();
        final String APPLY_EDIT_XPATH = ObjReader.getLocator("iNRCISYFApplyEditBtn");
        final String VIEW_APP_XPATH   = ObjReader.getLocator("iNRCISYFViewApplicationBtn");

        for (int iAttempt = 1; iAttempt <= MAX_RETRIES; iAttempt++)
        {
            log.info("[TC13-APPLY] Attempt " + iAttempt + "/" + MAX_RETRIES + " | herd=" + Hooks.CISYF_HERD);

            if (isVisible(APPLY_EDIT_XPATH, 3))
            {
                String iBtnText;
                try { iBtnText = xp(APPLY_EDIT_XPATH).first().locator("xpath=.//span").first().innerText().trim(); }
                catch (Exception iIgnored) { iBtnText = "?"; }
                log.info("[TC13-APPLY] Button '" + iBtnText + "' found on attempt " + iAttempt);

                iAction("WAITCLICKABLE", "XPATH", APPLY_EDIT_XPATH, null);
                iAction("CLICK",         "XPATH", APPLY_EDIT_XPATH, null);
                iAction("WAITVISIBLE",   "XPATH", ObjReader.getLocator("iNRCISYFDialogOverlay"), null);
                log.info("[TC13-APPLY] Category dialog opened.");
                return;
            }

            boolean iViewAppPresent = isVisible(VIEW_APP_XPATH, 2);
            log.warning("[TC13-APPLY] Attempt " + iAttempt + " | herd=" + Hooks.CISYF_HERD
                    + (iViewAppPresent ? " - herd is Submitted ('View Application'). Recovering..."
                                       : " - neither Apply nor Edit nor View Application found. Recovering..."));
            if (iViewAppPresent) NrcisyfTestData.markAlreadySubmitted(Hooks.CISYF_HERD);

            String[] iNext = NrcisyfTestData.nextHerd(Hooks.CISYF_USERNAME, Hooks.BLACKLISTED_HERDS, Hooks.EXPIRED_AGENTS, "Apply/Edit recovery");
            if (iNext == null)
            {
                iNext = nextCisyfHerd("List of individual herds with CISYF scheme", YEAR, 50 + (iAttempt * 25), "[TC13-APPLY]");
                if (iNext == null) continue;
            }

            if (!switchToHerd(iNext[0], iNext[1], "[TC13-APPLY]")) continue;
            log.info("[TC13-APPLY] Opened landing page for herd: " + iNext[0]);
        }

        throw new RuntimeException("[TC13-APPLY] Could not find Apply or Edit button after " + MAX_RETRIES + " attempts. Last herd: "
                + Hooks.CISYF_HERD + ". All candidates were submitted or exhausted.");
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the info icon for category {string} should display the correct description
    // Parameters    : pCategory - "A", "B", or "C"
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @Then("the info icon for category {string} should display the correct description")
    public void theInfoIconForCategoryShouldDisplayTheCorrectDescription(String pCategory)
    {
        log.info("[STEP] Then the info icon for category '" + pCategory + "' should display the correct description");

        String iIndex;
        switch (pCategory.trim().toUpperCase())
        {
            case "A": iIndex = "1"; break;
            case "B": iIndex = "2"; break;
            case "C": iIndex = "3"; break;
            default:  throw new RuntimeException("[TC13] Unknown category: '" + pCategory + "'. Expected A | B | C");
        }

        String iIconXpath = ObjReader.getLocator("iNRCISYFInfoIcon").replace("{index}", iIndex);
        iAction("WAITVISIBLE",   "XPATH", iIconXpath, null);
        iAction("WAITCLICKABLE", "XPATH", iIconXpath, null);
        iAction("CLICK",         "XPATH", iIconXpath, null);

        String iDescXpath = ObjReader.getLocator("iNRCISYFInfoContent").replace("{index}", iIndex);
        iAction("WAITVISIBLE", "XPATH", iDescXpath, null);

        String iInfoText = iAction("GETTEXT", "XPATH", iDescXpath, null);
        Assertions.assertFalse(iInfoText == null || iInfoText.trim().isEmpty(), "[TC13] Description for category " + pCategory + " should be visible.");
        log.info("[TC13] Category " + pCategory + " description verified ("
                + iInfoText.trim().substring(0, Math.min(60, iInfoText.trim().length())) + "...)");
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent closes the NRCISYF category dialog
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @When("the agent closes the NRCISYF category dialog")
    public void theAgentClosesTheNRCISYFCategoryDialog()
    {
        log.info("[STEP] When the agent closes the NRCISYF category dialog");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iNRCISYFCloseBtn"), null);
        log.info("NRCISYF category dialog closed.");
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the dialog should be dismissed
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @Then("the dialog should be dismissed")
    public void theDialogShouldBeDismissed()
    {
        log.info("[STEP] Then the dialog should be dismissed");
        iAction("WAITINVISIBLE", "XPATH", ObjReader.getLocator("iNRCISYFDialogOverlay"), null);
        log.info("Dialog dismissed confirmed.");
    }


    // ===================================================================================================================================
    //  SECTION 3 : CATEGORY SELECTION
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent resets all category selections
    // Description   : Unticks every ticked category. State is read from the mat-mdc-checkbox-checked class
    //                 (aria-checked is not in the DOM). JavaScript click on the native input, then waits up to 3 s for
    //                 the class to change, as the Selenium FluentWait did.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @And("the agent resets all category selections")
    public void theAgentResetsAllCategorySelections()
    {
        log.info("[STEP] And the agent resets all category selections");

        List<Locator> iCheckboxes = xp(ObjReader.getLocator("iNRCISYFCategoryCheckboxes")).all();

        if (iCheckboxes.isEmpty())
        {
            log.warning("[TC13] No category checkboxes found - dialog may not be open.");
            return;
        }

        int iUnchecked = 0;

        for (Locator iHost : iCheckboxes)
        {
            try
            {
                String iLabel = iHost.innerText().trim().replaceAll("\\s+", " ");

                if (!isChecked(iHost))
                {
                    log.info("[TC13] Already unchecked - skipping: " + iLabel);
                    continue;
                }

                UiHelpers.jsClick(iHost.locator("xpath=.//input[@type='checkbox']"));

                if (!waitChecked(iHost, false, 3000))
                {
                    log.warning("[TC13] Checkbox still ticked after 3 s: " + iLabel);
                    continue;
                }

                iUnchecked++;
                log.info("[TC13] Unchecked: " + iLabel);
            }
            catch (Exception e)
            {
                log.warning("[TC13] Could not reset checkbox: " + e.getMessage());
            }
        }

        log.info("[TC13] Reset complete - unchecked " + iUnchecked + " of " + iCheckboxes.size());
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent selects NRCISYF categories (DataTable)
    // Description   : The A. / B. / C. prefix picks the category checkbox. JavaScript click on the native input, then
    //                 waits up to 3 s for the ticked class.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @And("the agent selects NRCISYF categories")
    public void theAgentSelectsNRCISYFCategories(DataTable pDataTable)
    {
        log.info("[STEP] And the agent selects NRCISYF categories");

        for (String iCategory : pDataTable.asList())
        {
            String iClean = iCategory.trim();
            log.info("[TC13] Selecting: " + iClean);

            String iHostKey;
            String iInputKey;

            if      (iClean.startsWith("A.")) { iHostKey = "iNRCISYFCatACheckbox"; iInputKey = "iNRCISYFCatAInput"; }
            else if (iClean.startsWith("B.")) { iHostKey = "iNRCISYFCatBCheckbox"; iInputKey = "iNRCISYFCatBInput"; }
            else if (iClean.startsWith("C.")) { iHostKey = "iNRCISYFCatCCheckbox"; iInputKey = "iNRCISYFCatCInput"; }
            else
            {
                log.warning("[TC13] No A/B/C prefix - skipping: " + iClean);
                continue;
            }

            String iHostXpath = ObjReader.getLocator(iHostKey);
            iAction("WAITVISIBLE", "XPATH", iHostXpath, null);

            Locator iHost = xp(iHostXpath).first();
            try
            {
                if (isChecked(iHost))
                {
                    log.info("[TC13] '" + iClean + "' already selected - skipping.");
                    continue;
                }
            }
            catch (Exception e)
            {
                log.info("[TC13] Could not read class for '" + iClean + "' - proceeding.");
            }

            UiHelpers.jsClick(xp(ObjReader.getLocator(iInputKey)));

            if (waitChecked(iHost, true, 3000))
            {
                log.info("[TC13] Selected and verified: " + iClean);
            }
            else
            {
                log.warning("[TC13] Could not verify selection for '" + iClean + "' within 3 s.");
            }
        }
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the selected categories should be highlighted
    // Description   : No check, as in Selenium (highlight is confirmed on the screenshot).
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026
    // ***************************************************************************************************************************************************************************************
    @Then("the selected categories should be highlighted")
    public void theSelectedCategoriesShouldBeHighlighted()
    {
        log.info("[STEP] Then the selected categories should be highlighted");
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the invalid category combination error should be displayed for {string}
    // Parameters    : pCategory - "A" or "B"
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @Then("the invalid category combination error should be displayed for {string}")
    public void theInvalidCategoryCombinationErrorShouldBeDisplayedFor(String pCategory)
    {
        log.info("[STEP] Then the invalid category combination error should be displayed for: " + pCategory);
        String iErrorText = iAction("GETTEXT", "XPATH", ObjReader.getLocator("iNRCISYFCategoryError"), null);
        Assertions.assertFalse(iErrorText == null || iErrorText.isEmpty(), "Error message should appear for invalid A+B combination.");
        log.info("Invalid combo error confirmed for " + pCategory + ": " + iErrorText);
    }


    // ===================================================================================================================================
    //  SECTION 4 : CATEGORY NAVIGATION
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent proceeds past the category selection
    // Description   : Next, then OK on the CISYF notice when it appears (2 s check, as in Selenium).
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @And("the agent proceeds past the category selection")
    public void theAgentProceedsPastTheCategorySelection()
    {
        log.info("[STEP] And the agent proceeds past the category selection");
        try
        {
            iAction("CLICK", "XPATH", ObjReader.getLocator("iNRCISYFNextBtn"), null);
            if (isVisible(ObjReader.getLocator("iNRCISYFOKBtn"), 2))
            {
                iAction("CLICK", "XPATH", ObjReader.getLocator("iNRCISYFOKBtn"), null);
                log.info("OK confirmation accepted.");
            }
        }
        catch (Exception e)
        {
            log.info("No OK confirmation displayed - continuing.");
        }
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent should see the CISYF category prompt
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @Then("the agent should see the CISYF category prompt")
    public void theAgentShouldSeeTheCISYFCategoryPrompt()
    {
        log.info("[STEP] Then the agent should see the CISYF category prompt");
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iNRCISYFCISYFPrompt"), null);
        log.info("CISYF category prompt confirmed.");
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent selects additional CISYF category if prompted
    // Description   : "Select additional CISYF category and continue", then OK - only when the prompt is shown.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright, probe instead of a full timeout)
    // ***************************************************************************************************************************************************************************************
    @And("the agent selects additional CISYF category if prompted")
    public void theAgentSelectsAdditionalCISYFCategoryIfPrompted()
    {
        log.info("[STEP] And the agent selects additional CISYF category if prompted");

        if (!isVisible(ObjReader.getLocator("iNRCISYFSelectAdditionalCISYFBtn"), PROBE_SECONDS))
        {
            log.info("No additional CISYF prompt - continuing.");
            return;
        }

        try
        {
            iAction("CLICK", "XPATH", ObjReader.getLocator("iNRCISYFSelectAdditionalCISYFBtn"), null);
            iAction("CLICK", "XPATH", ObjReader.getLocator("iNRCISYFOKBtn"), null);
            log.info("Additional CISYF category selected.");
        }
        catch (Exception e)
        {
            log.info("Additional CISYF prompt could not be completed (" + e.getMessage() + ") - continuing.");
        }
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent skips CISYF category if prompted
    // Description   : "Do not select CISYF category and continue" - only when the prompt is shown.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright, probe instead of a full timeout)
    // ***************************************************************************************************************************************************************************************
    @And("the agent skips CISYF category if prompted")
    public void theAgentSkipsCISYFCategoryIfPrompted()
    {
        log.info("[STEP] And the agent skips CISYF category if prompted");

        if (!isVisible(ObjReader.getLocator("iNRCISYFDoNotSelectCISYFBtn"), PROBE_SECONDS))
        {
            log.info("No CISYF category prompt displayed - continuing.");
            return;
        }

        try
        {
            iAction("CLICK", "XPATH", ObjReader.getLocator("iNRCISYFDoNotSelectCISYFBtn"), null);
            log.info("CISYF category skipped.");
        }
        catch (Exception e)
        {
            log.info("CISYF prompt could not be skipped (" + e.getMessage() + ") - continuing.");
        }
    }


    // ===================================================================================================================================
    //  SECTION 5 : FARMING ENTITY SETUP
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent selects farming entity {string}
    // Parameters    : pEntityType - "Individual", "Joint herdowner", "Company" etc.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @And("the agent selects farming entity {string}")
    public void theAgentSelectsFarmingEntity(String pEntityType)
    {
        log.info("[STEP] And the agent selects farming entity: " + pEntityType);
        iAction("LIST", "XPATH", ObjReader.getLocator("iNRCISYFFarmingEntityDropdown"), pEntityType);
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent selects herd group type {string}
    // Description   : Uses iNRCISYFHerdGroupTypeDropdown, unchanged. NOTE: in the Object Repository that key points at the
    //                 "Farming Entity" label; the "Herd group type" label is iNRCISYFHerdGroupTypeDropdown2.
    // Parameters    : pGroupType - "Company", "Partnership" etc.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @And("the agent selects herd group type {string}")
    public void theAgentSelectsHerdGroupType(String pGroupType)
    {
        log.info("[STEP] And the agent selects herd group type: " + pGroupType);
        iAction("LIST", "XPATH", ObjReader.getLocator("iNRCISYFHerdGroupTypeDropdown"), pGroupType);
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the group member count dropdown should offer values (DataTable)
    // Description   : Opens the member count dropdown, reads every option, closes it, and checks each expected value.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @Then("the group member count dropdown should offer values")
    public void theGroupMemberCountDropdownShouldOfferValues(DataTable pDataTable)
    {
        log.info("[STEP] Then the group member count dropdown should offer values");

        List<String> iExpected = pDataTable.asList().stream().map(String::trim).collect(Collectors.toList());

        iAction("CLICK",       "XPATH", ObjReader.getLocator("iNRCISYFMemberCountDropdown"), null);
        iAction("WAITVISIBLE", "XPATH", ObjReader.getLocator("iMatSelectOpenPanel"), null);

        List<String> iActual = xp(ObjReader.getLocator("iMatOptionText")).allInnerTexts().stream()
                .map(String::trim).filter(t -> !t.isEmpty()).collect(Collectors.toList());

        // Close the panel again (Selenium clicked the dropdown a second time); Escape if that did not close it
        try { iAction("CLICK", "XPATH", ObjReader.getLocator("iNRCISYFMemberCountDropdown"), null); }
        catch (Exception iIgnored) { }
        if (isVisible(ObjReader.getLocator("iMatSelectOpenPanel"), 1)) UiHelpers.pressKey("Escape");

        for (String iVal : iExpected)
        {
            Assertions.assertTrue(iActual.contains(iVal), "Member count dropdown should contain: " + iVal + " | Actual: " + iActual);
        }
        log.info("Member count dropdown verified: " + iActual);
    }


    // ===================================================================================================================================
    //  SECTION 6 : NAVIGATION HELPERS
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent navigates back to the NRCISYF client list
    // Description   : Home, then My Clients (the feature file switches to the NR/CISYF tab next).
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @When("the agent navigates back to the NRCISYF client list")
    public void theAgentNavigatesBackToTheNRCISYFClientList()
    {
        log.info("[STEP] When the agent navigates back to the NRCISYF client list");

        iAction("CLICK", "XPATH", ObjReader.getLocator("iHomeLeftMenuLink"), null);
        pause(1500);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iCLientLeftMenuLink"), null);
    }


    // ===================================================================================================================================
    //  SECTION 7 : QUALIFICATION STEP
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent proceeds to the qualification step
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @And("the agent proceeds to the qualification step")
    public void theAgentProceedsToTheQualificationStep()
    {
        log.info("[STEP] And the agent proceeds to the qualification step");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iNRCISYFStepperNextBtn"), null);
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent completes the qualification details (DataTable)
    // Description   : Has qualification radio; with "No" nothing else is filled. Otherwise: date of completion
    //                 (disabled datepicker - clearAndEnterDate), certificate awarded radio, college, custom college,
    //                 qualification, custom qualification - each only when its row is in the DataTable.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @When("the agent completes the qualification details")
    public void theAgentCompletesTheQualificationDetails(DataTable pDataTable)
    {
        log.info("[STEP] When the agent completes the qualification details");

        Map<String, String> iData = pDataTable.asMap(String.class, String.class);

        String iHasQual   = iData.getOrDefault("hasQualification", "Yes").trim();
        String iHasQualXp = ObjReader.getLocator("iNRCISYFHasQualRadio").replace("{value}", iHasQual);
        iAction("WAITVISIBLE", "XPATH", iHasQualXp, null);
        iAction("CLICK",       "XPATH", iHasQualXp, null);

        if ("No".equalsIgnoreCase(iHasQual))
        {
            log.info("[TC13] Qualification = No - no further fields to fill.");
            return;
        }

        if (iData.containsKey("dateOfCompletion"))
        {
            iAction("WAITVISIBLE", "XPATH", ObjReader.getLocator("iNRCISYFDateOfCompletionInput"), null);
            clearAndEnterDate(xp(ObjReader.getLocator("iNRCISYFDateOfCompletionInput")).first(),
                    iData.get("dateOfCompletion").trim(), "Date of completion");
        }

        if (iData.containsKey("certificateAwarded"))
        {
            String iCertXp = ObjReader.getLocator("iNRCISYFCertAwardedRadio").replace("{value}", iData.get("certificateAwarded").trim());
            iAction("WAITVISIBLE", "XPATH", iCertXp, null);
            iAction("CLICK",       "XPATH", iCertXp, null);
        }

        if (iData.containsKey("college"))
        {
            iAction("LIST", "XPATH", ObjReader.getLocator("iNRCISYFCollegeDropdown"), iData.get("college").trim());
        }

        if (iData.containsKey("customCollege"))
        {
            iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iNRCISYFCustomCollegeField"), iData.get("customCollege").trim());
        }

        if (iData.containsKey("qualification"))
        {
            iAction("LIST", "XPATH", ObjReader.getLocator("iNRCISYFQualificationDropdown"), iData.get("qualification").trim());
        }

        if (iData.containsKey("customQualification"))
        {
            iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iNRCISYFCustomQualificationField"), iData.get("customQualification").trim());
        }

        log.info("[TC13] Qualification details completed: college=" + iData.getOrDefault("college", "N/A"));
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent completes the qualification details for each member (DataTable)
    // Description   : Same fields for every group member; clicks Next Farmer between members (up to 10).
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @When("the agent completes the qualification details for each member")
    public void theAgentCompletesTheQualificationDetailsForEachMember(DataTable pDataTable)
    {
        log.info("[STEP] When the agent completes the qualification details for each member");

        Map<String, String> iData        = pDataTable.asMap(String.class, String.class);
        final int           iMaxMembers  = 10;
        int                 iMemberCount = 0;

        for (int i = 0; i < iMaxMembers; i++)
        {
            iMemberCount++;
            log.info("[TC13] Filling qualification for member " + iMemberCount);

            String iHasQual      = iData.getOrDefault("hasQualification", "Yes").trim();
            String iHasQualXpath = ObjReader.getLocator("iNRCISYFHasQualRadio").replace("{value}", iHasQual);
            iAction("WAITVISIBLE", "XPATH", iHasQualXpath, null);
            iAction("CLICK",       "XPATH", iHasQualXpath, null);

            if (iData.containsKey("dateOfCompletion"))
            {
                clearAndEnterDate(xp(ObjReader.getLocator("iNRCISYFDateOfCompletionField")).first(),
                        iData.get("dateOfCompletion").trim(), "Date of completion member " + iMemberCount);
            }

            if (iData.containsKey("certificateAwarded"))
            {
                String iCertXpath = ObjReader.getLocator("iNRCISYFCertAwardedRadio").replace("{value}", iData.get("certificateAwarded").trim());
                iAction("WAITVISIBLE", "XPATH", iCertXpath, null);
                iAction("CLICK",       "XPATH", iCertXpath, null);
            }

            if (iData.containsKey("college"))
            {
                iAction("LIST", "XPATH", ObjReader.getLocator("iNRCISYFCollegeDropdown"), iData.get("college").trim());
            }

            if (iData.containsKey("qualification"))
            {
                iAction("LIST", "XPATH", ObjReader.getLocator("iNRCISYFQualificationDropdown"), iData.get("qualification").trim());
            }

            if (isVisible(ObjReader.getLocator("iNRCISYFNextFarmerBtn"), 3))
            {
                iAction("CLICK", "XPATH", ObjReader.getLocator("iNRCISYFNextFarmerBtn"), null);
                log.info("[TC13] Next Farmer clicked - proceeding to member " + (iMemberCount + 1));
            }
            else
            {
                log.info("[TC13] No more Next Farmer buttons - all " + iMemberCount + " member(s) completed.");
                break;
            }
        }
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the no-qualification information message should be displayed if applicable
    // Description   : Logs the message when it is shown; passes either way, as in Selenium.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @Then("the no-qualification information message should be displayed if applicable")
    public void theNoQualificationInformationMessageShouldBeDisplayedIfApplicable()
    {
        log.info("[STEP] Then the no-qualification information message should be displayed if applicable");

        String iMessageXpath = ObjReader.getLocator("iNRCISYFNoQualMessage");
        if (isVisible(iMessageXpath, PROBE_SECONDS))
        {
            log.info("No-qualification message found: " + xp(iMessageXpath).first().innerText().trim());
        }
        else
        {
            log.info("No-qualification message not displayed - may not apply in this environment.");
        }
    }


    // ===================================================================================================================================
    //  SECTION 8 : COMPANY DETAILS
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent enters company details (DataTable)
    // Description   : CRO number, company name, company secretary name. DataTable keys: croNumber, companyName, secretaryName
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @And("the agent enters company details")
    public void theAgentEntersCompanyDetails(DataTable pDataTable)
    {
        log.info("[STEP] And the agent enters company details");

        Map<String, String> iData = pDataTable.asMap(String.class, String.class);

        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iNRCISYFCRONumberInput"),            iData.get("croNumber").trim());
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iNRCISYFCompanyNameInput"),          iData.get("companyName").trim());
        iAction("TEXTBOX", "XPATH", ObjReader.getLocator("iNRCISYFCompanySecretaryNameInput"), iData.get("secretaryName").trim());

        log.info("[TC13] Company details entered: CRO=" + iData.get("croNumber"));
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent sets group member count to {string}
    // Parameters    : pCount - "1"..."6"
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @And("the agent sets group member count to {string}")
    public void theAgentSetsGroupMemberCountTo(String pCount)
    {
        log.info("[STEP] And the agent sets group member count to: " + pCount);
        iAction("LIST", "XPATH", ObjReader.getLocator("iNRCISYFMemberCountDropdown"), pCount);
    }


    // ===================================================================================================================================
    //  SECTION 9 : GROUP MEMBER DETAILS
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent enters group member details (DataTable)
    // Description   : Name, date of birth (disabled datepicker - clearAndEnterDate) and the eligible tick per member row.
    //                 DataTable columns: memberIndex | name | dob | eligible
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @And("the agent enters group member details")
    public void theAgentEntersGroupMemberDetails(DataTable pDataTable)
    {
        log.info("[STEP] And the agent enters group member details");

        List<Map<String, String>> iMembers = pDataTable.asMaps(String.class, String.class);

        for (Map<String, String> iMember : iMembers)
        {
            String iIdx      = iMember.get("memberIndex").trim();
            String iName     = iMember.get("name").trim();
            String iDob      = iMember.get("dob").trim();
            String iEligible = iMember.get("eligible").trim();

            log.info("[TC13] Entering member " + iIdx + ": " + iName);

            String iNameXpath = ObjReader.getLocator("iNRCISYFMemberNameInput").replace("{index}", iIdx);
            iAction("WAITVISIBLE", "XPATH", iNameXpath, null);
            iAction("TEXTBOX",     "XPATH", iNameXpath, iName);

            String iDobXpath = ObjReader.getLocator("iNRCISYFMemberDOBInput").replace("{index}", iIdx);
            clearAndEnterDate(xp(iDobXpath).first(), iDob, "DOB member " + iIdx);

            if ("Yes".equalsIgnoreCase(iEligible))
            {
                String iHostXpath  = ObjReader.getLocator("iNRCISYFMemberEligibleCheckboxHost").replace("{index}", iIdx);
                String iInputXpath = ObjReader.getLocator("iNRCISYFMemberEligibleInput").replace("{index}", iIdx);
                try
                {
                    if (isChecked(xp(iHostXpath).first()))
                    {
                        log.info("[TC13] Member " + iIdx + " already eligible - skipping.");
                    }
                    else
                    {
                        UiHelpers.jsClick(xp(iInputXpath));
                        log.info("[TC13] Eligible ticked for member " + iIdx);
                    }
                }
                catch (Exception e)
                {
                    log.warning("[TC13] Could not tick eligible for member " + iIdx + ": " + e.getMessage());
                }
            }

            log.info("[TC13] Member " + iIdx + " complete: " + iName + " DOB=" + iDob);
        }
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent confirms group status question as {string}
    // Description   : The radio value in the DOM is true / false - mapped from Yes / No.
    // Parameters    : pAnswer - "Yes" or "No"
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @And("the agent confirms group status question as {string}")
    public void theAgentConfirmsGroupStatusQuestionAs(String pAnswer)
    {
        log.info("[STEP] And the agent confirms group status question as: " + pAnswer);
        String iValue      = "Yes".equalsIgnoreCase(pAnswer.trim()) ? "true" : "false";
        String iRadioXpath = ObjReader.getLocator("iNRCISYFGroupStatusRadio").replace("{value}", iValue);
        iAction("WAITVISIBLE", "XPATH", iRadioXpath, null);
        iAction("CLICK",       "XPATH", iRadioXpath, null);
        log.info("[TC13] Group status confirmed: " + pAnswer + " (value=" + iValue + ")");
    }


    // ===================================================================================================================================
    //  SECTION 10 : SUMMARY / DOCUMENT UPLOAD
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent proceeds to the summary step
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @And("the agent proceeds to the summary step")
    public void theAgentProceedsToTheSummaryStep()
    {
        log.info("[STEP] And the agent proceeds to the summary step");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iNRCISYFNextToSummaryBtn"), null);
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent uploads NRCISYF documents (DataTable)
    // Description   : For every document label: JavaScript click on its Upload button, attach the sample PDF, Upload
    //                 Document, wait for the dialog to close.
    //                 File: -Dnrcisyf.upload.path, else src/test/resources/Test_Data/Cover_Letter.pdf
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @When("the agent uploads NRCISYF documents")
    public void theAgentUploadsNRCISYFDocuments(DataTable pDataTable)
    {
        log.info("[STEP] When the agent uploads NRCISYF documents");

        String iFilePath = System.getProperty("nrcisyf.upload.path", TEST_DATA_DIR + "Cover_Letter.pdf");

        for (String iDocType : pDataTable.asList())
        {
            String iClean = iDocType.trim();
            log.info("[TC13] Uploading: " + iClean);

            clickUploadButtonFor(iClean);

            iAction("UPLOADFILE",    "XPATH", ObjReader.getLocator("iNRCISYFFileUploadInput"),   iFilePath);
            iAction("WAITVISIBLE",   "XPATH", ObjReader.getLocator("iNRCISYFUploadDocumentBtn"), null);
            iAction("WAITCLICKABLE", "XPATH", ObjReader.getLocator("iNRCISYFUploadDocumentBtn"), null);
            iAction("CLICK",         "XPATH", ObjReader.getLocator("iNRCISYFUploadDocumentBtn"), null);
            iAction("WAITINVISIBLE", "XPATH", ObjReader.getLocator("iNRCISYFDialogOverlay"),     null);
            pause(2000);
            log.info("[TC13] Uploaded: " + iClean);
        }
    }


    // ===================================================================================================================================
    //  SECTION 11 : SUBMISSION / SAVE AND EXIT
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent saves and proceeds to the declaration step
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @And("the agent saves and proceeds to the declaration step")
    public void theAgentSavesAndProceedsToTheDeclarationStep()
    {
        log.info("[STEP] And the agent saves and proceeds to the declaration step");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iNRCISYFStepperSaveAndNextBtn"), null);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iNRCISYFSaveAndNextBtn"), null);
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent submits the NRCISYF application with declaration
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @And("the agent submits the NRCISYF application with declaration")
    public void theAgentSubmitsTheNRCISYFApplicationWithDeclaration()
    {
        log.info("[STEP] And the agent submits the NRCISYF application with declaration");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iNRCISYFSubmitApplicationBtn"), null);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iNRCISYFDeclarationCheckbox1"), null);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iNRCISYFDeclarationCheckbox2"), null);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iNRCISYFSubmitConfirmBtn"), null);
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the NRCISYF application should be submitted successfully
    // Description   : Checks the success banner, then records the herd as submitted (vault USED, remembered for the
    //                 post-submission section of this run).
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 02-10-2026 (vault)
    // ***************************************************************************************************************************************************************************************
    @Then("the NRCISYF application should be submitted successfully")
    public void theNRCISYFApplicationShouldBeSubmittedSuccessfully()
    {
        log.info("[STEP] Then the NRCISYF application should be submitted successfully");
        iAction("WAITVISIBLE", "XPATH", ObjReader.getLocator("iNRCISYFSubmitSuccessMsg"), null);
        String iConfirmation = iAction("GETTEXT", "XPATH", ObjReader.getLocator("iNRCISYFSubmitSuccessMsg"), null);
        Assertions.assertFalse(iConfirmation == null || iConfirmation.isEmpty(), "NRCISYF submission success should be visible.");
        log.info("NRCISYF application submitted successfully: " + iConfirmation);

        NrcisyfTestData.markSubmitted(Hooks.CISYF_HERD, Hooks.CISYF_USERNAME);
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent saves and exits the NRCISYF application
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @And("the agent saves and exits the NRCISYF application")
    public void theAgentSavesAndExitsTheNRCISYFApplication()
    {
        log.info("[STEP] And the agent saves and exits the NRCISYF application");
        iAction("CLICK", "XPATH", ObjReader.getLocator("iNRCISYFStepperSaveAndExitBtn"), null);
        iAction("CLICK", "XPATH", ObjReader.getLocator("iNRCISYFSaveExitDialogBtn"), null);
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the application should be saved successfully
    // Description   : Back on the landing page: the Apply / Edit button is shown again. The herd now holds a draft, so
    //                 it is marked USED in the vault (a later run would see Edit, not Apply).
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 02-10-2026 (vault)
    // ***************************************************************************************************************************************************************************************
    @Then("the application should be saved successfully")
    public void theApplicationShouldBeSavedSuccessfully()
    {
        log.info("[STEP] Then the application should be saved successfully");
        iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iNRCISYFApplyEditBtn"), null);
        log.info("Application saved successfully - back on landing page.");

        NrcisyfTestData.markSavedDraft(Hooks.CISYF_HERD);
    }


    // ===================================================================================================================================
    //  SECTION 12 : CUSTOM EDUCATION / QUALIFICATION VERIFICATION
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the education institution should display {string}
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @Then("the education institution should display {string}")
    public void theEducationInstitutionShouldDisplay(String pExpected)
    {
        log.info("[STEP] Then the education institution should display: " + pExpected);
        iAction("VERIFYTEXT", "XPATH",
                "//*[contains(@class,'summary') or contains(@class,'review')]//*[contains(text(),'" + pExpected + "')]", pExpected);
        log.info("Custom institution verified: " + pExpected);
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the qualification should display {string}
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @Then("the qualification should display {string}")
    public void theQualificationShouldDisplay(String pExpected)
    {
        log.info("[STEP] Then the qualification should display: " + pExpected);
        iAction("VERIFYTEXT", "XPATH",
                "//*[contains(@class,'summary') or contains(@class,'review')]//*[contains(text(),'" + pExpected + "')]", pExpected);
        log.info("Custom qualification verified: " + pExpected);
    }


    // ===================================================================================================================================
    //  SECTION 13 : UPLOAD VALIDATION
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent verifies the upload control only accepts PDF format (DataTable)
    // Description   : For every document label: open its upload dialog, attach Test_Data/image.png, Upload Document,
    //                 check both errors ("Document upload failed", "File is not a PDF"), Close, wait for the dialog to go.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @Then("the agent verifies the upload control only accepts PDF format")
    public void theAgentVerifiesTheUploadControlOnlyAcceptsPDFFormat(DataTable pDataTable)
    {
        log.info("[STEP] Then the agent verifies the upload control only accepts PDF format");

        String iImagePath = TEST_DATA_DIR + "image.png";

        for (String iDocType : pDataTable.asList())
        {
            String iClean = iDocType.trim();
            log.info("[TC13] PDF-only validation for: " + iClean);

            clickUploadButtonFor(iClean);

            iAction("UPLOADFILE",    "XPATH", ObjReader.getLocator("iNRCISYFFileUploadInput"),   iImagePath);
            iAction("WAITVISIBLE",   "XPATH", ObjReader.getLocator("iNRCISYFUploadDocumentBtn"), null);
            iAction("WAITCLICKABLE", "XPATH", ObjReader.getLocator("iNRCISYFUploadDocumentBtn"), null);
            iAction("CLICK",         "XPATH", ObjReader.getLocator("iNRCISYFUploadDocumentBtn"), null);

            iAction("WAITVISIBLE",   "XPATH", ObjReader.getLocator("iNRCISYFUploadErrorFailed"), null);
            iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iNRCISYFUploadErrorFailed"), null);
            log.info("[TC13] Error verified: Document upload failed");

            iAction("WAITVISIBLE",   "XPATH", ObjReader.getLocator("iNRCISYFUploadErrorNotPdf"), null);
            iAction("VERIFYELEMENT", "XPATH", ObjReader.getLocator("iNRCISYFUploadErrorNotPdf"), null);
            log.info("[TC13] Error verified: File is not a PDF");

            iAction("WAITVISIBLE",   "XPATH", ObjReader.getLocator("iNRCISYFUploadDialogCloseBtn"), null);
            iAction("WAITCLICKABLE", "XPATH", ObjReader.getLocator("iNRCISYFUploadDialogCloseBtn"), null);
            iAction("CLICK",         "XPATH", ObjReader.getLocator("iNRCISYFUploadDialogCloseBtn"), null);
            iAction("WAITINVISIBLE", "XPATH", ObjReader.getLocator("iNRCISYFDialogOverlay"),        null);
            pause(2000);
            log.info("[TC13] PDF validation complete for: " + iClean);
        }
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent opens the upload dialog for {string}
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @When("the agent opens the upload dialog for {string}")
    public void theAgentOpensTheUploadDialogFor(String pDocType)
    {
        log.info("[STEP] When the agent opens the upload dialog for: " + pDocType);
        clickUploadButtonFor(pDocType.trim());
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent closes the upload dialog without uploading
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @And("the agent closes the upload dialog without uploading")
    public void theAgentClosesTheUploadDialogWithoutUploading()
    {
        log.info("[STEP] And the agent closes the upload dialog without uploading");
        iAction("WAITVISIBLE",   "XPATH", ObjReader.getLocator("iNRCISYFUploadDialogCloseBtn"), null);
        iAction("WAITCLICKABLE", "XPATH", ObjReader.getLocator("iNRCISYFUploadDialogCloseBtn"), null);
        iAction("CLICK",         "XPATH", ObjReader.getLocator("iNRCISYFUploadDialogCloseBtn"), null);
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the upload dialog should be dismissed
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @Then("the upload dialog should be dismissed")
    public void theUploadDialogShouldBeDismissed()
    {
        log.info("[STEP] Then the upload dialog should be dismissed");
        iAction("WAITINVISIBLE", "XPATH", "//mat-dialog-container | //div[contains(@class,'cdk-overlay-pane')]", null);
        log.info("Upload dialog dismissed.");
    }


    // ===================================================================================================================================
    //  SECTION 14 : POST-SUBMISSION VERIFICATION
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent views the submitted NRCISYF application
    // Description   : Clicks View Application when the herd is Submitted. Otherwise recovers up to 10 times (as in
    //                 Selenium). 02-10-2026: the first recovery uses the herd submitted earlier in THIS run (same
    //                 agent - no re-login when it is the logged-in agent); the Selenium query for any submitted CISYF
    //                 herd (BISS_DATA + BISS_INET) runs only when nothing was submitted in this run.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 09-06-2026 | Updated: 02-10-2026 (own submission first)
    // ***************************************************************************************************************************************************************************************
    @And("the agent views the submitted NRCISYF application")
    public void theAgentViewsTheSubmittedNRCISYFApplication()
    {
        log.info("[STEP] And the agent views the submitted NRCISYF application");

        final int    MAX_RETRIES    = 10;
        final String YEAR           = System.getProperty("herd.year", "2026").trim();
        final String VIEW_APP_XPATH = ObjReader.getLocator("iNRCISYFViewApplicationBtn");

        boolean iOwnTried = false;

        for (int iAttempt = 1; iAttempt <= MAX_RETRIES; iAttempt++)
        {
            log.info("[TC13-POST] Attempt " + iAttempt + "/" + MAX_RETRIES + " | herd=" + Hooks.CISYF_HERD);

            if (isVisible(VIEW_APP_XPATH, 5))
            {
                iAction("CLICK", "XPATH", VIEW_APP_XPATH, null);
                log.info("[TC13-POST] Submitted herd confirmed - View Application clicked: " + Hooks.CISYF_HERD);
                return;
            }

            log.warning("[TC13-POST] Attempt " + iAttempt + " | herd=" + Hooks.CISYF_HERD
                    + " - View Application not present (herd not submitted). Recovering...");

            if (iAttempt == MAX_RETRIES)
            {
                throw new RuntimeException("[TC13-POST] Could not find a submitted CISYF herd after " + MAX_RETRIES
                        + " attempts. Last herd: " + Hooks.CISYF_HERD);
            }

            String[] iNext = null;
            if (!iOwnTried)
            {
                iOwnTried = true;
                String[] iOwn = NrcisyfTestData.lastSubmitted();
                if (iOwn != null && !iOwn[0].equalsIgnoreCase(Hooks.CISYF_HERD))
                {
                    log.info("[TC13-POST] Using the herd submitted in this run: " + iOwn[0] + " (" + iOwn[1] + ")");
                    iNext = iOwn;
                }
            }
            if (iNext == null)
            {
                iNext = nextCisyfHerd("List of submitted individual herds with CISYF scheme", YEAR, 50 + (iAttempt * 25), "[TC13-POST]");
                if (iNext == null) continue;
            }

            if (!switchToHerd(iNext[0], iNext[1], "[TC13-POST]")) continue;
            log.info("[TC13-POST] Opened landing page for submitted herd: " + iNext[0]);
        }

        throw new RuntimeException("[TC13-POST] Could not find a submitted CISYF herd after " + MAX_RETRIES + " attempts. Last herd: " + Hooks.CISYF_HERD);
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the uploaded documents should be accessible in correspondence
    // Description   : Clicks the Correspondence link when it is shown. The document-count check is commented out in the
    //                 Selenium version and stays that way here.
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @Then("the uploaded documents should be accessible in correspondence")
    public void theUploadedDocumentsShouldBeAccessibleInCorrespondence()
    {
        log.info("[STEP] Then the uploaded documents should be accessible in correspondence");

        String iLink = ObjReader.getLocator("iNRCISYFCorrespondenceNavBtn");
        if (isVisible(iLink, PROBE_SECONDS))
        {
            try { iAction("CLICK", "XPATH", iLink, null); }
            catch (Exception iIgnored) { log.info("Correspondence link could not be clicked - continuing."); }
        }
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the agent clicks on the {string} document link
    // Parameters    : pDocName - part of the link or button text
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @And("the agent clicks on the {string} document link")
    public void theAgentClicksOnTheDocumentLink(String pDocName)
    {
        log.info("[STEP] And the agent clicks on the document link: " + pDocName);
        iAction("CLICK", "XPATH", "//a[contains(normalize-space(),'" + pDocName.trim() + "')] | "
                + "//button[contains(normalize-space(),'" + pDocName.trim() + "')]", null);
    }

    // ***************************************************************************************************************************************************************************************
    // Step          : the document should open or download successfully
    // Description   : Passes when no error page is visible (same check as Selenium).
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 31-03-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    @Then("the document should open or download successfully")
    public void theDocumentShouldOpenOrDownloadSuccessfully()
    {
        log.info("[STEP] Then the document should open or download successfully");
        String iErrorXpath = "//*[contains(@class,'error') and contains(@class,'page')]";
        Assertions.assertFalse(countOf(iErrorXpath) > 0 && isVisible(iErrorXpath, 1),
                "No error page should be visible after clicking the document link.");
        log.info("Document link opened without errors.");
    }


    // ===================================================================================================================================
    //  HELPERS
    // ===================================================================================================================================

    // ***************************************************************************************************************************************************************************************
    // Function Name : searchAndOpenHerd
    // Description   : Types the herd in the NR/CISYF search box, clicks Search (twice when pDoubleClick, as the Selenium
    //                 search step did), waits up to 7 s for the row that holds THIS herd, and clicks its View link.
    //                 Returns false when that row never appears.
    //                 Change from Selenium: Selenium waited 2 s and clicked the first View link on the page, which can be a
    //                 row of the unfiltered list that is still on screen.
    // Parameters    : pHerd (String) - herd number | pSearchKey / pButtonKey (String) - Object Repository keys
    //                 pDoubleClick (boolean) - click Search twice
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 22-09-2026
    // ***************************************************************************************************************************************************************************************
    private static boolean searchAndOpenHerd(String pHerd, String pSearchKey, String pButtonKey, boolean pDoubleClick)
    {
        if (pHerd == null || pHerd.isBlank())
        {
            throw new IllegalStateException("[TC13] No CISYF herd - Hooks @Before(\"@tc13\") did not resolve one. Is the scenario tagged @tc13?");
        }

        iAction("TEXTBOX", "XPATH", ObjReader.getLocator(pSearchKey), pHerd);
        iAction("CLICK",   "XPATH", ObjReader.getLocator(pButtonKey), null);
        if (pDoubleClick) iAction("CLICK", "XPATH", ObjReader.getLocator(pButtonKey), null);

        String iHerdRowView = "//tr[.//td[contains(normalize-space(),'" + pHerd + "')]]"
                + "//td[contains(@class,'cdk-column-transfers')]//a[normalize-space()='View']";

        if (!isVisible(iHerdRowView, 7)) return false;

        iAction("CLICK", "XPATH", "(" + iHerdRowView + ")[1]", null);
        return true;
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : nextCisyfHerd
    // Description   : The Selenium fallback: next usable CISYF herd from BISS_DATA - rows of pLabel in random order,
    //                 blacklisted herds skipped, agent from BISS_INET, expired agents skipped.
    // Parameters    : pLabel (String) - DBRouter label | pYear (String) - scheme year | pLimit (int) - rows to fetch
    //                 pLogPrefix (String) - log prefix
    // Returns       : String[] {herd, agent}, or null when no candidate was usable
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 22-09-2026 (the candidate loop of the Selenium recovery code, shared by two steps)
    // ***************************************************************************************************************************************************************************************
    private static String[] nextCisyfHerd(String pLabel, String pYear, int pLimit, String pLogPrefix)
    {
        database.DBRouter.runDB("DATA", pLabel, pYear, String.valueOf(pLimit));
        List<Map<String, Object>> iDbRows = database.DBRouter.getRows();

        if (iDbRows == null || iDbRows.isEmpty())
        {
            log.warning(pLogPrefix + " BISS_DATA returned 0 rows at limit=" + pLimit + " - retrying.");
            return null;
        }

        List<String> iCandidates = new ArrayList<>();
        for (Map<String, Object> iRow : iDbRows)
        {
            String iH = Objects.toString(iRow.get("APP_HERD_NO"), "").trim();
            if (!iH.isEmpty()) iCandidates.add(iH);
        }
        Collections.shuffle(iCandidates, new Random(System.nanoTime()));

        for (String iCandidate : iCandidates)
        {
            if (Hooks.BLACKLISTED_HERDS.contains(iCandidate))
            {
                log.warning(pLogPrefix + " " + iCandidate + " is blacklisted - skipping.");
                continue;
            }

            database.DBRouter.runDB("INET", "Get Login Id for herd", iCandidate);
            String iUser = database.DBRouter.getValue("USERNAME");

            if (iUser == null || iUser.isBlank())
            {
                log.warning(pLogPrefix + " No INET agent for " + iCandidate + " - skipping.");
                continue;
            }
            iUser = iUser.trim();

            if (Hooks.EXPIRED_AGENTS.contains(iUser))
            {
                log.warning(pLogPrefix + " Agent " + iUser + " is EXPIRED for herd=" + iCandidate + " - skipping.");
                continue;
            }

            log.info(pLogPrefix + " Valid candidate: herd=" + iCandidate + " | agent=" + iUser);
            return new String[] { iCandidate, iUser };
        }

        log.warning(pLogPrefix + " All candidates exhausted at limit=" + pLimit + " - retrying with a larger limit.");
        return null;
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : switchToHerd
    // Description   : Makes pHerd / pUser the runtime CISYF pair (Hooks). When pUser is the agent already logged in,
    //                 only My Clients -> NR/CISYF -> search runs (02-10-2026); otherwise logout, login as pUser first.
    //                 Then searches the herd and opens its landing page.
    // Returns       : boolean - false when the login failed (expired) or the herd did not show
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 22-09-2026 | Updated: 02-10-2026 (same agent - no re-login)
    // ***************************************************************************************************************************************************************************************
    private static boolean switchToHerd(String pHerd, String pUser, String pLogPrefix)
    {
        boolean iSameAgent = pUser != null && pUser.equalsIgnoreCase(Hooks.CISYF_USERNAME);

        Hooks.RUNTIME_HERD     = pHerd;
        Hooks.RUNTIME_USERNAME = pUser;
        Hooks.CISYF_HERD       = pHerd;
        Hooks.CISYF_USERNAME   = pUser;
        log.info(pLogPrefix + " Hooks updated: herd=" + pHerd + " | agent=" + pUser + (iSameAgent ? " (same agent - no re-login)" : ""));

        if (!iSameAgent)
        {
            EntsSession.logout();
            if (!EntsSupport.loginSkippingExpired(pUser, "[TC13-RELOGIN]"))
            {
                log.warning(pLogPrefix + " Agent " + pUser + " expired during login - retrying with the next candidate.");
                return false;
            }
        }

        EntsSupport.openMyClientsTab(NRCISYF_TAB);
        log.info(pLogPrefix + " Navigated to NR/CISYF tab.");

        if (!searchAndOpenHerd(pHerd, "iNRCISYFHerdSearchField", "iNRCISYFSearchBtn", false))
        {
            log.warning(pLogPrefix + " New herd " + pHerd + " returned no rows after search - retrying.");
            NrcisyfTestData.markNotListed(pHerd, pUser);
            return false;
        }
        return true;
    }

    // ***************************************************************************************************************************************************************************************
    // Function Name : clickUploadButtonFor
    // Description   : JavaScript click on the Upload button of one document label (first 40 characters of the label,
    //                 as in Selenium - iNRCISYFUploadBtn uses {label}).
    // Parameters    : pDocType (String) - document label from the feature file
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 22-09-2026 (three Selenium copies merged)
    // ***************************************************************************************************************************************************************************************
    private static void clickUploadButtonFor(String pDocType)
    {
        String iLabel = pDocType.substring(0, Math.min(40, pDocType.length()));
        String iXpath = ObjReader.getLocator("iNRCISYFUploadBtn").replace("{label}", iLabel);

        iAction("WAITVISIBLE", "XPATH", iXpath, null);
        UiHelpers.jsClick(xp(iXpath));
    }

    // True when the mat-checkbox host carries the ticked class
    private static boolean isChecked(Locator pHost)
    {
        String iClass = pHost.getAttribute("class");
        return iClass != null && iClass.contains(CHECKED_CLASS);
    }

    // Polls every 300 ms until the ticked state equals pWanted, for up to pTimeoutMs (the Selenium FluentWait)
    private static boolean waitChecked(Locator pHost, boolean pWanted, long pTimeoutMs)
    {
        long iEnd = System.currentTimeMillis() + pTimeoutMs;
        while (true)
        {
            try
            {
                if (isChecked(pHost) == pWanted) return true;
            }
            catch (Exception iStale)
            {
                // re-rendered - read again on the next poll
            }
            if (System.currentTimeMillis() >= iEnd) return false;
            pause(300);
        }
    }

    // ***************************************************************************************************************************************************************************************
    // Method        : clearAndEnterDate
    // Description   : Clears and types a date into an Angular Material datepicker input that is disabled by default.
    //                 Same sequence as Selenium: remove disabled, scroll, focus, Ctrl+A, Delete, clear with input/change
    //                 events, type the date, Tab, read the value back; when it is empty, set it with JavaScript and Tab.
    // Parameters    : pInput (Locator) - datepicker input | pDate (String) - DD/MM/YYYY | pLabel (String) - for the log
    // Author        : Aniket Pathare | aniket.pathare@government.ie
    // Date Created  : 03-06-2026 | Updated: 22-09-2026 (Playwright)
    // ***************************************************************************************************************************************************************************************
    private static void clearAndEnterDate(Locator pInput, String pDate, String pLabel)
    {
        try
        {
            pInput.evaluate("el => { el.removeAttribute('disabled'); el.scrollIntoView({block:'center'}); el.focus(); }");

            pInput.press("ControlOrMeta+A");
            pInput.press("Delete");

            pInput.evaluate("el => { el.value = '';"
                    + " el.dispatchEvent(new Event('input',  {bubbles:true}));"
                    + " el.dispatchEvent(new Event('change', {bubbles:true})); }");

            pInput.pressSequentially(pDate);
            pInput.press("Tab");

            String iActual = pInput.inputValue();
            if (iActual == null || iActual.trim().isEmpty())
            {
                log.warning("[TC13] " + pLabel + " - value empty, retrying via JS value set.");
                UiHelpers.setValueByJs(pInput, pDate);
                pInput.press("Tab");
                iActual = pInput.inputValue();
            }

            if (iActual != null && iActual.trim().equals(pDate.trim()))
            {
                log.info("[TC13] " + pLabel + " set and verified: " + iActual);
            }
            else
            {
                log.warning("[TC13] " + pLabel + " - expected '" + pDate + "' but found '" + iActual + "' - proceeding.");
            }
        }
        catch (Exception e)
        {
            log.warning("[TC13] " + pLabel + " - clearAndEnterDate failed: " + e.getMessage());
        }
    }
}
